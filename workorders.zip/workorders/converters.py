"""
Custom URL path converters for workorders app
"""

class OrderNumberConverter:
    """
    Matches order numbers:
    - Contains letters: WO-001, ABC123
    - Contains hyphens: 2024-1009
    - Long numeric strings (6+ digits): 20241009, 202412
    
    Will NOT match short integers (1-5 digits): 1, 8, 123, 12345
    These will be handled by <int:pk> converter
    """
    # Match either:
    # - Strings with letters/hyphens: [A-Z-]
    # - OR numeric strings 6+ digits long: \d{6,}
    regex = r'(?:[A-Z0-9]*[A-Z-][A-Z0-9]*|\d{6,})'
    
    def to_python(self, value):
        return str(value)
    
    def to_url(self, value):
        return str(value)
