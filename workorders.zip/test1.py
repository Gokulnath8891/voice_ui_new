import streamlit as st
import azure.cognitiveservices.speech as speechsdk
import threading
import time

st.set_page_config(page_title="Azure Wake Word + STT", layout="centered")

# -------------------------
# Globals
# -------------------------
WAKEWORD = "hey buddy"
wake_event = threading.Event()
stop_event = threading.Event()

YOUR_AZURE_KEY = "1QD2Whn5LX4JPSORsLv7OP2zus76eJ86cLstg7zOLCHc3sVrqFYAJQQJ99BEACHYHv6XJ3w3AAAYACOGypYi"
YOUR_REGION = "eastus2"
# -------------------------
# Azure STT continuous loop
# -------------------------
def azure_continuous_stt():
    speech_config = speechsdk.SpeechConfig(
        subscription="YOUR_AZURE_KEY",
        region="YOUR_REGION"
    )
    audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)

    # Continuous speech recognizer
    recognizer = speechsdk.SpeechRecognizer(
        speech_config=speech_config,
        audio_config=audio_config
    )

    def recognized(evt: speechsdk.SpeechRecognitionEventArgs):
        text = evt.result.text.lower()
        print("Heard:", text)
        if WAKEWORD in text:
            wake_event.set()

    recognizer.recognized.connect(recognized)
    recognizer.start_continuous_recognition()

    # Keep thread alive
    while not stop_event.is_set():
        time.sleep(0.1)

    recognizer.stop_continuous_recognition()


# -------------------------
# Start listener once
# -------------------------
if "listener_started" not in st.session_state:
    thread = threading.Thread(target=azure_continuous_stt, daemon=True)
    thread.start()
    st.session_state.listener_started = True


# -------------------------
# UI
# -------------------------
st.title("🎤 Azure Wake-Word Detection (No Vosk)")

status = st.empty()
result_box = st.empty()

status.info("Listening… Say **'hey buddy'**")

if wake_event.is_set():
    wake_event.clear()
    status.success("✅ Wake word detected!")

    # Now listen for the user’s actual query
    speech_config = speechsdk.SpeechConfig(
        subscription="YOUR_AZURE_KEY",
        region="YOUR_REGION"
    )
    audio_config = speechsdk.AudioConfig(use_default_microphone=True)
    recognizer = speechsdk.SpeechRecognizer(
        speech_config=speech_config,
        audio_config=audio_config
    )

    status.info("🎙️ Speak your question…")

    user_query = recognizer.recognize_once_async().get()

    if user_query.reason == speechsdk.ResultReason.RecognizedSpeech:
        text = user_query.text
        result_box.success(f"🗣️ You said: **{text}**")
    else:
        result_box.error("❌ Could not understand your speech.")

    status.info("Say **'hey buddy'** again anytime.")