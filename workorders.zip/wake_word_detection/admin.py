"""
Django Admin Configuration for Wake Word Detection

Provides admin interface for managing wake word detection data.
"""

from django.contrib import admin
from django.utils.html import format_html
from django.db.models import Count, Avg
from .models import (
    WakeWordSession,
    WakeWordDetectionEvent,
    WakeWordCommand,
    WakeWordSettings,
    WakeWordAnalytics
)


@admin.register(WakeWordSession)
class WakeWordSessionAdmin(admin.ModelAdmin):
    list_display = [
        'session_id',
        'user',
        'wake_word_phrase',
        'is_active',
        'started_at',
        'detection_count',
        'success_rate_display',
        'duration_display'
    ]
    list_filter = [
        'is_active',
        'wake_word_phrase',
        'started_at',
        'language'
    ]
    search_fields = [
        'session_id',
        'user__username',
        'wake_word_phrase',
        'client_ip'
    ]
    readonly_fields = [
        'id',
        'session_id',
        'started_at',
        'ended_at',
        'duration_display',
        'success_rate_display'
    ]
    fieldsets = (
        ('Session Info', {
            'fields': ('id', 'session_id', 'user', 'is_active')
        }),
        ('Configuration', {
            'fields': ('wake_word_phrase', 'confidence_threshold', 'language')
        }),
        ('Timing', {
            'fields': ('started_at', 'ended_at', 'duration_display')
        }),
        ('Statistics', {
            'fields': ('detection_count', 'successful_commands', 'failed_commands', 'success_rate_display')
        }),
        ('Technical Details', {
            'fields': ('azure_region', 'client_ip', 'user_agent'),
            'classes': ('collapse',)
        })
    )
    
    def success_rate_display(self, obj):
        rate = obj.success_rate
        if rate >= 80:
            color = 'green'
        elif rate >= 60:
            color = 'orange'
        else:
            color = 'red'
        return format_html(
            '<span style="color: {};">{:.1f}%</span>',
            color,
            rate
        )
    success_rate_display.short_description = 'Success Rate'
    
    def duration_display(self, obj):
        duration = obj.duration
        total_seconds = int(duration.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
    duration_display.short_description = 'Duration'


@admin.register(WakeWordDetectionEvent)
class WakeWordDetectionEventAdmin(admin.ModelAdmin):
    list_display = [
        'timestamp',
        'session_short',
        'wake_word_detected',
        'command_text_short',
        'confidence_score',
        'processing_successful',
        'processing_time_ms'
    ]
    list_filter = [
        'wake_word_detected',
        'processing_successful',
        'was_processed',
        'timestamp',
        'session__wake_word_phrase'
    ]
    search_fields = [
        'full_text',
        'command_text',
        'session__session_id'
    ]
    readonly_fields = [
        'id',
        'timestamp',
        'session',
        'raw_azure_result'
    ]
    fieldsets = (
        ('Detection Info', {
            'fields': ('id', 'session', 'timestamp', 'wake_word_detected')
        }),
        ('Speech Content', {
            'fields': ('full_text', 'command_text', 'confidence_score')
        }),
        ('Processing', {
            'fields': ('processing_time_ms', 'was_processed', 'processing_successful', 'error_message')
        }),
        ('Response', {
            'fields': ('response_chunks_count', 'response_summary', 'tts_generated')
        }),
        ('Metadata', {
            'fields': ('raw_azure_result', 'custom_metadata'),
            'classes': ('collapse',)
        })
    )
    
    def session_short(self, obj):
        return obj.session.session_id[:8] + '...'
    session_short.short_description = 'Session'
    
    def command_text_short(self, obj):
        if obj.command_text:
            return obj.command_text[:50] + ('...' if len(obj.command_text) > 50 else '')
        return '-'
    command_text_short.short_description = 'Command'


@admin.register(WakeWordCommand)
class WakeWordCommandAdmin(admin.ModelAdmin):
    list_display = [
        'created_at',
        'command_text_short',
        'status',
        'command_category',
        'ai_summary_generated',
        'tts_generated',
        'total_processing_time_ms'
    ]
    list_filter = [
        'status',
        'command_category',
        'ai_summary_generated',
        'tts_generated',
        'vector_search_performed',
        'created_at'
    ]
    search_fields = [
        'command_text',
        'normalized_command',
        'summary_text'
    ]
    readonly_fields = [
        'id',
        'detection_event',
        'created_at'
    ]
    fieldsets = (
        ('Command Info', {
            'fields': ('id', 'detection_event', 'created_at', 'status')
        }),
        ('Command Processing', {
            'fields': ('command_text', 'normalized_command', 'command_category')
        }),
        ('Vector Search', {
            'fields': ('vector_search_performed', 'search_query', 'search_results_count', 'highest_similarity_score')
        }),
        ('AI Processing', {
            'fields': ('ai_summary_generated', 'summary_text', 'summary_confidence')
        }),
        ('Audio Output', {
            'fields': ('tts_generated', 'audio_file_path', 'audio_duration_seconds')
        }),
        ('Performance Metrics', {
            'fields': ('total_processing_time_ms', 'search_time_ms', 'ai_processing_time_ms', 'tts_time_ms'),
            'classes': ('collapse',)
        })
    )
    
    def command_text_short(self, obj):
        return obj.command_text[:50] + ('...' if len(obj.command_text) > 50 else '')
    command_text_short.short_description = 'Command'


@admin.register(WakeWordSettings)
class WakeWordSettingsAdmin(admin.ModelAdmin):
    list_display = [
        'user',
        'wake_word_phrase',
        'confidence_threshold',
        'language',
        'is_active',
        'enable_voice_assistant',
        'updated_at'
    ]
    list_filter = [
        'is_active',
        'wake_word_phrase',
        'language',
        'enable_voice_assistant',
        'enable_tts_response',
        'noise_suppression'
    ]
    search_fields = [
        'user__username',
        'wake_word_phrase'
    ]
    readonly_fields = [
        'id',
        'created_at',
        'updated_at'
    ]
    fieldsets = (
        ('User & Status', {
            'fields': ('user', 'is_active')
        }),
        ('Wake Word Configuration', {
            'fields': ('wake_word_phrase', 'confidence_threshold', 'language')
        }),
        ('Audio Settings', {
            'fields': ('microphone_sensitivity', 'noise_suppression', 'auto_gain_control')
        }),
        ('Processing Settings', {
            'fields': ('max_command_length_seconds', 'processing_timeout_seconds', 'enable_continuous_listening')
        }),
        ('Integration Settings', {
            'fields': ('enable_voice_assistant', 'enable_tts_response', 'default_collection_name')
        }),
        ('Performance Settings', {
            'fields': ('max_concurrent_sessions', 'session_timeout_minutes', 'cleanup_old_data_days'),
            'classes': ('collapse',)
        }),
        ('Notification Settings', {
            'fields': ('enable_detection_logging', 'enable_error_notifications', 'webhook_url'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )


@admin.register(WakeWordAnalytics)
class WakeWordAnalyticsAdmin(admin.ModelAdmin):
    list_display = [
        'date',
        'hour_display',
        'total_detections',
        'successful_commands',
        'failed_commands',
        'success_rate_display',
        'avg_confidence_score',
        'unique_users'
    ]
    list_filter = [
        'date',
        'hour'
    ]
    search_fields = [
        'date'
    ]
    readonly_fields = [
        'id',
        'created_at',
        'updated_at',
        'success_rate_display'
    ]
    fieldsets = (
        ('Time Period', {
            'fields': ('date', 'hour')
        }),
        ('Detection Metrics', {
            'fields': ('total_detections', 'successful_commands', 'failed_commands', 'false_positives', 'success_rate_display')
        }),
        ('Performance Metrics', {
            'fields': ('avg_confidence_score', 'avg_processing_time_ms', 'avg_response_time_ms')
        }),
        ('Command Analytics', {
            'fields': ('top_commands', 'command_categories'),
            'classes': ('collapse',)
        }),
        ('System Metrics', {
            'fields': ('active_sessions', 'total_session_time_seconds', 'error_count'),
            'classes': ('collapse',)
        }),
        ('User Metrics', {
            'fields': ('unique_users', 'returning_users'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    
    def hour_display(self, obj):
        if obj.hour is not None:
            return f"{obj.hour:02d}:00"
        return "All Day"
    hour_display.short_description = 'Hour'
    
    def success_rate_display(self, obj):
        total = obj.successful_commands + obj.failed_commands
        if total == 0:
            return "0%"
        rate = (obj.successful_commands / total) * 100
        
        if rate >= 80:
            color = 'green'
        elif rate >= 60:
            color = 'orange'
        else:
            color = 'red'
        return format_html(
            '<span style="color: {};">{:.1f}%</span>',
            color,
            rate
        )
    success_rate_display.short_description = 'Success Rate'


# Custom admin views for analytics
class WakeWordAnalyticsInline(admin.TabularInline):
    model = WakeWordAnalytics
    extra = 0
    readonly_fields = ['date', 'hour', 'total_detections', 'successful_commands']