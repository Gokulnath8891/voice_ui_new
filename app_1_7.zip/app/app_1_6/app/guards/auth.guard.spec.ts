import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { authGuard, loginGuard } from './auth.guard';
import { AuthService } from '../services/auth.service';

describe('AuthGuard', () => {
  let authService: jasmine.SpyObj<AuthService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const authSpy = jasmine.createSpyObj('AuthService', ['isLoggedIn']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: authSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });

    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  describe('authGuard', () => {
    it('should allow access when user is logged in', () => {
      Object.defineProperty(authService, 'isLoggedIn', { get: () => true });
      
      const result = TestBed.runInInjectionContext(() => authGuard());
      
      expect(result).toBeTruthy();
      expect(router.navigate).not.toHaveBeenCalled();
    });

    it('should redirect to login when user is not logged in', () => {
      Object.defineProperty(authService, 'isLoggedIn', { get: () => false });
      
      const result = TestBed.runInInjectionContext(() => authGuard());
      
      expect(result).toBeFalsy();
      expect(router.navigate).toHaveBeenCalledWith(['/login']);
    });
  });

  describe('loginGuard', () => {
    it('should redirect to quality-search when user is logged in', () => {
      Object.defineProperty(authService, 'isLoggedIn', { get: () => true });
      
      const result = TestBed.runInInjectionContext(() => loginGuard());
      
      expect(result).toBeFalsy();
      expect(router.navigate).toHaveBeenCalledWith(['/quality-search']);
    });

    it('should allow access to login when user is not logged in', () => {
      Object.defineProperty(authService, 'isLoggedIn', { get: () => false });
      
      const result = TestBed.runInInjectionContext(() => loginGuard());
      
      expect(result).toBeTruthy();
      expect(router.navigate).not.toHaveBeenCalled();
    });
  });
});
