import {Component, OnInit, OnDestroy, ChangeDetectorRef} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ButtonModule} from 'primeng/button';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {AvatarModule} from 'primeng/avatar';
import {FormsModule} from '@angular/forms';
import {TooltipModule} from 'primeng/tooltip';
import {VoiceApiService} from './voice-api.service';
import {WakeupVoiceService} from './wakeup-voice.service';
import {ChatCommunicationService} from '../services/chat-communication.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-chat-widget',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    InputTextareaModule,
    AvatarModule,
    FormsModule,
    TooltipModule,
  ],
  templateUrl: './chat-widget.component.html',
  styleUrls: ['./chat-widget.component.scss'],
})
export class ChatWidgetComponent implements OnInit, OnDestroy {
  isChatOpen = false;
  userInput = '';
  isRecording = false;
  isListening = false;
  isProcessing = false;
  private readonly mediaRecorder: MediaRecorder | null = null;
  private readonly audioChunks: Blob[] = [];
  private recognition: any = null;
  private autoOpenTimer: any = null;
  private autoCloseTimer: any = null;
  private readonly AUTO_CLOSE_DELAY = 30000; // 30 seconds
  private messageSubscription: Subscription | null = null;
  messages: {
    text: string; 
    sender: 'user' | 'bot'; 
    avatar: string; 
    isProcessing?: boolean;
    isVoice?: boolean;
  }[] = [
    {text: 'Hello! How can I help you today?', sender: 'bot', avatar: '🤖'},
  ];

  constructor(
    private readonly voiceApiService: VoiceApiService,
    private readonly voiceWakeup: WakeupVoiceService,
    private readonly chatService: ChatCommunicationService,
    private readonly cdr: ChangeDetectorRef
  ) {
    this.initializeMediaRecorder();
    this.initializeSpeechRecognition();
  }

  ngOnInit() {
    // Subscribe to incoming messages from other components
    this.messageSubscription = this.chatService.message$.subscribe(async (message) => {
      if (message.autoOpen && !this.isChatOpen) {
        this.toggleChat();
      }
      
      // Add bot message
      this.messages.push({
        text: message.text,
        sender: 'bot',
        avatar: '🤖',
      });
      
      this.scrollToBottom();
      
      // Play voice if requested
      if (message.isVoice) {
        try {
          await this.voiceApiService.speakText(message.text);
        } catch (error) {
          console.error('Error with text-to-speech:', error);
        }
      }
    });
    
    // Auto-open chat widget after 10 seconds
    // this.autoOpenTimer = setTimeout(() => {
    //   if (!this.isChatOpen) {
    //     this.toggleChat();
    //   }
    // }, 10000); // 10 seconds
    // this.voiceWakeup.startListening(() => {
    //   console.log('Wake word detected!');
    //   this.voiceWakeup.stopListening();

    //   if (!this.isChatOpen) {
    //     this.toggleChat();
    //     // Add a small delay to prevent a race condition for the microphone
    //     setTimeout(() => {
    //       this.toggleVoiceInput();
    //     }, 300); // 300ms is usually a safe delay
    //   }
    // });
    this.startWakeWordListener();
  }

  private async initializeMediaRecorder() {
    // We're now using speech recognition instead of MediaRecorder
    // This method is kept for compatibility but doesn't initialize MediaRecorder
    console.log('Using Speech Recognition API instead of MediaRecorder');
  }

  private initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition =
        (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      this.recognition = new SpeechRecognition();

      this.recognition.continuous = false;
      this.recognition.interimResults = true; // Enable interim results to see partial speech
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 1;

      this.recognition.onstart = () => {
        this.isRecording = true;
        console.log('[ChatWidget] 🎤 Voice recognition started - speak now...');
      };

      this.recognition.onresult = async (event: any) => {
        // Get the final result (not interim)
        let finalTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          if (result.isFinal) {
            finalTranscript += result[0].transcript;
          }
        }
        
        // Only process if we have a final transcript
        if (finalTranscript.trim()) {
          console.log('[ChatWidget] ✓ Final transcript received:', finalTranscript);
          this.isRecording = false;
          
          // Add user message with voice indicator
          this.messages.push({
            text: finalTranscript,
            sender: 'user',
            avatar: '🧑',
            isVoice: true
          });

          this.cdr.detectChanges(); // Force immediate UI update
          this.scrollToBottom();

          // Send transcribed text to API and get voice response
          await this.sendTranscriptToAPI(finalTranscript, true);
        }
      };

      // this.recognition.onerror = (event: any) => {
      //   console.error('Speech recognition error:', event.error);
      //   this.isListening = false;
      //   this.isRecording = false;
      this.recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        this.isRecording = false;
        
        // Handle specific errors
        if (event.error === 'network') {
          this.showErrorMessage('Network error. Please check your internet connection and try again.');
          console.log('[ChatWidget] Network error - speech recognition requires internet connection');
        } else if (event.error === 'not-allowed') {
          this.showErrorMessage('Microphone access denied. Please enable microphone permissions.');
        } else if (event.error === 'audio-capture') {
          this.showErrorMessage('Microphone not available. Please check your audio devices.');
        } else {
          this.showErrorMessage('Voice recognition failed. Please try again.');
        }
      };

      // this.recognition.onend = () => {
      //   this.isListening = false;
      //   this.isRecording = false;
      // };
      this.recognition.onend = () => {
        this.isRecording = false;
      };
    }
  }

  private async sendVoiceToAPI(audioBlob: Blob): Promise<void> {
    // This method is no longer used since we're using browser speech recognition
    // The voice input is now handled through the speech recognition API directly
    console.warn('sendVoiceToAPI called but not used in speech recognition mode');
  }

  private async sendTranscriptToAPI(transcript: string, isVoiceInput: boolean = false): Promise<void> {
    try {
      // Reset auto-close timer on user interaction
      this.resetAutoCloseTimer();
      
      // Add processing indicator for bot response
      const botMessageIndex = this.messages.length;
      this.messages.push({
        text: '🤔 Thinking...',
        sender: 'bot',
        avatar: '🤖',
        isProcessing: true,
      });

      this.cdr.detectChanges(); // Force immediate UI update
      this.scrollToBottom();

      // Get response from chat API
      const botResponse = await this.voiceApiService.sendTextToAPI(transcript);

      // Update bot message with actual response and voice indicator
      this.messages[botMessageIndex] = {
        text: botResponse,
        sender: 'bot',
        avatar: '🤖',
        isVoice: isVoiceInput // Mark as voice if input was voice
      };

      this.cdr.detectChanges(); // Force immediate UI update
      this.scrollToBottom();

      // Speak the response using text-to-speech (only if input was voice)
      if (isVoiceInput) {
        try {
          await this.voiceApiService.speakText(botResponse);
        } catch (ttsError) {
          console.error('Error with text-to-speech:', ttsError);
        }
      }
      
      // Reset auto-close timer after bot responds
      this.resetAutoCloseTimer();

      this.startWakeWordListener();
    } catch (error) {
      console.error('Chat API error:', error);
      this.messages[this.messages.length - 1] = {
        text: 'Sorry, I encountered an error. Please try again.',
        sender: 'bot',
        avatar: '🤖',
      };
      this.cdr.detectChanges(); // Force immediate UI update
      this.scrollToBottom();

      this.startWakeWordListener();
    }
  }

  private showErrorMessage(message: string): void {
    this.messages.push({
      text: message,
      sender: 'bot',
      avatar: '🤖',
    });
    this.scrollToBottom();
  }

  get isSpeechSupported(): boolean {
    return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  }

  get isMediaRecorderSupported(): boolean {
    // We're not using MediaRecorder anymore, so return false
    return false;
  }

  startVoiceInput() {
    if (this.isProcessing) return;
    if (this.recognition && !this.isRecording) {
      // Reset auto-close timer when voice input starts
      this.resetAutoCloseTimer();
      this.isRecording = true;
      console.log('[ChatWidget] Starting voice recognition...');
      try {
        this.recognition.start();
      } catch (error) {
        console.error('[ChatWidget] Error starting recognition:', error);
        this.isRecording = false;
      }
    }
  }

  stopVoiceInput() {
    if (this.recognition && this.isRecording) {
      console.log('[ChatWidget] Stopping voice recognition...');
      this.isRecording = false;
      try {
        this.recognition.stop();
      } catch (error) {
        console.error('[ChatWidget] Error stopping recognition:', error);
      }
    }
  }
  // toggleVoiceInput() {
  //   if (this.isProcessing) return;

  //   if (this.isListening || this.isRecording) {
  //     this.stopVoiceInput();
  //   } else {
  //     this.startVoiceInput();
  //   }
  // }
  toggleVoiceInput() {
    if (this.isProcessing) return;
    if (this.isRecording) {
      this.stopVoiceInput();
    } else {
      this.startVoiceInput();
    }
  }

  toggleChat() {
    this.isChatOpen = !this.isChatOpen;

    if (this.autoOpenTimer) {
      clearTimeout(this.autoOpenTimer);
      this.autoOpenTimer = null;
    }

    if (this.isChatOpen) {
      setTimeout(() => this.scrollToBottom(), 100);
      this.resetAutoCloseTimer(); // Start auto-close timer when chat opens
    } else {
      this.clearAutoCloseTimer();
      this.startWakeWordListener();
    }
  }

  /**
   * Reset the auto-close timer - called when user interacts with chat
   */
  private resetAutoCloseTimer(): void {
    this.clearAutoCloseTimer();
    
    console.log('[ChatWidget] Starting auto-close timer (30 seconds)');
    this.autoCloseTimer = setTimeout(() => {
      if (this.isChatOpen && !this.isRecording && !this.isProcessing) {
        console.log('[ChatWidget] Auto-closing due to inactivity');
        this.isChatOpen = false;
        this.startWakeWordListener();
      }
    }, this.AUTO_CLOSE_DELAY);
  }

  /**
   * Clear the auto-close timer
   */
  private clearAutoCloseTimer(): void {
    if (this.autoCloseTimer) {
      clearTimeout(this.autoCloseTimer);
      this.autoCloseTimer = null;
    }
  }

  private startWakeWordListener(): void {
    console.log('Restarting wake word listener...');
    this.voiceWakeup.startListening(
      () => {
        // Wake word callback
        console.log('Wake word detected!');
        this.voiceWakeup.stopListening();

        if (!this.isChatOpen) {
          // Case 1: Chat is closed. Open it AND start voice input.
          console.log('[ChatWidget] Chat is closed. Opening and starting voice input...');
          this.toggleChat();
          setTimeout(() => this.toggleVoiceInput(), 300); // Keep delay for mic handover
        } else {
          // Case 2: Chat is already open. Just start the voice input.
          console.log('[ChatWidget] Chat is open. Starting voice input directly...');
          this.toggleVoiceInput();
        }
      },
      async (transcript: string) => {
        // Work order command callback
        console.log('[ChatWidget] Work order command detected:', transcript);
        this.voiceWakeup.stopListening();

        // Open chat if closed
        if (!this.isChatOpen) {
          this.toggleChat();
        }

        // Add user message with voice indicator
        this.messages.push({
          text: transcript,
          sender: 'user',
          avatar: '🧑',
          isVoice: true
        });

        this.scrollToBottom();

        // Send to API and get response (mark as voice input)
        await this.sendTranscriptToAPI(transcript, true);
      }
    );
  }

  minimizeChat() {
    this.isChatOpen = false;
  }

  handleEnterKey(event: KeyboardEvent) {
    if (!event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  adjustTextareaHeight(event: any) {
    const textarea = event.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  }

  getVoiceButtonClass(): string {
    let baseClass = 'p-button-rounded voice-btn';
    if (this.isRecording) {
      baseClass += ' recording-active';
    }
    return baseClass;
  }

  getVoiceTooltip(): string {
    if (this.isRecording) {
      return 'Stop recording';
    } else if (this.isProcessing) {
      return 'Processing...';
    } else {
      return 'Start voice input';
    }
  }

  sendQuickMessage(message: string) {
    this.userInput = message;
    this.sendMessage();
  }

  getCurrentTime(): string {
    return new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
  }

  private scrollToBottom() {
    setTimeout(() => {
      const messagesContainer = document.querySelector('.chat-messages');
      if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      }
    }, 50);
  }

  async sendMessage() {
    this.isRecording = false;

    if (!this.userInput.trim() || this.isProcessing) return;

    // Reset auto-close timer on user interaction
    this.resetAutoCloseTimer();

    const messageText = this.userInput.trim();
    this.userInput = '';

    // Add user message (text input, not voice)
    this.messages.push({
      text: messageText,
      sender: 'user',
      avatar: '🧑',
      isVoice: false
    });

    this.cdr.detectChanges(); // Force immediate UI update
    this.scrollToBottom();

    // Send to API and get response (not voice input)
    await this.sendTranscriptToAPI(messageText, false);
  }

  // ngOnDestroy() {
  //   // Clean up the auto-open timer when component is destroyed
  //   if (this.autoOpenTimer) {
  //     clearTimeout(this.autoOpenTimer);
  //     this.autoOpenTimer = null;
  //   }
  // }
  ngOnDestroy() {
    console.log('[ChatWidget] Component destroyed. Stopping wake word listener.');
    if (this.autoOpenTimer) {
      clearTimeout(this.autoOpenTimer);
    }
    if (this.autoCloseTimer) {
      clearTimeout(this.autoCloseTimer);
    }
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
    this.voiceWakeup.stopListening();
  }
}
