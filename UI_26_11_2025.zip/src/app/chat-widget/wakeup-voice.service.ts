import {Injectable, NgZone} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class WakeupVoiceService {
  private recognition: any;
  private isListening = false;
  private wakeWord = 'hey buddy'; // Removed comma for better matching
  private wakeupCallback: () => void = () => {
    console.log('[VoiceWakeup] Default wakeup callback');
  };
  private workOrderCallback: (transcript: string) => void = () => {
    console.log('[VoiceWakeup] Default work order callback');
  };

  constructor(private readonly zone: NgZone) {
    console.log('[VoiceWakeup] Service initialized');

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.error('[VoiceWakeup] SpeechRecognition is not supported in this browser.');
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.lang = 'en-US';
    this.recognition.interimResults = false;

    this.recognition.onstart = () => {
      console.log('[VoiceWakeup] Recognition started');
    };

    this.recognition.onerror = (event) => {
      console.error(`Speech recognition error: ${event.error}`);
      // event.message might not always be available or standard, but can be helpful for debugging
      if (event.message) {
        console.error(`Error message (non-standard but informative): ${event.message}`);
      }

      // Implement specific error handling logic based on event.error
      switch (
        event.error // Use event.error here
      ) {
        case 'no-speech':
          console.log(
            'No speech detected. The microphone might be off or the user is not speaking.',
          );
          // You might want to stop listening or give feedback to the user
          // this.stopListening(); // Example: Stop on no-speech if you want
          break;
        case 'audio-capture':
          console.log('Microphone not available or audio input device issues.');
          // Inform the user about microphone problems
          // this.stopListening(); // Example: Stop on critical audio issues
          break;
        case 'not-allowed':
          console.log('Microphone access denied by the user or browser policy.');
          // Guide the user on how to enable microphone permissions
          // this.stopListening(); // Stop as we can't proceed without permission
          break;
        case 'network':
          console.log('Network error occurred during speech recognition.');
          break;
        case 'aborted':
          console.log('Speech recognition was aborted.');
          break;
        case 'bad-grammar':
          console.log('Bad grammar error occurred during speech recognition.');
          break;
        case 'language-not-supported':
          console.log('The specified language is not supported.');
          break;
        case 'service-not-allowed':
          console.log('The speech recognition service is not allowed.');
          break;
        default:
          console.log(`An unknown speech recognition error occurred: ${event.error}`);
          break;
      }
    };
    this.recognition.onresult = (event: any) => {
      const transcript = event.results[event.resultIndex][0].transcript.trim().toLowerCase();
      console.log('[VoiceWakeup] Heard:', transcript);
      console.log('[VoiceWakeup] Looking for wake word:', this.wakeWord);
      
      // Check for wake word - more flexible matching (removes punctuation)
      const normalizedTranscript = transcript.replaceAll(/[,.!?]/g, '').trim();
      const normalizedWakeWord = this.wakeWord.replaceAll(/[,.!?]/g, '').trim();
      
      if (normalizedTranscript.includes(normalizedWakeWord)) {
        console.log('[VoiceWakeup] ✓ Wake word detected!');
        this.zone.run(() => this.wakeupCallback());
        return;
      }
      
      // Check for work order command patterns:
      // Pattern 1: "help me fix WO-20241009" or "help me to fix WO-20241009"
      // Pattern 2: "help me fix work order 20241009" or "help me to fix work order 20241009"
      // Updated patterns to capture full number including variations like "20 24 10 01"
      const workOrderPattern1 = /help\s+me\s+(?:to\s+)?fix\s+(?:wo[-\s]?)?(\d+(?:\s*\d+)*)/i;
      const workOrderPattern2 = /help\s+me\s+(?:to\s+)?fix\s+work\s+order\s+(\d+(?:\s*\d+)*)/i;
      
      let match = workOrderPattern2.exec(transcript); // Try "work order" pattern first
      let workOrderId = '';
      
      if (match) {
        // Remove spaces from the number (in case speech recognition separates digits)
        const numberPart = match[1].replaceAll(/\s+/g, '');
        workOrderId = `WO-${numberPart}`;
        console.log('[VoiceWakeup] ✓ Work order command detected (pattern 2):', workOrderId);
      } else {
        match = workOrderPattern1.exec(transcript);
        if (match) {
          // Remove spaces from the number
          const numberPart = match[1].replaceAll(/\s+/g, '');
          workOrderId = `WO-${numberPart}`;
          console.log('[VoiceWakeup] ✓ Work order command detected (pattern 1):', workOrderId);
        }
      }
      
      if (workOrderId) {
        console.log('[VoiceWakeup] 📋 Final work order ID:', workOrderId);
        this.zone.run(() => this.workOrderCallback(`help me fix ${workOrderId}`));
      }
    };

    this.recognition.onend = () => {
      console.log('[VoiceWakeup] Recognition ended');
      if (this.isListening) {
        setTimeout(() => this.recognition.start(), 500); // Safe restart with delay
      }
    };

    this.recognition.onnomatch = () => {
      console.warn('[VoiceWakeup] No match for speech input');
    };
  }

  /**
   * Start wake word detection
   * @param callback Function to call when wake word is detected
   * @param workOrderCallback Function to call when work order command is detected
   */
  startListening(callback: () => void, workOrderCallback?: (transcript: string) => void): void {
    if (!this.recognition) {
      console.error('[VoiceWakeup] Cannot start listening - recognition not initialized');
      return;
    }

    if (this.isListening) {
      console.warn('[VoiceWakeup] startListening called, but recognition is already active.');
      return;
    }

    console.log('[VoiceWakeup] 🎤 Starting wake word listener...');
    console.log('[VoiceWakeup] Wake word:', this.wakeWord);
    this.wakeupCallback = callback;
    if (workOrderCallback) {
      this.workOrderCallback = workOrderCallback;
    }
    this.isListening = true;
    
    try {
      this.recognition.start();
      console.log('[VoiceWakeup] ✓ Recognition started successfully');
    } catch (error) {
      console.error('[VoiceWakeup] ✗ Error starting recognition:', error);
      this.isListening = false;
    }
  }

  /**
   * Stop wake word detection
   */
  stopListening(): void {
    if (!this.recognition) return;

    console.log('[VoiceWakeup] Listening stopped');
    this.isListening = false;
    this.recognition.stop();
  }
}
