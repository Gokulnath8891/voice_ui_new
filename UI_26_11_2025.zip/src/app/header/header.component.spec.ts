import {ComponentFixture, TestBed} from '@angular/core/testing';
import {Router} from '@angular/router';
import {HeaderComponent} from './header.component';
import {ActivatedRoute} from '@angular/router';
import {ActivatedRouteStub} from '../../testing/router-stubs';
import {AuthService} from '../services/auth.service';
import {ButtonModule} from 'primeng/button';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let compiled;
  let mockAuthService: jasmine.SpyObj<AuthService>;
  let mockRouter: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    const authSpy = jasmine.createSpyObj('AuthService', ['logout'], {
      isLoggedIn: false,
      currentUserValue: null
    });
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      imports: [HeaderComponent, ButtonModule],
      providers: [
        {provide: ActivatedRoute, useClass: ActivatedRouteStub},
        {provide: AuthService, useValue: authSpy},
        {provide: Router, useValue: routerSpy}
      ],
    }).compileComponents();

    mockAuthService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    mockRouter = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call logout and navigate when logout is clicked', () => {
    component.logout();
    expect(mockAuthService.logout).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
  });

  describe('Template Tests', () => {
    it('should have app logo set', () => {
      const appLogoDiv = compiled.querySelector('#app-icon img');
      expect(appLogoDiv.alt).toEqual('LatentView Logo');
    });

    it('should show user actions when logged in', () => {
      Object.defineProperty(mockAuthService, 'isLoggedIn', { get: () => true, configurable: true });
      Object.defineProperty(mockAuthService, 'currentUserValue', { get: () => ({ username: 'testuser', token: 'token' }), configurable: true });
      
      fixture.detectChanges();
      
      const userActions = compiled.querySelector('.user-actions');
      expect(userActions).toBeTruthy();
    });

    it('should not show user actions when not logged in', () => {
      Object.defineProperty(mockAuthService, 'isLoggedIn', { get: () => false, configurable: true });
      
      fixture.detectChanges();
      
      const userActions = compiled.querySelector('.user-actions');
      expect(userActions).toBeFalsy();
    });
  });
});
