import {ComponentFixture, TestBed} from '@angular/core/testing';

import {AppComponent} from './app.component';
import {
  ActivatedRouteStub,
  RouterLinkStubDirective,
  RouterOutletStubDirective,
  RouterStub,
} from '../testing/router-stubs';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {By} from '@angular/platform-browser';
import {ActivatedRoute, NavigationEnd, Router} from '@angular/router';
import {of} from 'rxjs';
import {MessageService} from 'primeng/api';
import {MockMessageService} from '../testing/primeng-stubs';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>, appComponent, compiled;
  const routerStub = new RouterStub();
  const activatedRouteStub = new ActivatedRouteStub();

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AppComponent],
      declarations: [
        //for routing we have to use some router stubs. these aren't given by angular.
        //but, the /testing/router-stubs.ts file, from google, provides the necessary mocks
        RouterLinkStubDirective,
        RouterOutletStubDirective,
      ],
      providers: [
        {provide: Router, useValue: routerStub},
        {provide: ActivatedRoute, useValue: activatedRouteStub},
        {provide: MessageService, useClass: MockMessageService},
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    appComponent = fixture.debugElement.componentInstance;
    compiled = fixture.debugElement.nativeElement;
  });

  describe('tests:', () => {
    it('should create the app', () => {
      expect(appComponent).toBeTruthy();
    });

    describe('ngOnInit(): ', () => {
      it('should leverage the router events to dynamically construct the skip url and check login page', () => {
        spyOn(appComponent, 'setSkipLinkUrl');
        spyOn(appComponent, 'checkIfLoginPage');
        routerStub.events = of(new NavigationEnd(2, 'test', 'test-after-redirect'));
        appComponent.ngOnInit();
        expect(appComponent.setSkipLinkUrl).toHaveBeenCalledWith('test-after-redirect');
        expect(appComponent.checkIfLoginPage).toHaveBeenCalledWith('test-after-redirect');
      });
    });

    describe('setSkipLinkUrl(): ', () => {
      it('should use the passed in url to appropriately set the skip url', () => {
        appComponent.skipToMain = 'someurl';
        appComponent.setSkipLinkUrl('test#app-content');
        expect(appComponent.skipToMain).toEqual('someurl');
        appComponent.setSkipLinkUrl('test');
        expect(appComponent.skipToMain).toEqual('test#app-content');
      });
    });

    describe('checkIfLoginPage(): ', () => {
      it('should correctly identify login page', () => {
        appComponent.checkIfLoginPage('/login');
        expect(appComponent.isLoginPage).toBeTruthy();
        
        appComponent.checkIfLoginPage('/login?returnUrl=test');
        expect(appComponent.isLoginPage).toBeTruthy();
        
        appComponent.checkIfLoginPage('/quality-search');
        expect(appComponent.isLoginPage).toBeFalsy();
      });
    });

    describe('template tests: ', () => {
      it('should include a header, main content section and footer when not on login page', () => {
        appComponent.isLoginPage = false;
        fixture.detectChanges();
        expect(compiled.querySelector('#app-header').tagName).toEqual('HEADER');
        expect(compiled.querySelector('#app-content').tagName).toEqual('MAIN');
        expect(compiled.querySelector('#footer').tagName).toEqual('FOOTER');
      });

      it('should hide header and footer when on login page', () => {
        appComponent.isLoginPage = true;
        fixture.detectChanges();
        expect(compiled.querySelector('#app-header')).toBeNull();
        expect(compiled.querySelector('#app-content').tagName).toEqual('MAIN');
        expect(compiled.querySelector('#footer')).toBeNull();
      });

      it('should add login-main class to main element when on login page', () => {
        appComponent.isLoginPage = true;
        fixture.detectChanges();
        expect(compiled.querySelector('#app-content').classList.contains('login-main')).toBeTruthy();
        
        appComponent.isLoginPage = false;
        fixture.detectChanges();
        expect(compiled.querySelector('#app-content').classList.contains('login-main')).toBeFalsy();
      });

      it('should have the toast component included and properly configured', () => {
        expect(fixture.debugElement.query(By.css('p-toast')).nativeElement.tagName).toEqual(
          'P-TOAST',
        );
      });

      it('should include the nav component in the header when not on login page', () => {
        appComponent.isLoginPage = false;
        fixture.detectChanges();
        //equiv to fixture.debugElement.query(By.css('#app-header app-nav'))
        expect(compiled.querySelector('#app-header app-nav')).toBeDefined();
      });

      it('should include a skip to main link before other items in the header when not on login page', () => {
        appComponent.isLoginPage = false;
        spyOn(appComponent, 'setSkipLinkUrl').and.callThrough();
        routerStub.events = of(new NavigationEnd(2, 'test', 'testurl-after-redirect'));

        appComponent.ngOnInit();

        fixture.detectChanges();
        expect(appComponent.setSkipLinkUrl).toHaveBeenCalledWith('testurl-after-redirect');
        expect(compiled.querySelector('#app-header').firstChild.tagName).toEqual('A');
        expect(compiled.querySelector('#app-header .skip-link').textContent).toEqual(
          'Skip to Content',
        );
        expect(
          compiled
            .querySelector('#app-header .skip-link')
            .href.endsWith('/testurl-after-redirect#app-content'),
        ).toEqual(true);
      });
    });
  });
});
