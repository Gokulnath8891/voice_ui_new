import { Injectable } from '@angular/core';
import * as SpeechSDK from 'microsoft-cognitiveservices-speech-sdk';
import { environment } from '../../environments/environment';
import { Subject } from 'rxjs';

export interface SpeechRecognitionResult {
  transcript: string;
  confidence: number;
  isFinal: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AzureSpeechService {
  private recognizer: SpeechSDK.SpeechRecognizer | null = null;
  private speechConfig: SpeechSDK.SpeechConfig | null = null;
  private isRecognizing = false;

  // Observables for speech events
  public onResult$ = new Subject<SpeechRecognitionResult>();
  public onError$ = new Subject<string>();
  public onEnd$ = new Subject<void>();

  constructor() {
    this.initializeSpeechConfig();
  }

  private initializeSpeechConfig() {
    try {
      this.speechConfig = SpeechSDK.SpeechConfig.fromSubscription(
        environment.azureSpeech.subscriptionKey,
        environment.azureSpeech.region
      );
      
      this.speechConfig.speechRecognitionLanguage = environment.azureSpeech.language;
      
      // Enable detailed results
      this.speechConfig.outputFormat = SpeechSDK.OutputFormat.Detailed;
      
      console.log('[AzureSpeech] ✅ Speech configuration initialized');
    } catch (error) {
      console.error('[AzureSpeech] ❌ Failed to initialize speech config:', error);
    }
  }

  /**
   * Start continuous speech recognition
   */
  startContinuousRecognition(): boolean {
    if (this.isRecognizing) {
      console.warn('[AzureSpeech] ⚠️ Recognition already in progress');
      return false;
    }

    if (!this.speechConfig) {
      console.error('[AzureSpeech] ❌ Speech configuration not initialized');
      this.onError$.next('Speech configuration not initialized');
      return false;
    }

    try {
      // Create audio config from default microphone
      const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
      
      // Create speech recognizer
      this.recognizer = new SpeechSDK.SpeechRecognizer(this.speechConfig, audioConfig);

      // Handle recognizing event (interim results)
      this.recognizer.recognizing = (s, e) => {
        if (e.result.reason === SpeechSDK.ResultReason.RecognizingSpeech) {
          console.log('[AzureSpeech] 🎤 Recognizing:', e.result.text);
          this.onResult$.next({
            transcript: e.result.text,
            confidence: 0,
            isFinal: false
          });
        }
      };

      // Handle recognized event (final results)
      this.recognizer.recognized = (s, e) => {
        if (e.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
          console.log('[AzureSpeech] ✅ Recognized:', e.result.text);
          
          // Extract confidence from detailed results
          const confidence = this.extractConfidence(e.result);
          
          this.onResult$.next({
            transcript: e.result.text,
            confidence: confidence,
            isFinal: true
          });
        } else if (e.result.reason === SpeechSDK.ResultReason.NoMatch) {
          console.warn('[AzureSpeech] ⚠️ No speech recognized');
        }
      };

      // Handle cancellation
      this.recognizer.canceled = (s, e) => {
        console.error('[AzureSpeech] ❌ Recognition canceled:', e.errorDetails);
        
        if (e.reason === SpeechSDK.CancellationReason.Error) {
          this.onError$.next(e.errorDetails);
        }
        
        this.isRecognizing = false;
        this.onEnd$.next();
      };

      // Handle session stopped
      this.recognizer.sessionStopped = (s, e) => {
        console.log('[AzureSpeech] 🛑 Session stopped');
        this.isRecognizing = false;
        this.onEnd$.next();
      };

      // Start continuous recognition
      this.recognizer.startContinuousRecognitionAsync(
        () => {
          console.log('[AzureSpeech] 🚀 Continuous recognition started');
          this.isRecognizing = true;
        },
        (error) => {
          console.error('[AzureSpeech] ❌ Failed to start recognition:', error);
          this.onError$.next(error);
          this.isRecognizing = false;
        }
      );

      return true;
    } catch (error) {
      console.error('[AzureSpeech] ❌ Error starting recognition:', error);
      this.onError$.next(error as string);
      return false;
    }
  }

  /**
   * Stop continuous speech recognition
   */
  stopContinuousRecognition(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.recognizer || !this.isRecognizing) {
        console.warn('[AzureSpeech] ⚠️ No active recognition to stop');
        resolve();
        return;
      }

      this.recognizer.stopContinuousRecognitionAsync(
        () => {
          console.log('[AzureSpeech] ✅ Recognition stopped');
          this.isRecognizing = false;
          this.cleanupRecognizer();
          resolve();
        },
        (error) => {
          console.error('[AzureSpeech] ❌ Error stopping recognition:', error);
          this.isRecognizing = false;
          this.cleanupRecognizer();
          reject(error);
        }
      );
    });
  }

  /**
   * Start single-shot recognition (recognizes one utterance)
   */
  recognizeOnce(): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.speechConfig) {
        reject('Speech configuration not initialized');
        return;
      }

      try {
        const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
        const recognizer = new SpeechSDK.SpeechRecognizer(this.speechConfig, audioConfig);

        recognizer.recognizeOnceAsync(
          (result) => {
            if (result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
              console.log('[AzureSpeech] ✅ Single recognition result:', result.text);
              recognizer.close();
              resolve(result.text);
            } else {
              console.warn('[AzureSpeech] ⚠️ Recognition failed:', result.reason);
              recognizer.close();
              reject('No speech recognized');
            }
          },
          (error) => {
            console.error('[AzureSpeech] ❌ Recognition error:', error);
            recognizer.close();
            reject(error);
          }
        );
      } catch (error) {
        console.error('[AzureSpeech] ❌ Error in recognizeOnce:', error);
        reject(error);
      }
    });
  }

  /**
   * Check if recognition is currently active
   */
  isActive(): boolean {
    return this.isRecognizing;
  }

  /**
   * Extract confidence score from detailed results
   */
  private extractConfidence(result: SpeechSDK.SpeechRecognitionResult): number {
    try {
      // Parse detailed JSON results if available
      if (result.properties) {
        const jsonResult = result.properties.getProperty(
          SpeechSDK.PropertyId.SpeechServiceResponse_JsonResult
        );
        
        if (jsonResult) {
          const parsed = JSON.parse(jsonResult);
          if (parsed.NBest && parsed.NBest.length > 0) {
            return parsed.NBest[0].Confidence || 0;
          }
        }
      }
    } catch (error) {
      console.warn('[AzureSpeech] ⚠️ Could not extract confidence:', error);
    }
    
    return 1.0; // Default confidence
  }

  /**
   * Cleanup recognizer resources
   */
  private cleanupRecognizer() {
    if (this.recognizer) {
      this.recognizer.close();
      this.recognizer = null;
    }
  }

  /**
   * Cleanup all resources
   */
  destroy() {
    this.stopContinuousRecognition();
    this.cleanupRecognizer();
    this.onResult$.complete();
    this.onError$.complete();
    this.onEnd$.complete();
  }
}
