import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QualitySearchComponent } from './work-order.component';

describe('QualitySearchComponent', () => {
  let component: QualitySearchComponent;
  let fixture: ComponentFixture<QualitySearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QualitySearchComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QualitySearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
