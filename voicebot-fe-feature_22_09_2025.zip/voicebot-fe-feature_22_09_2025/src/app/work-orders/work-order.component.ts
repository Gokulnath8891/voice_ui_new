import { HttpClient, HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { catchError, throwError } from 'rxjs';
import { SidebarModule } from 'primeng/sidebar';
import { ButtonModule } from 'primeng/button';
import { ChipModule } from 'primeng/chip';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AvatarModule } from 'primeng/avatar';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { CardModule } from 'primeng/card';
import { TagModule } from 'primeng/tag';

@Component({
  selector: 'work-order',
  standalone: true,
  imports: [
    FormsModule, 
    HttpClientModule, 
    SidebarModule, 
    ButtonModule, 
    ChipModule, 
    InputTextareaModule, 
    AvatarModule, 
    CommonModule,
    InputTextModule,
    TableModule,
    CardModule,
    TagModule
],
  templateUrl: './work-order.component.html',
  styleUrl: './work-order.component.scss'
})
export class WorkOrderComponent {
  userInput: string = '';
  tableData: any = null;
  userInputBeforeSubmit: string = '';
  sidebarOpen = false;
  searchInitiated = false;

  selectedPrograms: string[] = [];
  selectedModelYears: string[] = [];
  selectedProgramDecks: string[] = [];

  tableColumns: { field: string, header: string }[] = [];

  workOrders: any[] = [];
  cols: any[] = [];

  get lastQuery(): string {
    return this.tableData ? this.userInputBeforeSubmit : '';
  }

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.cols = [
      { field: 'id', header: 'Work Order ID' },
      { field: 'title', header: 'Title' },
      { field: 'description', header: 'Description' },
      { field: 'status', header: 'Status' },
      { field: 'priority', header: 'Priority' },
      { field: 'assignee', header: 'Assignee' },
      { field: 'department', header: 'Department' },
      { field: 'location', header: 'Location' },
      { field: 'category', header: 'Category' },
      { field: 'estimatedHours', header: 'Est. Hours' },
      { field: 'createdDate', header: 'Created Date' },
      { field: 'dueDate', header: 'Due Date' },
      { field: 'completedDate', header: 'Completed Date' }
    ];

    this.workOrders = [
      { 
        id: 'WO-001', 
        title: 'Kitchen Faucet Repair',
        description: 'Fix leaking faucet in kitchen', 
        status: 'Open', 
        priority: 'High', 
        assignee: 'John Doe', 
        department: 'Plumbing',
        location: 'Building A - Kitchen',
        category: 'Maintenance',
        estimatedHours: 2,
        createdDate: '2025-07-15',
        dueDate: '2025-07-25',
        completedDate: null
      },
      { 
        id: 'WO-002', 
        title: 'HVAC System Repair',
        description: 'Repair HVAC unit on rooftop', 
        status: 'In Progress', 
        priority: 'High', 
        assignee: 'Jane Smith', 
        department: 'HVAC',
        location: 'Building B - Rooftop',
        category: 'Repair',
        estimatedHours: 8,
        createdDate: '2025-07-10',
        dueDate: '2025-07-22',
        completedDate: null
      },
      { 
        id: 'WO-003', 
        title: 'Fire Alarm Inspection',
        description: 'Inspect fire alarm system', 
        status: 'Completed', 
        priority: 'Medium', 
        assignee: 'Mike Johnson', 
        department: 'Safety',
        location: 'Building C - All Floors',
        category: 'Inspection',
        estimatedHours: 4,
        createdDate: '2025-07-08',
        dueDate: '2025-07-15',
        completedDate: '2025-07-14'
      },
      { 
        id: 'WO-004', 
        title: 'Window Replacement',
        description: 'Replace broken window in office 201', 
        status: 'Open', 
        priority: 'Low', 
        assignee: 'Emily White', 
        department: 'Facilities',
        location: 'Building A - Office 201',
        category: 'Replacement',
        estimatedHours: 3,
        createdDate: '2025-07-12',
        dueDate: '2025-08-01',
        completedDate: null
      },
      { 
        id: 'WO-005', 
        title: 'Warehouse Painting',
        description: 'Paint the north wall of the warehouse', 
        status: 'On Hold', 
        priority: 'Low', 
        assignee: 'Chris Green', 
        department: 'Maintenance',
        location: 'Warehouse - North Wall',
        category: 'Maintenance',
        estimatedHours: 16,
        createdDate: '2025-07-18',
        dueDate: '2025-08-10',
        completedDate: null
      },
      { 
        id: 'WO-006', 
        title: 'Electrical Panel Upgrade',
        description: 'Upgrade electrical panel in server room', 
        status: 'In Progress', 
        priority: 'High', 
        assignee: 'Robert Brown', 
        department: 'Electrical',
        location: 'Building B - Server Room',
        category: 'Upgrade',
        estimatedHours: 12,
        createdDate: '2025-07-05',
        dueDate: '2025-07-20',
        completedDate: null
      },
      { 
        id: 'WO-007', 
        title: 'Elevator Maintenance',
        description: 'Monthly elevator maintenance check', 
        status: 'Completed', 
        priority: 'Medium', 
        assignee: 'Sarah Davis', 
        department: 'Elevator Services',
        location: 'Building A - All Elevators',
        category: 'Maintenance',
        estimatedHours: 6,
        createdDate: '2025-07-01',
        dueDate: '2025-07-05',
        completedDate: '2025-07-04'
      },
      { 
        id: 'WO-008', 
        title: 'Parking Lot Cleaning',
        description: 'Deep clean and seal parking lot surface', 
        status: 'Open', 
        priority: 'Low', 
        assignee: 'Michael Wilson', 
        department: 'Grounds',
        location: 'Parking Lot - Main',
        category: 'Cleaning',
        estimatedHours: 24,
        createdDate: '2025-07-16',
        dueDate: '2025-08-15',
        completedDate: null
      }
    ];
  }

  getStatusSeverity(status: string): string {
    switch (status) {
      case 'Completed':
        return 'success';
      case 'In Progress':
        return 'info';
      case 'Open':
        return 'warning';
      case 'On Hold':
        return 'danger';
      default:
        return 'secondary';
    }
  }

  getPrioritySeverity(priority: string): string {
    switch (priority) {
      case 'High':
        return 'danger';
      case 'Medium':
        return 'warning';
      case 'Low':
        return 'success';
      default:
        return 'info';
    }
  }

  toggleSidebar() {
    this.sidebarOpen = !this.sidebarOpen;
  }

  onSubmit() {
    if (!this.userInput) return;

    this.searchInitiated = true;
    this.userInputBeforeSubmit = this.userInput;

    const payload = {
      query: this.userInput
    };

    this.http.post('http://172.172.175.70:8081/plma-aims-suggestion/hackathon_query', payload)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          console.error('API error:', error);
          if (error.error && error.error.socket) {
            error.error.socket.destroy();
          }
          return throwError(() => new Error('Something bad happened; please try again later.'));
        })
      )
      .subscribe({
        next: (response: any) => {
          const data = Array.isArray(response) ? response : [response];
          this.tableData = data;
          if (data.length > 0) {
            this.tableColumns = Object.keys(data[0]).map(key => ({ field: key, header: key }));
          }
        }
      });
  }
}
