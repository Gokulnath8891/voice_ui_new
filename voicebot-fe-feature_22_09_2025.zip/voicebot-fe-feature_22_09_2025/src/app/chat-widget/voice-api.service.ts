import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment'; // adjust path if needed

@Injectable({
  providedIn: 'root',
})
export class VoiceApiService {
  private readonly API_BASE_URL = environment.baseUrl;
  private readonly VOICE_ENDPOINT = `${this.API_BASE_URL}/search/query`;
  private readonly CHAT_ENDPOINT = `${this.API_BASE_URL}/chat`;

  constructor(private http: HttpClient) {}

  async sendVoiceMessage(transcribedText: string): Promise<{ response: string; audioResponse?: Blob }> {
    try {
      console.log(this.VOICE_ENDPOINT,"this.VOICE_ENDPOINT");
      const response = await fetch(this.VOICE_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: transcribedText,
          max_chunks: 5,
          similarity_threshold: 0.7,
        }),
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const contentType = response.headers.get('content-type');

      if (contentType?.includes('application/json')) {
        const jsonResponse = await response.json();
        return {
          response: jsonResponse.summary || jsonResponse.response || jsonResponse.answer || 'No response available',
        };
      } else if (contentType?.includes('audio')) {
        const audioResponse = await response.blob();
        return {
          response: response.headers.get('x-response-text') || 'Audio response received',
          audioResponse,
        };
      } else {
        throw new Error('Unexpected response format');
      }
    } catch (error) {
      console.error('Voice API error:', error);
      throw new Error('Failed to process voice message');
    }
  }

  async sendTextToAPI(text: string): Promise<string> {
    try {
      const response = await fetch(this.VOICE_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: text,
          max_chunks: 5,
          similarity_threshold: 0.7,
        }),
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const jsonResponse = await response.json();
      return jsonResponse.summary || jsonResponse.response || jsonResponse.answer || 'No response available';
    } catch (error) {
      console.error('Chat API error:', error);
      throw new Error('Failed to get chat response');
    }
  }

  speakText(text: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;

        utterance.onend = () => resolve();
        utterance.onerror = (event) => reject(new Error(`Speech synthesis error: ${event.error}`));

        speechSynthesis.speak(utterance);
      } else {
        reject(new Error('Speech synthesis not supported'));
      }
    });
  }
}
