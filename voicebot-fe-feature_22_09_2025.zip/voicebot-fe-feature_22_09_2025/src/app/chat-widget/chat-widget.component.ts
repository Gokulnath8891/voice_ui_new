import {Component, OnInit, OnDestroy} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ButtonModule} from 'primeng/button';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {AvatarModule} from 'primeng/avatar';
import {FormsModule} from '@angular/forms';
import {TooltipModule} from 'primeng/tooltip';
import {VoiceApiService} from './voice-api.service';
import {WakeupVoiceService} from './wakeup-voice.service';

@Component({
  selector: 'app-chat-widget',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    InputTextareaModule,
    AvatarModule,
    FormsModule,
    TooltipModule,
  ],
  templateUrl: './chat-widget.component.html',
  styleUrls: ['./chat-widget.component.scss'],
})
export class ChatWidgetComponent implements OnInit, OnDestroy {
  isChatOpen = false;
  userInput = '';
  isRecording = false;
  isListening = false;
  isProcessing = false;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private recognition: any = null;
  private autoOpenTimer: any = null;
  messages: {text: string; sender: 'user' | 'bot'; avatar: string; isProcessing?: boolean}[] = [
    {text: 'Hello! How can I help you today?', sender: 'bot', avatar: '🤖'},
  ];

  constructor(
    private voiceApiService: VoiceApiService,
    private voiceWakeup: WakeupVoiceService,
  ) {
    this.initializeMediaRecorder();
    this.initializeSpeechRecognition();
  }

  ngOnInit() {
    // Auto-open chat widget after 10 seconds
    // this.autoOpenTimer = setTimeout(() => {
    //   if (!this.isChatOpen) {
    //     this.toggleChat();
    //   }
    // }, 10000); // 10 seconds
    // this.voiceWakeup.startListening(() => {
    //   console.log('Wake word detected!');
    //   this.voiceWakeup.stopListening();

    //   if (!this.isChatOpen) {
    //     this.toggleChat();
    //     // Add a small delay to prevent a race condition for the microphone
    //     setTimeout(() => {
    //       this.toggleVoiceInput();
    //     }, 300); // 300ms is usually a safe delay
    //   }
    // });
    this.startWakeWordListener();
  }

  private async initializeMediaRecorder() {
    // We're now using speech recognition instead of MediaRecorder
    // This method is kept for compatibility but doesn't initialize MediaRecorder
    console.log('Using Speech Recognition API instead of MediaRecorder');
  }

  private initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition =
        (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      this.recognition = new SpeechRecognition();

      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-US';

      // this.recognition.onstart = () => {
      //   this.isListening = true;
      //   this.isRecording = true;
      // };
      this.recognition.onstart = () => {
        this.isRecording = true; 
      };

      // this.recognition.onresult = async (event: any) => {
      //   const transcript = event.results[0][0].transcript;
      //   this.isListening = false;
      //   this.isRecording = false;
      this.recognition.onresult = async (event: any) => {
        const transcript = event.results[0][0].transcript;
        this.isRecording = false; 
        // Add user message
        this.messages.push({
          text: transcript,
          sender: 'user',
          avatar: '🧑',
        });

        this.scrollToBottom();

        // Send transcribed text to API and get voice response
        await this.sendTranscriptToAPI(transcript);
      };

      // this.recognition.onerror = (event: any) => {
      //   console.error('Speech recognition error:', event.error);
      //   this.isListening = false;
      //   this.isRecording = false;
      this.recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        this.isRecording = false;
        this.showErrorMessage('Voice recognition failed. Please try again.');
      };

      // this.recognition.onend = () => {
      //   this.isListening = false;
      //   this.isRecording = false;
      // };
      this.recognition.onend = () => {
        this.isRecording = false;
      };
    }
  }

  private async sendVoiceToAPI(audioBlob: Blob): Promise<void> {
    // This method is no longer used since we're using browser speech recognition
    // The voice input is now handled through the speech recognition API directly
    console.warn('sendVoiceToAPI called but not used in speech recognition mode');
  }

  private async sendTranscriptToAPI(transcript: string): Promise<void> {
    try {
      // Add processing indicator for bot response
      const botMessageIndex = this.messages.length;
      this.messages.push({
        text: '🤔 Thinking...',
        sender: 'bot',
        avatar: '🤖',
        isProcessing: true,
      });

      this.scrollToBottom();

      // Get response from chat API
      const botResponse = await this.voiceApiService.sendTextToAPI(transcript);

      // Update bot message with actual response
      this.messages[botMessageIndex] = {
        text: botResponse,
        sender: 'bot',
        avatar: '🤖',
      };

      // Speak the response using text-to-speech
      try {
        await this.voiceApiService.speakText(botResponse);
      } catch (ttsError) {
        console.error('Error with text-to-speech:', ttsError);
      }

      this.scrollToBottom();

      this.startWakeWordListener();
    } catch (error) {
      console.error('Chat API error:', error);
      this.messages[this.messages.length - 1] = {
        text: 'Sorry, I encountered an error. Please try again.',
        sender: 'bot',
        avatar: '🤖',
      };
      this.scrollToBottom();

      this.startWakeWordListener();
    }
  }

  private showErrorMessage(message: string): void {
    this.messages.push({
      text: message,
      sender: 'bot',
      avatar: '🤖',
    });
    this.scrollToBottom();
  }

  get isSpeechSupported(): boolean {
    return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  }

  get isMediaRecorderSupported(): boolean {
    // We're not using MediaRecorder anymore, so return false
    return false;
  }

  startVoiceInput() {
    if (this.isProcessing) return;
    if (this.recognition && !this.isRecording) {
      this.isRecording = true;
      this.recognition.start();
    }
  }

  stopVoiceInput() {
    if (this.recognition && this.isRecording) {
      this.recognition.stop();
      // onend will set isRecording to false
    }
  }
  // toggleVoiceInput() {
  //   if (this.isProcessing) return;

  //   if (this.isListening || this.isRecording) {
  //     this.stopVoiceInput();
  //   } else {
  //     this.startVoiceInput();
  //   }
  // }
  toggleVoiceInput() {
    if (this.isProcessing) return;
    if (this.isRecording) {
      this.stopVoiceInput();
    } else {
      this.startVoiceInput();
    }
  }

  toggleChat() {
    this.isChatOpen = !this.isChatOpen;

    if (this.autoOpenTimer) {
      clearTimeout(this.autoOpenTimer);
      this.autoOpenTimer = null;
    }

    if (this.isChatOpen) {
      setTimeout(() => this.scrollToBottom(), 100);
    } else {
      this.startWakeWordListener();
    }
  }

  private startWakeWordListener(): void {
    console.log('Restarting wake word listener...');
    this.voiceWakeup.startListening(() => {
      console.log('Wake word detected!');
      this.voiceWakeup.stopListening();

      if (!this.isChatOpen) {
        // Case 1: Chat is closed. Open it AND start voice input.
        console.log('[ChatWidget] Chat is closed. Opening and starting voice input...');
        this.toggleChat();
        setTimeout(() => this.toggleVoiceInput(), 300); // Keep delay for mic handover
      } else {
        // Case 2: Chat is already open. Just start the voice input.
        console.log('[ChatWidget] Chat is open. Starting voice input directly...');
        this.toggleVoiceInput();
      }
    });
  }

  minimizeChat() {
    this.isChatOpen = false;
  }

  handleEnterKey(event: KeyboardEvent) {
    if (!event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  adjustTextareaHeight(event: any) {
    const textarea = event.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  }

  getVoiceButtonClass(): string {
    let baseClass = 'p-button-rounded voice-btn';
    if (this.isRecording) {
      baseClass += ' recording-active';
    }
    return baseClass;
  }

  getVoiceTooltip(): string {
    if (this.isRecording) {
      return 'Stop recording';
    } else if (this.isProcessing) {
      return 'Processing...';
    } else {
      return 'Start voice input';
    }
  }

  sendQuickMessage(message: string) {
    this.userInput = message;
    this.sendMessage();
  }

  getCurrentTime(): string {
    return new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
  }

  private scrollToBottom() {
    setTimeout(() => {
      const messagesContainer = document.querySelector('.chat-messages');
      if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      }
    }, 50);
  }

  async sendMessage() {
    this.isRecording = false;

    if (!this.userInput.trim() || this.isProcessing) return;

    const messageText = this.userInput.trim();
    this.userInput = '';

    // Add user message
    this.messages.push({
      text: messageText,
      sender: 'user',
      avatar: '�',
    });

    this.scrollToBottom();

    // Send to API and get response
    await this.sendTranscriptToAPI(messageText);
  }

  // ngOnDestroy() {
  //   // Clean up the auto-open timer when component is destroyed
  //   if (this.autoOpenTimer) {
  //     clearTimeout(this.autoOpenTimer);
  //     this.autoOpenTimer = null;
  //   }
  // }
  ngOnDestroy() {
    console.log('[ChatWidget] Component destroyed. Stopping wake word listener.');    this.voiceWakeup.stopListening();
  }
}
