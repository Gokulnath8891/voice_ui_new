# Collaborating on FRF

This document will serve as a reference guide for collaboration between the various teams internal to the FRF process. Here we will capture our norms and scheduled touchpoints, which will be used for collaboration on development tasks.

## Planning and Project Management

The team plans work on a quarterly basis alongside the entire Dev Tools and Enablement department. Work that is prioritized for the quarter will be captured in Workboard, demonstrating team level ownership of tasks and rollup into the larger departmental objectives and plans. From that work, the WaME team will distill out the code releases required within the quarter, and will appropriately plan out work and groom backlogs to align.

Once high level release plans are created, associated stories are created in each repository backlog as GitHub Issues. These Issues are tied to Milestones that represent the planned releases of code. Tasktop is then utilized to sync Issues and Milestones from GitHub into Rally as User Stories and Features, respectively. A team board in Rally is then utilized to track work during standups, with the team operating in a Kanban style flow.

Standups will occur on Tuesdays and Thursdays, and will follow this agenda:

- What work is currently in-flight?
- Does any current work need further discussion or input?
- What cards have blockers?
- Technical discussions should stay focused and succinct, narrowing in on the specific blockers to delivery.

## Scheduled meetings and timeblocks

The team has established a set of meetings to help guide work efforts. The following meetings and cadences have been established:

- Standups - 8:30-9:30am EST, Tuesday and Thursday
- Whole team meetings and on-site collaboration - every Wednesday
- Retro and Planning - after every release, plus also during selected standups on an as-needed basis

No other standing meetings are scheduled, but additional code review or mobbing/pairing blocks of time may be scheduled.

## Working norms

As much as possible, the teams should strive for collaboration between the three parts of the team - NA WaME, AP WaME and larger Dev Enablement. Shared knowledge and thoughts will be key to maturing the FRF product. To that end, pairing and mobbing practices should be leveraged as much as possible.

To support mobbing/pairing across teams and regions, cards will try to be managed in region or team specific ways. This will allow for time-constraint free collaboration on those specific cards. Then, after the work is complete, reviews should be conducted including the portions of the team(s) that were not a part of the majority of the card.
