# frf-starter - Release Documentation

The goal of our frf-starter releases will be to track as closely to the major Angular version releases as possible. While we will strive to achieve this, we also rely on other packages that also need to update as versions of Angular are released, and this means that some amount of lag time will exist between a major Angular release and a release of a matching frf-starter version. This document will serve to outline some of these expectations, and will also outline the process we will take whenever we release a new version of the starter project.

## Angular & Dependent Package Releases

Whenever a new major release (18.0.0, for example) of Angular comes out, we can begin piloting usage of the major version against our already existing templates and reference apps. We will not be able to release a fully vetted package, though, until our dependent packages have also been updated. This includes two major items: PrimeNG and the PrimeNG Designer API. Both of these packages must be updated for compatibility with the new Angular release before we consider an upgrade to our templates. The delay in these dependencies releasing updated versions can take some time - up to 6 weeks in some cases. While we certainly can use pre-release builds of the libraries to keep up with proposed changes, we must wait for a production release before tagging our own final release.

## Tooling Dependencies

In addition to the dependent packages and libraries, keep in mind that tools and IDEs should also be updated during this process. Items like Node.js, WebStorm/IntelliJ and VS Code, web browsers, and other related packages all receive updates during the release cadence of our core package dependencies. These all should be verified for compatibility with the new versions of the dependent packages. In most cases, WaME will recommend a baseline tooling version to start with, assuming that packages will be forward-compatible from there. The below vetting process will mention where tooling requirements should be tested.

## Vetting a release

When starting work with a new Angular version, the following steps must be taken to verify the new packages work as expected in the Ford environment:

1. Visit the [Angular update tool guide](https://angular.dev/update-guide) and select the correct `from` and `to` versions. Set your app complexity to `Medium`. Click `Show me how to update!`
1. Follow the provided steps to update the app  
   ![Angular update page](images/AngularUpdate.png)
1. Delete your `node_modules` and `package-lock.json`, then run `npm install`.
1. After the above steps complete, the Angular upgrade tools will have automatically updated the app. For verification purposes, it is helpful to now compare the app against a fresh Angular CLI generation by doing the following:
   - Create a new project folder where you will store this temporary project. Generate a new sample project using a globally-installed copy of the latest version of the Angular CLI
     ```shell
     npx -p @angular/cli@18.x
     ng version
     ng new
     ```
   - Verify overall project structure and any configuration changes in dotfiles, config files, and `angular.json` with Beyond Compare
   - Verify FRF `package.json` with new list of Angular injected dependencies. _Note: You can get the actual installed list of dependencies in the generated project using `npm ls -l --depth=0`._
1. Update FRF `package.json` with the newest versions of non-Angular dependencies (items such as PrimeNG, FontAwesome, etc). You can find these by searching in [npmjs](https://www.npmjs.com/). You'll want to check for breaking changes before making updates.
1. Update FRF's `blue-oval-theme` by leveraging the [Prime Designer Showcase repository](https://github.ford.com/WaMCOE/primeng-designer) for theme development. Update the `blue-oval-theme` version in the `package.json`.
1. Update FRF's `@wame/ngx-frf-utilities` by leveraging the [FRF Packages repository](https://github.ford.com/WaMCOE/frf-packages).
1. Update the FRF Tekton PaC files in the `.tekton` folder and add/adjust any new configurations from the [FRF Tekton Pipelines repository](https://github.com/ford-innersource/devenablement.wame.frf-tekton-pipelines)
   1. Update the FRF Tekton PaC configuration files from the `config-files` folder
1. Update the `package.json` and `manifest.webmanifest` with your new project version. Search and replace references to the old project version.
1. Update the following files' `serviceName` with the latest major project version. For example: `frf-starter-v16`
   1. `.tekton/pipeline-configuration.json`
   1. `.tekton/pipeline-configuration-dev.json`
   1. `.tekton/pipeline-configuration-prod.json`
1. Update the following files' `imageTag` with the latest project full version (major.minor.patch) along with any pre-release information (alpha, beta, rc). For example: `16.0.0-alpha.1` or `16.0.0-beta.1`
   1. `.tekton/pipeline-configuration.json`
   1. `.tekton/pipeline-configuration-dev.json`
   1. `.tekton/pipeline-configuration-prod.json`
1. Run the full set of CI/CD tooling. Should any errors appear, fix them
1. Deploy a built version of the new template to GCP. Run the template across all necessary browsers to ensure compatibility
1. Finally, these structure and theming changes should be integrated into JAB, following the same procedure as above

With all five projects (`frf-starter`, `frf-jab`, `primeng-designer`, `frf-packages`, and `frf-tekton-pipelines`) updated, our due diligence is complete for vetting the updated Angular version itself. Additionally, this is the time when other tools should be updated as well, in accordance with team norms.

## Prepping a Release

As time progresses, it's inevitable that various features, tweaks and bugfixes outside the core package versioning and configuration will come up. These features need to be prioritized against other work and targeted for release milestones in the WaME pipeline. In general, the following release prioritization will hold true:

- **Major releases** should focus _only_ on updating to the latest version of our 3rd party dependencies, as outlined above. Major release milestones can also include other completed, non-dependent work, or any must-have dependencies that are required to ship on a major release (in other words, breaking changes)
- **Minor releases** will focus on feature updates. In most cases, these will be non-dependent features that were pushed out from the major release to afford better timeliness in release of the initial major package
- **Patch releases** will focus on break-fix, hotfix, or security type updates. These will be small, critical fixes that should ship as soon as they are completed

Pre-release packages (`alpha`, `beta`, or `release candidate` releases) can be considered before a major release is fully vetted for a general availability (GA) release. In this case, fully vetted means fully completing all the steps described in `Vetting a release`.

For example, a pre-release package could be tagged and released after step 5 of the vetting process, before the full changes have been vetted in the `frf-jab` reference app. If a pre-release package is released, its intentions should be clearly communicated within the release notes. In most cases, they will be leveraged to allow the community "early access" to a major set of features or changes while they are still being finalized by the WaME team.

## WaME frf-starter release process

Once the above requirements have been fulfilled and the type of release has been determined, the WaME team will follow this process for each release of this repo:

1. Complete all cards on the current [release milestone](https://github.ford.com/WaMCOE/frf-starter/milestones).
   - Cards should be merged to `dev` via pull requests (PRs), including passing Tekton checks and team review.
   - Issues should be moved to Accepted in Rally and Closed in GitHub once a PR is merged.
   - PRs from feature branches to dev should be tagged with a label from one of the following categories, as our autogenerated release notes rely on them:
     - Semver-Major
     - breaking-change
     - Semver-Minor
     - enhancement
     - bug
     - packaging
     - tooling
     - pipeline
     - documentation
1. Create a PR to merge `dev` into `main`.
   - This will include another pass of Tekton pipeline checks and team review.
   - Verify the [dev deployment to GCP](https://frf-starter-dev-v18-141670827380.us-central1.run.app) looks and functions as expected.
1. Merge the PR and verify the [prod deployment to GCP](https://frf-starter-v18-141670827380.us-central1.run.app).
1. Tag a release from `main`.
1. Draft release notes, including links to the merged PRs/issues. (see [version 16.1.0 release notes](https://github.ford.com/WaMCOE/frf-starter/releases/tag/v16.1.0) for an example).
   - Team approval is required before taking a release from draft to published.
1. For `frf-starter`, code needs to be merged into [central station](https://centralstation.ford.com/) with the following steps:
   - Merge the released code into the [`wamcoe/angular-template-wamcoe` repository](https://github.ford.com/WaMCOE/angular-template-wamcoe).
   - Create a PR from the `wamcoe/angular-template-wamcoe` fork into the `quartermaster/angular-template-wamcoe` repo, targeting the `develop` branch.
   - Review the optional dependencies that can be selected during template creation. These exist in `dev-central-engine/src/main/resources/dependencies/angular-standard.json`. Create a PR from the `wamcoe/dev-central-engine` fork into the `quartermaster/dev-central-engine` repo, targeting the `develop` branch.
   - Work with the Central Station team to finish merging.

## WaME post-release sync-up

After a release is complete, all devs on the WaME team should ensure they align their local workspaces with the updated release. This includes not only pulling the latest changes for the `main` branch on `frf-starter`, `frf-jab`, `primeng-designer`, `frf-packages`, and `frf-tekton-pipelines` but also ensuring all team members - especially those that may not have directly worked on the code - have aligned their local tools (e.g. WebStorm, Node/npm, etc) to the most recently recommended versions.
