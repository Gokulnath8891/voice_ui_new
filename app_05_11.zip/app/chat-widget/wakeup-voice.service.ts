import {Injectable, NgZone} from '@angular/core';

interface WakeWordCallback {
  id: string;
  onWakeWord: () => void;
  onWorkOrder?: (transcript: string) => void;
}

@Injectable({
  providedIn: 'root',
})
export class WakeupVoiceService {
  private recognition: any = null;
  private isRunning = false;
  private restartTimer: any = null;
  private readonly wakeWord = 'hey buddy';
  private callbacks: WakeWordCallback[] = [];

  constructor(private readonly zone: NgZone) {
    console.log('[WakeWord] 🎧 Service initialized');
    this.initializeRecognition();
  }

  private initializeRecognition(): void {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      console.error('[WakeWord] ❌ Speech Recognition not supported in this browser');
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.lang = 'en-US';
    this.recognition.interimResults = false;
    this.recognition.maxAlternatives = 1;

    // Recognition started
    this.recognition.onstart = () => {
      console.log('[WakeWord] ✅ Listening started');
      this.isRunning = true;
    };

    // Recognition result
    this.recognition.onresult = (event: any) => {
      const result = event.results[event.resultIndex];
      const transcript = result[0].transcript.trim().toLowerCase();
      
      console.log('[WakeWord] 🎤 Heard:', `"${transcript}"`);
      
      this.processTranscript(transcript);
    };

    // Recognition error
    this.recognition.onerror = (event: any) => {
      console.warn('[WakeWord] ⚠️ Error:', event.error);
      
      // Handle critical errors
      if (event.error === 'not-allowed' || event.error === 'audio-capture') {
        console.error('[WakeWord] ❌ Microphone permission denied or not available');
        this.isRunning = false;
      }
    };

    // Recognition ended
    this.recognition.onend = () => {
      console.log('[WakeWord] 🛑 Listening ended');
      this.isRunning = false;
      
      // Auto-restart if we have active callbacks
      if (this.callbacks.length > 0) {
        console.log('[WakeWord] 🔄 Auto-restarting in 1 second...');
        this.scheduleRestart();
      }
    };
  }

  private scheduleRestart(): void {
    if (this.restartTimer) {
      clearTimeout(this.restartTimer);
    }
    
    this.restartTimer = setTimeout(() => {
      if (this.callbacks.length > 0 && !this.isRunning) {
        this.start();
      }
    }, 1000);
  }

  private processTranscript(transcript: string): void {
    const normalized = transcript.replace(/[,.!?]/g, '').trim();
    
    // Check for wake word "hey buddy"
    if (normalized.includes(this.wakeWord)) {
      console.log('[WakeWord] ✅ Wake word detected!');
      this.triggerWakeWordCallbacks();
      return;
    }
    
    // Check for work order commands
    const workOrderPattern = /(?:help\s+me\s+(?:to\s+)?fix|start|resume|restart)\s+(?:work\s*order|wo)\s+(\d+(?:\s*\d+)*)/i;
    if (workOrderPattern.test(transcript)) {
      console.log('[WakeWord] 🎯 Work order command detected!');
      this.triggerWorkOrderCallbacks(transcript);
    }
  }

  private triggerWakeWordCallbacks(): void {
    this.zone.run(() => {
      this.callbacks.forEach(cb => {
        try {
          console.log('[WakeWord] 📞 Calling wake word callback:', cb.id);
          cb.onWakeWord();
        } catch (error) {
          console.error('[WakeWord] ❌ Error in wake word callback:', error);
        }
      });
    });
  }

  private triggerWorkOrderCallbacks(transcript: string): void {
    this.zone.run(() => {
      this.callbacks.forEach(cb => {
        if (cb.onWorkOrder) {
          try {
            console.log('[WakeWord] 📞 Calling work order callback:', cb.id);
            cb.onWorkOrder(transcript);
          } catch (error) {
            console.error('[WakeWord] ❌ Error in work order callback:', error);
          }
        }
      });
    });
  }

  private start(): void {
    if (!this.recognition) {
      console.error('[WakeWord] ❌ Recognition not initialized');
      return;
    }

    if (this.isRunning) {
      console.log('[WakeWord] ℹ️ Already running');
      return;
    }

    try {
      this.recognition.start();
      console.log('[WakeWord] ▶️ Start requested');
    } catch (error: any) {
      if (error.message?.includes('already started')) {
        console.log('[WakeWord] ℹ️ Already started');
        this.isRunning = true;
      } else {
        console.error('[WakeWord] ❌ Start failed:', error);
      }
    }
  }

  private stop(): void {
    if (!this.recognition) return;

    if (this.restartTimer) {
      clearTimeout(this.restartTimer);
      this.restartTimer = null;
    }

    if (this.isRunning) {
      try {
        this.recognition.stop();
        console.log('[WakeWord] ⏹️ Stop requested');
      } catch (error) {
        console.error('[WakeWord] ❌ Stop failed:', error);
      }
    }
    
    this.isRunning = false;
  }

  /**
   * Register a component to listen for wake word
   */
  register(componentId: string, onWakeWord: () => void, onWorkOrder?: (transcript: string) => void): void {
    console.log('[WakeWord] 📝 Registering:', componentId);
    
    // Check if already registered
    const existing = this.callbacks.find(cb => cb.id === componentId);
    if (existing) {
      console.log('[WakeWord] ⚠️ Component already registered, updating callbacks');
      existing.onWakeWord = onWakeWord;
      existing.onWorkOrder = onWorkOrder;
      return;
    }
    
    // Add new callback
    this.callbacks.push({
      id: componentId,
      onWakeWord,
      onWorkOrder
    });
    
    console.log('[WakeWord] ✅ Registered. Total callbacks:', this.callbacks.length);
    
    // Start listening if this is the first callback
    if (this.callbacks.length === 1) {
      this.start();
    }
  }

  /**
   * Unregister a component
   */
  unregister(componentId: string): void {
    console.log('[WakeWord] 🗑️ Unregistering:', componentId);
    
    const index = this.callbacks.findIndex(cb => cb.id === componentId);
    if (index > -1) {
      this.callbacks.splice(index, 1);
      console.log('[WakeWord] ✅ Unregistered. Remaining callbacks:', this.callbacks.length);
      
      // Stop listening if no more callbacks
      if (this.callbacks.length === 0) {
        this.stop();
      }
    } else {
      console.warn('[WakeWord] ⚠️ Component not found:', componentId);
    }
  }

  /**
   * Force restart the listener
   */
  restart(): void {
    console.log('[WakeWord] 🔄 Force restart requested');
    this.stop();
    setTimeout(() => {
      if (this.callbacks.length > 0) {
        this.start();
      }
    }, 500);
  }

  /**
   * Get current status
   */
  getStatus(): {
    isListening: boolean;
    isSupported: boolean;
    wakeWord: string;
    registeredComponents: number;
  } {
    return {
      isListening: this.isRunning,
      isSupported: !!this.recognition,
      wakeWord: this.wakeWord,
      registeredComponents: this.callbacks.length
    };
  }

  /**
   * DEPRECATED - Use register() instead
   */
  startListening(callback: () => void, workOrderCallback?: (transcript: string) => void): void {
    console.warn('[WakeWord] ⚠️ startListening() is deprecated. Use register() instead');
    this.register('legacy-callback', callback, workOrderCallback);
  }

  /**
   * DEPRECATED - Use unregister() instead
   */
  stopListening(): void {
    console.warn('[WakeWord] ⚠️ stopListening() is deprecated. Use unregister() instead');
    this.unregister('legacy-callback');
  }

  /**
   * DEPRECATED - Use unregister() instead
   */
  unregisterCallbacks(callback: () => void, workOrderCallback?: (transcript: string) => void): void {
    console.warn('[WakeWord] ⚠️ unregisterCallbacks() is deprecated. Use unregister() instead');
    this.unregister('legacy-callback');
  }

  /**
   * DEPRECATED - Use restart() instead
   */
  forceRestart(): void {
    this.restart();
  }

  /**
   * DEPRECATED - Use getStatus() instead
   */
  isCurrentlyListening(): boolean {
    return this.isRunning;
  }
}
