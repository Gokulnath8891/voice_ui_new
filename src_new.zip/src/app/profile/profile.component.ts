import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CardModule } from 'primeng/card';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { PasswordModule } from 'primeng/password';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { TabViewModule } from 'primeng/tabview';
import { FileUploadModule } from 'primeng/fileupload';
import { AvatarModule } from 'primeng/avatar';
import { DividerModule } from 'primeng/divider';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { AuthService, UserProfile } from '../services/auth.service';

interface Department {
  name: string;
  code: string;
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    CardModule,
    InputTextModule,
    ButtonModule,
    PasswordModule,
    ToastModule,
    TabViewModule,
    FileUploadModule,
    AvatarModule,
    DividerModule,
    InputTextareaModule,
    CalendarModule,
    DropdownModule
  ],
  providers: [MessageService],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})
export class ProfileComponent implements OnInit {
  profileForm!: FormGroup;
  passwordForm!: FormGroup;
  profilePicture: string = 'https://via.placeholder.com/150';
  userProfile: UserProfile | null = null;
  isLoading = false;
  
  departments: Department[] = [
    { name: 'Engineering', code: 'ENG' },
    { name: 'Human Resources', code: 'HR' },
    { name: 'Marketing', code: 'MKT' },
    { name: 'Sales', code: 'SAL' },
    { name: 'Finance', code: 'FIN' },
    { name: 'Operations', code: 'OPS' },
    { name: 'Customer Service', code: 'CS' }
  ];

  constructor(
    private readonly fb: FormBuilder,
    private readonly messageService: MessageService,
    private readonly authService: AuthService
  ) {}

  ngOnInit() {
    this.initializeForms();
    this.loadUserProfile();
  }

  initializeForms() {
    this.profileForm = this.fb.group({
      username: [{ value: '', disabled: true }],
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^\+?[\d\s\-()]+$/)]],
      department: ['', Validators.required],
      jobTitle: ['', Validators.required],
      employeeId: [{ value: '', disabled: true }],
      dateOfBirth: [''],
      bio: ['', Validators.maxLength(500)],
      address: [''],
      city: [''],
      country: ['']
    });

    this.passwordForm = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(8), this.passwordValidator]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  async loadUserProfile() {
    this.isLoading = true;
    
    try {
      this.userProfile = await this.authService.getUserProfile();
      
      if (this.userProfile) {
        // Map API response to form
        const userData = {
          username: this.userProfile.username,
          firstName: this.userProfile.first_name,
          lastName: this.userProfile.last_name,
          email: this.userProfile.email,
          phone: this.userProfile.profile?.phone || '',
          department: this.departments.find(d => d.name === this.userProfile?.profile?.department) || '',
          jobTitle: this.userProfile.role,
          employeeId: this.userProfile.profile?.employee_id || '',
          dateOfBirth: '',
          bio: '',
          address: '',
          city: '',
          country: ''
        };

        this.profileForm.patchValue(userData);
      } else {
        // Fallback to mock data if API fails
        this.loadMockUserProfile();
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'Failed to load profile. Using default data.'
      });
      this.loadMockUserProfile();
    } finally {
      this.isLoading = false;
    }
  }

  loadMockUserProfile() {
    // Simulate loading user data
    const userData = {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@company.com',
      phone: '+1 (555) 123-4567',
      department: { name: 'Engineering', code: 'ENG' },
      jobTitle: 'Senior Software Engineer',
      dateOfBirth: new Date('1990-05-15'),
      bio: 'Experienced software engineer with expertise in Angular and TypeScript development.',
      address: '123 Main Street',
      city: 'New York',
      country: 'United States'
    };

    this.profileForm.patchValue(userData);
  }

  passwordValidator(control: any) {
    const value = control.value;
    if (!value) return null;
    
    const hasUpperCase = /[A-Z]/.test(value);
    const hasLowerCase = /[a-z]/.test(value);
    const hasNumeric = /[0-9]/.test(value);
    const hasSpecial = /[#?!@$%^&*-]/.test(value);
    
    const valid = hasUpperCase && hasLowerCase && hasNumeric && hasSpecial;
    return valid ? null : { invalidPassword: true };
  }

  passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('newPassword');
    const confirmPassword = form.get('confirmPassword');
    
    if (newPassword && confirmPassword && newPassword.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }
    return null;
  }

  onFileSelect(event: any) {
    const file = event.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.profilePicture = e.target.result;
      };
      reader.readAsDataURL(file);
      
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: 'Profile picture updated successfully'
      });
    }
  }

  onProfileSubmit() {
    if (this.profileForm.valid) {
      // Simulate API call to update profile
      console.log('Profile Update:', this.profileForm.value);
      
      this.messageService.add({
        severity: 'success',
        summary: 'Profile Updated',
        detail: 'Your profile has been updated successfully'
      });
    } else {
      this.messageService.add({
        severity: 'error',
        summary: 'Validation Error',
        detail: 'Please fill all required fields correctly'
      });
    }
  }

  onPasswordSubmit() {
    if (this.passwordForm.valid) {
      // Simulate API call to change password
      console.log('Password Change Request');
      
      this.messageService.add({
        severity: 'success',
        summary: 'Password Changed',
        detail: 'Your password has been changed successfully'
      });
      
      this.passwordForm.reset();
    } else {
      this.messageService.add({
        severity: 'error',
        summary: 'Validation Error',
        detail: 'Please check your password requirements'
      });
    }
  }

  getFieldError(formGroup: FormGroup, fieldName: string): string {
    const field = formGroup.get(fieldName);
    if (field && field.errors && field.touched) {
      if (field.errors['required']) return `${fieldName} is required`;
      if (field.errors['email']) return 'Please enter a valid email';
      if (field.errors['minlength']) return `${fieldName} must be at least ${field.errors['minlength'].requiredLength} characters`;
      if (field.errors['pattern']) return 'Please enter a valid phone number';
      if (field.errors['invalidPassword']) return 'Password must contain uppercase, lowercase, number and special character';
      if (field.errors['passwordMismatch']) return 'Passwords do not match';
      if (field.errors['maxlength']) return `${fieldName} cannot exceed ${field.errors['maxlength'].requiredLength} characters`;
    }
    return '';
  }
}
