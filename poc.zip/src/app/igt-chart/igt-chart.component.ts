import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as Plotly from 'plotly.js-dist-min';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DividerModule } from 'primeng/divider';
import { FormsModule } from '@angular/forms';
import { MessageModule } from 'primeng/message';
import { TooltipModule } from 'primeng/tooltip';
import { ChipModule } from 'primeng/chip';

interface TestCondition {
  testId: string;
  speed: number;
  load: number;
}

interface DropdownOption {
  label: string;
  value: any;
}

@Component({
  selector: 'app-igt-chart',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    DropdownModule,
    ButtonModule,
    CardModule,
    DividerModule,
    MessageModule,
    TooltipModule,
    ChipModule
  ],
  templateUrl: './igt-chart.component.html',
  styleUrls: ['./igt-chart.component.scss']
})
export class IgtChartComponent implements OnInit, AfterViewInit {
  @ViewChild('plotlyChart', { static: false }) plotlyChart!: ElementRef;

  testConditions: DropdownOption[] = [
    { label: 'igt_YED_Z12E_CNG', value: { testId: 'igt_YED_Z12E_CNG', speed: 1600, load: 15 } },
    { label: 'igt_YED_Z12E_CNG (2000 RPM)', value: { testId: 'igt_YED_Z12E_CNG', speed: 2000, load: 25 } },
    { label: 'igt_YED_Z12E_CNG (2400 RPM)', value: { testId: 'igt_YED_Z12E_CNG', speed: 2400, load: 35 } },
  ];

  speedOptions: DropdownOption[] = [
    { label: '1600 RPM', value: 1600 },
    { label: '2000 RPM', value: 2000 },
    { label: '2400 RPM', value: 2400 },
    { label: '2800 RPM', value: 2800 },
    { label: '3200 RPM', value: 3200 },
  ];

  loadOptions: DropdownOption[] = [
    { label: '15%', value: 15 },
    { label: '25%', value: 25 },
    { label: '35%', value: 35 },
    { label: '45%', value: 45 },
    { label: '55%', value: 55 },
  ];

  deltaParam1Options: DropdownOption[] = [
    { label: 'IgnOut_Advance', value: 'IgnOut_Advance' },
    { label: 'IgnBas_Advance', value: 'IgnBas_Advance' },
    { label: 'IgnTiming_Actual', value: 'IgnTiming_Actual' },
  ];

  deltaParam2Options: DropdownOption[] = [
    { label: 'IgnBas_Advance', value: 'IgnBas_Advance' },
    { label: 'IgnOut_Advance', value: 'IgnOut_Advance' },
    { label: 'IgnTiming_Base', value: 'IgnTiming_Base' },
  ];

  selectedTestCondition: any = this.testConditions[0].value;
  selectedSpeed: number = 1600;
  selectedLoad: number = 15;
  deltaIgtParam1: string = 'IgnOut_Advance';
  deltaIgtParam2: string = 'IgnBas_Advance';

  constructor() {}

  ngOnInit(): void {
    this.selectedSpeed = this.selectedTestCondition.speed;
    this.selectedLoad = this.selectedTestCondition.load;
  }

  ngAfterViewInit(): void {
    this.generateChart();
  }

  onTestConditionChange(): void {
    this.selectedSpeed = this.selectedTestCondition.speed;
    this.selectedLoad = this.selectedTestCondition.load;
    this.generateChart();
  }

  onSpeedChange(): void {
    this.selectedTestCondition.speed = this.selectedSpeed;
    this.generateChart();
  }

  onLoadChange(): void {
    this.selectedTestCondition.load = this.selectedLoad;
    this.generateChart();
  }

  onDeltaParam1Change(): void {
    this.generateChart();
  }

  onDeltaParam2Change(): void {
    this.generateChart();
  }

  generateChart(): void {
    if (!this.plotlyChart) return;

    // Sample data points for Delta IGT (degrees)
    const deltaIgt = [-15, -13, -11, -9, -7, -5, -3, -1, 1, 3, 5, 7, 9, 11, 13, 15];

    // Generate sample data for IgnOut_Advance (blue line)
    const ignOutAdvance = deltaIgt.map(x => 30.8 - (x * 0.8));

    // Generate sample data for IgnBas_Advance (red line) - IMEP50
    const ignBasAdvance = [22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,22.04,]

    // Generate sample data for IMFR50 (green line)
    const imfr50 = deltaIgt.map(x => {
      if (x < -10) return 0.6;
      if (x < 0) return 0.6 + (x + 10) * 0.015;
      if (x < 10) return 0.75 + x * 0.02;
      return 0.95;
    });

    // Generate sample data for TORQUE (black line with markers)
    const torque = deltaIgt.map(x => {
      const peak = 10;
      return peak - Math.pow((x - peak) / 15, 2) * 3;
    });

    // Generate sample data for LAMBDA_METER (brown line)
    const lambdaMeter = [1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00]

    // Create triangle markers for knock events (downward triangles)
    const knockDeltaIgt = [-13, -11, -7, -3, 0, 3, 7, 10, 12, 14];
    const knockYPosition = knockDeltaIgt.map(x => {
      const idx = deltaIgt.indexOf(x);
      return idx >= 0 ? ignBasAdvance[idx] : 60;
    });

    // Helper function to get trend arrow (color will be set per line)
    const getTrendArrow = (current: number, previous: number) => {
      const diff = current - previous;
      const threshold = Math.abs(current) * 0.01; // 1% threshold for considering it flat
      
      if (diff > threshold) return '↗'; // Up arrow
      if (diff < -threshold) return '↘'; // Down arrow
      return '→'; // Flat arrow
    };

    // Create arrow annotations showing trends
    const annotations: Partial<Plotly.Annotations>[] = [];
    
    // Add trend arrows for ALL data points on all lines
    deltaIgt.forEach((x, idx) => {
      if (idx > 0) { // Skip first point since we need previous point for comparison
        
        // Add trend arrows for selected lines only (excluding IgnBas and LAMBDA_METER)
        const lineConfigs = [
          { data: ignOutAdvance, yref: 'y', size: 12, color: '#000000' },
          { data: imfr50, yref: 'y3', size: 12, color: '#4472C4' },
          { data: torque, yref: 'y4', size: 12, color: '#70AD47' }
        ];

        lineConfigs.forEach(config => {
          const current = config.data[idx];
          const previous = config.data[idx - 1];
          const arrow = getTrendArrow(current, previous);
          
          annotations.push({
            x: x,
            y: current,
            text: arrow,
            showarrow: false,
            font: { size: config.size, color: config.color, family: 'Arial', weight: 'bold' },
            xanchor: 'center',
            yanchor: 'middle',
            yref: config.yref
          });
        });
      }

    });

    // Add text annotations for key values at endpoints
    annotations.push(
      {
        x: 15,
        y: ignOutAdvance.at(-1) || 0,
        text: `${(ignOutAdvance.at(-1) || 0).toFixed(2)}`,
        showarrow: true,
        arrowhead: 2,
        arrowsize: 1,
        arrowwidth: 1,
        arrowcolor: '#000000',
        ax: 30,
        ay: 0,
        font: { size: 9, color: '#000000' },
        bgcolor: 'rgba(255, 255, 255, 0.8)',
        bordercolor: '#000000',
        borderwidth: 1,
        borderpad: 2,
        yref: 'y'
      }
    );

    const data: Plotly.Data[] = [
      // IgnOut_Advance (black line) - Left Y-axis 1
      {
        x: deltaIgt,
        y: ignOutAdvance,
        type: 'scatter',
        mode: 'lines+markers',
        name: `IgnOut_Advance: 0: 30.80`,
        line: { color: '#000000', width: 3 },
        marker: { size: 7, symbol: 'circle', color: '#000000' },
        yaxis: 'y'
      },
      // IgnBas_Advance (orange line) - Left Y-axis 2
      {
        x: deltaIgt,
        y: ignBasAdvance,
        type: 'scatter',
        mode: 'markers',
        name: `IgnBas_Advance_CNG: 22.04`,
        line: { color: '#8B3A0A', width: 3 },
        marker: { size: 10, symbol: 'triangle-down', color: '#8B3A0A' },
        yaxis: 'y2'
      },
      
      // MFB50 (blue line) - Right Y-axis 1
      {
        x: deltaIgt,
        y: imfr50,
        type: 'scatter',
        mode: 'lines+markers',
        name: 'MFB50_0: 0.603',
        line: { color: '#4472C4', width: 3 },
        marker: { size: 7, symbol: 'circle', color: '#4472C4' },
        yaxis: 'y3'
      },
      // TORQUE (green line with diamond markers) - Right Y-axis 2
      {
        x: deltaIgt,
        y: torque,
        type: 'scatter',
        mode: 'lines+markers',
        name: 'TORQUE: 10.24',
        line: { color: '#70AD47', width: 3 },
        marker: { size: 8, symbol: 'diamond', color: '#70AD47' },
        yaxis: 'y4'
      },
      // LAMBDA_METER (purple line) - Right Y-axis 3
      {
        x: deltaIgt,
        y: lambdaMeter,
        type: 'scatter',
        mode: 'markers',
        name: 'LAMBDA_METER: 1.00',
        line: { color: '#9966CC', width: 3 },
        marker: { size: 10, symbol: 'triangle-down', color: '#9966CC' },
        yaxis: 'y5'
      }
    ];

    const layout: Partial<Plotly.Layout> = {
      title: {
        text: `${this.selectedTestCondition.speed} RPM ${this.selectedTestCondition.load}% LOAD`,
        font: { size: 14, family: 'Arial' },
        x: 0.02,
        xanchor: 'left',
        y: 0.98,
        yanchor: 'top'
      },
      xaxis: {
        title: {
          text: 'Delta IGT (s)',
          font: { size: 11 }
        },
        gridcolor: '#E5E5E5',
        zeroline: true,
        zerolinecolor: '#999',
        zerolinewidth: 1,
        range: [-17, 17],
        showgrid: true,
  domain: [0.1, 0.9]
      },
      // Left Y-axis 1: IgnOut_Advance (black) - outer left
      yaxis: {
        title: {
          text: 'IgnOut_Advance_0',
          font: { color: '#000000', size: 10 }
        },
        tickfont: { color: '#000000', size: 9 },
        side: 'left',
        position: 0,
        range: [0, 40],
        showgrid: false,
        showticklabels: true,
        ticks: 'outside',
        ticklen: 5
      },
      // Left Y-axis 2: IgnBas_Advance (orange) - inner left
      yaxis2: {
        title: {
          text: 'IgnBas_Advance_CNG: 22.04',
          font: { color: '#ED7D31', size: 10 }
        },
        tickfont: { color: '#ED7D31', size: 9 },
        overlaying: 'y',
        side: 'left',
        position: 0.1,
        range: [0, 70],
        showgrid: false,
        showticklabels: true,
        ticks: 'outside',
        ticklen: 5
      },
      // Right Y-axis 1: MFB50 (blue) - inner right
      yaxis3: {
        title: {
          text: 'MFB50_0',
          font: { color: '#4472C4', size: 10 }
        },
        tickfont: { color: '#4472C4', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 0.9,
        range: [0.5, 1.2],
        showgrid: false,
        showticklabels: true,
        ticks: 'outside',
        ticklen: 5
      },
      // Right Y-axis 2: TORQUE (green) - middle right
      yaxis4: {
        title: {
          text: 'TORQUE',
          font: { color: '#70AD47', size: 10 }
        },
        tickfont: { color: '#70AD47', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 0.95,
        range: [8.2, 12],
        showgrid: false,
        showticklabels: true,
        ticks: 'outside',
        ticklen: 5
      },
      // Right Y-axis 3: LAMBDA_METER (purple) - outer right
      yaxis5: {
        title: {
          text: 'LAMBDA_METER',
          font: { color: '#9966CC', size: 10 }
        },
        tickfont: { color: '#9966CC', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 1,
        range: [0.98, 1.02],
        showgrid: false,
        showticklabels: true,
        ticks: 'outside',
        ticklen: 5
      },
      legend: {
        x: 0.5,
        y: 1.15,
        xanchor: 'center',
        yanchor: 'top',
        orientation: 'h',
        bgcolor: 'rgba(255, 255, 255, 0.95)',
        bordercolor: '#333333',
        borderwidth: 1,
        font: { size: 8, family: 'Arial' },
        itemsizing: 'constant',
        tracegroupgap: 6,
        itemwidth: 35,
        traceorder: 'normal'
      },
      hovermode: 'closest',
      showlegend: true,
      autosize: true,
      margin: { l: 60, r: 100, t: 120, b: 50 },
      plot_bgcolor: '#FFFFFF',
      paper_bgcolor: '#FFFFFF',
      // Add vertical lines for all data points and reference lines
      shapes: [
        // Existing red dashed line at x=10
        {
          type: 'line',
          x0: -.0,
          y0: 0,
          x1: -.0,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: 'black',
            width: 2,
            dash: 'solid'
          }
        },
        {
          type: 'line',
          x0: .1,
          y0: 0,
          x1: .1,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: '#E74C3C',
            width: 2,
            dash: 'solid'
          }
        },
        // Existing gray dotted line at x=0
        {
          type: 'line',
          x0: 0.9,
          y0: 0,
          x1: .9,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: '#4472C4',
            width: 2,
            dash: 'solid'
          }
        },
        // Vertical line near right side for TORQUE reference
        {
          type: 'line',
          x0: .95,
          y0: 0,
          x1: .95,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: '#70AD47',
            width: 2,
            dash: 'solid'
          }
        },
        {
          type: 'line',
          x0: .99,
          y0: 0,
          x1: .99,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: '#9966CC',
            width: 2,
            dash: 'solid'
          }
        },
        // Add vertical grid lines at all data points
        ...deltaIgt.map(x => ({
          type: 'line' as const,
          x0: x,
          x1: x,
          y0: 0,
          y1: 1,
          yref: 'paper' as const,
          line: {
            color: '#E0E0E0',
            width: 0.5,
            dash: 'dot' as const
          }
        }))
      ],
      annotations: annotations
    };

    const config: Partial<Plotly.Config> = {
      responsive: true,
      displayModeBar: true,
      displaylogo: false,
      modeBarButtonsToRemove: ['lasso2d', 'select2d'],
      toImageButtonOptions: {
        format: 'png',
        filename: `IGT_Report_${this.selectedTestCondition.speed}RPM_${this.selectedTestCondition.load}Load`,
        height: 800,
        width: 1200,
        scale: 2
      }
    };

    Plotly.newPlot(this.plotlyChart.nativeElement, data, layout, config);
  }

  downloadReport(format: string = 'pdf'): void {
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const filename = `IGT_Report_${this.selectedTestCondition.speed}RPM_${this.selectedTestCondition.load}Load_${timestamp}`;

    switch (format) {
      case 'pdf':
        alert(`Downloading IGT Report (PDF)...\nFilename: ${filename}.pdf\nThis feature will generate a comprehensive report with all test data and charts.`);
        break;
      
      case 'png':
        if (this.plotlyChart) {
          Plotly.downloadImage(this.plotlyChart.nativeElement, {
            format: 'png',
            filename: filename,
            height: 800,
            width: 1200,
            scale: 2
          });
        }
        break;
      
      case 'csv':
        this.downloadCSV(filename);
        break;
      
      case 'excel':
        alert(`Downloading IGT Data (Excel)...\nFilename: ${filename}.xlsx\nThis feature will export all chart data to Excel format.`);
        break;
      
      default:
        alert('Unsupported format selected.');
    }
  }

  private downloadCSV(filename: string): void {
    // Generate CSV data from the chart data
    const deltaIgt = [-15, -13, -11, -9, -7, -5, -3, -1, 1, 3, 5, 7, 9, 11, 13, 15];
    const ignOutAdvance = deltaIgt.map(x => 30.8 - (x * 0.8));
    const ignBasAdvance = Array(16).fill(22.04);
    const imfr50 = deltaIgt.map(x => {
      if (x < -10) return 0.6;
      if (x < 0) return 0.6 + (x + 10) * 0.015;
      if (x < 10) return 0.75 + x * 0.02;
      return 0.95;
    });
    const torque = deltaIgt.map(x => {
      const peak = 10;
      return peak - Math.pow((x - peak) / 15, 2) * 3;
    });
    const lambdaMeter = Array(16).fill(1.00);

    // Create CSV content
    let csvContent = 'Delta_IGT,IgnOut_Advance_0,IgnBas_Advance_CNG,MFB50_0,TORQUE,LAMBDA_METER\n';
    
    for (let i = 0; i < deltaIgt.length; i++) {
      csvContent += `${deltaIgt[i]},${ignOutAdvance[i].toFixed(3)},${ignBasAdvance[i]},${imfr50[i].toFixed(3)},${torque[i].toFixed(3)},${lambdaMeter[i]}\n`;
    }

    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }
}
