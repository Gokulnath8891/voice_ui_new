# IGT Chart - Quick Customization Guide

## 🎨 Common Customizations

### 1. Change Chart Colors

```typescript
// In igt-chart.component.ts, modify the data array

{
  name: 'Your Parameter',
  line: { color: '#YOUR_HEX_COLOR', width: 2 },
  marker: { size: 6, color: '#YOUR_HEX_COLOR' }
}
```

**Color Palette Reference:**
- Blue: `#4472C4` (Ignition)
- Red: `#ED7D31` (Timing)
- Green: `#70AD47` (Air-Fuel)
- Black: `#000000` (Torque)
- Brown: `#A5682A` (Lambda)

### 2. Add New Y-Axis

```typescript
// Add to layout configuration
yaxis5: {
  title: 'Your Parameter',
  titlefont: { color: '#YOUR_COLOR' },
  tickfont: { color: '#YOUR_COLOR' },
  overlaying: 'y',
  side: 'right',
  position: 1.05,  // Adjust position
  range: [min, max]
}

// Add corresponding data trace
{
  x: deltaIgt,
  y: yourData,
  name: 'Your Parameter',
  yaxis: 'y5'  // Reference the new axis
}
```

### 3. Modify Chart Title

```typescript
title: {
  text: `${rpm} RPM ${load}% LOAD - Custom Subtitle`,
  font: { 
    size: 20,      // Font size
    weight: 'bold',
    family: 'Arial'
  },
  xanchor: 'center',
  yanchor: 'top'
}
```

### 4. Add Custom Annotations

```typescript
// Add to annotations array in layout
{
  x: 5,              // X coordinate
  y: 30,             // Y coordinate
  text: 'Peak Performance',
  showarrow: true,
  arrowhead: 2,
  arrowsize: 1,
  arrowwidth: 2,
  arrowcolor: '#E74C3C',
  ax: 20,            // Arrow X offset
  ay: -40,           // Arrow Y offset
  font: {
    size: 12,
    color: '#E74C3C'
  },
  bgcolor: 'rgba(255, 255, 255, 0.8)',
  bordercolor: '#E74C3C',
  borderwidth: 2,
  borderpad: 4
}
```

### 5. Add Horizontal/Vertical Lines

```typescript
// Add to shapes array in layout

// Horizontal line
{
  type: 'line',
  x0: -15,
  x1: 15,
  y0: 35,    // Y position
  y1: 35,
  line: {
    color: 'rgba(255, 0, 0, 0.5)',
    width: 2,
    dash: 'dot'  // 'solid', 'dot', 'dash', 'dashdot'
  }
}

// Vertical line
{
  type: 'line',
  x0: 0,     // X position
  x1: 0,
  y0: 0,
  y1: 1,
  yref: 'paper',  // Use paper coordinates
  line: {
    color: 'rgba(0, 0, 255, 0.5)',
    width: 2,
    dash: 'dash'
  }
}
```

### 6. Add Shaded Regions

```typescript
// Add to shapes array
{
  type: 'rect',
  x0: 5,
  x1: 15,
  y0: 0,
  y1: 1,
  yref: 'paper',
  fillcolor: 'rgba(255, 0, 0, 0.1)',
  line: { width: 0 },
  layer: 'below'  // 'below' or 'above' traces
}
```

### 7. Customize Markers

```typescript
marker: {
  size: 8,
  symbol: 'circle',  // Options: circle, square, diamond, cross, x, 
                     // triangle-up, triangle-down, star, pentagon
  color: '#4472C4',
  line: {
    color: '#000000',
    width: 1
  }
}
```

### 8. Add Multiple Traces

```typescript
// Example: Add confidence bands
const data: Plotly.Data[] = [
  // Main line
  {
    x: deltaIgt,
    y: mainData,
    name: 'Measured',
    mode: 'lines',
    line: { color: '#4472C4', width: 3 }
  },
  // Upper bound
  {
    x: deltaIgt,
    y: upperBound,
    name: 'Upper Bound',
    mode: 'lines',
    line: { color: '#4472C4', width: 1, dash: 'dash' },
    showlegend: false
  },
  // Lower bound
  {
    x: deltaIgt,
    y: lowerBound,
    name: 'Lower Bound',
    mode: 'lines',
    line: { color: '#4472C4', width: 1, dash: 'dash' },
    fill: 'tonexty',  // Fill to previous trace
    fillcolor: 'rgba(68, 114, 196, 0.2)',
    showlegend: false
  }
];
```

### 9. Customize Hover Information

```typescript
{
  x: deltaIgt,
  y: data,
  hovertemplate: '<b>%{fullData.name}</b><br>' +
                 'Delta IGT: %{x}°<br>' +
                 'Value: %{y:.2f}<br>' +
                 '<extra></extra>',
  hoverlabel: {
    bgcolor: '#FFF',
    bordercolor: '#333',
    font: { size: 12, family: 'Arial' }
  }
}
```

### 10. Adjust Legend Position

```typescript
legend: {
  x: 0.5,           // 0 = left, 1 = right
  y: 1.15,          // >1 = above chart
  xanchor: 'center', // 'left', 'center', 'right'
  yanchor: 'bottom', // 'top', 'middle', 'bottom'
  orientation: 'horizontal', // or 'vertical'
  bgcolor: 'rgba(255, 255, 255, 0.9)',
  bordercolor: '#999',
  borderwidth: 1,
  font: {
    size: 11,
    family: 'Arial'
  }
}
```

## 📊 Chart Type Examples

### Line Chart with Markers
```typescript
mode: 'lines+markers'
```

### Scatter Plot Only
```typescript
mode: 'markers'
```

### Area Chart
```typescript
mode: 'lines',
fill: 'tozeroy'  // or 'tonexty'
```

### Bar Chart
```typescript
type: 'bar',
marker: { color: '#4472C4' }
```

## 🎯 Pro Tips

1. **Layer Control**: Use `layer: 'below'` in shapes to place them behind traces
2. **Performance**: Limit data points to ~1000 for smooth interaction
3. **Colors**: Use `rgba()` for transparency effects
4. **Responsive**: Set `autosize: true` in config
5. **Download**: Customize filename in `toImageButtonOptions`

## 📱 Responsive Breakpoints

```scss
// Desktop (default)
@media (min-width: 1025px) { }

// Tablet
@media (max-width: 1024px) { }

// Mobile
@media (max-width: 768px) { }
```

## 🔗 Useful Links

- [Plotly.js Documentation](https://plotly.com/javascript/)
- [Plotly Color Scales](https://plotly.com/javascript/colorscales/)
- [Marker Symbols](https://plotly.com/javascript/reference/scatter/#scatter-marker-symbol)
- [Line Dash Styles](https://plotly.com/javascript/line-charts/)

---

**Need more help?** Check the full component code in `src/app/igt-chart/igt-chart.component.ts`
