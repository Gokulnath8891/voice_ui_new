# IGT Chart Component - POC

This is a Proof of Concept (POC) project for visualizing Ignition, Timing, and Air-Fuel Ratio data using Plotly.js in Angular.

## 🚀 Features

### Interactive IGT Chart
- **Multiple Y-Axes**: Displays up to 4 different parameters simultaneously
  - IgnOut_Advance (°) - Blue line
  - IgnBas_Advance (IMEP50) - Red line
  - IMFR50 - Green line
  - TORQUE - Black line with diamond markers
  - LAMBDA_METER - Brown line

### Advanced Chart Features
- ✅ **Interactive Controls**: Zoom, pan, and hover for detailed data points
- ✅ **Knock Event Indicators**: Downward triangles (▼) showing knock occurrences
- ✅ **Annotations**: Optimal point markers for easy identification
- ✅ **Vertical Reference Lines**: Dashed lines for key reference points
- ✅ **Export Functionality**: Download charts as PNG images
- ✅ **Responsive Design**: Works on desktop, tablet, and mobile devices

### User Controls
- **Test Condition Selection**: Choose from multiple test configurations
- **Speed Selection**: 1600, 2000, 2400, 2800, 3200 RPM
- **Load Selection**: 15%, 25%, 35%, 45%, 55%
- **Delta IGT Parameters**: Customize X-axis definition with two parameters

## 📦 Technologies Used

- **Angular 18**: Modern standalone components
- **Plotly.js**: Advanced charting library
- **TypeScript**: Type-safe development
- **SCSS**: Styled with modern CSS features
- **PrimeNG**: UI component library (available for future enhancements)

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd poc_temp
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the development server**
   ```bash
   npm run start-local
   ```

4. **Open your browser**
   Navigate to `https://localhost:9500/`

## 📁 Project Structure

```
src/app/
├── igt-chart/                    # IGT Chart Component
│   ├── igt-chart.component.ts    # Component logic with Plotly integration
│   ├── igt-chart.component.html  # Template with controls
│   ├── igt-chart.component.scss  # Styles
│   └── igt-chart.component.spec.ts # Unit tests
├── app.component.ts              # Root component
├── app.component.html            # Root template
├── app.component.scss            # Root styles
├── app.config.ts                 # App configuration
└── app.routes.ts                 # Routing configuration
```

## 🎨 Chart Customization

### Adding More Data Points
Edit `igt-chart.component.ts` and modify the sample data generation:

```typescript
// Example: Add more delta IGT points
const deltaIgt = [-20, -18, -15, ..., 15, 18, 20];

// Adjust the corresponding Y-axis data
const ignOutAdvance = deltaIgt.map(x => /* your formula */);
```

### Modifying Chart Layout
The chart layout is fully customizable through Plotly's configuration:

```typescript
const layout: Partial<Plotly.Layout> = {
  title: 'Your Custom Title',
  xaxis: { /* X-axis config */ },
  yaxis: { /* Y-axis config */ },
  // Add more axes as needed
};
```

### Adding Annotations
```typescript
annotations: [
  {
    x: 10,
    y: 1.05,
    text: 'Your annotation',
    showarrow: true,
    arrowhead: 2
  }
]
```

### Adding Shapes (Lines, Rectangles)
```typescript
shapes: [
  {
    type: 'line',
    x0: 5, x1: 5,
    y0: 0, y1: 1,
    line: { color: 'red', dash: 'dot' }
  }
]
```

## 🔧 Available Scripts

- `npm run start-local` - Start development server
- `npm run build-dev` - Build for development
- `npm run build-prod` - Build for production
- `npm run test` - Run unit tests
- `npm run test-coverage` - Run tests with coverage
- `npm run lint-local` - Run linter and fix issues
- `npm run e2e-local` - Run end-to-end tests

## 📊 Sample Data

The component currently uses generated sample data that simulates:
- Ignition timing advance curves
- Air-fuel ratio measurements
- Torque curves with optimal points
- Knock event patterns
- Lambda sensor readings

**To use real data**: Replace the sample data generation in `generateChart()` with API calls or file imports.

## 🎯 Future Enhancements

- [ ] Connect to real data sources (API/Database)
- [ ] Add more test conditions and parameters
- [ ] Export to Excel/CSV functionality
- [ ] Historical data comparison
- [ ] Real-time data streaming
- [ ] Advanced filtering and search
- [ ] User preferences and saved views
- [ ] Multi-language support

## 🐛 Known Issues

- Some TypeScript linting warnings (non-blocking)
- Ghost errors from deleted app.module.ts (will clear on next build)

## 📱 Responsive Design

The chart is fully responsive and adapts to:
- **Desktop**: Full feature set with side-by-side layout
- **Tablet**: Stacked layout with adjusted chart size
- **Mobile**: Vertical layout with optimized touch interactions

## 🤝 Contributing

This is a POC project. For any improvements or suggestions:
1. Create a feature branch
2. Make your changes
3. Test thoroughly
4. Submit a pull request

## 📄 License

This project is for POC purposes.

## 👨‍💻 Developer Notes

### Plotly.js Integration
- Using `plotly.js-dist-min` for smaller bundle size
- TypeScript types included via `@types/plotly.js`
- Charts are redrawn on control changes for optimal performance

### Performance Considerations
- Chart rendering is optimized with `Plotly.newPlot()`
- Data points are limited to reasonable ranges
- Responsive resizing is handled automatically

### Browser Compatibility
- Chrome/Edge: ✅ Full support
- Firefox: ✅ Full support
- Safari: ✅ Full support
- IE11: ❌ Not supported (requires polyfills)

## 📞 Support

For questions or issues, please contact the development team.

---

**Last Updated**: January 11, 2026
**Version**: 1.0.0-POC
