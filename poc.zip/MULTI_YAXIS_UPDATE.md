# Multi Y-Axis Chart Update

## ✅ Changes Implemented

### Y-Axis Configuration

The chart now displays **5 separate Y-axes** matching your reference image:

#### Left Side (2 axes):
1. **IgnOut_Advance_0** (Blue - #4472C4)
   - Range: 0-40
   - Position: Left side
   - Label: "IgnOut_Advance_0"

2. **IgnBas_Advance_CNG: 22.04** (Orange - #ED7D31)
   - Range: 0-70
   - Position: Left side (overlaid)
   - Label: "IgnBas_Advance_CNG: 22.04"
   - Shows knock event markers (▼)

#### Right Side (3 axes):
3. **MFB50_0: 0.603** (Green - #70AD47)
   - Range: 0.5-1.0
   - Position: Right side
   - Label: "MFB50_0: 0.603"

4. **TORQUE: 10.24** (Black - #000000)
   - Range: 8-12
   - Position: Right side (overlaid)
   - Label: "TORQUE: 10.24"
   - Shows trend arrows (↑↓)

5. **LAMBDA_METER: 1.00** (Purple - #9966CC)
   - Range: 0.7-1.1
   - Position: Right side (overlaid)
   - Label: "LAMBDA_METER: 1.00"

### Visual Features

✅ **All Y-axis labels visible** on left and right sides
✅ **Color-coded labels** matching line colors
✅ **Proper axis spacing** with margins (L:80, R:80)
✅ **Multiple overlaid axes** using Plotly's axis anchoring
✅ **Grid lines disabled** for clarity (only X-axis grid visible)
✅ **Smaller font sizes** (10-11px) for compact display
✅ **Knock event markers** (▼) on IgnBas_Advance axis
✅ **Trend arrows** (↑↓→) on TORQUE line
✅ **Annotations** with connecting arrows
✅ **Reference lines** at x=0 and x=10

### Legend

- Positioned at top-center
- Shows all 5 traces with current values
- Horizontal orientation
- Semi-transparent background

### Data Traces

Each trace is now properly assigned to its corresponding Y-axis:
- `yaxis: 'y'` → IgnOut_Advance
- `yaxis: 'y2'` → IgnBas_Advance  
- `yaxis: 'y3'` → MFB50
- `yaxis: 'y4'` → TORQUE
- `yaxis: 'y5'` → LAMBDA_METER

## 📊 How It Looks

The chart now matches your reference image with:
- Blue and Orange lines on the left
- Green, Black, and Purple lines on the right
- All Y-axis titles visible and color-coded
- Clean, professional appearance
- Multiple scales properly aligned

## 🎯 Result

You now have a fully functional multi-axis chart that displays:
- **2 left Y-axes** for ignition parameters
- **3 right Y-axes** for performance metrics
- All axes properly labeled and color-coded
- Interactive zoom, pan, and hover features
- Trend indicators and annotations

The chart replicates the style and functionality of your reference image!
