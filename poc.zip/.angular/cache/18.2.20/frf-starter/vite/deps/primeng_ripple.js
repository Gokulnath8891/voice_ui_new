import {
  Ripple,
  RippleModule
} from "./chunk-G5GOPBJM.js";
import "./chunk-BUGEQH7Q.js";
import "./chunk-2Q4EFRBL.js";
import "./chunk-3OF44R55.js";
import "./chunk-JIQKDRPZ.js";
import "./chunk-5UHPBBN3.js";
import "./chunk-HM5YLMWO.js";
import "./chunk-3OV72XIM.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
