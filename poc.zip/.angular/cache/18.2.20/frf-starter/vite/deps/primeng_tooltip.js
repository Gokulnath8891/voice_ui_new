import {
  Tooltip,
  TooltipModule
} from "./chunk-6PXE43MZ.js";
import "./chunk-BUGEQH7Q.js";
import "./chunk-2Q4EFRBL.js";
import "./chunk-3OF44R55.js";
import "./chunk-JIQKDRPZ.js";
import "./chunk-5UHPBBN3.js";
import "./chunk-HM5YLMWO.js";
import "./chunk-3OV72XIM.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
