import {
  InputText,
  InputTextModule
} from "./chunk-TLYNU6W5.js";
import "./chunk-J6LOXFID.js";
import "./chunk-2Q4EFRBL.js";
import "./chunk-3OF44R55.js";
import "./chunk-JIQKDRPZ.js";
import "./chunk-5UHPBBN3.js";
import "./chunk-HM5YLMWO.js";
import "./chunk-3OV72XIM.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
