# Django API Endpoints - Complete Analysis for Angular Migration

## Overview
This document provides a comprehensive analysis of all Django REST API endpoints currently used by the Dash application (`voice_assistant_dash_app.py`). These endpoints are ready to be consumed by an Angular frontend application.

**Base URL:** `http://localhost:8000/api`

---

## 📋 API Endpoints Summary

### 1. Authentication Endpoints

#### **POST** `/api/login/`
**Purpose:** User authentication and role identification

**Request:**
```json
{
  "username": "string",
  "password": "string"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "user": {
    "id": 1,
    "username": "john_smith",
    "first_name": "John",
    "last_name": "Smith",
    "role": "technician"  // or "service_manager"
  }
}
```

**Response (401 Unauthorized):**
```json
{
  "error": "Invalid credentials"
}
```

**Angular Usage:**
- Used for login form submission
- Store user data and role in Angular service/state management
- Use role to determine which dashboard to display
- Token-based auth can be added later (JWT)

---

### 2. Technician Work Orders

#### **GET** `/api/technician/workorders/`
**Purpose:** Get top 10 work orders assigned to the logged-in technician

**Query Parameters:**
- `user_id` (required): The technician's user ID

**Example:** `GET /api/technician/workorders/?user_id=1`

**Response (200 OK):**
```json
{
  "work_orders": [
    {
      "id": 101,
      "order_number": "WO-2024-001",
      "title": "Oil Change Service",
      "description": "Routine oil change and filter replacement",
      "status": "IN_PROGRESS",  // PENDING, ASSIGNED, IN_PROGRESS, COMPLETED
      "priority": "MEDIUM",      // LOW, MEDIUM, HIGH, URGENT
      "customer_name": "John Doe",
      "vehicle": "2020 Toyota Camry",
      "created_at": "2024-11-19T10:30:00Z",
      "estimated_hours": 2.5,
      "actual_hours": 1.8,
      "progress": 65.0,          // Percentage (0-100)
      "total_steps": 8,
      "completed_steps": 5
    }
  ]
}
```

**Angular Usage:**
- Display work order cards/list for technicians
- Show progress bars using `progress` field
- Filter by status (active vs completed tabs)
- Sort by priority or date
- Click on card to start work order workflow

---

### 3. Manager Work Orders

#### **GET** `/api/manager/workorders/`
**Purpose:** Get work orders for service manager dashboard with filtering

**Query Parameters:**
- `user_id` (required): The service manager's user ID
- `status` (optional): Filter by status
  - Values: `all`, `pending`, `assigned`, `in_progress`, `completed`
  - Default: `all`

**Example:** `GET /api/manager/workorders/?user_id=2&status=in_progress`

**Response (200 OK):**
```json
{
  "work_orders": [
    {
      "id": 101,
      "order_number": "WO-2024-001",
      "title": "Oil Change Service",
      "description": "Routine oil change and filter replacement",
      "status": "IN_PROGRESS",
      "priority": "MEDIUM",
      "customer_name": "John Doe",
      "vehicle": "2020 Toyota Camry",
      "technician_name": "Alex Wilson",
      "created_at": "2024-11-19T10:30:00Z",
      "estimated_hours": 2.5,
      "actual_hours": 1.8,
      "progress": 65.0,
      "total_steps": 8,
      "completed_steps": 5,
      "steps": [
        {
          "step_number": 1,
          "title": "Prepare Vehicle",
          "is_completed": true,
          "completed_at": "2024-11-19T10:35:00Z"
        },
        {
          "step_number": 2,
          "title": "Drain Oil",
          "is_completed": true,
          "completed_at": "2024-11-19T10:45:00Z"
        },
        {
          "step_number": 3,
          "title": "Replace Oil Filter",
          "is_completed": false,
          "completed_at": null
        }
      ]
    }
  ]
}
```

**Angular Usage:**
- Display filtered work order lists for managers
- Show filter buttons (All, Pending, Assigned, In Progress, Completed)
- Display detailed step-by-step progress
- Monitor technician performance

---

### 4. Chat Query Processing

#### **POST** `/api/chat/query/`
**Purpose:** Process chat queries and start work order workflows

**Request:**
```json
{
  "query": "work order WO-2024-001",
  "user_id": 1,
  "type": "text"  // or "voice"
}
```

**Response Types:**

**A) Work Order Start (200 OK):**
```json
{
  "type": "work_order_start",
  "session_id": "wo_101_1_abc123",
  "work_order": {
    "id": 101,
    "order_number": "WO-2024-001",
    "title": "Oil Change Service",
    "vehicle": "2020 Toyota Camry",
    "total_steps": 8
  },
  "current_step": {
    "step_number": 1,
    "title": "Prepare Vehicle",
    "description": "Park vehicle on level ground. Engage parking brake. Open hood.",
    "estimated_time": 0.25
  },
  "message": "Starting work order WO-2024-001. Step 1: Prepare Vehicle",
  "instruction": "Park vehicle on level ground. Engage parking brake. Open hood.",
  "tts_text": "Step 1 of 8: Prepare Vehicle. Park vehicle on level ground..."
}
```

**B) General Query Response (200 OK):**
```json
{
  "type": "simple_response",
  "message": "Based on the maintenance documentation, here is the answer to your query..."
}
```

**C) Error Response (200 OK):**
```json
{
  "type": "error",
  "message": "Work order WO-2024-999 not found"
}
```

**Special Commands:**
- `"work order WO-XXX"` - Start work order
- `"start over WO-XXX"` - Reset and restart work order
- `"resume WO-XXX"` - Resume from last incomplete step
- General queries - Get maintenance information

**Angular Usage:**
- Chatbot interface for voice/text queries
- Start work order workflow
- Display step-by-step instructions
- Handle resume/restart functionality
- Show error messages appropriately

---

### 5. Session Feedback Processing

#### **POST** `/api/chat/feedback/`
**Purpose:** Submit step completion feedback and advance to next step

**Request:**
```json
{
  "session_id": "wo_101_1_abc123",
  "feedback": "Completed draining old oil. Oil was dark and needed replacement.",
  "user_id": 1
}
```

**Response Types:**

**A) Next Step (200 OK):**
```json
{
  "type": "next_step",
  "current_step": {
    "step_number": 3,
    "title": "Replace Oil Filter",
    "description": "Remove old oil filter using filter wrench. Clean mounting surface...",
    "estimated_time": 0.5
  },
  "message": "Step completed successfully! Moving to next step.",
  "tts_text": "Step 3 of 8: Replace Oil Filter. Remove old oil filter...",
  "progress": {
    "completed": 2,
    "total": 8,
    "percentage": 25.0
  }
}
```

**B) Work Order Complete (200 OK):**
```json
{
  "type": "complete",
  "message": "🎉 Work order WO-2024-001 completed successfully!",
  "tts_text": "Congratulations! Work order completed successfully.",
  "total_steps": 8,
  "total_time": 2.3,
  "estimated_time": 2.5,
  "time_variance": -0.2  // Negative means under estimate (good!)
}
```

**C) Error Response (200 OK):**
```json
{
  "type": "error",
  "message": "Session not found or has expired"
}
```

**Angular Usage:**
- Submit step completion feedback
- Display next step instructions
- Show progress bar updates
- Display completion summary with time tracking
- Handle session errors

---

### 6. Voice Commands List

#### **GET** `/api/voice/commands/`
**Purpose:** Get list of available voice commands and their descriptions

**Response (200 OK):**
```json
{
  "commands": [
    {
      "command": "work order [number]",
      "description": "Start a specific work order",
      "example": "work order WO-2024-001"
    },
    {
      "command": "step complete",
      "description": "Mark current step as complete",
      "example": "step complete"
    },
    {
      "command": "what is my next task",
      "description": "Get next work order or step",
      "example": "what is my next task"
    }
  ]
}
```

**Angular Usage:**
- Display help/command reference
- Voice command auto-complete
- User guidance

---

### 7. Voice Proxy Initialization

#### **GET** `/api/voice/init/`
**Purpose:** Initialize voice proxy system for voice command mapping

**Query Parameters:**
- `user_id` (required): User ID for context

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Voice proxy initialized successfully"
}
```

**Angular Usage:**
- Call on app initialization for voice-enabled users
- Enables voice-to-work-order mapping

---

### 8. Work Order Feedback History

#### **GET** `/api/workorder/{work_order_id}/feedback/`
**Purpose:** Get complete feedback history for a work order

**Example:** `GET /api/workorder/101/feedback/`

**Response (200 OK):**
```json
{
  "success": true,
  "work_order_id": 101,
  "work_order_number": "WO-2024-001",
  "feedback_history": [
    {
      "step_number": 1,
      "feedback": "Vehicle prepared and ready for service",
      "time_spent": 0.25,
      "submitted_at": "2024-11-19T10:35:00Z",
      "user_id": 1
    },
    {
      "step_number": 2,
      "feedback": "Completed draining old oil. Oil was dark...",
      "time_spent": 0.5,
      "submitted_at": "2024-11-19T10:45:00Z",
      "user_id": 1
    }
  ]
}
```

**Angular Usage:**
- Display detailed work order history
- Show technician feedback for each step
- Time tracking per step
- Quality assurance review

---

### 9. Reset Work Order

#### **POST** `/api/workorder/reset/`
**Purpose:** Reset a completed work order back to ASSIGNED status

**Request:**
```json
{
  "work_order_number": "WO-2024-001",
  "user_id": 1
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Work order WO-2024-001 has been reset to ASSIGNED status",
  "work_order_number": "WO-2024-001",
  "new_status": "ASSIGNED"
}
```

**Response (400 Bad Request):**
```json
{
  "error": "Only completed work orders can be reset"
}
```

**Angular Usage:**
- Reset button on completed work orders
- Training/demo purposes
- Rework scenarios

---

## 🔐 Authentication & Authorization

**Current Implementation:**
- Username/password authentication via `/api/login/`
- User role returned in login response (technician or service_manager)
- User ID passed as query parameter or in request body

**Recommended Angular Implementation:**
1. Use Angular HTTP Interceptor for adding user credentials
2. Store user session in Angular service (state management)
3. Implement route guards based on user role
4. Add JWT token authentication (future enhancement)

**Example Angular Auth Service:**
```typescript
export class AuthService {
  private currentUser: BehaviorSubject<User | null>;
  
  login(username: string, password: string): Observable<User> {
    return this.http.post<LoginResponse>(`${API_BASE_URL}/login/`, {
      username,
      password
    }).pipe(
      map(response => response.user),
      tap(user => this.currentUser.next(user))
    );
  }
  
  getUserRole(): 'technician' | 'service_manager' | null {
    return this.currentUser.value?.role || null;
  }
}
```

---

## 🔄 Workflow States

### Work Order Status Values:
- `PENDING` - Not yet assigned
- `ASSIGNED` - Assigned to technician
- `IN_PROGRESS` - Work started
- `COMPLETED` - All steps finished

### Priority Values:
- `LOW`
- `MEDIUM`
- `HIGH`
- `URGENT`

### Session Workflow:
1. User logs in → `/api/login/`
2. Load work orders → `/api/technician/workorders/` or `/api/manager/workorders/`
3. Start work order → `/api/chat/query/` with "work order WO-XXX"
4. Complete each step → `/api/chat/feedback/` with feedback text
5. Repeat step 4 until all steps complete
6. View history → `/api/workorder/{id}/feedback/`

---

## 📊 Data Models

### User Object:
```typescript
interface User {
  id: number;
  username: string;
  first_name: string;
  last_name: string;
  role: 'technician' | 'service_manager';
}
```

### Work Order Object:
```typescript
interface WorkOrder {
  id: number;
  order_number: string;
  title: string;
  description: string;
  status: 'PENDING' | 'ASSIGNED' | 'IN_PROGRESS' | 'COMPLETED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  customer_name: string;
  vehicle: string;
  technician_name?: string;  // Only for managers
  created_at: string;  // ISO 8601 format
  estimated_hours: number;
  actual_hours: number;
  progress: number;  // 0-100
  total_steps: number;
  completed_steps: number;
  steps?: WorkOrderStep[];  // Only for managers
}
```

### Work Order Step Object:
```typescript
interface WorkOrderStep {
  step_number: number;
  title: string;
  description?: string;
  estimated_time?: number;
  is_completed: boolean;
  completed_at: string | null;  // ISO 8601 format
}
```

### Chat Session Object:
```typescript
interface ChatSession {
  session_id: string;
  work_order: {
    id: number;
    order_number: string;
    title: string;
    vehicle: string;
    total_steps: number;
  };
  current_step: WorkOrderStep;
}
```

---

## 🎯 Angular Component Mapping

### 1. Login Component
- **Endpoint:** `POST /api/login/`
- **Features:** Username/password form, role-based routing

### 2. Technician Dashboard Component
- **Endpoint:** `GET /api/technician/workorders/`
- **Features:** Work order cards, tabs (active/completed), progress bars

### 3. Manager Dashboard Component
- **Endpoint:** `GET /api/manager/workorders/`
- **Features:** Filtered work order lists, status buttons, detailed views

### 4. Chat/Workflow Component
- **Endpoints:** 
  - `POST /api/chat/query/`
  - `POST /api/chat/feedback/`
- **Features:** Chat interface, step-by-step instructions, voice/text input

### 5. Work Order Detail Component
- **Endpoint:** `GET /api/workorder/{id}/feedback/`
- **Features:** Feedback history, time tracking, step details

### 6. Work Order Card Component
- **Used in:** Dashboard components
- **Features:** Display work order summary, progress bar, action buttons

---

## 🚀 API Testing Recommendations

### Using Postman/Thunder Client:

**1. Login:**
```bash
POST http://localhost:8000/api/login/
Content-Type: application/json

{
  "username": "john_smith",
  "password": "demo123"
}
```

**2. Get Technician Work Orders:**
```bash
GET http://localhost:8000/api/technician/workorders/?user_id=1
```

**3. Start Work Order:**
```bash
POST http://localhost:8000/api/chat/query/
Content-Type: application/json

{
  "query": "work order WO-2024-001",
  "user_id": 1,
  "type": "text"
}
```

**4. Submit Feedback:**
```bash
POST http://localhost:8000/api/chat/feedback/
Content-Type: application/json

{
  "session_id": "wo_101_1_abc123",
  "feedback": "Step completed successfully",
  "user_id": 1
}
```

---

## 🔧 CORS Configuration

Ensure Django is configured to allow Angular frontend requests:

```python
# settings.py
INSTALLED_APPS = [
    'corsheaders',
    ...
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    ...
]

CORS_ALLOWED_ORIGINS = [
    "http://localhost:4200",  # Angular default dev server
]

# For development only:
CORS_ALLOW_ALL_ORIGINS = True
```

---

## 📝 Notes for Angular Development

1. **Error Handling:** All endpoints return JSON error objects. Implement global error interceptor in Angular.

2. **Loading States:** Work orders can take time to generate tasks. Show loading indicators.

3. **Real-time Updates:** Consider implementing WebSocket or polling for live work order status updates.

4. **Offline Support:** Cache work order data for offline access using Angular Service Worker.

5. **Voice Integration:** The current system supports voice commands. Integrate Web Speech API in Angular for voice input.

6. **Progress Tracking:** Use `progress`, `completed_steps`, and `total_steps` fields to show visual progress indicators.

7. **Time Tracking:** Display estimated vs actual hours for performance monitoring.

8. **Session Management:** Store `session_id` when starting work order workflow. Include in all feedback submissions.

---

## 🎨 UI/UX Recommendations

1. **Dashboard Cards:** Display work orders as cards with:
   - Priority badge (color-coded)
   - Status indicator
   - Progress bar
   - Vehicle and customer info
   - Action buttons (Start, Resume, View Details)

2. **Chat Interface:** 
   - Sliding panel or modal
   - Message history
   - Voice button for speech input
   - Text input field
   - Auto-scroll to latest message

3. **Step Instructions:**
   - Clear step numbering
   - Expandable details
   - Completion checkbox
   - Feedback text area
   - Timer/duration tracking

4. **Manager View:**
   - Sortable table or grid
   - Filter chips
   - Export functionality
   - Drill-down to technician details

---

## ✅ API Checklist for Angular Team

- [ ] Set up Angular HTTP Client service
- [ ] Create TypeScript interfaces for all data models
- [ ] Implement authentication service with login/logout
- [ ] Create HTTP interceptor for error handling
- [ ] Implement route guards for role-based access
- [ ] Build work order service for CRUD operations
- [ ] Create chat/workflow service for session management
- [ ] Set up state management (NgRx/Akita) if needed
- [ ] Configure CORS in Django backend
- [ ] Test all endpoints with actual API calls
- [ ] Implement loading and error states
- [ ] Add success/error notifications (toast/snackbar)

---

## 📚 Additional Resources

- Django REST Framework: https://www.django-rest-framework.org/
- Angular HttpClient: https://angular.io/guide/http
- TypeScript Interfaces: https://www.typescriptlang.org/docs/handbook/interfaces.html

---

**Document Version:** 1.0  
**Last Updated:** November 19, 2025  
**Contact:** Backend Development Team
