# Azure OpenAI 403 Error - Network Restriction Issue

## Problem

```
403 Client Error: Forbidden
{"error":{"code":"403","message": "Access denied due to Virtual Network/Firewall rules."}}
```

## Root Cause

Your Azure OpenAI resource has **network security restrictions** enabled. Your current IP address is not in the allowlist.

---

## Solution Options

### Option 1: Add Your IP to Azure Firewall Allowlist (Recommended for Dev)

1. **Go to Azure Portal**
   - Navigate to: https://portal.azure.com

2. **Find Your Azure OpenAI Resource**
   - Search for: `voice-assitant-openai`
   - Click on the resource

3. **Open Networking Settings**
   - In the left menu, find **"Networking"** under "Resource Management"
   - Click on it

4. **Add Your IP Address**
   - Under "Firewall", click **"Add client IP"** 
   - OR manually add your IP address
   - Click **"Save"**

5. **Wait 2-3 minutes** for the rules to propagate

6. **Test Again**
   ```bash
   python test_azure_openai.py
   ```

---

### Option 2: Disable Firewall (Dev/Testing Only)

⚠️ **Warning:** Only do this in development environments!

1. Go to Azure Portal → Your OpenAI Resource → **Networking**
2. Under "Firewalls and virtual networks", select:
   - ✅ **"Allow access from all networks"**
3. Click **"Save"**
4. Wait 2-3 minutes
5. Test again

---

### Option 3: Use VPN (Corporate Environment)

If this is a corporate resource:
1. Connect to your company VPN
2. Your VPN IP should already be in the allowlist
3. Test again

---

## How to Find Your Current IP Address

### Windows PowerShell
```powershell
(Invoke-WebRequest -Uri "https://api.ipify.org").Content
```

### Alternative (Browser)
Visit: https://whatismyipaddress.com/

---

## After Fixing Network Access

Once you've added your IP to the allowlist, test the connection:

```bash
# Test Azure OpenAI connection
python test_azure_openai.py

# If successful, start Django server
python manage.py runserver

# Test the Agentic RAG endpoint
curl -X POST http://localhost:8000/api/agentic-rag/query/ \
  -H "Content-Type: application/json" \
  -d '{"query": "How do I replace brake pads?"}'
```

---

## Verification Steps

✅ **Successful Connection:**
```
Status Code: 200
✅ SUCCESS!
Response: Hello, connection successful!
```

❌ **Still Blocked:**
```
Status Code: 403
❌ FAILED!
Response: Access denied due to Virtual Network/Firewall rules
```

If still blocked after adding your IP:
- Wait a few minutes for Azure to propagate changes
- Double-check the IP address you added
- Ensure you clicked "Save" in Azure Portal
- Try disabling any proxy/VPN that might change your IP

---

## Alternative: Use Environment Variable for Different Endpoints

If you have multiple Azure OpenAI resources (dev/prod), update the `.env` file:

```env
# Development (no firewall)
AZURE_OPENAI_ENDPOINT=https://your-dev-openai.openai.azure.com
AZURE_OPENAI_KEY=your_dev_key

# Production (with firewall)
# AZURE_OPENAI_ENDPOINT=https://voice-assitant-openai.openai.azure.com
# AZURE_OPENAI_KEY=your_prod_key
```

Then update `agentic_rag/service.py` to read from environment:

```python
import os
from dotenv import load_dotenv

load_dotenv()

AZURE_OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT', 'https://voice-assitant-openai.openai.azure.com')
AZURE_OPENAI_API_KEY = os.getenv('AZURE_OPENAI_KEY')
```

---

## Quick Fix Command (Get Your IP)

```powershell
# Get your public IP
$myIP = (Invoke-WebRequest -Uri "https://api.ipify.org").Content
Write-Host "Your IP: $myIP"
Write-Host "Add this IP to Azure OpenAI Firewall allowlist"
```

---

## Need Help?

Contact your Azure administrator to:
- Add your IP to the allowlist
- Grant you permission to modify network rules
- Provide a dev environment without network restrictions
