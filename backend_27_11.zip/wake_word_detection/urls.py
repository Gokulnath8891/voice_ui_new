"""
Wake Word Detection URL Configuration

API endpoints for wake word detection as specified in WAKE_WORD_USAGE.md
"""

from django.urls import path
from . import views

app_name = 'wake_word_detection'

urlpatterns = [
    # Core wake word control endpoints
    path('start', views.start_wake_word, name='start_wake_word'),
    path('stop', views.stop_wake_word, name='stop_wake_word'),
    path('status', views.wake_word_status, name='wake_word_status'),
    path('stream', views.wake_word_stream, name='wake_word_stream'),
    path('process', views.process_wake_word_command, name='process_wake_word_command'),
    
    # Settings and configuration
    path('settings', views.WakeWordSettingsView.as_view(), name='wake_word_settings'),
    
    # Analytics and monitoring
    path('analytics', views.WakeWordAnalyticsView.as_view(), name='wake_word_analytics'),
]