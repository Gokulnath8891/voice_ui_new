"""
Agentic RAG Models
This module does not require database models as it uses external services.
"""

# No models required for this app
# The module uses:
# - PostgreSQL (via psycopg2 direct connection)
# - Azure OpenAI (via API)
# - SentenceTransformer (in-memory model)
