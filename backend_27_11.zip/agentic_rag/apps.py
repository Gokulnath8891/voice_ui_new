from django.apps import AppConfig


class AgenticRagConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'agentic_rag'
