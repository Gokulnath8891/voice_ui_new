import streamlit as st
import psycopg2
import numpy as np
from typing import TypedDict, Optional
from sentence_transformers import SentenceTransformer
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

# ===============================
# 🔹 Define State using TypedDict
# ===============================
class QueryState(TypedDict):
    query: str
    result: Optional[str]
    context: Optional[str]

# ===============================
# 🔹 Azure OpenAI Configuration
# ===============================

# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


DB_URI='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'

EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
#engine = create_engine(DB_URI)
model = SentenceTransformer(EMBED_MODEL)


# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


# ===============================
# 🔹 SentenceTransformer Embedding
# ===============================
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ===============================
# 🔹 PostgreSQL Connection
# ===============================
def get_pg_connection():
    return psycopg2.connect(
        host="voiceassistantpsql.postgres.database.azure.com",
        dbname="voice_assistant_db",
        user="postgres",
        password="voice_password",
        port="5432"
    )

# ===============================
# 🔹 Router Node
# ===============================
def router_node(state: QueryState):
    """Decide whether to use SQL or vector search."""
    #q = state["query"].lower()
    q=state.get("query","").lower()
    #if q.strip().contains("work order") or " from " in q:
    if "work order" in q:
        next_node="db_agent"
    else:
        next_node="vector_agent"
    return {"next":next_node}

# ===============================
# 🔹 SQL Agent Node
# ===============================
def db_agent(state: QueryState):
    """Executes SQL queries directly in PostgreSQL."""
    query = state["query"]
    context = state.get("context", "")
    prompt = f"""
    You are an automotive assistant.
    If question involves work order details, use SQL to retrieve them.
    Otherwise, answer naturally.
    Previous context: {context}
    Question: {query}
    """
    
    db = SQLDatabase.from_uri(
        "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )

    
    sql_agent = create_sql_agent(
        llm=llm,
        db=db,
        verbose=True,
        top_k=5,  # optional
        agent_type="openai-tools",  # use the new LCEL-compatible type
    )

    # Run user query through the SQL agent
    try:
        result = sql_agent.invoke({"input": prompt})
        result_text = result.get("output", "No output from SQL Agent.")
    except Exception as e:
        result_text = f"Error executing SQL Agent: {e}"

    return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {result_text}",
        "result": result_text
    }
    
# ===============================
# 🔹 Vector Agent Node
# ===============================
def vector_agent(state: QueryState):
    """Performs semantic search using pgvector and SentenceTransformer."""
    query = state["query"]
    context = state.get("context", "")
    try:
        # Step 1: Encode the query into vector
        query_vector = embed_model.encode(query)
        query_vector = np.array(query_vector, dtype=np.float32).tolist()

        # Step 2: Retrieve similar content
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT content, 1 - (embedding <=> %s::vector) AS similarity
            FROM powertrain_pdf_docs
            ORDER BY embedding <=> %s::vector
            LIMIT 3;
        """, (query_vector, query_vector))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            return {"result": "⚠️ No similar content found in vector DB."}

        context = "\n".join([r[0] for r in rows])

        # Step 3: LLM call with retrieved context
        prompt = f"""
        You are a helpful voice assistant for an automotive technician.
        Use the following context to answer the user's question.
        If you don’t know the answer, politely say No.
        Be brief and clear.
        If there are multiple steps, just give one step and ask the user if they want to proceed for next step.

        \n\n Context:\n{context}
        \n\n query: {query}
        """
        response = llm.invoke(prompt)
        first_answer=response.content.strip()
        return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {first_answer}",
        "result": first_answer}

    except Exception as e:
        return {"result": f"⚠️ Vector Agent Error: {e}"}

# ===============================
# 🔹 LangGraph Workflow
# ===============================
graph = StateGraph(QueryState)
graph.add_node("router", router_node)
graph.add_node("db_agent", db_agent)
graph.add_node("vector_agent", vector_agent)

graph.add_conditional_edges(
    "router",
    lambda state:state["next"],
    {
        "db_agent": "db_agent",
        "vector_agent": "vector_agent"
    }
)

graph.add_edge("db_agent", END)
graph.add_edge("vector_agent", END)
graph.set_entry_point("router")

# Memory checkpoint
checkpointer = MemorySaver()
app = graph.compile(checkpointer=checkpointer)
config={"configurable":{"thread_id":"1"}}
#app = graph.compile()
# ---------------------------------------------------------------------
# 💬 Streamlit Chat Interface
# ---------------------------------------------------------------------
st.set_page_config(page_title="Automotive Technician Assistant", page_icon="🚗", layout="wide")
st.title("🚗 Automotive Technician Assistant")

if "history" not in st.session_state:
    st.session_state.history = []
    st.session_state.context = ""

user_input = st.chat_input("Ask your question...")

if user_input:
    st.session_state.history.append({"role": "user", "content": user_input})

    # Run the LangGraph
    output_state = app.invoke({
        "query": user_input,
        "context": st.session_state.context        
    },config=config)

    result = output_state.get("result", "⚠️ No result key found.")
    st.session_state.context = output_state.get("context", st.session_state.context)
    st.session_state.history.append({"role": "assistant", "content": result})

# Display chat history
for msg in st.session_state.history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])