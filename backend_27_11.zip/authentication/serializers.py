from rest_framework import serializers
from django.contrib.auth.models import User, Group
from django.contrib.auth.password_validation import validate_password
from workorders.models import TechnicianProfile, ServiceManagerProfile


class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True)
    role = serializers.ChoiceField(choices=['Technician', 'Service Manager'], default='Technician')
    
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password', 'password_confirm', 'role']
        
    def validate(self, attrs):
        if attrs['password'] != attrs['password_confirm']:
            raise serializers.ValidationError("Password fields didn't match.")
        return attrs
        
    def create(self, validated_data):
        # Remove password_confirm and role from validated_data
        validated_data.pop('password_confirm')
        role = validated_data.pop('role')
        
        # Create user
        user = User.objects.create_user(**validated_data)
        
        # Assign role
        if role == 'Service Manager':
            service_manager_group, _ = Group.objects.get_or_create(name='Service Manager')
            user.groups.clear()  # Remove default Technician group
            user.groups.add(service_manager_group)
            
            # Create ServiceManagerProfile
            ServiceManagerProfile.objects.create(
                user=user,
                employee_id=f"MGR-{user.id:04d}"
            )
            
            # Remove TechnicianProfile if it was created by signal
            if hasattr(user, 'technician_profile'):
                user.technician_profile.delete()
        
        return user


class UserProfileSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    profile = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'role', 'profile']
        
    def get_role(self, obj):
        if obj.groups.filter(name='Service Manager').exists():
            return 'Service Manager'
        elif obj.groups.filter(name='Technician').exists():
            return 'Technician'
        return 'Unknown'
        
    def get_profile(self, obj):
        if hasattr(obj, 'service_manager_profile'):
            return {
                'employee_id': obj.service_manager_profile.employee_id,
                'phone': obj.service_manager_profile.phone,
                'department': obj.service_manager_profile.department,
            }
        elif hasattr(obj, 'technician_profile'):
            return {
                'employee_id': obj.technician_profile.employee_id,
                'phone': obj.technician_profile.phone,
                'specialization': obj.technician_profile.specialization,
            }
        return None