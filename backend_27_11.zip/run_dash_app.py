#!/usr/bin/env python
"""
Voice Assistant Dash App Runner
Setup and launch script for the voice assistant Dash application
"""

import os
import sys
import subprocess
import time
import threading
from pathlib import Path

def install_requirements():
    """Install required packages"""
    print("📦 Installing required packages...")
    
    # Install packages that might need special handling
    packages_to_install = [
        "dash==2.14.0",
        "dash-bootstrap-components==1.5.0",
        "plotly==5.15.0",
        "SpeechRecognition==3.10.0",
        "pyttsx3==2.90",
        "Pillow==10.0.0"
    ]
    
    for package in packages_to_install:
        try:
            print(f"Installing {package}...")
            subprocess.run([sys.executable, "-m", "pip", "install", package, "--break-system-packages"], 
                         check=True, capture_output=True)
            print(f"✅ {package} installed successfully")
        except subprocess.CalledProcessError as e:
            print(f"⚠️  Warning: Could not install {package}: {e}")
            print("You may need to install it manually")

def check_django_server():
    """Check if Django server is running"""
    import requests
    try:
        # Use a simple API endpoint instead of admin (which redirects)
        response = requests.post("http://localhost:8000/api/login/", 
                               json={"username": "test", "password": "test"}, 
                               timeout=5)
        # Even if login fails, if we get a response, server is running
        return True
    except requests.exceptions.ConnectionError:
        return False
    except:
        # Other errors (like invalid credentials) mean server is running
        return True

def start_django_server():
    """Start Django server in background"""
    print("🚀 Starting Django server...")
    
    django_cmd = [sys.executable, "manage.py", "runserver", "8000"]
    
    try:
        django_process = subprocess.Popen(
            django_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=Path(__file__).parent
        )
        
        # Wait a few seconds for Django to start
        time.sleep(5)
        
        if django_process.poll() is None:
            print("✅ Django server started on http://localhost:8000")
            return django_process
        else:
            print("❌ Failed to start Django server")
            return None
            
    except Exception as e:
        print(f"❌ Error starting Django server: {e}")
        return None

def check_logo_file():
    """Check if logo file exists"""
    logo_path = r"C:\Users\DELL\Downloads\lv_logo.png"
    if os.path.exists(logo_path):
        print(f"✅ Logo file found: {logo_path}")
        return True
    else:
        print(f"⚠️  Logo file not found: {logo_path}")
        print("The app will work without the logo")
        return False

def run_dash_app():
    """Run the Dash application"""
    print("🎯 Starting Voice Assistant Dash App...")
    
    try:
        # Import and run the Dash app
        from voice_assistant_dash_app import app
        
        print("🌐 Dash app starting on http://localhost:8050")
        print("📱 Open this URL in your web browser")
        print("🎤 Make sure your microphone is working for voice commands")
        print("🔑 Default login credentials:")
        print("   - Username: any technician (e.g., alex_wilson_tech)")
        print("   - Password: password123")
        print("   - Username: any service manager (e.g., john_smith_sm)")
        print("   - Password: password123")
        
        app.run(debug=False, host='0.0.0.0', port=8050)
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Please make sure all required packages are installed")
        return False
    except Exception as e:
        print(f"❌ Error running Dash app: {e}")
        return False

def main():
    """Main function"""
    print("=" * 60)
    print("🎤 VOICE ASSISTANT DASH APPLICATION SETUP")
    print("=" * 60)
    
    # Check current directory
    current_dir = Path.cwd()
    print(f"📁 Current directory: {current_dir}")
    
    # Check logo file
    check_logo_file()
    
    # Check if Django server is already running
    print("\n🔍 Checking Django server...")
    if check_django_server():
        print("✅ Django server is already running")
    else:
        print("🚀 Django server not running, attempting to start...")
        django_process = start_django_server()
        
        if django_process is None:
            print("❌ Could not start Django server automatically")
            print("Please start it manually with: python manage.py runserver 8000")
            return
    
    # Wait a moment
    time.sleep(2)
    
    # Run Dash app
    print("\n" + "=" * 60)
    print("🎯 LAUNCHING DASH APPLICATION")
    print("=" * 60)
    
    run_dash_app()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Application stopped by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
    finally:
        print("\n🔧 Cleaning up...")
        print("✅ Done!")