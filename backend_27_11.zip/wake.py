from fastapi import FastAPI
import azure.cognitiveservices.speech as speechsdk
import threading

app = FastAPI()

AZURE_KEY = "1QD2Whn5LX4JPSORsLv7OP2zus76eJ86cLstg7zOLCHc3sVrqFYAJQQJ99BEACHYHv6XJ3w3AAAYACOGypYi",
AZURE_REGION = "eastus2"

wake_word = "hey buddy"

# Shared state
last_text = ""
wake_detected = False
running = False


def start_continuous_recognition():
    global last_text, wake_detected, running

    speech_config = speechsdk.SpeechConfig(subscription=AZURE_KEY, region=AZURE_REGION)
    audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)

    running = True

    # ✅ Callback fires every time speech is recognized
    def on_recognized(evt):
        global last_text, wake_detected, running
        if evt.result.text:
            last_text = evt.result.text
            print("Heard:", last_text)

            if wake_word.lower() in last_text.lower():
                wake_detected = True
                running = False
                recognizer.stop_continuous_recognition()
   
    # Bind callback
    recognizer.recognized.connect(on_recognized)

    # Start listening in background
    recognizer.start_continuous_recognition()

    # Keep the thread alive
    while running:
        pass

    recognizer.stop_continuous_recognition()


@app.get("/start")
def start():
    global last_text, wake_detected, running
    last_text = ""
    wake_detected = False
    running = True

    t = threading.Thread(target=start_continuous_recognition)
    t.start()

    return {"status": "listening started"}


@app.get("/status")
def status():
    return {
        "last_text": last_text,
        "wake_detected": wake_detected,
        "listening": running
    }
