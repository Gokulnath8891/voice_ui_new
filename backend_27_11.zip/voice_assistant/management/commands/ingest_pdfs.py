from django.core.management.base import BaseCommand, CommandError
from django.conf import settings
from pathlib import Path
import sys
import os

# Add the project root to Python path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.append(str(project_root))

from pdf_to_vectordb import PDFToVectorDB


class Command(BaseCommand):
    help = 'Ingest PDF files into PostgreSQL vector database'

    def add_arguments(self, parser):
        # Input options
        input_group = parser.add_mutually_exclusive_group(required=True)
        input_group.add_argument(
            '--docs-folder',
            type=str,
            help='Path to folder containing PDF files'
        )
        input_group.add_argument(
            '--single-file',
            type=str,
            help='Path to single PDF file'
        )
        
        # Configuration options
        parser.add_argument(
            '--collection-name',
            type=str,
            default='pdf_documents',
            help='Name of vector collection (default: pdf_documents)'
        )
        parser.add_argument(
            '--chunk-size',
            type=int,
            default=1000,
            help='Text chunk size in characters (default: 1000)'
        )
        parser.add_argument(
            '--chunk-overlap',
            type=int,
            default=200,
            help='Overlap between chunks in characters (default: 200)'
        )
        
        # Processing options
        parser.add_argument(
            '--recursive',
            action='store_true',
            default=True,
            help='Process PDFs in subfolders recursively (default: True)'
        )
        parser.add_argument(
            '--reset',
            action='store_true',
            help='Reset collection (delete all existing documents)'
        )
        parser.add_argument(
            '--test-search',
            type=str,
            help='Test search after processing with given query'
        )

    def handle(self, *args, **options):
        try:
            # Initialize processor
            processor = PDFToVectorDB(
                collection_name=options['collection_name'],
                chunk_size=options['chunk_size'],
                chunk_overlap=options['chunk_overlap']
            )
            
            self.stdout.write(
                self.style.SUCCESS(f'Initializing vector collection: {options["collection_name"]}')
            )
            
            # Initialize vector service
            processor.initialize_vector_service()
            
            # Reset collection if requested
            if options['reset']:
                self.stdout.write(
                    self.style.WARNING(f'Resetting collection: {options["collection_name"]}')
                )
                from voice_assistant.vector_models import DocumentCollection
                DocumentCollection.objects.filter(name=options['collection_name']).delete()
                processor.initialize_vector_service()  # Reinitialize after reset
            
            # Process files
            if options['single_file']:
                pdf_path = Path(options['single_file'])
                if not pdf_path.exists():
                    raise CommandError(f'File not found: {pdf_path}')
                
                self.stdout.write(f'Processing single file: {pdf_path}')
                processor.process_single_pdf(pdf_path)
            
            elif options['docs_folder']:
                docs_folder = Path(options['docs_folder'])
                if not docs_folder.exists():
                    raise CommandError(f'Docs folder does not exist: {docs_folder}')
                
                self.stdout.write(f'Processing folder: {docs_folder}')
                processor.process_folder(docs_folder, recursive=options['recursive'])
            
            # Print statistics
            stats = processor.stats
            self.stdout.write('\n' + self.style.SUCCESS('=== PROCESSING STATISTICS ==='))
            self.stdout.write(f'✅ Successfully processed files: {stats["processed_files"]}')
            self.stdout.write(f'❌ Failed files: {stats["failed_files"]}')
            self.stdout.write(f'⏭️  Skipped files: {stats["skipped_files"]}')
            self.stdout.write(f'📄 Total chunks created: {stats["total_chunks"]}')
            
            if processor.vector_service:
                collection_stats = processor.vector_service.get_collection_stats()
                self.stdout.write(f'🗂️  Collection: {collection_stats.get("name", "unknown")}')
                self.stdout.write(f'📚 Total documents: {collection_stats.get("total_documents", 0)}')
            
            # Test search if requested
            if options['test_search']:
                self.stdout.write(f'\n🔍 Testing search: "{options["test_search"]}"')
                result = processor.vector_service.search_similar(options['test_search'], max_results=3)
                
                if result['status'] == 'success':
                    self.stdout.write(f'Found {len(result["relevant_chunks"])} results:')
                    for i, chunk in enumerate(result['relevant_chunks'][:3]):
                        self.stdout.write(f'  {i+1}. Similarity: {chunk["similarity_score"]:.3f}')
                        self.stdout.write(f'     Source: {chunk["source"]}')
                        self.stdout.write(f'     Content: {chunk["content"][:100]}...')
                else:
                    self.stdout.write(
                        self.style.ERROR(f'Search test failed: {result.get("error", "Unknown error")}')
                    )
            
            self.stdout.write('\n' + self.style.SUCCESS('✅ PDF ingestion completed successfully!'))
            
        except Exception as e:
            raise CommandError(f'PDF ingestion failed: {e}')