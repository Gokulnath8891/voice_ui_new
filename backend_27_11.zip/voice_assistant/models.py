from django.db import models
from django.contrib.auth.models import User
import uuid


class VoiceSession(models.Model):
    """Track voice assistant sessions for analytics and debugging"""
    session_id = models.UUIDField(default=uuid.uuid4, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    total_requests = models.IntegerField(default=0)
    
    def __str__(self):
        return f"Session {self.session_id} - {self.created_at}"


class SpeechRecognitionRequest(models.Model):
    """Log speech recognition requests and results"""
    session = models.ForeignKey(VoiceSession, on_delete=models.CASCADE, related_name='speech_requests')
    request_id = models.UUIDField(default=uuid.uuid4, unique=True)
    audio_file_name = models.CharField(max_length=255, null=True, blank=True)
    audio_format = models.CharField(max_length=50, null=True, blank=True)
    audio_duration = models.FloatField(null=True, blank=True)  # in seconds
    recognized_text = models.TextField(null=True, blank=True)
    confidence_score = models.FloatField(null=True, blank=True)
    processing_time_ms = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=[
        ('SUCCESS', 'Success'),
        ('FAILED', 'Failed'),
        ('PROCESSING', 'Processing')
    ], default='PROCESSING')
    error_message = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Speech Request {self.request_id} - {self.status}"


class SemanticSearchRequest(models.Model):
    """Log semantic search queries and results"""
    session = models.ForeignKey(VoiceSession, on_delete=models.CASCADE, related_name='search_requests')
    request_id = models.UUIDField(default=uuid.uuid4, unique=True)
    query_text = models.TextField()
    max_chunks = models.IntegerField(default=5)
    similarity_threshold = models.FloatField(default=0.7)
    summary_text = models.TextField(null=True, blank=True)
    chunks_found = models.IntegerField(default=0)
    processing_time_ms = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=[
        ('SUCCESS', 'Success'),
        ('FAILED', 'Failed'),
        ('PROCESSING', 'Processing')
    ], default='PROCESSING')
    error_message = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Search Request {self.request_id} - {self.query_text[:50]}"


class RelevantChunk(models.Model):
    """Store relevant chunks returned from semantic search"""
    search_request = models.ForeignKey(SemanticSearchRequest, on_delete=models.CASCADE, related_name='relevant_chunks')
    content = models.TextField()
    similarity_score = models.FloatField()
    source = models.CharField(max_length=255, null=True, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    rank = models.IntegerField()  # Ranking order in results
    
    class Meta:
        ordering = ['rank']
    
    def __str__(self):
        return f"Chunk {self.rank} - Score: {self.similarity_score}"


class TextToSpeechRequest(models.Model):
    """Log text-to-speech requests"""
    session = models.ForeignKey(VoiceSession, on_delete=models.CASCADE, related_name='tts_requests')
    request_id = models.UUIDField(default=uuid.uuid4, unique=True)
    input_text = models.TextField()
    text_length = models.IntegerField()  # Character count
    voice_rate = models.IntegerField(default=150)
    voice_volume = models.FloatField(default=0.8)
    voice_name = models.CharField(max_length=100, default='default')
    audio_file_path = models.CharField(max_length=500, null=True, blank=True)
    audio_duration = models.FloatField(null=True, blank=True)  # in seconds
    processing_time_ms = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=[
        ('SUCCESS', 'Success'),
        ('FAILED', 'Failed'),
        ('PROCESSING', 'Processing')
    ], default='PROCESSING')
    error_message = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"TTS Request {self.request_id} - {self.input_text[:50]}"


class APIUsageLog(models.Model):
    """Track API usage for rate limiting and analytics"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    ip_address = models.GenericIPAddressField()
    endpoint = models.CharField(max_length=100)
    method = models.CharField(max_length=10)
    status_code = models.IntegerField()
    processing_time_ms = models.IntegerField()
    request_size_bytes = models.IntegerField(null=True, blank=True)
    response_size_bytes = models.IntegerField(null=True, blank=True)
    user_agent = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['user', 'created_at']),
            models.Index(fields=['ip_address', 'created_at']),
        ]
    
    def __str__(self):
        return f"{self.method} {self.endpoint} - {self.status_code}"


class VectorStoreMetadata(models.Model):
    """Store metadata about the vector store"""
    collection_name = models.CharField(max_length=100, unique=True)
    total_documents = models.IntegerField(default=0)
    embedding_model = models.CharField(max_length=100)
    last_updated = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    description = models.TextField(blank=True)
    
    def __str__(self):
        return f"Vector Store: {self.collection_name}"


# Import vector models (PostgreSQL with pgvector)
try:
    from .vector_models import (
        DocumentCollection, DocumentChunk, SearchQuery, 
        SearchResult, VectorSearchCache, VectorIndexStatus
    )
except ImportError:
    # pgvector not available, skip vector models
    pass
