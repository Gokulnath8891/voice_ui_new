import os
import io
import time
import tempfile
import threading
from typing import Dict, List, Tuple, Optional, Any
from django.conf import settings
from django.core.files.uploadedfile import InMemoryUploadedFile
import logging

try:
    import azure.cognitiveservices.speech as speechsdk
except ImportError:
    speechsdk = None

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

try:
    import chromadb
except ImportError:
    chromadb = None

try:
    from openai import AzureOpenAI
except ImportError:
    AzureOpenAI = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

logger = logging.getLogger(__name__)


class AzureSpeechService:
    """Service for Azure Cognitive Services Speech Recognition"""
    
    def __init__(self):
        if not speechsdk:
            raise ImportError("azure-cognitiveservices-speech not installed")
        
        self.speech_key = settings.AZURE_SPEECH_KEY
        self.speech_region = settings.AZURE_SPEECH_REGION
        
        if not self.speech_key or not self.speech_region:
            raise ValueError("Azure Speech credentials not configured")
    
    def recognize_from_file(self, audio_file: InMemoryUploadedFile) -> Dict[str, Any]:
        """Recognize speech from uploaded audio file"""
        start_time = time.time()
        
        try:
            # Create a temporary file for the audio
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                for chunk in audio_file.chunks():
                    temp_file.write(chunk)
                temp_file_path = temp_file.name
            
            # Configure speech recognition
            speech_config = speechsdk.SpeechConfig(
                subscription=self.speech_key, 
                region=self.speech_region
            )
            speech_config.speech_recognition_language = "en-US"
            
            audio_config = speechsdk.audio.AudioConfig(filename=temp_file_path)
            speech_recognizer = speechsdk.SpeechRecognizer(
                speech_config=speech_config, 
                audio_config=audio_config
            )
            
            # Perform recognition
            result = speech_recognizer.recognize_once()
            
            # Clean up temporary file
            os.unlink(temp_file_path)
            
            processing_time = int((time.time() - start_time) * 1000)
            
            if result.reason == speechsdk.ResultReason.RecognizedSpeech:
                return {
                    "status": "success",
                    "recognized_text": result.text,
                    "confidence_score": 0.95,  # Azure doesn't provide confidence in basic tier
                    "processing_time_ms": processing_time
                }
            elif result.reason == speechsdk.ResultReason.NoMatch:
                return {
                    "status": "failed",
                    "error": "No speech could be recognized",
                    "processing_time_ms": processing_time
                }
            else:
                return {
                    "status": "failed",
                    "error": f"Speech recognition failed: {result.reason}",
                    "processing_time_ms": processing_time
                }
        
        except Exception as e:
            processing_time = int((time.time() - start_time) * 1000)
            logger.error(f"Speech recognition error: {str(e)}")
            return {
                "status": "failed",
                "error": str(e),
                "processing_time_ms": processing_time
            }


class SemanticSearchService:
    """Service for semantic search using SentenceTransformers and ChromaDB"""
    
    def __init__(self):
        if not SentenceTransformer:
            raise ImportError("sentence-transformers not installed")
        if not chromadb:
            raise ImportError("chromadb not installed")
        
        self.model_name = "thenlper/gte-large"
        self.vector_store_path = settings.VECTOR_STORE_PATH
        self.collection_name = settings.VECTOR_COLLECTION_NAME
        
        # Initialize embedding model (lazy loading)
        self._embedding_model = None
        self._client = None
        self._collection = None
    
    @property
    def embedding_model(self):
        if self._embedding_model is None:
            self._embedding_model = SentenceTransformer(self.model_name)
        return self._embedding_model
    
    @property
    def client(self):
        if self._client is None:
            if self.vector_store_path:
                self._client = chromadb.PersistentClient(path=self.vector_store_path)
            else:
                self._client = chromadb.Client()
        return self._client
    
    @property
    def collection(self):
        if self._collection is None:
            try:
                self._collection = self.client.get_collection(name=self.collection_name)
            except Exception as e:
                logger.error(f"Error accessing collection {self.collection_name}: {str(e)}")
                # Create a dummy collection if it doesn't exist
                self._collection = self.client.create_collection(name=self.collection_name)
        return self._collection
    
    def search_and_summarize(self, query: str, max_chunks: int = 5, 
                           similarity_threshold: float = 0.7) -> Dict[str, Any]:
        """Perform semantic search and generate summary"""
        start_time = time.time()
        
        try:
            # Generate query embedding
            query_embedding = self.embedding_model.encode([query])[0].tolist()
            
            # Search vector store
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=max_chunks
            )
            
            # Process results
            relevant_chunks = []
            if results['documents'] and results['documents'][0]:
                for i, (doc, distance) in enumerate(zip(
                    results['documents'][0], 
                    results['distances'][0]
                )):
                    # Convert distance to similarity score (ChromaDB uses cosine distance)
                    similarity_score = 1 - distance
                    
                    if similarity_score >= similarity_threshold:
                        chunk_data = {
                            "content": doc,
                            "similarity_score": round(similarity_score, 4),
                            "source": results['metadatas'][0][i].get('source', 'unknown') if results['metadatas'][0] else 'unknown'
                        }
                        relevant_chunks.append(chunk_data)
            
            # Generate summary using the chunks
            summary = self._generate_summary(query, relevant_chunks)
            
            processing_time = int((time.time() - start_time) * 1000)
            
            return {
                "status": "success",
                "query": query,
                "summary": summary,
                "relevant_chunks": relevant_chunks,
                "processing_time_ms": processing_time
            }
        
        except Exception as e:
            processing_time = int((time.time() - start_time) * 1000)
            logger.error(f"Semantic search error: {str(e)}")
            return {
                "status": "failed",
                "error": str(e),
                "processing_time_ms": processing_time
            }
    
    def _generate_summary(self, query: str, chunks: List[Dict]) -> str:
        """Generate summary using Azure OpenAI or fallback method"""
        try:
            if not chunks:
                return "I couldn't find any relevant information for your query."
            
            # Try Azure OpenAI first
            if settings.AZURE_OPENAI_KEY and AzureOpenAI:
                return self._generate_openai_summary(query, chunks)
            else:
                return self._generate_fallback_summary(query, chunks)
        
        except Exception as e:
            logger.error(f"Summary generation error: {str(e)}")
            return self._generate_fallback_summary(query, chunks)
    
    def _generate_openai_summary(self, query: str, chunks: List[Dict]) -> str:
        """Generate summary using Azure OpenAI"""
        try:
            client = AzureOpenAI(
                api_key=settings.AZURE_OPENAI_KEY,
                api_version="2023-12-01-preview",
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT
            )
            
            # Prepare context from chunks
            context = "\n\n".join([f"Source: {chunk['source']}\n{chunk['content']}" 
                                 for chunk in chunks[:3]])  # Limit context size
            
            messages = [
                {"role": "system", "content": "You are a helpful assistant that provides concise, accurate summaries based on the given context."},
                {"role": "user", "content": f"Query: {query}\n\nContext:\n{context}\n\nPlease provide a comprehensive but concise answer to the query based on the context provided."}
            ]
            
            response = client.chat.completions.create(
                model=settings.AZURE_OPENAI_DEPLOYMENT_NAME,
                messages=messages,
                max_tokens=500,
                temperature=0.3
            )
            
            return response.choices[0].message.content.strip()
        
        except Exception as e:
            logger.error(f"OpenAI summary generation error: {str(e)}")
            return self._generate_fallback_summary(query, chunks)
    
    def _generate_fallback_summary(self, query: str, chunks: List[Dict]) -> str:
        """Generate a simple fallback summary"""
        if not chunks:
            return "I couldn't find any relevant information for your query."
        
        # Simple extractive summary
        top_chunk = chunks[0]
        summary = f"Based on the available information: {top_chunk['content'][:300]}..."
        
        if len(chunks) > 1:
            summary += f"\n\nAdditional relevant information was found from {len(chunks)} sources with similarity scores ranging from {chunks[-1]['similarity_score']:.2f} to {chunks[0]['similarity_score']:.2f}."
        
        return summary


class TextToSpeechService:
    """Service for Text-to-Speech using pyttsx3"""
    
    def __init__(self):
        if not pyttsx3:
            raise ImportError("pyttsx3 not installed")
        
        self._engine = None
        self._lock = threading.Lock()
    
    @property
    def engine(self):
        if self._engine is None:
            with self._lock:
                if self._engine is None:
                    self._engine = pyttsx3.init()
        return self._engine
    
    def synthesize_speech(self, text: str, voice_settings: Dict = None) -> Dict[str, Any]:
        """Convert text to speech and return audio file"""
        start_time = time.time()
        
        try:
            if voice_settings is None:
                voice_settings = {
                    "rate": settings.TTS_RATE,
                    "volume": settings.TTS_VOLUME,
                    "voice": "default"
                }
            
            # Configure voice settings
            with self._lock:
                engine = self.engine
                engine.setProperty('rate', voice_settings.get('rate', settings.TTS_RATE))
                engine.setProperty('volume', voice_settings.get('volume', settings.TTS_VOLUME))
                
                # Create temporary file for audio output
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.wav')
                temp_file_path = temp_file.name
                temp_file.close()
                
                # Generate speech
                engine.save_to_file(text, temp_file_path)
                engine.runAndWait()
            
            processing_time = int((time.time() - start_time) * 1000)
            
            # Calculate estimated duration (rough estimation)
            words = len(text.split())
            estimated_duration = words / (voice_settings.get('rate', settings.TTS_RATE) / 60)
            
            return {
                "status": "success",
                "audio_file_path": temp_file_path,
                "text_length": len(text),
                "estimated_duration": estimated_duration,
                "processing_time_ms": processing_time
            }
        
        except Exception as e:
            processing_time = int((time.time() - start_time) * 1000)
            logger.error(f"TTS error: {str(e)}")
            return {
                "status": "failed",
                "error": str(e),
                "processing_time_ms": processing_time
            }


# Service instances
speech_service = None
search_service = None
tts_service = None

def get_speech_service():
    global speech_service
    if speech_service is None:
        speech_service = AzureSpeechService()
    return speech_service

def get_search_service():
    global search_service
    if search_service is None:
        # Try to use PostgreSQL vector service first
        try:
            from .postgres_service import get_postgres_vector_service
            collection_name = getattr(settings, 'VECTOR_COLLECTION_NAME', 'default')
            search_service = get_postgres_vector_service(collection_name)
            logger.info("Using PostgreSQL vector service for semantic search")
        except Exception as e:
            logger.warning(f"PostgreSQL vector service not available: {str(e)}")
            # Fallback to ChromaDB service
            search_service = SemanticSearchService()
            logger.info("Using ChromaDB service for semantic search")
    return search_service

def get_tts_service():
    global tts_service
    if tts_service is None:
        tts_service = TextToSpeechService()
    return tts_service