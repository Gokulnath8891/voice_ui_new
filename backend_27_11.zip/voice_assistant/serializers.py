from rest_framework import serializers
from .models import (
    VoiceSession, SpeechRecognitionRequest, SemanticSearchRequest,
    RelevantChunk, TextToSpeechRequest, APIUsageLog, VectorStoreMetadata
)


class VoiceSessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoiceSession
        fields = ['session_id', 'created_at', 'updated_at', 'total_requests']
        read_only_fields = ['session_id', 'created_at', 'updated_at']


class SpeechRecognitionRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = SpeechRecognitionRequest
        fields = [
            'request_id', 'audio_file_name', 'audio_format', 'audio_duration',
            'recognized_text', 'confidence_score', 'processing_time_ms',
            'status', 'error_message', 'created_at'
        ]
        read_only_fields = [
            'request_id', 'recognized_text', 'confidence_score', 
            'processing_time_ms', 'status', 'error_message', 'created_at'
        ]


class SpeechRecognitionInputSerializer(serializers.Serializer):
    """Serializer for speech recognition API input"""
    audio_file = serializers.FileField(
        help_text="Audio file in WAV or MP3 format (max 60 seconds)"
    )
    
    def validate_audio_file(self, value):
        # Check file size (50MB max)
        if value.size > 50 * 1024 * 1024:
            raise serializers.ValidationError("Audio file too large. Maximum size is 50MB.")
        
        # Check file extension
        allowed_extensions = ['.wav', '.mp3', '.m4a', '.ogg']
        file_extension = value.name.lower().split('.')[-1]
        if f'.{file_extension}' not in allowed_extensions:
            raise serializers.ValidationError(
                f"Unsupported audio format. Allowed formats: {', '.join(allowed_extensions)}"
            )
        
        return value


class SpeechRecognitionOutputSerializer(serializers.Serializer):
    """Serializer for speech recognition API output"""
    status = serializers.CharField()
    recognized_text = serializers.CharField(required=False)
    confidence_score = serializers.FloatField(required=False)
    processing_time_ms = serializers.IntegerField()
    error = serializers.CharField(required=False)


class RelevantChunkSerializer(serializers.ModelSerializer):
    class Meta:
        model = RelevantChunk
        fields = ['content', 'similarity_score', 'source', 'metadata', 'rank']


class SemanticSearchInputSerializer(serializers.Serializer):
    """Serializer for semantic search API input"""
    query = serializers.CharField(
        max_length=1000,
        help_text="Text query for semantic search"
    )
    max_chunks = serializers.IntegerField(
        default=5,
        min_value=1,
        max_value=20,
        help_text="Maximum number of relevant chunks to return"
    )
    similarity_threshold = serializers.FloatField(
        default=0.7,
        min_value=0.0,
        max_value=1.0,
        help_text="Minimum similarity score for relevant chunks"
    )
    
    def validate_query(self, value):
        if len(value.strip()) < 3:
            raise serializers.ValidationError("Query must be at least 3 characters long.")
        return value.strip()


class SemanticSearchOutputSerializer(serializers.Serializer):
    """Serializer for semantic search API output"""
    status = serializers.CharField()
    query = serializers.CharField()
    summary = serializers.CharField(required=False)
    relevant_chunks = RelevantChunkSerializer(many=True, required=False)
    processing_time_ms = serializers.IntegerField()
    error = serializers.CharField(required=False)


class SemanticSearchRequestSerializer(serializers.ModelSerializer):
    relevant_chunks = RelevantChunkSerializer(many=True, read_only=True)
    
    class Meta:
        model = SemanticSearchRequest
        fields = [
            'request_id', 'query_text', 'max_chunks', 'similarity_threshold',
            'summary_text', 'chunks_found', 'processing_time_ms',
            'status', 'error_message', 'created_at', 'relevant_chunks'
        ]
        read_only_fields = [
            'request_id', 'summary_text', 'chunks_found', 'processing_time_ms',
            'status', 'error_message', 'created_at'
        ]


class VoiceSettingsSerializer(serializers.Serializer):
    """Serializer for TTS voice settings"""
    rate = serializers.IntegerField(
        default=150,
        min_value=50,
        max_value=300,
        help_text="Speech rate in words per minute"
    )
    volume = serializers.FloatField(
        default=0.8,
        min_value=0.0,
        max_value=1.0,
        help_text="Voice volume (0.0 to 1.0)"
    )
    voice = serializers.CharField(
        default="default",
        max_length=100,
        help_text="Voice name or identifier"
    )


class TextToSpeechInputSerializer(serializers.Serializer):
    """Serializer for text-to-speech API input"""
    text = serializers.CharField(
        max_length=5000,
        help_text="Text to convert to speech (max 5000 characters)"
    )
    voice_settings = VoiceSettingsSerializer(required=False)
    
    def validate_text(self, value):
        if len(value.strip()) < 1:
            raise serializers.ValidationError("Text cannot be empty.")
        
        # Check for reasonable word count
        word_count = len(value.split())
        if word_count > 1000:
            raise serializers.ValidationError("Text too long. Maximum 1000 words allowed.")
        
        return value.strip()


class TextToSpeechRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = TextToSpeechRequest
        fields = [
            'request_id', 'input_text', 'text_length', 'voice_rate',
            'voice_volume', 'voice_name', 'audio_file_path', 'audio_duration',
            'processing_time_ms', 'status', 'error_message', 'created_at'
        ]
        read_only_fields = [
            'request_id', 'text_length', 'audio_file_path', 'audio_duration',
            'processing_time_ms', 'status', 'error_message', 'created_at'
        ]


class APIUsageLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = APIUsageLog
        fields = [
            'endpoint', 'method', 'status_code', 'processing_time_ms',
            'request_size_bytes', 'response_size_bytes', 'created_at'
        ]


class VectorStoreMetadataSerializer(serializers.ModelSerializer):
    class Meta:
        model = VectorStoreMetadata
        fields = [
            'collection_name', 'total_documents', 'embedding_model',
            'last_updated', 'created_at', 'is_active', 'description'
        ]
        read_only_fields = ['last_updated', 'created_at']


class ErrorResponseSerializer(serializers.Serializer):
    """Standard error response format"""
    status = serializers.CharField(default="error")
    message = serializers.CharField()
    details = serializers.DictField(required=False)
    timestamp = serializers.DateTimeField()


class VoiceAssistantStatsSerializer(serializers.Serializer):
    """Serializer for voice assistant statistics"""
    total_sessions = serializers.IntegerField()
    total_speech_requests = serializers.IntegerField()
    total_search_requests = serializers.IntegerField()
    total_tts_requests = serializers.IntegerField()
    average_processing_time_ms = serializers.FloatField()
    success_rate = serializers.FloatField()
    most_common_queries = serializers.ListField(child=serializers.CharField())


# Session management serializers
class CreateSessionSerializer(serializers.Serializer):
    """Serializer for creating a new voice session"""
    pass  # No input required for session creation


class SessionResponseSerializer(serializers.Serializer):
    """Serializer for session creation response"""
    session_id = serializers.UUIDField()
    created_at = serializers.DateTimeField()
    message = serializers.CharField(default="Session created successfully")