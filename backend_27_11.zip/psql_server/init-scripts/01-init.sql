-- Database initialisation script for Django Voice Assistant
-- This file will be automatically executed when the container starts

-- Create the main database for the voice assistant application
CREATE DATABASE voice_assistant_db;

-- Create application user with appropriate permissions
CREATE USER postgres WITH ENCRYPTED PASSWORD 'voice_password';

-- Grant necessary privileges to the voice_assistant_db database
GRANT ALL PRIVILEGES ON DATABASE voice_assistant_db TO postgres;

-- Connect to the voice_assistant_db database to set up schema permissions
\CONNECT  voice_assistant_db

-- Install pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Grant schema privileges
GRANT USAGE ON SCHEMA public TO postgres;
GRANT CREATE ON SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON SCHEMA public TO postgres;

-- Set default privileges for future tables (Django will create these)
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON FUNCTIONS TO postgres;

-- Ensure the postgres user can create and manage all database objects
ALTER USER postgres CREATEDB;
ALTER USER postgres SUPERUSER;

-- Verify pgvector extension is installed
SELECT extname, extversion FROM pg_extension WHERE extname = 'vector';

-- Success message
SELECT 'Voice Assistant database initialized successfully!' as status;