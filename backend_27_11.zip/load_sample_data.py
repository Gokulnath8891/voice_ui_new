#!/usr/bin/env python
"""
Load sample data into the Django database.

This script populates the database with sample data for:
- Users (Technicians and Service Managers)
- Technician Profiles
- Service Manager Profiles
- Customers
- Vehicles
- Work Orders
- Work Order Steps
- Work Order Feedback
- Work Order Summaries

Usage:
    python load_sample_data.py

Note: This script will skip voice assistant related models as they
depend on the PDF processing/vector database setup.
"""

import os
import sys
import django
import json
from datetime import datetime
from decimal import Decimal

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
django.setup()

from django.contrib.auth.models import User, Group
from django.utils import timezone
from workorders.models import (
    TechnicianProfile,
    ServiceManagerProfile,
    Customer,
    Vehicle,
    WorkOrder,
    WorkOrderStep,
    WorkOrderFeedback,
    WorkOrderSummary
)


def parse_datetime(dt_string):
    """Parse datetime string to timezone-aware datetime object."""
    if dt_string:
        dt = datetime.fromisoformat(dt_string.replace('Z', '+00:00'))
        return timezone.make_aware(dt, timezone.utc) if timezone.is_naive(dt) else dt
    return None


def create_groups():
    """Create user groups for Technician and Service Manager."""
    print("Creating groups...")
    technician_group, created = Group.objects.get_or_create(name='Technician')
    if created:
        print("  ✓ Created Technician group")
    else:
        print("  - Technician group already exists")

    manager_group, created = Group.objects.get_or_create(name='Service Manager')
    if created:
        print("  ✓ Created Service Manager group")
    else:
        print("  - Service Manager group already exists")

    return technician_group, manager_group


def create_users(data):
    """Create users from JSON data."""
    print("\nCreating users...")
    user_mapping = {}

    for user_data in data.get('users', []):
        fields = user_data['fields']
        user, created = User.objects.get_or_create(
            username=fields['username'],
            defaults={
                'first_name': fields['first_name'],
                'last_name': fields['last_name'],
                'email': fields['email'],
                'is_staff': fields['is_staff'],
                'is_active': fields['is_active'],
                'is_superuser': fields['is_superuser'],
            }
        )

        if created:
            # Set a simple password for demo purposes
            user.set_password('demo123')
            user.save()
            print(f"  ✓ Created user: {user.username}")
        else:
            print(f"  - User already exists: {user.username}")

        # Add user to groups
        group_ids = fields.get('groups', [])
        for group_id in group_ids:
            if group_id == 1:
                user.groups.add(Group.objects.get(name='Technician'))
            elif group_id == 2:
                user.groups.add(Group.objects.get(name='Service Manager'))

        user_mapping[user_data['pk']] = user

    return user_mapping


def create_technician_profiles(data, user_mapping):
    """Create technician profiles."""
    print("\nCreating technician profiles...")

    for profile_data in data.get('technician_profiles', []):
        fields = profile_data['fields']
        user = user_mapping[fields['user']]

        profile, created = TechnicianProfile.objects.get_or_create(
            user=user,
            defaults={
                'employee_id': fields['employee_id'],
                'phone': fields['phone'],
                'specialization': fields['specialization'],
            }
        )

        if created:
            print(f"  ✓ Created profile for: {user.username} ({fields['specialization']})")
        else:
            print(f"  - Profile already exists for: {user.username}")


def create_service_manager_profiles(data, user_mapping):
    """Create service manager profiles."""
    print("\nCreating service manager profiles...")

    for profile_data in data.get('service_manager_profiles', []):
        fields = profile_data['fields']
        user = user_mapping[fields['user']]

        profile, created = ServiceManagerProfile.objects.get_or_create(
            user=user,
            defaults={
                'employee_id': fields['employee_id'],
                'phone': fields['phone'],
                'department': fields['department'],
            }
        )

        if created:
            print(f"  ✓ Created profile for: {user.username} ({fields['department']})")
        else:
            print(f"  - Profile already exists for: {user.username}")


def create_customers(data):
    """Create customers."""
    print("\nCreating customers...")
    customer_mapping = {}

    for customer_data in data.get('customers', []):
        fields = customer_data['fields']

        customer, created = Customer.objects.get_or_create(
            email=fields['email'],
            defaults={
                'first_name': fields['first_name'],
                'last_name': fields['last_name'],
                'phone': fields['phone'],
                'address': fields['address'],
            }
        )

        if created:
            print(f"  ✓ Created customer: {customer.first_name} {customer.last_name}")
        else:
            print(f"  - Customer already exists: {customer.first_name} {customer.last_name}")

        customer_mapping[customer_data['pk']] = customer

    return customer_mapping


def create_vehicles(data, customer_mapping):
    """Create vehicles."""
    print("\nCreating vehicles...")
    vehicle_mapping = {}

    for vehicle_data in data.get('vehicles', []):
        fields = vehicle_data['fields']
        customer = customer_mapping[fields['customer']]

        vehicle, created = Vehicle.objects.get_or_create(
            vin=fields['vin'],
            defaults={
                'customer': customer,
                'make': fields['make'],
                'model': fields['model'],
                'year': fields['year'],
                'license_plate': fields['license_plate'],
                'mileage': fields['mileage'],
            }
        )

        if created:
            print(f"  ✓ Created vehicle: {vehicle.year} {vehicle.make} {vehicle.model}")
        else:
            print(f"  - Vehicle already exists: {vehicle.year} {vehicle.make} {vehicle.model}")

        vehicle_mapping[vehicle_data['pk']] = vehicle

    return vehicle_mapping


def create_work_orders(data, customer_mapping, vehicle_mapping, user_mapping):
    """Create work orders."""
    print("\nCreating work orders...")
    work_order_mapping = {}

    for wo_data in data.get('work_orders', []):
        fields = wo_data['fields']

        work_order, created = WorkOrder.objects.get_or_create(
            order_number=fields['order_number'],
            defaults={
                'customer': customer_mapping[fields['customer']],
                'vehicle': vehicle_mapping[fields['vehicle']],
                'service_manager': user_mapping[fields['service_manager']],
                'technician': user_mapping.get(fields['technician']) if fields.get('technician') else None,
                'title': fields['title'],
                'description': fields['description'],
                'status': fields['status'],
                'priority': fields['priority'],
                'estimated_hours': Decimal(fields['estimated_hours']) if fields.get('estimated_hours') else None,
                'actual_hours': Decimal(fields['actual_hours']) if fields.get('actual_hours') else None,
                'assigned_at': parse_datetime(fields.get('assigned_at')),
                'started_at': parse_datetime(fields.get('started_at')),
                'completed_at': parse_datetime(fields.get('completed_at')),
            }
        )

        if created:
            print(f"  ✓ Created work order: {work_order.order_number} - {work_order.title}")
        else:
            print(f"  - Work order already exists: {work_order.order_number}")

        work_order_mapping[wo_data['pk']] = work_order

    return work_order_mapping


def create_work_order_steps(data, work_order_mapping):
    """Create work order steps."""
    print("\nCreating work order steps...")
    step_mapping = {}

    for step_data in data.get('work_order_steps', []):
        fields = step_data['fields']
        work_order = work_order_mapping[fields['work_order']]

        step, created = WorkOrderStep.objects.get_or_create(
            work_order=work_order,
            step_number=fields['step_number'],
            defaults={
                'title': fields['title'],
                'description': fields['description'],
                'estimated_time': Decimal(fields['estimated_time']),
                'is_completed': fields['is_completed'],
                'completed_at': parse_datetime(fields.get('completed_at')),
            }
        )

        if created:
            print(f"  ✓ Created step {step.step_number} for {work_order.order_number}")
        else:
            print(f"  - Step already exists: {work_order.order_number} - Step {step.step_number}")

        step_mapping[step_data['pk']] = step

    return step_mapping


def create_work_order_feedback(data, work_order_mapping, step_mapping, user_mapping):
    """Create work order feedback."""
    print("\nCreating work order feedback...")

    for feedback_data in data.get('work_order_feedback', []):
        fields = feedback_data['fields']

        feedback, created = WorkOrderFeedback.objects.get_or_create(
            work_order=work_order_mapping[fields['work_order']],
            step=step_mapping[fields['step']],
            technician=user_mapping[fields['technician']],
            defaults={
                'feedback_text': fields['feedback_text'],
                'time_spent': Decimal(fields['time_spent']),
                'issues_encountered': fields['issues_encountered'],
                'recommendations': fields['recommendations'],
                'created_at': parse_datetime(fields['created_at']),
            }
        )

        if created:
            print(f"  ✓ Created feedback for {feedback.work_order.order_number} - Step {feedback.step.step_number}")
        else:
            print(f"  - Feedback already exists")


def create_work_order_summaries(data, work_order_mapping):
    """Create work order summaries."""
    print("\nCreating work order summaries...")

    for summary_data in data.get('work_order_summaries', []):
        fields = summary_data['fields']
        work_order = work_order_mapping[fields['work_order']]

        summary, created = WorkOrderSummary.objects.get_or_create(
            work_order=work_order,
            defaults={
                'summary_text': fields['summary_text'],
                'total_time_spent': Decimal(fields['total_time_spent']),
                'total_steps_completed': fields['total_steps_completed'],
                'major_issues_resolved': fields['major_issues_resolved'],
                'recommendations_for_customer': fields['recommendations_for_customer'],
                'created_at': parse_datetime(fields['created_at']),
            }
        )

        if created:
            print(f"  ✓ Created summary for {work_order.order_number}")
        else:
            print(f"  - Summary already exists for {work_order.order_number}")


def main():
    """Main function to load all sample data."""
    print("=" * 70)
    print("Loading Sample Data for Voice Assistant Work Order System")
    print("=" * 70)

    # Load JSON data
    json_file = 'sample_data.json'
    print(f"\nLoading data from {json_file}...")

    try:
        with open(json_file, 'r') as f:
            data = json.load(f)
        print("  ✓ JSON data loaded successfully")
    except FileNotFoundError:
        print(f"  ✗ Error: {json_file} not found!")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"  ✗ Error: Invalid JSON format - {e}")
        sys.exit(1)

    # Create data in order (respecting foreign key dependencies)
    try:
        create_groups()
        user_mapping = create_users(data)
        create_technician_profiles(data, user_mapping)
        create_service_manager_profiles(data, user_mapping)
        customer_mapping = create_customers(data)
        vehicle_mapping = create_vehicles(data, customer_mapping)
        work_order_mapping = create_work_orders(data, customer_mapping, vehicle_mapping, user_mapping)
        step_mapping = create_work_order_steps(data, work_order_mapping)
        create_work_order_feedback(data, work_order_mapping, step_mapping, user_mapping)
        create_work_order_summaries(data, work_order_mapping)

        print("\n" + "=" * 70)
        print("✓ Sample data loaded successfully!")
        print("=" * 70)
        print("\nSummary:")
        print(f"  - Users: {User.objects.count()}")
        print(f"  - Technicians: {TechnicianProfile.objects.count()}")
        print(f"  - Service Managers: {ServiceManagerProfile.objects.count()}")
        print(f"  - Customers: {Customer.objects.count()}")
        print(f"  - Vehicles: {Vehicle.objects.count()}")
        print(f"  - Work Orders: {WorkOrder.objects.count()}")
        print(f"  - Work Order Steps: {WorkOrderStep.objects.count()}")
        print(f"  - Feedback Entries: {WorkOrderFeedback.objects.count()}")
        print(f"  - Summaries: {WorkOrderSummary.objects.count()}")
        print("\nAll users have password: demo123")
        print("\nYou can now use the Django admin or API to view this data.")

    except Exception as e:
        print(f"\n✗ Error occurred while loading data: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
