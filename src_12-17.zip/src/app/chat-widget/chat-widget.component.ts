import {Component, OnInit, OnDestroy, ChangeDetectorRef} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ButtonModule} from 'primeng/button';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {AvatarModule} from 'primeng/avatar';
import {FormsModule} from '@angular/forms';
import {TooltipModule} from 'primeng/tooltip';
import {Router} from '@angular/router';
import {VoiceApiService} from './voice-api.service';
import {WakeupVoiceService} from './wakeup-voice.service';
import {ChatCommunicationService} from '../services/chat-communication.service';
import {FeedbackService} from '../services/feedback.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-chat-widget',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    InputTextareaModule,
    AvatarModule,
    FormsModule,
    TooltipModule,
  ],
  templateUrl: './chat-widget.component.html',
  styleUrls: ['./chat-widget.component.scss'],
})
export class ChatWidgetComponent implements OnInit, OnDestroy {
  
  isChatOpen = false;
  userInput = '';
  isRecording = false;
  isListening = false;
  isProcessing = false;
  isUserTyping = false; // Track if user is actively typing
  isVoicePlaying = false; // Track if voice output is playing
  isFeedbackInProgress = false; // Track if feedback is being submitted
  private readonly mediaRecorder: MediaRecorder | null = null;
  private readonly audioChunks: Blob[] = [];
  private recognition: any = null;
  private autoOpenTimer: any = null;
  private autoCloseTimer: any = null;
  private readonly AUTO_CLOSE_DELAY = 30000; // 30 seconds
  private messageSubscription: Subscription | null = null;
  messages: {
    text: string; 
    sender: 'user' | 'bot'; 
    avatar: string; 
    isProcessing?: boolean;
    isVoice?: boolean;
    stepNumber?: number;
    sessionId?: string;
    feedback?: 'positive' | 'negative' | null;
  }[] = [
    {text: 'Hello! How can I help you today?', sender: 'bot', avatar: '🤖'},
  ];
  private currentStepNumber = 0;
  private currentSessionId = '';

  constructor(
    private readonly voiceApiService: VoiceApiService,
    private readonly voiceWakeup: WakeupVoiceService,
    private readonly chatService: ChatCommunicationService,
    private readonly cdr: ChangeDetectorRef,
    private readonly feedbackService: FeedbackService,
    private readonly router: Router
  ) {
    console.log('[ChatWidget] Component constructor called');
    this.initializeMediaRecorder();
    this.initializeSpeechRecognition();
  }

  ngOnInit() {
    console.log('[ChatWidget] Component initialized - ngOnInit called');
    // Get session ID if available
    const sessionId = sessionStorage.getItem('current_session_id');
    if (sessionId) {
      this.currentSessionId = sessionId;
    }

    // Subscribe to incoming messages from other components
    this.messageSubscription = this.chatService.message$.subscribe(async (message) => {
      if (message.autoOpen && !this.isChatOpen) {
        this.toggleChat();
      }
      
      // Increment step number for tracking
      this.currentStepNumber++;
      
      // Add bot message with feedback tracking
      this.messages.push({
        text: message.text,
        sender: 'bot',
        avatar: '🤖',
        sessionId: this.currentSessionId,
        stepNumber: this.currentStepNumber,
        feedback: null
      });
      
      this.scrollToBottom();
      
      // Play voice if requested
      if (message.isVoice) {
        try {
          this.isVoicePlaying = true;
          await this.voiceApiService.speakText(message.text);
          this.isVoicePlaying = false;
          // Notify that voice synthesis is complete
          this.chatService.notifyVoiceComplete();
        } catch (error) {
          console.error('Error with text-to-speech:', error);
          this.isVoicePlaying = false;
        }
      }
    });
    
    // Auto-open chat widget after 10 seconds
    // this.autoOpenTimer = setTimeout(() => {
    //   if (!this.isChatOpen) {
    //     this.toggleChat();
    //   }
    // }, 10000); // 10 seconds
    // this.voiceWakeup.startListening(() => {
    //   console.log('Wake word detected!');
    //   this.voiceWakeup.stopListening();

    //   if (!this.isChatOpen) {
    //     this.toggleChat();
    //     // Add a small delay to prevent a race condition for the microphone
    //     setTimeout(() => {
    //       this.toggleVoiceInput();
    //     }, 300); // 300ms is usually a safe delay
    //   }
    // });
    this.startWakeWordListener();
  }

  private async initializeMediaRecorder() {
    // We're now using speech recognition instead of MediaRecorder
    // This method is kept for compatibility but doesn't initialize MediaRecorder
    console.log('Using Speech Recognition API instead of MediaRecorder');
  }

  private initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition =
        (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      this.recognition = new SpeechRecognition();

      // Enhanced settings for maximum accuracy
      this.recognition.continuous = true; // Keep listening to capture complete sentences
      this.recognition.interimResults = true; // Show interim results for better UX
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 5; // Get top 5 alternatives for better accuracy

      this.recognition.onstart = () => {
        this.isRecording = true;
        console.log('[ChatWidget] 🎤 Voice recognition started - speak now...');
      };

      this.recognition.onresult = async (event: any) => {
        // Process all results to get the complete transcript
        let finalTranscript = '';
        let interimTranscript = '';
        
        // Iterate through all results
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          
          if (result.isFinal) {
            // For final results, use the most confident alternative
            let bestTranscript = result[0].transcript;
            let bestConfidence = result[0].confidence || 0;
            
            // Check all alternatives to find the best one
            for (let j = 0; j < Math.min(result.length, 5); j++) {
              const alternative = result[j];
              const confidence = alternative.confidence || 0;
              
              console.log(`[ChatWidget] Alternative ${j}: "${alternative.transcript}" (confidence: ${confidence.toFixed(2)})`);
              
              if (confidence > bestConfidence) {
                bestTranscript = alternative.transcript;
                bestConfidence = confidence;
              }
            }
            
            console.log(`[ChatWidget] Selected best alternative: "${bestTranscript}" (confidence: ${bestConfidence.toFixed(2)})`);
            finalTranscript += bestTranscript + ' ';
          } else {
            // Interim results for visual feedback
            interimTranscript += result[0].transcript;
          }
        }
        
        // Update UI with interim results
        if (interimTranscript && !finalTranscript) {
          console.log('[ChatWidget] Interim:', interimTranscript);
        }
        
        // Process final transcript
        if (finalTranscript) {
          finalTranscript = finalTranscript.trim();
          console.log('[ChatWidget] ✓ Final transcript received:', finalTranscript);
          
          // Stop recognition to process this result
          this.isRecording = false;
          this.recognition.stop();
          
          // Add user message with voice indicator
          this.messages.push({
            text: finalTranscript,
            sender: 'user',
            avatar: '🧑',
            isVoice: true
          });

          this.cdr.detectChanges(); // Force immediate UI update
          this.scrollToBottom();

          // Send transcribed text to API and get voice response
          await this.sendTranscriptToAPI(finalTranscript, true);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.error('[ChatWidget] Speech recognition error:', event.error);
        this.isRecording = false;
        
        // Handle specific errors
        if (event.error === 'network') {
          this.showErrorMessage('Network error. Please check your internet connection and try again.');
          console.log('[ChatWidget] Network error - speech recognition requires internet connection');
        } else if (event.error === 'not-allowed') {
          this.showErrorMessage('Microphone access denied. Please enable microphone permissions.');
        } else if (event.error === 'audio-capture') {
          this.showErrorMessage('Microphone not available. Please check your audio devices.');
        } else if (event.error !== 'no-speech') {
          // Don't show error for no-speech, it's normal
          this.showErrorMessage('Voice recognition failed. Please try again.');
        }
      };

      this.recognition.onend = () => {
        this.isRecording = false;
      };
    }
  }

  private async sendVoiceToAPI(audioBlob: Blob): Promise<void> {
    // This method is no longer used since we're using browser speech recognition
    // The voice input is now handled through the speech recognition API directly
    console.warn('sendVoiceToAPI called but not used in speech recognition mode');
  }

  private async sendTranscriptToAPI(transcript: string, isVoiceInput: boolean = false): Promise<void> {
    try {
      // Reset auto-close timer on user interaction
      this.resetAutoCloseTimer();
      
      // Check if this is a restart work order command (e.g., "restart work order 20241007")
      const restartPattern = /restart\s+(?:the\s+)?(?:work\s*order\s*|wo[-\s]?)(\d+)/i;
      const restartMatch = transcript.match(restartPattern);
      
      if (restartMatch) {
        const workOrderNumber = restartMatch[1];
        console.log('[ChatWidget] Restart work order command detected:', workOrderNumber);
        
        // Add user message to chat
        this.messages.push({
          text: transcript,
          sender: 'user',
          avatar: '👤',
          isVoice: isVoiceInput,
        });
        
        this.cdr.detectChanges();
        this.scrollToBottom();
        
        // Stop widget voice recognition before navigating
        this.pauseVoiceRecognition();
        
        // Close the chat widget
        this.toggleChat();
        
        // Store the action in sessionStorage and navigate to work orders page
        sessionStorage.setItem('pending_work_order_action', JSON.stringify({
          orderNumber: `WO-${workOrderNumber}`,
          action: 'restart'
        }));
        
        setTimeout(() => {
          console.log('[ChatWidget] Navigating to work orders for restart:', `WO-${workOrderNumber}`);
          this.router.navigate(['/work-order']);
        }, 300); // Small delay to allow widget to close smoothly
        
        return;
      }
      
      // Check if this is a resume work order command (e.g., "resume work order 20241008")
      const resumePattern = /resume\s+(?:the\s+)?(?:work\s*order\s*|wo[-\s]?)(\d+)/i;
      const resumeMatch = transcript.match(resumePattern);
      
      if (resumeMatch) {
        const workOrderNumber = resumeMatch[1];
        console.log('[ChatWidget] Resume work order command detected:', workOrderNumber);
        
        // Add user message to chat
        this.messages.push({
          text: transcript,
          sender: 'user',
          avatar: '👤',
          isVoice: isVoiceInput,
        });
        
        this.cdr.detectChanges();
        this.scrollToBottom();
        
        // Stop widget voice recognition before navigating
        this.pauseVoiceRecognition();
        
        // Close the chat widget
        this.toggleChat();
        
        // Store the action in sessionStorage and navigate to work orders page
        sessionStorage.setItem('pending_work_order_action', JSON.stringify({
          orderNumber: `WO-${workOrderNumber}`,
          action: 'resume'
        }));
        
        setTimeout(() => {
          console.log('[ChatWidget] Navigating to work orders for resume:', `WO-${workOrderNumber}`);
          this.router.navigate(['/work-order']);
        }, 300); // Small delay to allow widget to close smoothly
        
        return;
      }
      
      // Check if this is a start work order command with multiple variations:
      // - "help me fix work order 20241008"
      // - "help me to fix work order 20241008"
      // - "start work 20241008"
      // - "start work order 20241008"
      const helpPattern = /help\s+me\s+(?:to\s+)?fix\s+(?:work\s*order\s*|wo[-\s]?)(\d+)/i;
      const startPattern = /start\s+(?:work\s*order\s*|work\s+)(\d+)/i;
      
      const helpMatch = transcript.match(helpPattern);
      const startMatch = transcript.match(startPattern);
      const workOrderMatch = helpMatch || startMatch;
      
      if (workOrderMatch) {
        const workOrderNumber = workOrderMatch[1];
        console.log('[ChatWidget] Work order start command detected:', workOrderNumber);
        
        // Add user message to chat
        this.messages.push({
          text: transcript,
          sender: 'user',
          avatar: '👤',
          isVoice: isVoiceInput,
        });
        
        this.cdr.detectChanges();
        this.scrollToBottom();
        
        // Stop widget voice recognition before navigating
        this.pauseVoiceRecognition();
        
        // Close the chat widget
        this.toggleChat();
        
        // Store the action in sessionStorage and navigate to work orders page
        sessionStorage.setItem('pending_work_order_action', JSON.stringify({
          orderNumber: `WO-${workOrderNumber}`,
          action: 'start'
        }));
        
        setTimeout(() => {
          console.log('[ChatWidget] Navigating to work orders for start:', `WO-${workOrderNumber}`);
          this.router.navigate(['/work-order']);
        }, 300); // Small delay to allow widget to close smoothly
        
        return;
      }
      
      // Update session ID if changed
      const sessionId = sessionStorage.getItem('current_session_id');
      if (sessionId) {
        this.currentSessionId = sessionId;
      }

      // Add processing indicator for bot response
      const botMessageIndex = this.messages.length;
      this.messages.push({
        text: '🤔 Thinking...',
        sender: 'bot',
        avatar: '🤖',
        isProcessing: true,
      });

      this.cdr.detectChanges(); // Force immediate UI update
      this.scrollToBottom();

      // Get response from chat API
      const botResponse = await this.voiceApiService.sendTextToAPI(transcript);

      // Increment step number for tracking
      this.currentStepNumber++;

      // Update bot message with actual response and voice indicator
      this.messages[botMessageIndex] = {
        text: botResponse,
        sender: 'bot',
        avatar: '🤖',
        isVoice: isVoiceInput, // Mark as voice if input was voice
        sessionId: this.currentSessionId,
        stepNumber: this.currentStepNumber,
        feedback: null
      };

      this.cdr.detectChanges(); // Force immediate UI update
      this.scrollToBottom();

      // Speak the response using text-to-speech (only if input was voice)
      if (isVoiceInput) {
        try {
          this.isVoicePlaying = true;
          await this.voiceApiService.speakText(botResponse);
          this.isVoicePlaying = false;
          // Notify that voice synthesis is complete
          this.chatService.notifyVoiceComplete();
        } catch (ttsError) {
          console.error('Error with text-to-speech:', ttsError);
          this.isVoicePlaying = false;
        }
      }
      
      // Reset auto-close timer after bot responds
      this.resetAutoCloseTimer();

      this.startWakeWordListener();
    } catch (error) {
      console.error('Chat API error:', error);
      this.messages[this.messages.length - 1] = {
        text: 'Sorry, I encountered an error. Please try again.',
        sender: 'bot',
        avatar: '🤖',
      };
      this.cdr.detectChanges(); // Force immediate UI update
      this.scrollToBottom();

      this.startWakeWordListener();
    }
  }

  private showErrorMessage(message: string): void {
    this.messages.push({
      text: message,
      sender: 'bot',
      avatar: '🤖',
    });
    this.scrollToBottom();
  }

  get isSpeechSupported(): boolean {
    return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  }

  get isMediaRecorderSupported(): boolean {
    // We're not using MediaRecorder anymore, so return false
    return false;
  }

  startVoiceInput() {
    if (this.isProcessing) return;
    if (this.recognition && !this.isRecording) {
      // Reset auto-close timer when voice input starts
      this.resetAutoCloseTimer();
      this.isRecording = true;
      console.log('[ChatWidget] Starting voice recognition...');
      try {
        this.recognition.start();
      } catch (error) {
        console.error('[ChatWidget] Error starting recognition:', error);
        this.isRecording = false;
      }
    }
  }

  stopVoiceInput() {
    if (this.recognition && this.isRecording) {
      console.log('[ChatWidget] Stopping voice recognition...');
      this.isRecording = false;
      try {
        this.recognition.stop();
      } catch (error) {
        console.error('[ChatWidget] Error stopping recognition:', error);
      }
    }
  }

  /**
   * Pause voice recognition (for modal usage)
   */
  pauseVoiceRecognition(): void {
    console.log('[ChatWidget] Pausing voice recognition for modal...');
    this.stopVoiceInput();
    // Stop wake word listener too
    this.voiceWakeup.stopListening();
  }

  /**
   * Resume voice recognition (after modal closes)
   */
  resumeVoiceRecognition(): void {
    console.log('[ChatWidget] Resuming voice recognition after modal...');
    // Restart wake word listener
    this.startWakeWordListener();
  }

  // toggleVoiceInput() {
  //   if (this.isProcessing) return;

  //   if (this.isListening || this.isRecording) {
  //     this.stopVoiceInput();
  //   } else {
  //     this.startVoiceInput();
  //   }
  // }
  toggleVoiceInput() {
    if (this.isProcessing) return;
    if (this.isRecording) {
      this.stopVoiceInput();
    } else {
      this.startVoiceInput();
    }
  }

  toggleChat() {
    console.log('[ChatWidget] toggleChat called. Current state:', this.isChatOpen, '-> New state:', !this.isChatOpen);
    this.isChatOpen = !this.isChatOpen;

    if (this.autoOpenTimer) {
      clearTimeout(this.autoOpenTimer);
      this.autoOpenTimer = null;
    }

    if (this.isChatOpen) {
      setTimeout(() => this.scrollToBottom(), 100);
      this.resetAutoCloseTimer(); // Start auto-close timer when chat opens
    } else {
      this.clearAutoCloseTimer();
      // Stop wake word listener first, then restart it
      console.log('[ChatWidget] Chat closed, restarting wake word listener...');
      this.voiceWakeup.stopListening();
      setTimeout(() => {
        this.startWakeWordListener();
      }, 700); // Wait for stop to complete before starting again
    }
  }

  /**
   * Reset the auto-close timer - called when user interacts with chat
   */
  private resetAutoCloseTimer(): void {
    this.clearAutoCloseTimer();
    
    console.log('[ChatWidget] Starting auto-close timer (30 seconds)');
    this.autoCloseTimer = setTimeout(() => {
      // Don't close if any activity is in progress
      const hasActivity = this.isRecording || 
                         this.isProcessing || 
                         this.isUserTyping || 
                         this.isVoicePlaying || 
                         this.isFeedbackInProgress;
      
      if (this.isChatOpen && !hasActivity) {
        console.log('[ChatWidget] Auto-closing due to inactivity');
        this.isChatOpen = false;
        this.startWakeWordListener();
      } else if (hasActivity) {
        console.log('[ChatWidget] Activity detected, resetting timer');
        this.resetAutoCloseTimer(); // Reset timer if activity is in progress
      }
    }, this.AUTO_CLOSE_DELAY);
  }

  /**
   * Clear the auto-close timer
   */
  private clearAutoCloseTimer(): void {
    if (this.autoCloseTimer) {
      clearTimeout(this.autoCloseTimer);
      this.autoCloseTimer = null;
    }
  }

  private startWakeWordListener(): void {
    console.log('Restarting wake word listener...');
    this.voiceWakeup.startListening(
      () => {
        // Wake word callback
        console.log('Wake word detected!');
        this.voiceWakeup.stopListening();

        if (!this.isChatOpen) {
          // Case 1: Chat is closed. Open it AND start voice input.
          console.log('[ChatWidget] Chat is closed. Opening and starting voice input...');
          this.toggleChat();
          setTimeout(() => this.toggleVoiceInput(), 300); // Keep delay for mic handover
        } else {
          // Case 2: Chat is already open. Just start the voice input.
          console.log('[ChatWidget] Chat is open. Starting voice input directly...');
          this.toggleVoiceInput();
        }
      },
      async (transcript: string) => {
        // Work order command callback
        console.log('[ChatWidget] Work order command detected:', transcript);
        this.voiceWakeup.stopListening();

        // Open chat if closed
        if (!this.isChatOpen) {
          this.toggleChat();
        }

        // Add user message with voice indicator
        this.messages.push({
          text: transcript,
          sender: 'user',
          avatar: '🧑',
          isVoice: true
        });

        this.scrollToBottom();

        // Send to API and get response (mark as voice input)
        await this.sendTranscriptToAPI(transcript, true);
      }
    );
  }

  minimizeChat() {
    this.isChatOpen = false;
  }

  handleEnterKey(event: KeyboardEvent) {
    if (!event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  adjustTextareaHeight(event: any) {
    const textarea = event.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  }

  getVoiceButtonClass(): string {
    let baseClass = 'p-button-rounded voice-btn';
    if (this.isRecording) {
      baseClass += ' recording-active';
    }
    return baseClass;
  }

  getVoiceTooltip(): string {
    if (this.isRecording) {
      return 'Stop recording';
    } else if (this.isProcessing) {
      return 'Processing...';
    } else {
      return 'Start voice input';
    }
  }

  sendQuickMessage(message: string) {
    this.userInput = message;
    this.sendMessage();
  }

  getCurrentTime(): string {
    return new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
  }

  private scrollToBottom() {
    setTimeout(() => {
      const messagesContainer = document.querySelector('.chat-messages');
      if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      }
    }, 50);
  }

  async sendMessage() {
    this.isRecording = false;

    if (!this.userInput.trim() || this.isProcessing) return;

    // User sent message, no longer typing
    this.isUserTyping = false;

    // Reset auto-close timer on user interaction
    this.resetAutoCloseTimer();

    const messageText = this.userInput.trim();
    this.userInput = '';

    // Add user message (text input, not voice)
    this.messages.push({
      text: messageText,
      sender: 'user',
      avatar: '🧑',
      isVoice: false
    });

    this.cdr.detectChanges(); // Force immediate UI update
    this.scrollToBottom();

    // Send to API and get response (not voice input)
    await this.sendTranscriptToAPI(messageText, false);
  }

  // ngOnDestroy() {
  //   // Clean up the auto-open timer when component is destroyed
  //   if (this.autoOpenTimer) {
  //     clearTimeout(this.autoOpenTimer);
  //     this.autoOpenTimer = null;
  //   }
  // }
  ngOnDestroy() {
    console.log('[ChatWidget] Component destroyed. Stopping wake word listener.');
    if (this.autoOpenTimer) {
      clearTimeout(this.autoOpenTimer);
    }
    if (this.autoCloseTimer) {
      clearTimeout(this.autoCloseTimer);
    }
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
    this.voiceWakeup.stopListening();
  }

  /**
   * Handle input focus - user is typing
   */
  onInputFocus(): void {
    console.log('[ChatWidget] User started typing');
    this.isUserTyping = true;
    this.clearAutoCloseTimer(); // Stop timer while typing
  }

  /**
   * Handle input blur - user stopped typing
   */
  onInputBlur(): void {
    console.log('[ChatWidget] User stopped typing');
    this.isUserTyping = false;
    // Only restart timer if input is empty
    if (!this.userInput.trim()) {
      this.resetAutoCloseTimer();
    }
  }

  /**
   * Handle input change - track typing activity
   */
  onInputChange(): void {
    // If user clears the input while typing, restart timer
    if (!this.userInput.trim() && !this.isUserTyping) {
      this.resetAutoCloseTimer();
    }
  }
  
  /**
   * Submit feedback for a bot message
   */
  submitFeedback(message: any, isPositive: boolean): void {
    if (!message.sessionId || message.stepNumber === undefined) {
      console.warn('[ChatWidget] Cannot submit feedback - missing session or step info');
      return;
    }

    const feedback = isPositive ? 'positive' : 'negative';
    
    console.log('[ChatWidget] Submitting feedback:', {
      sessionId: message.sessionId,
      stepNumber: message.stepNumber,
      feedback: feedback
    });

    this.isFeedbackInProgress = true;

    this.feedbackService.submitFeedback(
      message.sessionId,
      message.stepNumber,
      feedback,
      '' // No notes for now
    ).subscribe({
      next: (response) => {
        console.log('[ChatWidget] Feedback submitted successfully:', response);
        
        // Update message feedback state
        message.feedback = feedback;
        this.cdr.detectChanges();

        // Check if there's a next step to display
        if (response.type === 'next_step' && response.message) {
          this.handleNextStepResponse(response);
        } else if (response.type === 'work_order_complete') {
          this.handleWorkOrderComplete(response);
        }
        
        this.isFeedbackInProgress = false;
      },
      error: (error) => {
        console.error('[ChatWidget] Failed to submit feedback:', error);
        alert('Failed to submit feedback. Please try again.');
        this.isFeedbackInProgress = false;
      }
    });
  }

  /**
   * Handle next step response after feedback
   */
  private async handleNextStepResponse(response: any): Promise<void> {
    // Store completed step for UI update
    if (response.progress?.completed) {
      sessionStorage.setItem('completed_step', response.progress.completed.toString());
    }

    // Increment step number for the new message
    this.currentStepNumber++;

    // Format the response message
    let responseMessage = response.message;
    
    // Add tts_text if available
    if (response.tts_text) {
      responseMessage += `\n\n${response.tts_text}`;
    }

    // Add estimated time if available
    if (response.current_step?.estimated_time) {
      responseMessage += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
    }

    // Add progress info
    if (response.progress) {
      responseMessage += `\n\nProgress: ${response.progress.completed}/${response.progress.total} steps (${response.progress.percentage.toFixed(1)}%)`;
    }

    // Add new bot message with the next step
    this.messages.push({
      text: responseMessage,
      sender: 'bot',
      avatar: '🤖',
      isVoice: true,
      sessionId: this.currentSessionId,
      stepNumber: this.currentStepNumber,
      feedback: null
    });

    this.cdr.detectChanges();
    this.scrollToBottom();

    // Speak the response
    try {
      this.isVoicePlaying = true;
      await this.voiceApiService.speakText(responseMessage);
      this.isVoicePlaying = false;
      // Notify that voice synthesis is complete for step marking
      this.chatService.notifyVoiceComplete();
    } catch (error) {
      console.error('[ChatWidget] Error with text-to-speech:', error);
      this.isVoicePlaying = false;
    }
  }

  /**
   * Handle work order completion
   */
  private async handleWorkOrderComplete(response: any): Promise<void> {
    // Work order completed
    sessionStorage.setItem('work_order_complete', 'true');
    
    this.messages.push({
      text: response.message || 'Work order completed successfully! 🎉',
      sender: 'bot',
      avatar: '🤖',
      isVoice: true,
      sessionId: this.currentSessionId,
      stepNumber: this.currentStepNumber,
      feedback: null
    });

    this.cdr.detectChanges();
    this.scrollToBottom();

    try {
      this.isVoicePlaying = true;
      await this.voiceApiService.speakText(response.message || 'Work order completed successfully!');
      this.isVoicePlaying = false;
      this.chatService.notifyVoiceComplete();
    } catch (error) {
      console.error('[ChatWidget] Error with text-to-speech:', error);
      this.isVoicePlaying = false;
    }
  }
}
