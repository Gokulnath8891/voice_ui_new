import { TestBed } from '@angular/core/testing';

import { WakeupVoiceServiceService } from './wakeup-voice.service';

describe('WakeupVoiceServiceService', () => {
  let service: WakeupVoiceServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WakeupVoiceServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
