import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginComponent } from './login.component';
import { AuthService } from '../services/auth.service';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { CardModule } from 'primeng/card';
import { MessageModule } from 'primeng/message';
import { CheckboxModule } from 'primeng/checkbox';
import { DividerModule } from 'primeng/divider';
import { RippleModule } from 'primeng/ripple';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let mockRouter: jasmine.SpyObj<Router>;
  let mockAuthService: jasmine.SpyObj<AuthService>;

  beforeEach(async () => {
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    const authSpy = jasmine.createSpyObj('AuthService', ['login']);

    await TestBed.configureTestingModule({
      imports: [
        LoginComponent,
        ReactiveFormsModule,
        ButtonModule,
        InputTextModule,
        PasswordModule,
        CardModule,
        MessageModule,
        CheckboxModule,
        DividerModule,
        RippleModule
      ],
      providers: [
        { provide: Router, useValue: routerSpy },
        { provide: AuthService, useValue: authSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    mockRouter = TestBed.inject(Router) as jasmine.SpyObj<Router>;
    mockAuthService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form with empty values', () => {
    expect(component.loginForm.get('username')?.value).toBe('');
    expect(component.loginForm.get('password')?.value).toBe('');
    expect(component.loginForm.get('rememberMe')?.value).toBe(false);
  });

  it('should validate required fields', () => {
    const usernameControl = component.loginForm.get('username');
    const passwordControl = component.loginForm.get('password');

    expect(usernameControl?.valid).toBeFalsy();
    expect(passwordControl?.valid).toBeFalsy();

    usernameControl?.setValue('testuser');
    passwordControl?.setValue('password123');

    expect(usernameControl?.valid).toBeTruthy();
    expect(passwordControl?.valid).toBeTruthy();
  });

  it('should show error message for invalid credentials', async () => {
    mockAuthService.login.and.returnValue(Promise.resolve(false));
    
    component.loginForm.patchValue({
      username: 'wrong',
      password: 'wrong'
    });

    await component.onSubmit();

    expect(component.errorMessage).toBe('Invalid username or password');
    expect(component.isLoading).toBeFalsy();
  });

  it('should navigate on successful login', async () => {
    mockAuthService.login.and.returnValue(Promise.resolve(true));
    
    component.loginForm.patchValue({
      username: 'admin',
      password: 'password'
    });

    await component.onSubmit();

    expect(mockRouter.navigate).toHaveBeenCalledWith(['/quality-search']);
    expect(component.isLoading).toBeFalsy();
  });

  it('should return correct field errors', () => {
    const usernameControl = component.loginForm.get('username');
    usernameControl?.markAsTouched();
    
    expect(component.getFieldError('username')).toBe('Username is required');
    
    usernameControl?.setValue('ab');
    expect(component.getFieldError('username')).toBe('Username must be at least 3 characters');
  });

  it('should check if field is invalid correctly', () => {
    const usernameControl = component.loginForm.get('username');
    
    expect(component.isFieldInvalid('username')).toBeFalsy();
    
    usernameControl?.markAsTouched();
    expect(component.isFieldInvalid('username')).toBeTruthy();
    
    usernameControl?.setValue('validuser');
    expect(component.isFieldInvalid('username')).toBeFalsy();
  });
});
