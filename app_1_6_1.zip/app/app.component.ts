import {Component, OnInit} from '@angular/core';
import {NavigationEnd, Router, RouterOutlet} from '@angular/router';
import {filter} from 'rxjs/operators';
import {CommonModule} from '@angular/common';
import {NavComponent} from './nav/nav.component';
import {ToastModule} from 'primeng/toast';
import {FooterComponent} from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { ChatWidgetComponent } from './chat-widget/chat-widget.component';

/** Class for the app component that is bootstrapped to run the application
 */
@Component({
  selector: 'body',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: true,
  imports: [CommonModule, NavComponent, ToastModule, RouterOutlet, HeaderComponent, FooterComponent, ChatWidgetComponent],
})
export class AppComponent implements OnInit {
  /** string used to hold the url for the skipToMain link */
  skipToMain: string;
  
  /** boolean to track if we're on the login page */
  isLoginPage: boolean = false;

  /** constructor for setting up DI in this component */
  constructor(private readonly router: Router) {}

  /** this class requires this method to implement the OnInit interface */
  ngOnInit(): void {
    // Check initial route
    this.checkIfLoginPage(this.router.url);
    
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.setSkipLinkUrl(event.urlAfterRedirects);
        this.checkIfLoginPage(event.urlAfterRedirects);
      });
  }

  /**
   * setSkipLinkUrl takes in a url string and processes whether
   * the skipToMain link should be updated to use the new value
   * @param currentUrl the new url to refer to
   */
  private setSkipLinkUrl(currentUrl: string): void {
    if (!currentUrl.endsWith('#app-content')) {
      this.skipToMain = `${currentUrl}#app-content`;
    }
  }

  /**
   * checkIfLoginPage determines if the current route is an authentication page
   * @param currentUrl the current url to check
   */
  private checkIfLoginPage(currentUrl: string): void {
    const authPages = ['/login', '/forgot-password', '/reset-password'];
    this.isLoginPage = authPages.some(page => 
      currentUrl === page || currentUrl.startsWith(page + '?') || currentUrl.startsWith(page + '/')
    );
  }
}
