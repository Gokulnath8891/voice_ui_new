import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';

export interface User {
  username: string;
  token: string;
}

export interface LoginResponse {
  access?: string;
  refresh?: string;
  token?: string;
  user?: {
    username: string;
    email?: string;
  };
}

export interface UserProfile {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  profile: {
    employee_id: string;
    phone: string;
    department: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;
  private readonly apiUrl = environment.apiUrl;

  constructor(private readonly http: HttpClient) {
    // Check for existing token in storage
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    const username = localStorage.getItem('username') || sessionStorage.getItem('username') || '';
    const user = token ? { username, token } : null;
    
    this.currentUserSubject = new BehaviorSubject<User | null>(user);
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  public get isLoggedIn(): boolean {
    return !!this.currentUserValue;
  }

  async login(username: string, password: string, rememberMe: boolean = false): Promise<boolean> {
    try {
      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'accept': 'application/json'
      });

      const body = {
        username,
        password
      };

      const response = await firstValueFrom(
        this.http.post<LoginResponse>(`${this.apiUrl}/auth/login/`, body, { headers })
      );

      // Handle successful login
      if (response && (response.access || response.token)) {
        const token = response.access || response.token || '';
        const user: User = { 
          username: response.user?.username || username, 
          token 
        };
        
        // Store token and username based on remember me preference
        if (rememberMe) {
          localStorage.setItem('authToken', token);
          localStorage.setItem('username', user.username);
          sessionStorage.removeItem('authToken');
          sessionStorage.removeItem('username');
        } else {
          sessionStorage.setItem('authToken', token);
          sessionStorage.setItem('username', user.username);
          localStorage.removeItem('authToken');
          localStorage.removeItem('username');
        }

        // Store refresh token if available
        if (response.refresh) {
          if (rememberMe) {
            localStorage.setItem('refreshToken', response.refresh);
          } else {
            sessionStorage.setItem('refreshToken', response.refresh);
          }
        }
        
        this.currentUserSubject.next(user);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  }

  logout(): void {
    // Remove token from storage
    localStorage.removeItem('authToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('username');
    sessionStorage.removeItem('authToken');
    sessionStorage.removeItem('refreshToken');
    sessionStorage.removeItem('username');
    
    // Update current user
    this.currentUserSubject.next(null);
  }

  getToken(): string | null {
    return localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
  }

  getRefreshToken(): string | null {
    return localStorage.getItem('refreshToken') || sessionStorage.getItem('refreshToken');
  }

  async getUserProfile(): Promise<UserProfile | null> {
    try {
      const token = this.getToken();
      if (!token) {
        throw new Error('No authentication token found');
      }

      const headers = new HttpHeaders({
        'accept': '*/*',
        'Authorization': `Bearer ${token}`
      });

      const response = await firstValueFrom(
        this.http.get<UserProfile>(`${this.apiUrl}/auth/me/`, { headers })
      );

      return response;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return null;
    }
  }
}
