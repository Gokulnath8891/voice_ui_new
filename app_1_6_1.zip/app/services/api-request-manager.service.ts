import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { shareReplay, finalize, tap, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AuthService } from './auth.service';

/**
 * Centralized API Request Manager Service
 * 
 * This service acts as a single source of truth for all API calls to prevent duplicates.
 * It implements:
 * - Global request deduplication across all components and services
 * - Request caching with automatic cleanup
 * - Proper Observable sharing to prevent multiple HTTP calls
 * - Request cancellation when needed
 * 
 * Usage:
 * - All API calls should go through this service
 * - The service automatically handles authentication headers
 * - Duplicate requests are automatically detected and deduplicated
 */
@Injectable({
  providedIn: 'root'
})
export class ApiRequestManagerService {
  private readonly apiUrl = environment.apiUrl;
  
  // Global cache for all pending requests - prevents duplicate API calls
  private static pendingRequests = new Map<string, Observable<any>>();
  
  // Track request timestamps for debugging
  private static requestTimestamps = new Map<string, number>();
  
  // Subject for request events (for monitoring/debugging)
  private requestEvents$ = new Subject<{ type: 'start' | 'complete' | 'error' | 'dedupe', key: string, timestamp: number }>();

  constructor(
    private readonly http: HttpClient,
    private readonly authService: AuthService
  ) {
    console.log('[ApiRequestManager] 🚀 Service initialized');
  }

  /**
   * Generate a unique key for a request based on endpoint and payload
   */
  private generateRequestKey(endpoint: string, payload: any): string {
    // Create a stable string representation of the payload
    const payloadStr = JSON.stringify(payload, Object.keys(payload).sort());
    return `${endpoint}::${payloadStr}`;
  }

  /**
   * Get authentication headers
   */
  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  /**
   * POST request with automatic deduplication
   * 
   * @param endpoint - API endpoint (e.g., 'chat/query', 'chat/feedback')
   * @param payload - Request payload
   * @param options - Additional options (bypass deduplication, custom headers, etc.)
   * @returns Observable that emits the response
   */
  post<T>(
    endpoint: string, 
    payload: any,
    options: {
      bypassDedupe?: boolean;
      customHeaders?: HttpHeaders;
    } = {}
  ): Observable<T> {
    const requestKey = this.generateRequestKey(endpoint, payload);
    const now = Date.now();
    
    // Log request attempt
    console.log(`[ApiRequestManager] 📤 POST request:`, {
      endpoint,
      requestKey: requestKey.substring(0, 80) + '...',
      timestamp: now
    });
    
    // Check if this exact request is already in progress (unless bypassed)
    if (!options.bypassDedupe && ApiRequestManagerService.pendingRequests.has(requestKey)) {
      console.warn(`[ApiRequestManager] ⛔ DUPLICATE REQUEST BLOCKED:`, {
        endpoint,
        requestKey: requestKey.substring(0, 80) + '...',
        originalTimestamp: ApiRequestManagerService.requestTimestamps.get(requestKey),
        timeSinceOriginal: now - (ApiRequestManagerService.requestTimestamps.get(requestKey) || 0)
      });
      
      this.requestEvents$.next({ type: 'dedupe', key: requestKey, timestamp: now });
      
      // Return the existing observable
      return ApiRequestManagerService.pendingRequests.get(requestKey)! as Observable<T>;
    }
    
    // Create new request
    const url = `${this.apiUrl}/${endpoint}`;
    const headers = options.customHeaders || this.getHeaders();
    
    console.log(`[ApiRequestManager] ✅ CREATING NEW REQUEST:`, {
      endpoint,
      url,
      requestKey: requestKey.substring(0, 80) + '...'
    });
    
    // Store timestamp
    ApiRequestManagerService.requestTimestamps.set(requestKey, now);
    this.requestEvents$.next({ type: 'start', key: requestKey, timestamp: now });
    
    // Create observable with proper cleanup
    const request$ = this.http.post<T>(url, payload, { headers }).pipe(
      tap((response) => {
        console.log(`[ApiRequestManager] ✅ REQUEST SUCCESS:`, {
          endpoint,
          requestKey: requestKey.substring(0, 80) + '...',
          duration: Date.now() - now
        });
        this.requestEvents$.next({ type: 'complete', key: requestKey, timestamp: Date.now() });
      }),
      catchError((error) => {
        console.error(`[ApiRequestManager] ❌ REQUEST ERROR:`, {
          endpoint,
          requestKey: requestKey.substring(0, 80) + '...',
          error: error.message,
          duration: Date.now() - now
        });
        this.requestEvents$.next({ type: 'error', key: requestKey, timestamp: Date.now() });
        throw error;
      }),
      finalize(() => {
        // Cleanup: Remove from pending requests after completion or error
        console.log(`[ApiRequestManager] 🧹 CLEANING UP REQUEST:`, {
          endpoint,
          requestKey: requestKey.substring(0, 80) + '...',
          totalDuration: Date.now() - now
        });
        ApiRequestManagerService.pendingRequests.delete(requestKey);
        ApiRequestManagerService.requestTimestamps.delete(requestKey);
      }),
      shareReplay(1) // Share the result with all subscribers
    );
    
    // Store in pending requests
    ApiRequestManagerService.pendingRequests.set(requestKey, request$);
    
    return request$;
  }

  /**
   * POST request that returns a Promise (for compatibility with existing code)
   */
  async postPromise<T>(
    endpoint: string,
    payload: any,
    options: {
      bypassDedupe?: boolean;
      customHeaders?: HttpHeaders;
    } = {}
  ): Promise<T> {
    return this.post<T>(endpoint, payload, options).toPromise() as Promise<T>;
  }

  /**
   * GET request with automatic deduplication
   */
  get<T>(
    endpoint: string,
    options: {
      bypassDedupe?: boolean;
      customHeaders?: HttpHeaders;
    } = {}
  ): Observable<T> {
    const requestKey = `GET::${endpoint}`;
    const now = Date.now();
    
    console.log(`[ApiRequestManager] 📥 GET request:`, {
      endpoint,
      requestKey,
      timestamp: now
    });
    
    // Check if this exact request is already in progress
    if (!options.bypassDedupe && ApiRequestManagerService.pendingRequests.has(requestKey)) {
      console.warn(`[ApiRequestManager] ⛔ DUPLICATE GET REQUEST BLOCKED:`, {
        endpoint,
        requestKey,
        originalTimestamp: ApiRequestManagerService.requestTimestamps.get(requestKey),
        timeSinceOriginal: now - (ApiRequestManagerService.requestTimestamps.get(requestKey) || 0)
      });
      
      this.requestEvents$.next({ type: 'dedupe', key: requestKey, timestamp: now });
      return ApiRequestManagerService.pendingRequests.get(requestKey)! as Observable<T>;
    }
    
    const url = `${this.apiUrl}/${endpoint}`;
    const headers = options.customHeaders || this.getHeaders();
    
    ApiRequestManagerService.requestTimestamps.set(requestKey, now);
    this.requestEvents$.next({ type: 'start', key: requestKey, timestamp: now });
    
    const request$ = this.http.get<T>(url, { headers }).pipe(
      tap(() => {
        console.log(`[ApiRequestManager] ✅ GET SUCCESS:`, {
          endpoint,
          duration: Date.now() - now
        });
        this.requestEvents$.next({ type: 'complete', key: requestKey, timestamp: Date.now() });
      }),
      catchError((error) => {
        console.error(`[ApiRequestManager] ❌ GET ERROR:`, {
          endpoint,
          error: error.message
        });
        this.requestEvents$.next({ type: 'error', key: requestKey, timestamp: Date.now() });
        throw error;
      }),
      finalize(() => {
        console.log(`[ApiRequestManager] 🧹 CLEANING UP GET REQUEST:`, { endpoint });
        ApiRequestManagerService.pendingRequests.delete(requestKey);
        ApiRequestManagerService.requestTimestamps.delete(requestKey);
      }),
      shareReplay(1)
    );
    
    ApiRequestManagerService.pendingRequests.set(requestKey, request$);
    return request$;
  }

  /**
   * Clear all pending requests (useful for cleanup or reset)
   */
  clearAllPendingRequests(): void {
    console.log(`[ApiRequestManager] 🧹 CLEARING ALL PENDING REQUESTS (${ApiRequestManagerService.pendingRequests.size} total)`);
    ApiRequestManagerService.pendingRequests.clear();
    ApiRequestManagerService.requestTimestamps.clear();
  }

  /**
   * Get count of pending requests (for monitoring/debugging)
   */
  getPendingRequestCount(): number {
    return ApiRequestManagerService.pendingRequests.size;
  }

  /**
   * Check if a specific request is pending
   */
  isRequestPending(endpoint: string, payload: any): boolean {
    const requestKey = this.generateRequestKey(endpoint, payload);
    return ApiRequestManagerService.pendingRequests.has(requestKey);
  }

  /**
   * Get observable of request events (for monitoring/debugging)
   */
  getRequestEvents(): Observable<{ type: 'start' | 'complete' | 'error' | 'dedupe', key: string, timestamp: number }> {
    return this.requestEvents$.asObservable();
  }
}
