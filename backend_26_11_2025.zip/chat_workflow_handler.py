#!/usr/bin/env python
"""
Chat Workflow Handler
Handles the step-by-step workflow and feedback collection in the chat interface
"""

import requests
import json
from datetime import datetime
import time
from django.core.cache import cache

class ChatWorkflowHandler:
    """Handles chat workflow states and step progression"""
    
    def __init__(self, api_base_url="http://localhost:8000/api"):
        self.api_base_url = api_base_url
        self.session_timeout = 7200  # 2 hours in seconds
    
    def _get_session(self, session_id):
        """Get session from cache"""
        return cache.get(f"workflow_session_{session_id}")
    
    def _set_session(self, session_id, session_data):
        """Store session in cache"""
        cache.set(f"workflow_session_{session_id}", session_data, self.session_timeout)
    
    def _delete_session(self, session_id):
        """Delete session from cache"""
        cache.delete(f"workflow_session_{session_id}")
        cache.delete(f"chat_history_{session_id}")

    def _get_chat_history(self, session_id):
        """Get chat message history for a session"""
        return cache.get(f"chat_history_{session_id}", [])

    def _set_chat_history(self, session_id, messages):
        """Store chat message history for a session"""
        cache.set(f"chat_history_{session_id}", messages, self.session_timeout)

    def _add_chat_message(self, session_id, message):
        """Add a message to the session's chat history"""
        history = self._get_chat_history(session_id)
        history.append(message)
        self._set_chat_history(session_id, history)
        return history

    def get_work_order_session_id(self, work_order_number, user_id):
        """Get consistent session ID for a work order and user"""
        # Try to find work order by number to get ID
        try:
            import os
            import django
            os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
            django.setup()
            from workorders.models import WorkOrder

            work_order = WorkOrder.objects.get(order_number=work_order_number)
            return f"wo_{work_order.id}_{user_id}"
        except:
            return f"wo_{work_order_number}_{user_id}"
    
    def start_work_order_session(self, user_id, work_order_data, current_step):
        """Start a new work order session"""
        # Check for existing session for this work order and user
        existing_session_id = f"wo_{work_order_data['id']}_{user_id}"
        existing_session = self._get_session(existing_session_id)

        if existing_session and existing_session.get('awaiting_feedback'):
            print(f"📋 Reusing existing session: {existing_session_id}")
            return existing_session_id

        # Create new session with consistent ID (without timestamp for reuse)
        session_id = existing_session_id

        session_data = {
            'type': 'work_order',
            'user_id': user_id,
            'work_order': work_order_data,
            'current_step_number': current_step['step_number'],
            'current_step': current_step,
            'step_start_time': datetime.now().isoformat(),
            'completed_steps': existing_session.get('completed_steps', []) if existing_session else [],
            'awaiting_feedback': True
        }
        self._set_session(session_id, session_data)
        print(f"📋 Created new session: {session_id}")

        return session_id
    
    def start_general_query_session(self, user_id, query_info, current_step):
        """Start a new general query session"""
        session_id = f"gq_{user_id}_{int(time.time())}"
        
        session_data = {
            'type': 'general_query',
            'user_id': user_id,
            'query_info': query_info,
            'current_step_number': current_step['step_number'],
            'current_step': current_step,
            'step_start_time': datetime.now().isoformat(),
            'completed_steps': [],
            'awaiting_feedback': True
        }
        self._set_session(session_id, session_data)
        
        return session_id
    
    def process_feedback(self, session_id, feedback_text, user_id):
        """Process step feedback and move to next step"""
        session = self._get_session(session_id)
        if not session:
            return {'type': 'error', 'message': 'Session not found or expired'}
        
        print(f"🔄 DEBUG: Found session for {session_id}: {session['type']}")
        
        if not session['awaiting_feedback']:
            return {'type': 'error', 'message': 'Not currently awaiting feedback'}
        
        try:
            # Calculate time spent (parse ISO format datetime)
            step_start_time = datetime.fromisoformat(session['step_start_time'])
            time_spent = (datetime.now() - step_start_time).total_seconds() / 3600  # Convert to hours
            
            current_step = session['current_step']
            
            if session['type'] == 'work_order':
                # Process work order feedback directly without circular HTTP call
                try:
                    from api_endpoints import DashAPIEndpoints
                    from django.http import HttpRequest

                    # Create a mock request object
                    mock_request = HttpRequest()
                    mock_request.method = 'POST'
                    mock_request._body = json.dumps({
                        'work_order_id': session['work_order']['id'],
                        'step_number': current_step['step_number'],
                        'feedback': feedback_text,
                        'user_id': user_id,
                        'time_spent': time_spent
                    }).encode('utf-8')

                    # Call the API method directly
                    api_endpoints = DashAPIEndpoints()
                    response = api_endpoints.submit_step_feedback(mock_request)
                except ImportError as e:
                    print(f"⚠️ Warning: Could not import API endpoints: {e}")
                    # Enhanced fallback with proper next step details
                    next_step_number = current_step['step_number'] + 1
                    work_order = session['work_order']

                    # Try to get next step details from work order data
                    next_step_title = 'Next Step'
                    next_step_description = 'Continue with the next step'

                    try:
                        # If work order has steps data, get the actual next step
                        if 'steps' in work_order:
                            for step in work_order['steps']:
                                if step.get('step_number') == next_step_number:
                                    next_step_title = step.get('title', 'Next Step')
                                    next_step_description = step.get('description', 'Continue with the next step')
                                    break
                    except Exception:
                        pass

                    # Create enhanced TTS message similar to what the API would provide
                    tts_text = f'Step {current_step["step_number"]} completed and feedback recorded. Ready for step {next_step_number}: {next_step_title}. {next_step_description}'

                    response = type('MockResponse', (), {
                        'status_code': 200,
                        'content': json.dumps({
                            'type': 'next_step',
                            'current_step': {
                                'step_number': next_step_number,
                                'title': next_step_title,
                                'description': next_step_description
                            },
                            'message': f'Step {current_step["step_number"]} completed! Ready for step {next_step_number}',
                            'instruction': next_step_description,
                            'tts_text': tts_text
                        }).encode('utf-8')
                    })()
                
                if response.status_code == 200:
                    result = json.loads(response.content.decode('utf-8'))
                    
                    # Mark step as completed
                    session['completed_steps'].append({
                        'step_number': current_step['step_number'],
                        'feedback': feedback_text,
                        'time_spent': time_spent,
                        'completed_at': datetime.now().isoformat()
                    })
                    
                    if result['type'] == 'work_order_complete':
                        # Work order complete
                        total_time = sum(step['time_spent'] for step in session['completed_steps'])
                        self._delete_session(session_id)
                        return {
                            'type': 'complete',
                            'message': f'Excellent! You have completed all {len(session["completed_steps"])} steps for work order {session["work_order"]["order_number"]}',
                            'tts_text': f'Congratulations! You have successfully completed work order {session["work_order"]["order_number"]} in {total_time:.1f} hours. Thank you for your detailed feedback and professional work!',
                            'total_time': total_time,
                            'total_steps': len(session['completed_steps'])
                        }
                    
                    elif result['type'] == 'next_step':
                        # Move to next step
                        next_step = result['current_step']
                        session['current_step_number'] = next_step['step_number']
                        session['current_step'] = next_step
                        session['step_start_time'] = datetime.now().isoformat()
                        session['awaiting_feedback'] = True
                        self._set_session(session_id, session)
                        
                        return {
                            'type': 'next_step',
                            'current_step': next_step,
                            'message': result['message'],
                            'instruction': result['instruction'],
                            'tts_text': result['tts_text'],
                            'progress': result.get('progress', {})
                        }
                    
                    else:
                        return {'type': 'error', 'message': 'Unexpected response from API'}
                
                else:
                    return {'type': 'error', 'message': 'Failed to submit feedback to API'}
            
            elif session['type'] == 'general_query':
                # Handle general query step completion
                session['completed_steps'].append({
                    'step_number': current_step['step_number'],
                    'feedback': feedback_text,
                    'time_spent': time_spent,
                    'completed_at': datetime.now().isoformat()
                })
                
                # Check if there are more steps
                query_info = session['query_info']
                all_steps = query_info.get('all_steps', [])
                next_step_index = current_step['step_number']  # Next step (1-indexed)
                
                if next_step_index < len(all_steps):
                    # Move to next step
                    next_step = all_steps[next_step_index]  # 0-indexed array
                    session['current_step_number'] = next_step['step_number']
                    session['current_step'] = next_step
                    session['step_start_time'] = datetime.now().isoformat()
                    session['awaiting_feedback'] = True
                    self._set_session(session_id, session)
                    
                    return {
                        'type': 'next_step',
                        'current_step': next_step,
                        'message': f'Step {current_step["step_number"]} completed! Ready for step {next_step["step_number"]}',
                        'instruction': next_step['description'],
                        'tts_text': f'Step {next_step["step_number"]} of {len(all_steps)}: {next_step["title"]}. {next_step["description"]}',
                        'progress': {
                            'completed': len(session['completed_steps']),
                            'total': len(all_steps),
                            'percentage': round(len(session['completed_steps']) / len(all_steps) * 100, 1)
                        }
                    }
                else:
                    # All steps complete
                    total_time = sum(step['time_spent'] for step in session['completed_steps'])
                    self._cleanup_session(session_id)
                    
                    return {
                        'type': 'complete',
                        'message': f'Excellent! You have completed all {len(all_steps)} steps for: {query_info["original_query"]}',
                        'tts_text': f'Congratulations! You have successfully completed all {len(all_steps)} steps. Total time: {total_time:.1f} hours. Thank you for your detailed feedback!',
                        'total_time': total_time,
                        'total_steps': len(session['completed_steps'])
                    }
            
            else:
                return {'type': 'error', 'message': 'Unknown session type'}
        
        except Exception as e:
            return {'type': 'error', 'message': f'Error processing feedback: {str(e)}'}
    
    def get_session_status(self, session_id):
        """Get current session status"""
        session = self._get_session(session_id)
        if not session:
            return None
        
        return {
            'session_id': session_id,
            'type': session['type'],
            'current_step': session['current_step'],
            'awaiting_feedback': session['awaiting_feedback'],
            'completed_steps_count': len(session['completed_steps']),
            'step_start_time': session['step_start_time']
        }
    
    def list_active_sessions(self, user_id=None):
        """List active sessions, optionally filtered by user"""
        # Note: Django cache doesn't support iteration over keys with patterns
        # This method would require implementing a separate session registry
        # For now, return empty list and recommend using get_session_status with known session_ids
        print("⚠️  list_active_sessions: Cache-based storage doesn't support session enumeration")
        return []
    
    def _cleanup_session(self, session_id):
        """Clean up completed session"""
        self._delete_session(session_id)
    
    def cleanup_expired_sessions(self, max_age_hours=2):
        """Clean up sessions older than max_age_hours"""
        # Note: Django cache doesn't support iteration over keys with patterns
        # Sessions will automatically expire based on the cache timeout (self.session_timeout)
        # This method is not implemented for cache-based storage
        print("⚠️  cleanup_expired_sessions: Cache-based storage uses automatic expiration")

    def get_or_create_work_order_session(self, work_order_number, user_id):
        """
        Get existing work order session or return structure for creating new one.
        This maintains separate chat history per work order.
        """
        session_id = self.get_work_order_session_id(work_order_number, user_id)
        session = self._get_session(session_id)

        if session:
            # Return existing session with its chat history
            chat_history = self._get_chat_history(session_id)
            return {
                'session_id': session_id,
                'session_data': session,
                'chat_history': chat_history,
                'exists': True
            }
        else:
            # No existing session - will be created when work order starts
            return {
                'session_id': session_id,
                'session_data': None,
                'chat_history': [],
                'exists': False
            }

    def load_work_order_chat_history(self, work_order_number, user_id):
        """Load complete chat history for a work order"""
        session_id = self.get_work_order_session_id(work_order_number, user_id)
        return self._get_chat_history(session_id)

    def save_work_order_message(self, work_order_number, user_id, message):
        """Save a message to work order's chat history"""
        session_id = self.get_work_order_session_id(work_order_number, user_id)
        return self._add_chat_message(session_id, message)

    def reset_work_order_session(self, work_order_number, user_id):
        """Reset work order session and chat history (for start over)"""
        session_id = self.get_work_order_session_id(work_order_number, user_id)
        self._delete_session(session_id)
        print(f"🔄 Reset session and chat history for {work_order_number}")
        return session_id

    def switch_to_work_order(self, work_order_number, user_id):
        """
        Switch to a work order and return its complete chat history.
        This is the key method for seamless work order switching.
        """
        session_info = self.get_or_create_work_order_session(work_order_number, user_id)

        print(f"🔄 Switching to {work_order_number}: {'existing' if session_info['exists'] else 'new'} session")
        print(f"   Chat history: {len(session_info['chat_history'])} messages")

        return session_info
        return 0

# Global workflow handler instance
workflow_handler = ChatWorkflowHandler()

# Utility functions for Dash app
def detect_feedback_keywords(message):
    """Detect if message contains feedback keywords"""
    feedback_keywords = [
        'complete', 'completed', 'done', 'finished', 'step complete',
        'step done', 'step finished', 'next step', 'move on', 'ready for next'
    ]

    message_lower = message.lower()
    return any(keyword in message_lower for keyword in feedback_keywords)

def is_new_command(message):
    """Detect if message is a new command rather than feedback"""
    new_command_patterns = [
        'start', 'begin', 'resume', 'help me', 'work order', 'wo-', 'start over',
        'reset', 'new task', 'different', 'switch to', 'change to'
    ]

    message_lower = message.lower()
    return any(pattern in message_lower for pattern in new_command_patterns)

def should_treat_as_feedback(message, has_active_workflow):
    """Determine if message should be treated as feedback during active workflow"""
    if not has_active_workflow:
        return False

    # If it's clearly a new command, don't treat as feedback
    if is_new_command(message):
        return False

    # If it contains explicit feedback keywords, treat as feedback
    if detect_feedback_keywords(message):
        return True

    # For active workflows, treat any non-command message as feedback
    # This allows natural feedback like "checked refrigerant levels", "inspected", etc.
    return True

def extract_step_number_from_feedback(message):
    """Extract step number from feedback message"""
    import re
    
    # Look for patterns like "step 1 complete", "step 2 done", etc.
    patterns = [
        r'step\s+(\d+)\s+(?:complete|done|finished)',
        r'(?:complete|done|finished)\s+step\s+(\d+)',
        r'step\s+(\d+)'
    ]
    
    message_lower = message.lower()
    for pattern in patterns:
        match = re.search(pattern, message_lower)
        if match:
            return int(match.group(1))
    
    return None

def is_wake_word_command(message):
    """Check if message contains wake word"""
    wake_words = ['hey buddy', 'hey botty', 'assistant']
    message_lower = message.lower()
    return any(wake_word in message_lower for wake_word in wake_words)

def clean_wake_word_from_message(message):
    """Remove wake word from message"""
    wake_words = ['hey buddy', 'hey botty', 'assistant']
    message_lower = message.lower()
    
    for wake_word in wake_words:
        if wake_word in message_lower:
            # Find the position and remove it
            pos = message_lower.find(wake_word)
            if pos != -1:
                cleaned = message[:pos] + message[pos + len(wake_word):]
                return cleaned.strip()
    
    return message.strip()

if __name__ == "__main__":
    # Test the workflow handler
    handler = ChatWorkflowHandler()
    
    print("Chat Workflow Handler initialized")
    print("Available methods:")
    print("- start_work_order_session()")
    print("- start_general_query_session()")  
    print("- process_feedback()")
    print("- get_session_status()")
    print("- list_active_sessions()")
    print("- cleanup_expired_sessions()")