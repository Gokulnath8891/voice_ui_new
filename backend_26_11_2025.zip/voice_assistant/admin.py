from django.contrib import admin
from django.utils.html import format_html
from .models import (
    VoiceSession, SpeechRecognitionRequest, SemanticSearchRequest,
    RelevantChunk, TextToSpeechRequest, APIUsageLog, VectorStoreMetadata
)


@admin.register(VoiceSession)
class VoiceSessionAdmin(admin.ModelAdmin):
    list_display = ['session_id', 'user', 'total_requests', 'created_at', 'updated_at']
    list_filter = ['created_at', 'updated_at']
    search_fields = ['session_id', 'user__username']
    readonly_fields = ['session_id', 'created_at', 'updated_at']
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')


@admin.register(SpeechRecognitionRequest)
class SpeechRecognitionRequestAdmin(admin.ModelAdmin):
    list_display = [
        'request_id', 'session', 'audio_file_name', 'status', 
        'confidence_score', 'processing_time_ms', 'created_at'
    ]
    list_filter = ['status', 'created_at', 'audio_format']
    search_fields = ['request_id', 'recognized_text', 'audio_file_name']
    readonly_fields = ['request_id', 'created_at']
    
    fieldsets = (
        ('Request Info', {
            'fields': ('request_id', 'session', 'created_at')
        }),
        ('Audio Details', {
            'fields': ('audio_file_name', 'audio_format', 'audio_duration')
        }),
        ('Results', {
            'fields': ('recognized_text', 'confidence_score', 'status')
        }),
        ('Performance', {
            'fields': ('processing_time_ms', 'error_message')
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('session')


class RelevantChunkInline(admin.TabularInline):
    model = RelevantChunk
    extra = 0
    readonly_fields = ['rank', 'similarity_score', 'source']
    fields = ['rank', 'content', 'similarity_score', 'source']


@admin.register(SemanticSearchRequest)
class SemanticSearchRequestAdmin(admin.ModelAdmin):
    list_display = [
        'request_id', 'session', 'query_text_short', 'chunks_found',
        'status', 'processing_time_ms', 'created_at'
    ]
    list_filter = ['status', 'created_at', 'max_chunks']
    search_fields = ['request_id', 'query_text', 'summary_text']
    readonly_fields = ['request_id', 'created_at']
    inlines = [RelevantChunkInline]
    
    fieldsets = (
        ('Request Info', {
            'fields': ('request_id', 'session', 'created_at')
        }),
        ('Query Details', {
            'fields': ('query_text', 'max_chunks', 'similarity_threshold')
        }),
        ('Results', {
            'fields': ('summary_text', 'chunks_found', 'status')
        }),
        ('Performance', {
            'fields': ('processing_time_ms', 'error_message')
        }),
    )
    
    def query_text_short(self, obj):
        return obj.query_text[:50] + '...' if len(obj.query_text) > 50 else obj.query_text
    query_text_short.short_description = 'Query'
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('session')


@admin.register(RelevantChunk)
class RelevantChunkAdmin(admin.ModelAdmin):
    list_display = ['search_request', 'rank', 'similarity_score', 'source', 'content_short']
    list_filter = ['rank', 'source']
    search_fields = ['content', 'source']
    
    def content_short(self, obj):
        return obj.content[:100] + '...' if len(obj.content) > 100 else obj.content
    content_short.short_description = 'Content'


@admin.register(TextToSpeechRequest)
class TextToSpeechRequestAdmin(admin.ModelAdmin):
    list_display = [
        'request_id', 'session', 'text_short', 'text_length',
        'voice_rate', 'status', 'processing_time_ms', 'created_at'
    ]
    list_filter = ['status', 'created_at', 'voice_rate', 'voice_name']
    search_fields = ['request_id', 'input_text']
    readonly_fields = ['request_id', 'text_length', 'created_at']
    
    fieldsets = (
        ('Request Info', {
            'fields': ('request_id', 'session', 'created_at')
        }),
        ('Input Text', {
            'fields': ('input_text', 'text_length')
        }),
        ('Voice Settings', {
            'fields': ('voice_rate', 'voice_volume', 'voice_name')
        }),
        ('Results', {
            'fields': ('audio_file_path', 'audio_duration', 'status')
        }),
        ('Performance', {
            'fields': ('processing_time_ms', 'error_message')
        }),
    )
    
    def text_short(self, obj):
        return obj.input_text[:50] + '...' if len(obj.input_text) > 50 else obj.input_text
    text_short.short_description = 'Text'
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('session')


@admin.register(APIUsageLog)
class APIUsageLogAdmin(admin.ModelAdmin):
    list_display = [
        'endpoint', 'method', 'status_code', 'user', 'ip_address',
        'processing_time_ms', 'created_at'
    ]
    list_filter = ['status_code', 'method', 'endpoint', 'created_at']
    search_fields = ['endpoint', 'ip_address', 'user__username']
    readonly_fields = ['created_at']
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Request Info', {
            'fields': ('endpoint', 'method', 'status_code', 'created_at')
        }),
        ('User Details', {
            'fields': ('user', 'ip_address', 'user_agent')
        }),
        ('Performance', {
            'fields': ('processing_time_ms', 'request_size_bytes', 'response_size_bytes')
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')


@admin.register(VectorStoreMetadata)
class VectorStoreMetadataAdmin(admin.ModelAdmin):
    list_display = [
        'collection_name', 'total_documents', 'embedding_model',
        'is_active', 'last_updated', 'created_at'
    ]
    list_filter = ['is_active', 'embedding_model', 'created_at', 'last_updated']
    search_fields = ['collection_name', 'description']
    readonly_fields = ['last_updated', 'created_at']
    
    fieldsets = (
        ('Collection Info', {
            'fields': ('collection_name', 'description', 'is_active')
        }),
        ('Technical Details', {
            'fields': ('total_documents', 'embedding_model')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'last_updated')
        }),
    )


# Custom admin actions
def mark_as_active(modeladmin, request, queryset):
    queryset.update(is_active=True)
mark_as_active.short_description = "Mark selected collections as active"

def mark_as_inactive(modeladmin, request, queryset):
    queryset.update(is_active=False)
mark_as_inactive.short_description = "Mark selected collections as inactive"

VectorStoreMetadataAdmin.actions = [mark_as_active, mark_as_inactive]

# Register vector models if available
try:
    from .vector_models import (
        DocumentCollection, DocumentChunk, SearchQuery, 
        SearchResult, VectorSearchCache, VectorIndexStatus
    )
    
    @admin.register(DocumentCollection)
    class DocumentCollectionAdmin(admin.ModelAdmin):
        list_display = ['name', 'total_documents', 'embedding_model', 'is_active', 'created_at']
        list_filter = ['is_active', 'embedding_model', 'created_at']
        search_fields = ['name', 'description']
        readonly_fields = ['id', 'created_at', 'updated_at']
    
    @admin.register(DocumentChunk)
    class DocumentChunkAdmin(admin.ModelAdmin):
        list_display = ['content_short', 'collection', 'source', 'word_count', 'created_at']
        list_filter = ['collection', 'source_type', 'language', 'created_at']
        search_fields = ['content', 'source', 'metadata']
        readonly_fields = ['id', 'word_count', 'character_count', 'created_at', 'updated_at']
        
        def content_short(self, obj):
            return obj.content[:100] + '...' if len(obj.content) > 100 else obj.content
        content_short.short_description = 'Content'
    
    @admin.register(SearchQuery)
    class SearchQueryAdmin(admin.ModelAdmin):
        list_display = ['query_short', 'collection', 'results_count', 'search_time_ms', 'created_at']
        list_filter = ['collection', 'created_at']
        search_fields = ['query_text']
        readonly_fields = ['id', 'query_embedding', 'created_at']
        
        def query_short(self, obj):
            return obj.query_text[:50] + '...' if len(obj.query_text) > 50 else obj.query_text
        query_short.short_description = 'Query'
    
    @admin.register(VectorSearchCache)
    class VectorSearchCacheAdmin(admin.ModelAdmin):
        list_display = ['query_short', 'collection', 'cache_hits', 'last_accessed', 'expires_at']
        list_filter = ['collection', 'created_at', 'expires_at']
        search_fields = ['query_text']
        readonly_fields = ['query_hash', 'cached_results', 'created_at']
        
        def query_short(self, obj):
            return obj.query_text[:50] + '...' if len(obj.query_text) > 50 else obj.query_text
        query_short.short_description = 'Query'

except ImportError:
    # Vector models not available
    pass

# Customize admin site
admin.site.site_header = "Voice Assistant Administration"
admin.site.site_title = "Voice Assistant Admin"
admin.site.index_title = "Voice Assistant Management"
