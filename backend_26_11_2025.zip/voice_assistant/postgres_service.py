import time
import hashlib
import logging
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime, timedelta
from django.utils import timezone
from django.db import transaction, connection
from django.core.cache import cache
import numpy as np

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

try:
    from openai import AzureOpenAI
except ImportError:
    AzureOpenAI = None

try:
    from .vector_models import (
        DocumentCollection, DocumentChunk, SearchQuery, 
        SearchResult, VectorSearchCache, VectorIndexStatus
    )
except ImportError:
    # Fallback if pgvector models not available
    DocumentCollection = DocumentChunk = SearchQuery = SearchResult = None
    VectorSearchCache = VectorIndexStatus = None

from django.conf import settings

logger = logging.getLogger(__name__)


class PostgresVectorService:
    """Service for vector operations using PostgreSQL with pgvector"""
    
    def __init__(self, collection_name: str = "default"):
        if not SentenceTransformer:
            raise ImportError("sentence-transformers not installed")
        
        if not DocumentCollection:
            raise ImportError("pgvector models not available")
        
        self.collection_name = collection_name
        self.model_name = "thenlper/gte-large"
        self.embedding_dimension = 1024
        
        # Initialize embedding model (lazy loading)
        self._embedding_model = None
        self._collection = None
    
    @property
    def embedding_model(self):
        if self._embedding_model is None:
            self._embedding_model = SentenceTransformer(self.model_name)
        return self._embedding_model
    
    @property
    def collection(self):
        if self._collection is None:
            self._collection, created = DocumentCollection.objects.get_or_create(
                name=self.collection_name,
                defaults={
                    'description': f'Vector collection for {self.collection_name}',
                    'embedding_model': self.model_name,
                    'embedding_dimension': self.embedding_dimension,
                    'is_active': True
                }
            )
            
            if created:
                self._ensure_vector_index()
                logger.info(f"Created new collection: {self.collection_name}")
        
        return self._collection
    
    def _ensure_vector_index(self):
        """Ensure vector similarity index exists for better performance"""
        try:
            with connection.cursor() as cursor:
                # Create HNSW index for vector similarity search
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS document_chunks_embedding_hnsw_idx 
                    ON document_chunks 
                    USING hnsw (embedding vector_cosine_ops)
                    WHERE collection_id = %s;
                """, [str(self.collection.id)])
                
                # Create IVFFlat index as alternative (good for smaller datasets)
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS document_chunks_embedding_ivfflat_idx 
                    ON document_chunks 
                    USING ivfflat (embedding vector_cosine_ops) 
                    WITH (lists = 100)
                    WHERE collection_id = %s;
                """, [str(self.collection.id)])
                
                logger.info(f"Vector indexes ensured for collection {self.collection_name}")
        
        except Exception as e:
            logger.warning(f"Could not create vector indexes: {str(e)}")
    
    def add_documents(self, documents: List[Dict[str, Any]]) -> int:
        """Add documents to the vector store"""
        added_count = 0
        
        try:
            with transaction.atomic():
                for doc in documents:
                    content = doc.get('content', '')
                    if not content:
                        continue
                    
                    # Generate embedding
                    embedding = self.embedding_model.encode([content])[0]
                    
                    # Create document chunk
                    chunk = DocumentChunk.objects.create(
                        collection=self.collection,
                        content=content,
                        metadata=doc.get('metadata', {}),
                        source=doc.get('source', ''),
                        source_type=doc.get('source_type', ''),
                        chunk_index=doc.get('chunk_index', 0),
                        embedding=embedding.tolist(),
                        language=doc.get('language', 'en')
                    )
                    added_count += 1
                
                # Update collection count
                self.collection.total_documents = DocumentChunk.objects.filter(
                    collection=self.collection
                ).count()
                self.collection.save()
                
                logger.info(f"Added {added_count} documents to collection {self.collection_name}")
        
        except Exception as e:
            logger.error(f"Error adding documents: {str(e)}")
            raise
        
        return added_count
    
    def search_similar(self, query: str, max_results: int = 5, 
                      similarity_threshold: float = 0.7) -> Dict[str, Any]:
        """Search for similar documents using vector similarity"""
        start_time = time.time()
        
        try:
            # Check cache first
            cache_key = self._get_cache_key(query, max_results, similarity_threshold)
            cached_result = self._get_cached_result(cache_key)
            if cached_result:
                return cached_result
            
            # Generate query embedding
            embedding_start = time.time()
            query_embedding = self.embedding_model.encode([query])[0]
            embedding_time = int((time.time() - embedding_start) * 1000)
            
            # Perform vector similarity search
            search_start = time.time()
            
            # Create search query record
            search_query = SearchQuery.objects.create(
                collection=self.collection,
                query_text=query,
                query_embedding=query_embedding.tolist(),
                similarity_threshold=similarity_threshold,
                max_results=max_results,
                embedding_time_ms=embedding_time
            )
            
            # Execute similarity search using SQL
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT 
                        id,
                        content,
                        metadata,
                        source,
                        source_type,
                        chunk_index,
                        1 - (embedding <=> %s::vector) AS similarity_score
                    FROM document_chunks 
                    WHERE collection_id = %s 
                        AND 1 - (embedding <=> %s::vector) >= %s
                    ORDER BY embedding <=> %s::vector ASC
                    LIMIT %s;
                """, [
                    query_embedding.tolist(),
                    str(self.collection.id),
                    query_embedding.tolist(),
                    similarity_threshold,
                    query_embedding.tolist(),
                    max_results
                ])
                
                results = cursor.fetchall()
            
            search_time = int((time.time() - search_start) * 1000)
            
            # Process results
            relevant_chunks = []
            similarities = []
            
            for rank, (chunk_id, content, metadata, source, source_type, chunk_index, similarity) in enumerate(results):
                chunk_data = {
                    "content": content,
                    "similarity_score": round(float(similarity), 4),
                    "source": source or 'unknown',
                    "source_type": source_type,
                    "chunk_index": chunk_index,
                    "metadata": metadata or {}
                }
                relevant_chunks.append(chunk_data)
                similarities.append(float(similarity))
                
                # Create search result record
                SearchResult.objects.create(
                    search_query=search_query,
                    document_chunk_id=chunk_id,
                    similarity_score=float(similarity),
                    rank=rank + 1
                )
            
            # Update search query with results
            search_query.results_count = len(relevant_chunks)
            search_query.search_time_ms = search_time
            if similarities:
                search_query.highest_similarity = max(similarities)
                search_query.lowest_similarity = min(similarities)
            search_query.save()
            
            # Generate summary
            summary = self._generate_summary(query, relevant_chunks)
            
            total_time = int((time.time() - start_time) * 1000)
            
            result = {
                "status": "success",
                "query": query,
                "summary": summary,
                "relevant_chunks": relevant_chunks,
                "processing_time_ms": total_time,
                "embedding_time_ms": embedding_time,
                "search_time_ms": search_time,
                "total_chunks_in_collection": self.collection.total_documents
            }
            
            # Cache the result
            self._cache_result(cache_key, result)
            
            return result
        
        except Exception as e:
            processing_time = int((time.time() - start_time) * 1000)
            logger.error(f"Vector search error: {str(e)}")
            return {
                "status": "failed",
                "error": str(e),
                "processing_time_ms": processing_time
            }
    
    def _get_cache_key(self, query: str, max_results: int, similarity_threshold: float) -> str:
        """Generate cache key for search query"""
        cache_data = f"{self.collection_name}:{query}:{max_results}:{similarity_threshold}"
        return hashlib.sha256(cache_data.encode()).hexdigest()
    
    def _get_cached_result(self, cache_key: str) -> Optional[Dict]:
        """Get cached search result if available"""
        try:
            cached_entry = VectorSearchCache.objects.filter(
                query_hash=cache_key,
                collection=self.collection,
                expires_at__gt=timezone.now()
            ).first()
            
            if cached_entry:
                cached_entry.cache_hits += 1
                cached_entry.last_accessed = timezone.now()
                cached_entry.save()
                
                result = cached_entry.cached_results
                result['from_cache'] = True
                return result
        
        except Exception as e:
            logger.warning(f"Cache retrieval error: {str(e)}")
        
        return None
    
    def _cache_result(self, cache_key: str, result: Dict):
        """Cache search result for future use"""
        try:
            # Cache for 1 hour by default
            expires_at = timezone.now() + timedelta(hours=1)
            
            VectorSearchCache.objects.update_or_create(
                query_hash=cache_key,
                defaults={
                    'collection': self.collection,
                    'query_text': result['query'],
                    'cached_results': result,
                    'results_count': len(result.get('relevant_chunks', [])),
                    'expires_at': expires_at
                }
            )
        
        except Exception as e:
            logger.warning(f"Cache storage error: {str(e)}")
    
    def _generate_summary(self, query: str, chunks: List[Dict]) -> str:
        """Generate summary using Azure OpenAI or fallback method"""
        try:
            if not chunks:
                return "I couldn't find any relevant information for your query."
            
            # Try Azure OpenAI first
            if settings.AZURE_OPENAI_KEY and AzureOpenAI:
                return self._generate_openai_summary(query, chunks)
            else:
                return self._generate_fallback_summary(query, chunks)
        
        except Exception as e:
            logger.error(f"Summary generation error: {str(e)}")
            return self._generate_fallback_summary(query, chunks)
    
    def _generate_openai_summary(self, query: str, chunks: List[Dict]) -> str:
        """Generate summary using Azure OpenAI"""
        try:
            client = AzureOpenAI(
                api_key=settings.AZURE_OPENAI_KEY,
                api_version="2023-12-01-preview",
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT
            )
            
            # Prepare context from chunks
            context = "\n\n".join([
                f"Source: {chunk['source']}\n{chunk['content']}" 
                for chunk in chunks[:3]  # Limit context size
            ])
            
            messages = [
                {"role": "system", "content": "You are a helpful assistant that provides concise, accurate summaries based on the given context."},
                {"role": "user", "content": f"Query: {query}\n\nContext:\n{context}\n\nPlease provide a comprehensive but concise answer to the query based on the context provided."}
            ]
            
            response = client.chat.completions.create(
                model=settings.AZURE_OPENAI_DEPLOYMENT_NAME,
                messages=messages,
                max_tokens=500,
                temperature=0.3
            )
            
            return response.choices[0].message.content.strip()
        
        except Exception as e:
            logger.error(f"OpenAI summary generation error: {str(e)}")
            return self._generate_fallback_summary(query, chunks)
    
    def _generate_fallback_summary(self, query: str, chunks: List[Dict]) -> str:
        """Generate a simple fallback summary"""
        if not chunks:
            return "I couldn't find any relevant information for your query."
        
        # Simple extractive summary
        top_chunk = chunks[0]
        summary = f"Based on the available information: {top_chunk['content'][:300]}..."
        
        if len(chunks) > 1:
            summary += f"\n\nAdditional relevant information was found from {len(chunks)} sources with similarity scores ranging from {chunks[-1]['similarity_score']:.2f} to {chunks[0]['similarity_score']:.2f}."
        
        return summary
    
    def get_collection_stats(self) -> Dict[str, Any]:
        """Get collection statistics"""
        try:
            stats = {
                'name': self.collection.name,
                'total_documents': self.collection.total_documents,
                'embedding_model': self.collection.embedding_model,
                'embedding_dimension': self.collection.embedding_dimension,
                'is_active': self.collection.is_active,
                'created_at': self.collection.created_at,
                'updated_at': self.collection.updated_at
            }
            
            # Add search statistics
            total_searches = SearchQuery.objects.filter(collection=self.collection).count()
            if total_searches > 0:
                avg_search_time = SearchQuery.objects.filter(
                    collection=self.collection,
                    search_time_ms__isnull=False
                ).aggregate(avg_time=models.Avg('search_time_ms'))['avg_time']
                
                stats.update({
                    'total_searches': total_searches,
                    'average_search_time_ms': round(avg_search_time or 0, 2)
                })
            
            return stats
        
        except Exception as e:
            logger.error(f"Error getting collection stats: {str(e)}")
            return {'error': str(e)}
    
    def cleanup_old_data(self, days_to_keep: int = 30):
        """Clean up old search queries and cache entries"""
        try:
            cutoff_date = timezone.now() - timedelta(days=days_to_keep)
            
            # Clean old search queries
            old_queries = SearchQuery.objects.filter(
                collection=self.collection,
                created_at__lt=cutoff_date
            )
            deleted_queries = old_queries.count()
            old_queries.delete()
            
            # Clean expired cache entries
            expired_cache = VectorSearchCache.objects.filter(
                collection=self.collection,
                expires_at__lt=timezone.now()
            )
            deleted_cache = expired_cache.count()
            expired_cache.delete()
            
            logger.info(f"Cleaned up {deleted_queries} old queries and {deleted_cache} expired cache entries")
            return deleted_queries + deleted_cache
        
        except Exception as e:
            logger.error(f"Cleanup error: {str(e)}")
            return 0


# Service instance
_postgres_service = None

def get_postgres_vector_service(collection_name: str = "default"):
    """Get PostgreSQL vector service instance"""
    global _postgres_service
    if _postgres_service is None or _postgres_service.collection_name != collection_name:
        _postgres_service = PostgresVectorService(collection_name)
    return _postgres_service