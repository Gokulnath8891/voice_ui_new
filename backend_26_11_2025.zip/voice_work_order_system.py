#!/usr/bin/env python
"""
Voice-Activated Work Order System

This system handles the voice-activated workflow for work orders:
1. Voice input with work order ID
2. LLM generates task breakdown from work order details
3. Tasks stored in WorkOrderStep model
4. Voice instructions given to technician
5. Feedback collected and stored
6. Summary generated and saved

Usage:
    python voice_work_order_system.py
"""

import os
import sys
import time
# %%
import django
# %%


import logging
from pathlib import Path
from datetime import datetime
from decimal import Decimal
import re
import pyttsx3
import threading
from typing import List, Dict, Any
import json

# Add the project directory to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
django.setup()

from django.contrib.auth.models import User
from workorders.models import (
    WorkOrder, 
    WorkOrderStep, 
    WorkOrderFeedback, 
    WorkOrderSummary
)

# Import voice assistant components
try:
    from voice_assistant.postgres_service import get_postgres_vector_service
    from wake_word_detection.detector import WakeWordDetector
    VOICE_ASSISTANT_AVAILABLE = True
except ImportError:
    print("⚠️  Voice assistant components not available")
    VOICE_ASSISTANT_AVAILABLE = False

# Import voice proxy system
try:
    from voice_proxy_system import enhance_voice_work_order_extraction, voice_proxy, initialize_voice_proxy_for_user
    VOICE_PROXY_AVAILABLE = True
except ImportError:
    print("⚠️  Voice proxy system not available")
    VOICE_PROXY_AVAILABLE = False

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('voice_workorder.log')
    ]
)

logger = logging.getLogger(__name__)


class VectorService:
    """Service for handling PostgreSQL vector database operations using pgvector"""
    
    def __init__(self):
        self.embedding_model = None
        self.has_embeddings = False
        self.db_available = False
        self._initialize_vector_db()
    
    def _initialize_vector_db(self):
        """Initialize the PostgreSQL vector database connection"""
        try:
            from django.db import connection
            import pgvector.psycopg2
            
            # Try to initialize embedding model
            try:
                from sentence_transformers import SentenceTransformer
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
                self.has_embeddings = True
                logger.info("Embedding model loaded successfully")
            except ImportError:
                logger.warning("sentence-transformers not available, using text-only matching")
                self.embedding_model = None
                self.has_embeddings = False
            
            # Ensure connection is established
            connection.ensure_connection()
            
            # Register pgvector type
            pgvector.psycopg2.register_vector(connection.connection)
            
            # Check if pgvector extension is available
            with connection.cursor() as cursor:
                # Create pgvector extension if not exists
                cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
                
                # Create procedures table if not exists
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS work_order_procedures (
                        id SERIAL PRIMARY KEY,
                        content TEXT NOT NULL,
                        embedding VECTOR(384),
                        procedure_type VARCHAR(100),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                
                # Check if we have any procedures
                cursor.execute("SELECT COUNT(*) FROM work_order_procedures;")
                count = cursor.fetchone()[0]
                
                if count == 0:
                    self._add_sample_procedures()
            
            self.db_available = True
            logger.info("PostgreSQL vector database initialized successfully")
            
        except ImportError as e:
            logger.error(f"Failed to initialize vector service: {str(e).replace('No module named', 'missing module')} not installed")
            self.db_available = False
        except Exception as e:
            logger.error(f"Failed to initialize PostgreSQL vector database: {e}")
            self.db_available = False
    
    def search_relevant_procedures(self, query: str, n_results: int = 5) -> List[Dict[str, Any]]:
        """Search for relevant procedures based on work order description using PostgreSQL"""
        if not self.db_available:
            logger.warning("PostgreSQL vector database not available, using fallback")
            return self._get_fallback_procedures(query)
        
        try:
            from django.db import connection
            
            if self.has_embeddings and self.embedding_model:
                # Use vector similarity search
                # encode() with a string returns 1D array, with a list returns 2D array
                query_embedding = self.embedding_model.encode(query)
                embedding_list = query_embedding.tolist()
                
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT 
                            content,
                            procedure_type,
                            1 - (embedding <=> %s::vector) as similarity
                        FROM work_order_procedures
                        WHERE embedding IS NOT NULL
                        ORDER BY embedding <=> %s::vector
                        LIMIT %s;
                    """, [embedding_list, embedding_list, n_results])
                    
                    results = cursor.fetchall()
                    
                    # Format results
                    formatted_results = []
                    for row in results:
                        content, procedure_type, similarity = row
                        formatted_results.append({
                            'content': content,
                            'distance': 1.0 - similarity,  # Convert similarity to distance
                            'metadata': {'type': procedure_type or 'general'}
                        })
                    
                    logger.info(f"Found {len(formatted_results)} relevant procedures using vector search")
                    return formatted_results
            else:
                # Use text-based search as fallback
                query_lower = query.lower()
                keywords = [word.strip() for word in query_lower.split() if len(word.strip()) > 2]
                
                with connection.cursor() as cursor:
                    if keywords:
                        # Simple text matching
                        like_conditions = []
                        params = []
                        for keyword in keywords[:3]:  # Limit to first 3 keywords
                            like_conditions.append("LOWER(content) LIKE %s")
                            params.append(f"%{keyword}%")
                        
                        where_clause = " OR ".join(like_conditions)
                        cursor.execute(f"""
                            SELECT content, procedure_type
                            FROM work_order_procedures
                            WHERE {where_clause}
                            LIMIT %s;
                        """, params + [n_results])
                        
                        results = cursor.fetchall()
                        formatted_results = []
                        for content, proc_type in results:
                            formatted_results.append({
                                'content': content,
                                'distance': 0.5,  # Default distance for text matching
                                'metadata': {'type': proc_type or 'general'}
                            })
                        
                        if formatted_results:
                            logger.info(f"Found {len(formatted_results)} relevant procedures using text search")
                            return formatted_results
                
                # If no matches found, return fallback
                logger.warning("No procedures found in database, using fallback")
                return self._get_fallback_procedures(query)
            
        except Exception as e:
            logger.error(f"Error searching PostgreSQL vector database: {e}")
            return self._get_fallback_procedures(query)
    
    def _add_sample_procedures(self):
        """Add sample procedures to the PostgreSQL vector database"""
        sample_procedures = [
            {"content": "Safety preparation and workspace setup for brake repair work", "type": "brake"},
            {"content": "Remove wheels and inspect brake system components including pads and rotors", "type": "brake"},
            {"content": "Remove brake caliper and old brake pads using proper tools", "type": "brake"},
            {"content": "Clean and lubricate caliper slide pins and mounting hardware", "type": "brake"},
            {"content": "Install new brake pads and reassemble brake caliper properly", "type": "brake"},
            {"content": "Test brake pedal feel and perform brake system verification", "type": "brake"},
            {"content": "Warm up engine and prepare oil change workspace safely", "type": "oil"},
            {"content": "Drain old engine oil completely using proper drain procedures", "type": "oil"},
            {"content": "Replace oil filter with new one using correct installation torque", "type": "oil"},
            {"content": "Add new engine oil and check fluid levels", "type": "oil"},
            {"content": "Reset maintenance reminder systems and test indicators", "type": "oil"},
            {"content": "Inspect tire condition and check tire pressure measurements", "type": "tire"},
            {"content": "Remove wheels safely using proper lifting equipment", "type": "tire"},
            {"content": "Rotate tires according to manufacturer recommended pattern", "type": "tire"},
            {"content": "Install wheels with proper torque specifications", "type": "tire"},
            {"content": "Test drive vehicle and verify proper operation", "type": "general"},
            {"content": "Check engine diagnostic procedures and code reading", "type": "engine"},
            {"content": "Battery testing and electrical system diagnosis", "type": "electrical"},
            {"content": "Cooling system inspection and thermostat replacement", "type": "cooling"},
            {"content": "Air conditioning system diagnosis and refrigerant service", "type": "ac"},
            {"content": "Suspension component inspection and replacement procedures", "type": "suspension"},
            {"content": "Transmission fluid service and filter replacement", "type": "transmission"}
        ]
        
        try:
            from django.db import connection
            
            # Insert procedures with or without embeddings
            with connection.cursor() as cursor:
                for proc in sample_procedures:
                    if self.has_embeddings and self.embedding_model:
                        # Generate embedding for this procedure
                        embedding = self.embedding_model.encode([proc["content"]])
                        embedding_list = embedding[0].tolist()
                        cursor.execute("""
                            INSERT INTO work_order_procedures (content, embedding, procedure_type)
                            VALUES (%s, %s, %s)
                        """, [proc["content"], embedding_list, proc["type"]])
                    else:
                        # Insert without embedding (will be NULL)
                        cursor.execute("""
                            INSERT INTO work_order_procedures (content, procedure_type)
                            VALUES (%s, %s)
                        """, [proc["content"], proc["type"]])
            
            logger.info(f"Added {len(sample_procedures)} sample procedures to PostgreSQL vector database")
            
        except Exception as e:
            logger.error(f"Failed to add sample procedures to PostgreSQL: {e}")
    
    def _get_fallback_procedures(self, query: str) -> List[Dict[str, Any]]:
        """Fallback procedures when vector DB is not available"""
        query_lower = query.lower()
        
        fallback_procedures = {
            'brake': [
                'Safety inspection and preparation of work area',
                'Remove wheels and inspect brake system components', 
                'Remove brake caliper and old brake pads',
                'Clean and lubricate caliper components',
                'Install new brake pads and reassemble',
                'Test brake system operation and road test'
            ],
            'oil': [
                'Warm up engine and prepare workspace',
                'Drain old engine oil completely',
                'Replace oil filter with new one',
                'Install new oil and check levels',
                'Reset maintenance indicators',
                'Dispose of waste oil properly'
            ],
            'tire': [
                'Inspect current tire condition and pressure',
                'Remove wheels from vehicle safely',
                'Rotate tires according to pattern',
                'Check and adjust tire pressures',
                'Reinstall wheels with proper torque',
                'Test drive and verify alignment'
            ]
        }
        
        for key, procedures in fallback_procedures.items():
            if key in query_lower:
                return [{'content': proc, 'distance': 0.1, 'metadata': {'type': 'fallback'}} 
                       for proc in procedures]
        
        # Generic fallback
        return [
            {'content': 'Inspect and prepare work area', 'distance': 0.2, 'metadata': {'type': 'generic'}},
            {'content': 'Perform diagnostic procedures', 'distance': 0.2, 'metadata': {'type': 'generic'}},
            {'content': 'Complete required repairs', 'distance': 0.2, 'metadata': {'type': 'generic'}},
            {'content': 'Test and verify repairs', 'distance': 0.2, 'metadata': {'type': 'generic'}},
            {'content': 'Clean up and document work', 'distance': 0.2, 'metadata': {'type': 'generic'}}
        ]


class TTSService:
    """Text-to-Speech service using pyttsx3"""

    def __init__(self):
        self.engine = None
        self._tts_lock = threading.Lock()  # Thread lock for TTS operations
        self._initialize_tts()

    def _initialize_tts(self):
        """Initialize the TTS engine"""
        try:
            self.engine = pyttsx3.init()

            # Configure voice settings
            voices = self.engine.getProperty('voices')
            if voices:
                self.engine.setProperty('voice', voices[0].id)

            self.engine.setProperty('rate', 175)  # Speech rate
            self.engine.setProperty('volume', 0.9)  # Volume level

            logger.info("TTS engine initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize TTS engine: {e}")
            self.engine = None
    
    def speak(self, text: str, blocking: bool = True):
        """Speak the given text"""
        if not self.engine:
            logger.warning(f"TTS not available, would speak: {text}")
            print(f"🔊 TTS: {text}")
            return

        def speak_safely():
            """Thread-safe TTS function"""
            try:
                with self._tts_lock:  # Ensure only one TTS operation at a time
                    self.engine.say(text)
                    self.engine.runAndWait()
                    print(f"🔊 TTS: {text}")
            except RuntimeError as e:
                if "run loop already started" in str(e):
                    # Fallback: just print the text if TTS fails
                    print(f"🔊 TTS (fallback): {text}")
                    logger.warning(f"TTS run loop conflict, using fallback: {text}")
                else:
                    raise e
            except Exception as e:
                logger.error(f"TTS error: {e}")
                print(f"🔊 TTS Error, would speak: {text}")

        # Always run in a separate thread
        thread = threading.Thread(target=speak_safely, daemon=True)
        thread.start()

        if blocking:
            thread.join(timeout=5)  # Wait max 5 seconds for completion


class LLMService:
    """Service for LLM interactions with Azure OpenAI support"""
    
    def __init__(self):
        self.client = None
        self.is_azure = False
        self.model_name = "gpt-4.1-mini"
        self._initialize_llm()
    
    def _initialize_llm(self):
        """Initialize the LLM client - prioritize Azure OpenAI"""
        try:
            import openai
            
            # Check for Azure OpenAI configuration first (use existing env var names)
            azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
            azure_api_key = os.getenv('AZURE_OPENAI_KEY')  # Use existing variable name
            azure_api_version = os.getenv('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
            azure_deployment_name = os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME', 'gpt-4.1-mini')  # Use existing default
            print(azure_endpoint,"|",azure_api_key,"|",azure_api_version,"|",azure_deployment_name)
            
            if azure_endpoint and azure_api_key:
                # Use Azure OpenAI
                self.client = openai.AzureOpenAI(
                    azure_endpoint=azure_endpoint,
                    api_key=azure_api_key,
                    api_version=azure_api_version
                )
                self.is_azure = True
                self.model_name = azure_deployment_name
                logger.info("Azure OpenAI client initialized successfully")
                return
            
            # Fallback to standard OpenAI
            openai_api_key = os.getenv('OPENAI_API_KEY')
            if openai_api_key:
                self.client = openai.OpenAI(api_key=openai_api_key)
                self.is_azure = False
                self.model_name = "gpt-4.1-mini"
                logger.info("Standard OpenAI client initialized successfully")
                return
            
            # No API keys found
            logger.warning("No Azure OpenAI or OpenAI API credentials found, using mock responses")
            
        except ImportError:
            logger.error("OpenAI package not installed")
        except Exception as e:
            logger.error(f"Failed to initialize LLM client: {e}")
    
    def generate_question_from_work_order(self, title: str, description: str) -> str:
        """Convert work order title and description into a question for vector search"""
        
        if not self.client:
            # Fallback question generation
            return f"How do I perform {title.lower()}? What are the steps for {description.lower()}?"
        
        try:
            prompt = f"""
            Convert this work order into a clear question that would help find relevant maintenance procedures:
            
            Title: {title}
            Description: {description}
            
            Generate a specific question that focuses on the technical procedures needed.
            Keep it concise and focused on actionable steps.
            """
            
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=100,
                temperature=0.3
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"LLM error: {e}")
            return f"How do I perform {title.lower()}? What are the steps for {description.lower()}?"
    
    def generate_detailed_steps(self, work_order_title: str, work_order_description: str, 
                               relevant_procedures: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate detailed work order steps using LLM with vector context"""
        
        if not self.client:
            return self._generate_fallback_steps(work_order_title, work_order_description)
        
        try:
            # Format relevant procedures for context
            context = "\\n".join([proc['content'] for proc in relevant_procedures[:3]])
            
            prompt = f"""
            Generate 6-8 detailed work steps for this automotive service task:
            
            Title: {work_order_title}
            Description: {work_order_description}
            
            Related procedures for context:
            {context}
            
            Return a JSON array of steps, each with:
            - title: Brief step title
            - description: Detailed instructions (2-3 sentences)
            - estimated_time: Time in hours (decimal, like 0.25, 0.5, 1.0)
            
            Focus on safety, proper procedures, and logical sequence.
            """
            
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.4
            )
            
            # Parse JSON response
            steps_json = response.choices[0].message.content.strip()
            
            # Clean up JSON if it's wrapped in code blocks
            if steps_json.startswith("```json"):
                steps_json = steps_json.replace("```json", "").replace("```", "").strip()
            elif steps_json.startswith("```"):
                steps_json = steps_json.replace("```", "").strip()
            
            steps = json.loads(steps_json)
            
            # Validate and ensure proper format
            formatted_steps = []
            for i, step in enumerate(steps, 1):
                formatted_steps.append({
                    'step_number': i,
                    'title': step.get('title', f'Step {i}'),
                    'description': step.get('description', 'Perform required work'),
                    'estimated_time': float(step.get('estimated_time', 0.5))
                })
            
            return formatted_steps
            
        except Exception as e:
            logger.error(f"LLM step generation error: {e}")
            return self._generate_fallback_steps(work_order_title, work_order_description)
    
    def _generate_fallback_steps(self, title: str, description: str) -> List[Dict[str, Any]]:
        """Generate fallback steps when LLM is not available"""
        
        # Basic pattern matching for common services
        title_lower = title.lower()
        
        if 'brake' in title_lower:
            return [
                {'step_number': 1, 'title': 'Safety Setup and Initial Inspection', 'description': 'Ensure vehicle is on level ground, engage parking brake. Gather brake service tools. Inspect brake fluid level and color. Check for external brake fluid leaks.', 'estimated_time': 0.25},
                {'step_number': 2, 'title': 'Remove Wheels and Inspect Brake System', 'description': 'Raise vehicle safely and remove wheels. Visually inspect brake pads, rotors, calipers, and brake lines. Measure rotor thickness and check for scoring or warping.', 'estimated_time': 0.5},
                {'step_number': 3, 'title': 'Remove Brake Caliper and Pads', 'description': 'Remove brake caliper bolts carefully. Support caliper with wire hanger. Remove old brake pads and inspect caliper pistons. Check caliper slide pins for proper operation.', 'estimated_time': 0.5},
                {'step_number': 4, 'title': 'Prepare Caliper and Install New Pads', 'description': 'Clean caliper bracket and lubricate slide pins. Compress caliper piston using proper tool. Install new brake pads with anti-squeal compound. Ensure proper pad orientation.', 'estimated_time': 0.5},
                {'step_number': 5, 'title': 'Reinstall Caliper and Wheels', 'description': 'Reinstall brake caliper with proper torque specification. Reinstall wheels and lower vehicle. Pump brake pedal to seat pads against rotors.', 'estimated_time': 0.5},
                {'step_number': 6, 'title': 'Test Brake System Performance', 'description': 'Check brake pedal feel and travel. Test drive at low speed to verify proper brake operation. Check for any unusual noises or vibrations.', 'estimated_time': 0.25}
            ]
        elif 'oil' in title_lower:
            return [
                {'step_number': 1, 'title': 'Prepare Vehicle and Workspace', 'description': 'Warm engine to operating temperature. Position vehicle on level ground. Gather oil change tools and materials. Locate drain plug and oil filter.', 'estimated_time': 0.25},
                {'step_number': 2, 'title': 'Drain Old Engine Oil', 'description': 'Remove drain plug and allow oil to drain completely. Inspect drain plug and gasket condition. Clean drain plug threads and surrounding area.', 'estimated_time': 0.5},
                {'step_number': 3, 'title': 'Replace Oil Filter', 'description': 'Remove old oil filter using proper filter wrench. Clean filter mounting surface. Apply thin layer of oil to new filter gasket and install.', 'estimated_time': 0.25},
                {'step_number': 4, 'title': 'Add New Engine Oil', 'description': 'Install drain plug with new gasket if needed. Add recommended amount of new engine oil. Check oil level and add as necessary to reach proper level.', 'estimated_time': 0.25},
                {'step_number': 5, 'title': 'Final Inspection and Testing', 'description': 'Start engine and check for leaks around drain plug and filter. Turn off engine and recheck oil level after 5 minutes. Reset oil life monitor if equipped.', 'estimated_time': 0.25}
            ]
        else:
            # Generic steps
            return [
                {'step_number': 1, 'title': 'Initial Inspection and Setup', 'description': 'Review work order requirements and gather necessary tools. Perform initial vehicle inspection. Prepare workspace for service.', 'estimated_time': 0.25},
                {'step_number': 2, 'title': 'Diagnostic Procedures', 'description': 'Perform required diagnostic tests. Document findings and confirm service requirements. Identify any additional issues.', 'estimated_time': 0.5},
                {'step_number': 3, 'title': 'Service Preparation', 'description': 'Prepare vehicle for service work. Disconnect or protect sensitive components. Gather replacement parts and materials.', 'estimated_time': 0.25},
                {'step_number': 4, 'title': 'Perform Required Service', 'description': 'Complete the required service work according to manufacturer specifications. Follow proper procedures and safety protocols.', 'estimated_time': 1.0},
                {'step_number': 5, 'title': 'Quality Check and Testing', 'description': 'Inspect completed work for quality and completeness. Test system operation and verify proper function. Check for any leaks or issues.', 'estimated_time': 0.25},
                {'step_number': 6, 'title': 'Final Documentation', 'description': 'Clean work area and dispose of waste materials properly. Document work completed and any recommendations. Prepare vehicle for customer return.', 'estimated_time': 0.25}
            ]


class WorkOrderTaskBreakdownService:
    """Service to break down work orders into detailed steps using LLM and vector search"""
    
    def __init__(self):
        # Initialize new service components
        self.vector_service = VectorService()
        self.llm_service = LLMService()
        logger.info("Task breakdown service initialized with new components")
    
    def generate_task_breakdown(self, work_order: WorkOrder) -> list:
        """
        Generate detailed task breakdown for a work order using LLM and vector search
        
        Process:
        1. Convert work order title/description into a question using LLM
        2. Query vector database for relevant procedure chunks
        3. Generate detailed stepwise solution using LLM with context
        4. Store steps in WorkOrderStep model
        
        Args:
            work_order: WorkOrder instance
            
        Returns:
            List of WorkOrderStep objects created
        """
        logger.info(f"Generating task breakdown for work order: {work_order.order_number}")
        
        try:
            # Step 1: Convert work order into a question format using LLM
            question = self.llm_service.generate_question_from_work_order(
                work_order.title, work_order.description
            )
            logger.info(f"Generated question: {question}")
            
            # Step 2: Query vector database for relevant procedures
            relevant_procedures = self.vector_service.search_relevant_procedures(question)
            logger.info(f"Found {len(relevant_procedures)} relevant procedures")
            
            # Step 3: Generate detailed steps using LLM with context
            step_data = self.llm_service.generate_detailed_steps(
                work_order.title, work_order.description, relevant_procedures
            )
            
            # Step 4: Create WorkOrderStep objects
            created_steps = []
            total_estimated_time = 0
            
            for step_info in step_data:
                step = WorkOrderStep.objects.create(
                    work_order=work_order,
                    step_number=step_info['step_number'],
                    title=step_info['title'],
                    description=step_info['description'],
                    estimated_time=step_info['estimated_time']
                )
                created_steps.append(step)
                total_estimated_time += step_info['estimated_time']
            
            # Update work order estimated hours
            work_order.estimated_hours = Decimal(str(total_estimated_time))
            work_order.save()
            
            logger.info(f"Created {len(created_steps)} steps for work order {work_order.order_number}")
            return created_steps
            
        except Exception as e:
            logger.error(f"Error generating task breakdown: {e}")
            # Fallback to basic steps
            return self._create_fallback_steps(work_order)
    
    def _create_fallback_steps(self, work_order: WorkOrder) -> list:
        """Create basic fallback steps when LLM/vector search fails"""
        try:
            # Use the LLM service fallback method
            fallback_data = self.llm_service._generate_fallback_steps(work_order.title, work_order.description)
            
            created_steps = []
            total_estimated_time = 0
            
            for step_info in fallback_data:
                step = WorkOrderStep.objects.create(
                    work_order=work_order,
                    step_number=step_info['step_number'],
                    title=step_info['title'],
                    description=step_info['description'],
                    estimated_time=step_info['estimated_time']
                )
                created_steps.append(step)
                total_estimated_time += step_info['estimated_time']
            
            # Update work order estimated hours
            work_order.estimated_hours = Decimal(str(total_estimated_time))
            work_order.save()
            
            logger.info(f"Created {len(created_steps)} fallback steps for work order {work_order.order_number}")
            return created_steps
            
        except Exception as e:
            logger.error(f"Error creating fallback steps: {e}")
            return []
    
    def _convert_to_question(self, work_order: WorkOrder) -> str:
        """
        Convert work order title and description into a question format for vector search
        
        Args:
            work_order: WorkOrder instance
            
        Returns:
            Question string optimized for vector search
        """
        title = work_order.title.strip()
        description = work_order.description.strip()
        vehicle = f"{work_order.vehicle.year} {work_order.vehicle.make} {work_order.vehicle.model}"
        
        # Convert common work order patterns to questions
        if "oil change" in title.lower():
            question = f"How to perform oil change on {vehicle}? {description}"
        elif "brake" in title.lower():
            if "pad" in title.lower():
                question = f"How to replace brake pads on {vehicle}? {description}"
            else:
                question = f"How to service brake system on {vehicle}? {description}"
        elif "air conditioning" in title.lower() or "ac" in title.lower():
            question = f"How to diagnose and repair air conditioning problems in {vehicle}? {description}"
        elif "transmission" in title.lower():
            question = f"How to diagnose and fix transmission issues in {vehicle}? {description}"
        elif "check engine" in title.lower() or "diagnostic" in title.lower():
            question = f"How to diagnose check engine light problems in {vehicle}? {description}"
        elif "battery" in title.lower():
            question = f"How to test and replace battery in {vehicle}? {description}"
        elif "coolant" in title.lower():
            question = f"How to service cooling system in {vehicle}? {description}"
        elif "spark plug" in title.lower():
            question = f"How to replace spark plugs in {vehicle}? {description}"
        elif "suspension" in title.lower() or "strut" in title.lower():
            question = f"How to replace suspension components in {vehicle}? {description}"
        elif "tire" in title.lower() and "alignment" in title.lower():
            question = f"How to perform tire rotation and wheel alignment on {vehicle}? {description}"
        else:
            # Generic question format
            question = f"How to {title.lower()} for {vehicle}? {description}"
        
        # Clean up the question
        question = question.replace("  ", " ").strip()
        
        return question
    
    def _query_vector_database(self, question: str, work_order: WorkOrder) -> dict:
        """
        Query vector database for relevant solution chunks
        
        Args:
            question: Formatted question for vector search
            work_order: WorkOrder instance for additional context
            
        Returns:
            Dictionary with search results and relevant chunks
        """
        if not self.vector_service:
            logger.warning("Vector service not available")
            return None
        
        try:
            # Primary search with the question
            logger.info(f"Querying vector database with question: {question}")
            
            result = self.vector_service.search_similar(
                query=question,
                max_results=8,  # Get more chunks for better context
                similarity_threshold=0.5  # Lower threshold to get more results
            )
            
            if result["status"] == "success":
                logger.info(f"Vector search successful. Found {len(result.get('relevant_chunks', []))} chunks")
                return result
            else:
                logger.warning(f"Vector search failed: {result.get('error', 'Unknown error')}")
                
                # Fallback search with just title and vehicle
                fallback_query = f"{work_order.title} {work_order.vehicle.make} {work_order.vehicle.model}"
                logger.info(f"Trying fallback search: {fallback_query}")
                
                fallback_result = self.vector_service.search_similar(
                    query=fallback_query,
                    max_results=5,
                    similarity_threshold=0.4
                )
                
                if fallback_result["status"] == "success":
                    logger.info("Fallback search successful")
                    return fallback_result
                else:
                    logger.error("Both primary and fallback searches failed")
                    return None
                    
        except Exception as e:
            logger.error(f"Error querying vector database: {e}")
            return None
    
    def _generate_tasks_from_chunks(self, work_order: WorkOrder, question: str, search_result: dict) -> list:
        """
        Generate stepwise tasks from relevant chunks found in vector database
        
        Args:
            work_order: WorkOrder instance
            question: Original question asked
            search_result: Results from vector database search
            
        Returns:
            List of task dictionaries
        """
        try:
            relevant_chunks = search_result.get('relevant_chunks', [])
            summary = search_result.get('summary', '')
            
            logger.info(f"Generating tasks from {len(relevant_chunks)} relevant chunks")
            
            # In a real implementation, this would use an LLM to process the chunks
            # For now, we'll create a structured approach based on the chunks
            
            if not relevant_chunks and not summary:
                logger.warning("No chunks or summary available, using template tasks")
                return self._generate_example_tasks(work_order)
            
            # Analyze chunks to determine task structure
            combined_content = summary + "\n\n"
            for chunk in relevant_chunks[:5]:  # Use top 5 chunks
                combined_content += f"Content: {chunk.get('content', '')}\n"
                combined_content += f"Source: {chunk.get('source', 'Unknown')}\n\n"
            
            # Generate tasks based on content analysis
            tasks = self._analyze_content_for_tasks(work_order, question, combined_content)
            
            logger.info(f"Generated {len(tasks)} tasks from vector search results")
            return tasks
            
        except Exception as e:
            logger.error(f"Error generating tasks from chunks: {e}")
            return self._generate_example_tasks(work_order)
    
    def _analyze_content_for_tasks(self, work_order: WorkOrder, question: str, content: str) -> list:
        """
        Analyze the content from vector search to generate specific tasks
        
        This is a simplified version - in production, this would use an LLM
        to intelligently parse the content and generate tasks.
        """
        content_lower = content.lower()
        title_lower = work_order.title.lower()
        
        # Determine service type and generate appropriate tasks
        if "oil change" in title_lower or "oil" in content_lower:
            return self._generate_oil_change_tasks_from_content(content)
        elif "brake" in title_lower or "brake" in content_lower:
            return self._generate_brake_tasks_from_content(content)
        elif "air conditioning" in title_lower or "ac" in content_lower:
            return self._generate_ac_tasks_from_content(content)
        elif "transmission" in title_lower or "transmission" in content_lower:
            return self._generate_transmission_tasks_from_content(content)
        elif "diagnostic" in title_lower or "check engine" in title_lower:
            return self._generate_diagnostic_tasks_from_content(content)
        elif "battery" in title_lower or "battery" in content_lower:
            return self._generate_battery_tasks_from_content(content)
        else:
            return self._generate_general_tasks_from_content(work_order, content)
    
    def _generate_oil_change_tasks_from_content(self, content: str) -> list:
        """Generate oil change tasks based on content from vector search"""
        base_tasks = self._oil_change_tasks()
        
        # Enhance tasks with content-specific information
        enhanced_tasks = []
        for task in base_tasks:
            enhanced_task = task.copy()
            
            # Add content-specific enhancements
            if "drain" in task['title'].lower() and "drain pan" in content.lower():
                enhanced_task['description'] += " Ensure drain pan is properly positioned to avoid spills."
            
            if "filter" in task['title'].lower() and ("filter wrench" in content.lower() or "hand tight" in content.lower()):
                enhanced_task['description'] += " Use appropriate filter wrench and tighten hand-tight plus 3/4 turn as specified."
            
            if "oil level" in task['title'].lower() and "dipstick" in content.lower():
                enhanced_task['description'] += " Use dipstick to verify oil level is between MIN and MAX marks."
            
            enhanced_tasks.append(enhanced_task)
        
        return enhanced_tasks
    
    def _generate_brake_tasks_from_content(self, content: str) -> list:
        """Generate brake service tasks based on content from vector search"""
        base_tasks = self._brake_service_tasks()
        
        # Enhance with content-specific details
        enhanced_tasks = []
        for task in base_tasks:
            enhanced_task = task.copy()
            
            if "caliper" in task['title'].lower() and "brake fluid" in content.lower():
                enhanced_task['description'] += " Be careful not to spill brake fluid on painted surfaces."
            
            if "rotor" in task['description'].lower() and ("thickness" in content.lower() or "measure" in content.lower()):
                enhanced_task['description'] += " Measure rotor thickness and check for scoring or warping."
            
            enhanced_tasks.append(enhanced_task)
        
        return enhanced_tasks
    
    def _generate_ac_tasks_from_content(self, content: str) -> list:
        """Generate AC service tasks based on content from vector search"""
        return self._ac_service_tasks()  # Base AC tasks
    
    def _generate_transmission_tasks_from_content(self, content: str) -> list:
        """Generate transmission service tasks based on content from vector search"""
        return self._transmission_service_tasks()  # Base transmission tasks
    
    def _generate_diagnostic_tasks_from_content(self, content: str) -> list:
        """Generate diagnostic tasks based on content from vector search"""
        return self._diagnostic_tasks()  # Base diagnostic tasks
    
    def _generate_battery_tasks_from_content(self, content: str) -> list:
        """Generate battery service tasks based on content from vector search"""
        return self._battery_service_tasks()  # Base battery tasks
    
    def _generate_general_tasks_from_content(self, work_order: WorkOrder, content: str) -> list:
        """Generate general tasks based on content analysis"""
        # Analyze content for common patterns
        tasks = []
        estimated_time = float(work_order.estimated_hours) if work_order.estimated_hours else 2.0
        time_per_task = estimated_time / 4  # Divide into 4 main tasks
        
        # Generic task structure based on content
        tasks.extend([
            {
                "title": f"Initial Assessment - {work_order.title}",
                "description": f"Review work order requirements: {work_order.description[:150]}... Perform initial visual inspection based on available documentation.",
                "estimated_time": time_per_task * 0.5
            },
            {
                "title": "Diagnostic and Investigation",
                "description": "Perform detailed diagnostic procedures based on symptoms and available technical information. Document findings and identify root cause.",
                "estimated_time": time_per_task
            },
            {
                "title": "Execute Required Service",
                "description": f"Perform the required service work: {work_order.title}. Follow safety procedures and manufacturer specifications.",
                "estimated_time": time_per_task * 2
            },
            {
                "title": "Testing and Final Verification",
                "description": "Test repaired system for proper operation. Verify all work is completed according to specifications. Document results and recommendations.",
                "estimated_time": time_per_task * 0.5
            }
        ])
        
        return tasks
    
    def _generate_example_tasks(self, work_order: WorkOrder, enhanced_context=False) -> list:
        """Generate example task breakdown based on work order type"""
        
        # Determine task type based on title keywords
        title_lower = work_order.title.lower()
        
        if "oil change" in title_lower:
            return self._oil_change_tasks()
        elif "brake" in title_lower:
            return self._brake_service_tasks()
        elif "air conditioning" in title_lower or "ac" in title_lower:
            return self._ac_service_tasks()
        elif "transmission" in title_lower:
            return self._transmission_service_tasks()
        elif "check engine" in title_lower or "diagnostic" in title_lower:
            return self._diagnostic_tasks()
        elif "battery" in title_lower:
            return self._battery_service_tasks()
        else:
            return self._general_service_tasks(work_order)
    
    def _oil_change_tasks(self) -> list:
        """Oil change task breakdown"""
        return [
            {
                "title": "Safety Setup and Vehicle Preparation",
                "description": "Ensure vehicle is on level ground, engage parking brake, let engine cool for 10 minutes. Gather tools: oil drain pan, socket wrench, oil filter wrench, funnel.",
                "estimated_time": 0.25
            },
            {
                "title": "Raise Vehicle and Locate Drain Plug",
                "description": "Use hydraulic lift or jack and stands to raise vehicle safely. Locate oil drain plug and oil filter. Check for any visible leaks or damage to oil pan.",
                "estimated_time": 0.25
            },
            {
                "title": "Drain Old Engine Oil",
                "description": "Position drain pan under oil drain plug. Remove drain plug with appropriate socket. Allow oil to drain completely (15-20 minutes). Inspect drain plug and washer.",
                "estimated_time": 0.5
            },
            {
                "title": "Replace Oil Filter",
                "description": "Locate and remove old oil filter using filter wrench. Clean filter mounting surface. Apply thin layer of new oil to new filter gasket. Install new filter hand-tight plus 3/4 turn.",
                "estimated_time": 0.25
            },
            {
                "title": "Reinstall Drain Plug and Add New Oil",
                "description": "Clean drain plug threads and oil pan threads. Reinstall drain plug with new washer if needed. Torque to specification. Lower vehicle. Add new oil through filler cap using funnel.",
                "estimated_time": 0.25
            },
            {
                "title": "Check Oil Level and Test",
                "description": "Start engine and let idle for 2-3 minutes. Turn off and wait 5 minutes. Check oil level with dipstick. Add oil if needed. Check for leaks under vehicle.",
                "estimated_time": 0.25
            },
            {
                "title": "Final Inspection and Documentation",
                "description": "Reset oil life monitor if equipped. Record oil type, amount used, and mileage. Complete service checklist. Clean work area and dispose of waste oil properly.",
                "estimated_time": 0.25
            }
        ]
    
    def _brake_service_tasks(self) -> list:
        """Brake service task breakdown"""
        return [
            {
                "title": "Safety Setup and Initial Inspection",
                "description": "Ensure vehicle is on level ground, engage parking brake. Gather brake service tools. Inspect brake fluid level and color. Check for external brake fluid leaks.",
                "estimated_time": 0.25
            },
            {
                "title": "Remove Wheels and Inspect Brake System",
                "description": "Raise vehicle safely and remove wheels. Visually inspect brake pads, rotors, calipers, and brake lines. Measure rotor thickness and check for scoring or warping.",
                "estimated_time": 0.5
            },
            {
                "title": "Remove Brake Caliper and Pads",
                "description": "Remove brake caliper bolts carefully. Support caliper with wire hanger. Remove old brake pads and inspect caliper pistons. Check caliper slide pins for proper operation.",
                "estimated_time": 0.5
            },
            {
                "title": "Prepare Caliper and Install New Pads",
                "description": "Clean caliper bracket and lubricate slide pins. Compress caliper piston using proper tool. Install new brake pads with correct orientation and hardware.",
                "estimated_time": 0.5
            },
            {
                "title": "Reinstall Caliper and Wheels",
                "description": "Reinstall brake caliper with proper torque specification. Reinstall wheels and lower vehicle. Pump brake pedal to seat pads before moving vehicle.",
                "estimated_time": 0.5
            },
            {
                "title": "Test Brake System Performance",
                "description": "Check brake pedal feel and travel. Test drive at low speed to verify proper brake operation. Check for any unusual noises, vibration, or pulling.",
                "estimated_time": 0.25
            }
        ]
    
    def _ac_service_tasks(self) -> list:
        """Air conditioning service task breakdown"""
        return [
            {
                "title": "Initial AC System Diagnosis",
                "description": "Connect AC manifold gauges to service ports. Check static pressure readings. Start engine and test AC operation at idle and various RPMs.",
                "estimated_time": 0.5
            },
            {
                "title": "Visual Inspection of AC Components",
                "description": "Inspect AC compressor, condenser, evaporator, and all visible lines for leaks, damage, or corrosion. Check compressor belt condition and tension.",
                "estimated_time": 0.5
            },
            {
                "title": "Test AC Refrigerant Levels",
                "description": "Check refrigerant levels using manifold gauges. Perform leak test using electronic leak detector or UV dye. Document pressure readings and ambient temperature.",
                "estimated_time": 0.5
            },
            {
                "title": "Service AC System as Needed",
                "description": "Add refrigerant if low, evacuate and recharge if contaminated, or repair leaks as found. Replace AC filter/cabin air filter if accessible.",
                "estimated_time": 0.75
            },
            {
                "title": "Final AC Performance Test",
                "description": "Test AC performance with digital thermometer. Verify proper cooling at various settings. Check for proper compressor cycling and system operation.",
                "estimated_time": 0.25
            }
        ]
    
    def _transmission_service_tasks(self) -> list:
        """Transmission service task breakdown"""  
        return [
            {
                "title": "Initial Transmission Inspection",
                "description": "Check transmission fluid level and condition with engine running and transmission warm. Inspect for external leaks around pan, cooler lines, and seals.",
                "estimated_time": 0.25
            },
            {
                "title": "Locate and Assess Leak Source",
                "description": "Clean transmission and surrounding area. Use UV dye or leak detection spray to identify specific leak location. Check torque on pan bolts and fittings.",
                "estimated_time": 0.5
            },
            {
                "title": "Repair Identified Leak",
                "description": "Based on leak location, replace gasket, seal, or tighten connection as appropriate. May require removing transmission pan or other components.",
                "estimated_time": 1.5
            },
            {
                "title": "Refill and Test Transmission",
                "description": "Add proper type and amount of transmission fluid. Test drive vehicle through all gears. Check for proper shifting and fluid level after test drive.",
                "estimated_time": 0.5
            },
            {
                "title": "Final Leak Check and Documentation",
                "description": "Let vehicle sit and recheck for any leaks. Document repair performed and fluid type/amount used. Advise customer on transmission maintenance schedule.",
                "estimated_time": 0.25
            }
        ]
    
    def _diagnostic_tasks(self) -> list:
        """Diagnostic task breakdown"""
        return [
            {
                "title": "Connect Diagnostic Scanner",
                "description": "Connect OBD-II scanner to diagnostic port. Retrieve all stored diagnostic trouble codes (DTCs) and pending codes. Record code numbers and descriptions.",
                "estimated_time": 0.25
            },
            {
                "title": "Research Diagnostic Codes",
                "description": "Look up diagnostic codes in repair database. Review technical service bulletins (TSBs) and common causes for the specific vehicle and codes found.",
                "estimated_time": 0.25
            },
            {
                "title": "Perform System Testing",
                "description": "Based on codes found, perform specific system tests such as fuel pressure, ignition system, emission components, or sensor readings as indicated.",
                "estimated_time": 0.5
            },
            {
                "title": "Identify Root Cause and Repair",
                "description": "Based on test results, identify the actual problem component or system. Perform necessary repairs or replacements to resolve the check engine light.",
                "estimated_time": 1.0
            },
            {
                "title": "Clear Codes and Verify Repair",
                "description": "Clear diagnostic codes and perform drive cycle test. Verify that check engine light stays off and no codes return. Test drive under various conditions.",
                "estimated_time": 0.5
            }
        ]
    
    def _battery_service_tasks(self) -> list:
        """Battery service task breakdown"""
        return [
            {
                "title": "Test Current Battery Condition",
                "description": "Use battery tester to check battery condition, cranking amps, and reserve capacity. Test specific gravity if serviceable battery. Record test results.",
                "estimated_time": 0.25
            },
            {
                "title": "Test Charging System",
                "description": "Test alternator output voltage and current. Check belt condition and tension. Test voltage drop across charging system connections.",
                "estimated_time": 0.5
            },
            {
                "title": "Remove Old Battery Safely",
                "description": "Turn off all electrical components. Remove negative cable first, then positive. Remove battery hold-down hardware. Lift out old battery safely.",
                "estimated_time": 0.25
            },
            {
                "title": "Clean and Install New Battery",
                "description": "Clean battery tray and cable terminals. Apply corrosion inhibitor. Install new battery with positive cable first, then negative. Secure with hold-down.",
                "estimated_time": 0.25
            },
            {
                "title": "Test New Battery Installation",
                "description": "Start engine and verify proper charging voltage. Test all electrical systems for proper operation. Reset any electronic systems that lost memory.",
                "estimated_time": 0.25
            }
        ]
    
    def _general_service_tasks(self, work_order: WorkOrder) -> list:
        """General service task breakdown"""
        return [
            {
                "title": "Initial Vehicle Assessment",
                "description": f"Review work order details: {work_order.description[:100]}... Perform visual inspection of affected systems and components.",
                "estimated_time": 0.5
            },
            {
                "title": "Diagnostic Testing",
                "description": "Perform relevant diagnostic tests based on customer complaint and vehicle symptoms. Document findings and test results.",
                "estimated_time": 1.0
            },
            {
                "title": "Identify Required Repairs",
                "description": "Based on diagnostic results, identify specific components or systems that need repair or replacement. Check parts availability.",
                "estimated_time": 0.5
            },
            {
                "title": "Perform Required Service",
                "description": "Execute the necessary repairs or maintenance procedures. Follow manufacturer specifications and proper safety procedures.",
                "estimated_time": work_order.estimated_hours or 2.0
            },
            {
                "title": "Test and Verify Repair",
                "description": "Test the repaired system to ensure proper operation. Perform any required calibrations or adjustments.",
                "estimated_time": 0.5
            },
            {
                "title": "Final Inspection and Documentation",
                "description": "Complete final quality check. Document all work performed, parts used, and any recommendations for the customer.",
                "estimated_time": 0.25
            }
        ]


class VoiceWorkOrderWorkflow:
    """Main workflow handler for voice-activated work order processing"""
    
    def __init__(self):
        self.task_breakdown_service = WorkOrderTaskBreakdownService()
        self.tts_service = TTSService()
        self.current_work_order = None
        self.current_step_index = 0
        self.technician = None
        self.step_start_times = {}  # Track when each step started for timing
    
    def extract_work_order_id(self, voice_input: str) -> str:
        """Extract work order ID from voice input using enhanced voice proxy system"""
        logger.info(f"Extracting work order ID from: '{voice_input}'")
        
        # Try the enhanced voice proxy system first
        if VOICE_PROXY_AVAILABLE:
            try:
                proxy_result = enhance_voice_work_order_extraction(voice_input)
                if proxy_result:
                    logger.info(f"Voice proxy found work order: {proxy_result}")
                    return proxy_result
            except Exception as e:
                logger.warning(f"Voice proxy error: {e}, falling back to original method")
        
        # Fallback to original patterns for backward compatibility
        logger.info("Using fallback work order extraction")
        patterns = [
            r'WO-([A-Z0-9]{6,8})',  # WO-ABC123
            r'work\s*order\s*([A-Z0-9]{6,8})',  # work order ABC123
            r'order\s*([A-Z0-9]{6,8})',  # order ABC123
            r'([A-Z0-9]{6,8})',  # Just the ID itself
        ]
        
        voice_input_upper = voice_input.upper()
        
        for pattern in patterns:
            match = re.search(pattern, voice_input_upper)
            if match:
                order_id = match.group(1)
                # Try with WO- prefix
                possible_ids = [f"WO-{order_id}", order_id]
                
                for possible_id in possible_ids:
                    if WorkOrder.objects.filter(order_number=possible_id).exists():
                        logger.info(f"Found work order: {possible_id}")
                        return possible_id
        
        logger.warning(f"No valid work order ID found in: '{voice_input}'")
        return None
    
    def initialize_voice_proxy_for_user(self, user_id: int) -> dict:
        """Initialize voice proxy mapping for a specific user"""
        if not VOICE_PROXY_AVAILABLE:
            logger.warning("Voice proxy system not available")
            return {}
        
        try:
            mapping = initialize_voice_proxy_for_user(user_id)
            logger.info(f"🎤 Initialized voice proxy for user {user_id} with {len(mapping)} work orders")
            return mapping
        except Exception as e:
            logger.error(f"Error initializing voice proxy for user {user_id}: {e}")
            return {}
    
    def get_user_voice_commands_help(self, user_id: int) -> List[str]:
        """Get voice command help for a specific user"""
        if not VOICE_PROXY_AVAILABLE:
            return ["Voice proxy system not available"]
        
        try:
            from voice_proxy_system import get_user_voice_commands
            return get_user_voice_commands(user_id)
        except Exception as e:
            logger.error(f"Error getting voice commands for user {user_id}: {e}")
            return [f"Error: {str(e)}"]
    
    def load_work_order(self, order_number: str) -> WorkOrder:
        """Load work order by order number"""
        try:
            work_order = WorkOrder.objects.get(order_number=order_number)
            logger.info(f"Loaded work order: {work_order}")
            return work_order
        except WorkOrder.DoesNotExist:
            logger.error(f"Work order not found: {order_number}")
            return None
    
    def generate_and_store_tasks(self, work_order: WorkOrder) -> bool:
        """Generate task breakdown and store in database"""
        logger.info(f"Generating tasks for work order: {work_order.order_number}")
        
        try:
            # Check if tasks already exist
            if work_order.steps.exists():
                logger.info(f"Tasks already exist for work order: {work_order.order_number}")
                return True
            
            # Generate and store tasks (the service now handles storage internally)
            created_steps = self.task_breakdown_service.generate_task_breakdown(work_order)
            
            if created_steps:
                logger.info(f"Successfully created {len(created_steps)} tasks for work order: {work_order.order_number}")
                return True
            else:
                logger.error("No tasks were created")
                return False
            
        except Exception as e:
            logger.error(f"Error generating tasks: {e}")
            return False
    
    def get_voice_instructions(self, work_order: WorkOrder, step_number: int = None) -> str:
        """Generate voice instructions for technician and speak them"""
        if step_number is None:
            # Overview of all tasks
            steps = work_order.steps.all().order_by('step_number')
            if not steps.exists():
                instruction = f"No tasks found for work order {work_order.order_number}. Please generate task breakdown first."
                self.tts_service.speak(instruction)
                return instruction
            
            instruction = f"Work order {work_order.order_number} for {work_order.vehicle}. "
            instruction += f"Title: {work_order.title}. "
            instruction += f"This work order has {steps.count()} steps. "
            instruction += "Here's the overview: "
            
            for step in steps[:3]:  # First 3 steps
                instruction += f"Step {step.step_number}: {step.title}. "
            
            if steps.count() > 3:
                instruction += f"And {steps.count() - 3} more steps. "
            
            instruction += "Say 'start step one' to begin the first task."
            
        else:
            # Specific step instructions
            try:
                step = work_order.steps.get(step_number=step_number)
                
                # Record step start time
                self.step_start_times[step.id] = datetime.now()
                
                instruction = f"Step {step.step_number} of {work_order.steps.count()}: {step.title}. "
                instruction += f"Here's what you need to do: {step.description} "
                instruction += f"Estimated time: {step.estimated_time} hours. "
                instruction += f"When complete, say 'step {step_number} complete' to provide feedback."
                
            except WorkOrderStep.DoesNotExist:
                instruction = f"Step {step_number} not found for work order {work_order.order_number}."
        
        # Speak the instruction
        self.tts_service.speak(instruction)
        return instruction
    
    def collect_step_feedback(self, work_order: WorkOrder, step_number: int, technician: User, 
                            feedback_text: str, time_spent: float = None, 
                            issues: str = "", recommendations: str = "") -> bool:
        """Collect and store feedback for a completed step"""
        logger.info(f"Collecting feedback for step {step_number} of work order {work_order.order_number}")
        
        try:
            step = work_order.steps.get(step_number=step_number)
            
            # Calculate actual time spent if not provided
            if time_spent is None and step.id in self.step_start_times:
                start_time = self.step_start_times[step.id]
                actual_time = (datetime.now() - start_time).total_seconds() / 3600  # Convert to hours
                time_spent = round(actual_time, 2)
                # Clean up the tracking
                del self.step_start_times[step.id]
            elif time_spent is None:
                time_spent = float(step.estimated_time)
            
            # Mark step as completed
            step.is_completed = True
            from django.utils import timezone
            step.completed_at = timezone.now()
            step.save()
            
            # Store feedback
            WorkOrderFeedback.objects.create(
                work_order=work_order,
                step=step,
                technician=technician,
                feedback_text=feedback_text,
                time_spent=Decimal(str(time_spent)),
                issues_encountered=issues,
                recommendations=recommendations
            )
            
            # Provide voice feedback to technician
            total_steps = work_order.steps.count()
            completed_steps = work_order.steps.filter(is_completed=True).count()
            
            feedback_response = f"Step {step_number} completed and feedback recorded. "
            
            if completed_steps >= total_steps:
                feedback_response += f"Excellent! All {total_steps} steps are now complete. Work order is finished."
                self.tts_service.speak(feedback_response)
            else:
                # Get next step details to include in TTS
                next_step_number = step_number + 1
                try:
                    next_step_obj = work_order.steps.get(step_number=next_step_number)
                    feedback_response += f"Ready for step {next_step_number}: {next_step_obj.title}. {next_step_obj.description}"
                except Exception:
                    feedback_response += f"Ready for step {next_step_number}. Please continue with the next step."

                self.tts_service.speak(feedback_response)
            
            logger.info(f"Feedback collected for step {step_number}")
            return True
            
        except WorkOrderStep.DoesNotExist:
            logger.error(f"Step {step_number} not found")
            self.tts_service.speak(f"Error: Step {step_number} not found.")
            return False
        except Exception as e:
            logger.error(f"Error collecting feedback: {e}")
            self.tts_service.speak("Error recording feedback. Please try again.")
            return False
    
    def generate_work_order_summary(self, work_order: WorkOrder) -> bool:
        """Generate comprehensive summary of completed work order"""
        logger.info(f"Generating summary for work order: {work_order.order_number}")
        
        try:
            # Check if all steps are completed
            total_steps = work_order.steps.count()
            completed_steps = work_order.steps.filter(is_completed=True).count()
            
            if completed_steps == 0:
                logger.warning("No steps completed yet")
                return False
            
            # Gather feedback and calculate totals
            all_feedback = WorkOrderFeedback.objects.filter(work_order=work_order)
            total_time = sum(feedback.time_spent for feedback in all_feedback)
            estimated_time = sum(step.estimated_time for step in work_order.steps.all())
            time_variance = total_time - estimated_time
            
            # Generate summary text
            summary_parts = []
            summary_parts.append(f"Work Order {work_order.order_number} Summary:")
            summary_parts.append(f"Vehicle: {work_order.vehicle}")
            summary_parts.append(f"Service: {work_order.title}")
            summary_parts.append(f"Completed {completed_steps} of {total_steps} planned steps.")
            summary_parts.append(f"Total time spent: {total_time} hours.")
            
            if all_feedback.exists():
                summary_parts.append("\nWork Details:")
                for feedback in all_feedback:
                    summary_parts.append(f"- Step {feedback.step.step_number}: {feedback.step.title}")
                    summary_parts.append(f"  Time: {feedback.time_spent}h, Status: Completed")
                    if feedback.issues_encountered:
                        summary_parts.append(f"  Issues: {feedback.issues_encountered}")
            
            # Collect major issues and recommendations
            major_issues = []
            recommendations = []
            
            for feedback in all_feedback:
                if feedback.issues_encountered.strip():
                    major_issues.append(feedback.issues_encountered)
                if feedback.recommendations.strip():
                    recommendations.append(feedback.recommendations)
            
            summary_text = " ".join(summary_parts)
            
            # Create or update summary
            summary, created = WorkOrderSummary.objects.get_or_create(
                work_order=work_order,
                defaults={
                    'summary_text': summary_text,
                    'total_time_spent': total_time,
                    'total_steps_completed': completed_steps,
                    'major_issues_resolved': " ".join(major_issues),
                    'recommendations_for_customer': " ".join(recommendations)
                }
            )
            
            if not created:
                # Update existing summary
                summary.summary_text = summary_text
                summary.total_time_spent = total_time
                summary.total_steps_completed = completed_steps
                summary.major_issues_resolved = " ".join(major_issues)
                summary.recommendations_for_customer = " ".join(recommendations)
                summary.save()
            
            # Generate voice summary for technician
            voice_summary = self._generate_voice_summary(work_order, completed_steps, total_steps, total_time, time_variance, major_issues)
            self.tts_service.speak(voice_summary)
            
            # Update work order status if all steps complete
            if completed_steps >= total_steps:
                work_order.status = 'COMPLETED'
                from django.utils import timezone
                work_order.completed_at = timezone.now()
                work_order.actual_hours = total_time
                work_order.save()
            
            logger.info(f"Summary {'created' if created else 'updated'} for work order: {work_order.order_number}")
            return True
            
        except Exception as e:
            logger.error(f"Error generating summary: {e}")
            error_msg = "Error generating work order summary. Please try again."
            self.tts_service.speak(error_msg)
            return False
    
    def _generate_voice_summary(self, work_order: WorkOrder, completed_steps: int, total_steps: int, 
                               total_time: float, time_variance: float, major_issues: list) -> str:
        """Generate a concise voice summary for the technician"""
        
        voice_summary = f"Work order {work_order.order_number} summary complete. "
        
        if completed_steps >= total_steps:
            voice_summary += f"Congratulations! You have successfully completed all {total_steps} steps. "
        else:
            voice_summary += f"You completed {completed_steps} out of {total_steps} steps. "
        
        # Time summary
        hours = int(total_time)
        minutes = int((total_time - hours) * 60)
        
        if hours > 0:
            voice_summary += f"Total time: {hours} hours"
            if minutes > 0:
                voice_summary += f" and {minutes} minutes. "
            else:
                voice_summary += ". "
        else:
            voice_summary += f"Total time: {minutes} minutes. "
        
        # Time variance feedback
        if abs(time_variance) > 0.25:  # More than 15 minutes difference
            if time_variance > 0:
                voice_summary += f"This took {abs(time_variance):.1f} hours longer than estimated. "
            else:
                voice_summary += f"Great job! You finished {abs(time_variance):.1f} hours ahead of schedule. "
        
        # Issues summary
        if major_issues:
            voice_summary += f"Please note: {len(major_issues)} issues were encountered during this service. "
        else:
            voice_summary += "No major issues were reported. "
        
        voice_summary += "Thank you for your excellent work. The summary has been saved for audit purposes."
        
        return voice_summary
    
    def process_text_input(self, text_input: str, technician_username: str = None) -> str:
        """
        Process text input that may contain work order ID
        
        This method handles:
        1. Extracting work order ID from text
        2. Fetching work order from database
        3. Converting title/description to question
        4. Querying vector database for relevant chunks
        5. Generating stepwise solution from chunks
        6. Saving steps to WorkOrderStep table
        
        Args:
            text_input: Text that contains work order ID
            technician_username: Username of technician
            
        Returns:
            Response message about the process
        """
        logger.info(f"Processing text input: '{text_input}'")
        
        # Step 1: Extract work order ID from text
        order_id = self.extract_work_order_id(text_input)
        if not order_id:
            return "No valid work order ID found in the text. Please include a work order number like 'WO-12345678'."
        
        # Step 2: Fetch work order data from database
        work_order = self.load_work_order(order_id)
        if not work_order:
            return f"Work order {order_id} not found in database."
        
        # Step 3: Set as current work order
        self.current_work_order = work_order
        
        # Get technician user
        if technician_username:
            try:
                self.technician = User.objects.get(username=technician_username)
            except User.DoesNotExist:
                return f"Technician {technician_username} not found."
        
        # Step 4: Generate tasks from work order using LLM + vector search
        if not self.generate_and_store_tasks(work_order):
            return f"Failed to generate task breakdown for work order {order_id}."
        
        # Step 5: Return success message with task overview
        steps = work_order.steps.all().order_by('step_number')
        total_time = sum(step.estimated_time for step in steps)
        
        response = f"✅ Work order {order_id} processed successfully!\n\n"
        response += f"📋 Title: {work_order.title}\n"
        response += f"🚗 Vehicle: {work_order.vehicle}\n"
        response += f"📝 Generated {steps.count()} detailed steps\n"
        response += f"⏱️ Total estimated time: {total_time} hours\n\n"
        response += "🎤 Next steps:\n"
        response += f"• Say 'Hey buddy, start step 1' to begin\n"
        response += f"• Say 'Hey buddy, step X complete' after each step\n"
        response += f"• Say 'Hey buddy, generate summary' when finished"
        
        return response
    
    def process_voice_command(self, voice_input: str, technician_username: str = None) -> str:
        """Main entry point for processing voice commands"""
        logger.info(f"Processing voice command: '{voice_input}'")
        
        voice_input_lower = voice_input.lower().strip()
        
        # Get technician user
        if technician_username:
            try:
                self.technician = User.objects.get(username=technician_username)
            except User.DoesNotExist:
                return f"Technician {technician_username} not found."
        
        # Extract work order ID if mentioned
        if "work order" in voice_input_lower or "WO-" in voice_input.upper():
            return self.process_text_input(voice_input, technician_username)
        
        # Handle step-specific commands
        if self.current_work_order:
            if "start step" in voice_input_lower:
                # Extract step number
                step_match = re.search(r'step (\d+)', voice_input_lower)
                if step_match:
                    step_num = int(step_match.group(1))
                    return self.get_voice_instructions(self.current_work_order, step_num)
                else:
                    return "Please specify which step number to start."
            
            elif "step" in voice_input_lower and "complete" in voice_input_lower:
                # Handle step completion and feedback
                step_match = re.search(r'step (\d+)', voice_input_lower)
                if step_match:
                    step_num = int(step_match.group(1))
                    
                    # Extract feedback from voice input
                    feedback_text = self._extract_feedback_from_input(voice_input, step_num)
                    
                    if self.collect_step_feedback(
                        self.current_work_order, 
                        step_num, 
                        self.technician or User.objects.filter(groups__name='Technician').first(),
                        feedback_text
                    ):
                        # Check if this was the last step
                        total_steps = self.current_work_order.steps.count()
                        completed_steps = self.current_work_order.steps.filter(is_completed=True).count()
                        
                        if completed_steps >= total_steps:
                            # All steps complete, generate summary
                            self.generate_work_order_summary(self.current_work_order)
                            return f"Step {step_num} completed. All steps are now complete! Work order summary has been generated."
                        else:
                            next_step = step_num + 1
                            return f"Step {step_num} completed and feedback recorded. Ready for step {next_step}. Say 'start step {next_step}' to continue."
                    else:
                        return f"Failed to record completion for step {step_num}."
            
            elif "summary" in voice_input_lower:
                if self.generate_work_order_summary(self.current_work_order):
                    return f"Summary generated for work order {self.current_work_order.order_number}."
                else:
                    return "Unable to generate summary. Make sure some steps are completed."
        
        return "I didn't understand that command. Please mention a work order number or give step instructions."
    
    def _extract_feedback_from_input(self, voice_input: str, step_num: int) -> str:
        """Extract feedback content from voice input"""
        feedback_text = f"Step {step_num} completed via voice command."
        
        # Look for additional feedback in the input
        voice_lower = voice_input.lower()
        
        if "no issues" in voice_lower or "no problems" in voice_lower:
            feedback_text += " No issues encountered."
        elif "issue" in voice_lower or "problem" in voice_lower:
            feedback_text += " Some issues were encountered during this step."
        
        if "successful" in voice_lower:
            feedback_text += " Task completed successfully."
        elif "difficult" in voice_lower:
            feedback_text += " Task was more challenging than expected."
        
        # Extract specific comments
        patterns = [
            r'complete[d]?,?\s+(.+?)(?:\.|$)',
            r'finished[,]?\s+(.+?)(?:\.|$)',
            r'done[,]?\s+(.+?)(?:\.|$)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, voice_lower)
            if match:
                additional_feedback = match.group(1).strip()
                if len(additional_feedback) > 3 and additional_feedback not in feedback_text.lower():
                    feedback_text += f" Additional notes: {additional_feedback}."
                break
        
        return feedback_text


# Example usage and testing functions
def demo_voice_workflow():
    """Demonstrate the voice workflow"""
    print("🎤 Voice Work Order Workflow Demo")
    print("=" * 50)
    
    workflow = VoiceWorkOrderWorkflow()
    
    # Test commands
    test_commands = [
        "hey buddy, work order WO-12345678",
        "start step 1",
        "step 1 complete",
        "start step 2", 
        "step 2 complete",
        "generate summary"
    ]
    
    print("Testing voice commands:")
    for cmd in test_commands:
        print(f"\n🗣️ Voice Input: '{cmd}'")
        response = workflow.process_voice_command(cmd, "alex_wilson_tech")
        print(f"🤖 Response: {response}")
        time.sleep(1)


if __name__ == "__main__":
    demo_voice_workflow()