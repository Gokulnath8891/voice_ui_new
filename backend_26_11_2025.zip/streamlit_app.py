import streamlit as st
from graph import app

st.set_page_config(page_title="Unified LangGraph Assistant", page_icon="🧠", layout="wide")
st.title("🧠 LangGraph RAG + SQL Agent (Azure OpenAI + Postgres)")

user_q = st.text_area("Ask a question:", height=100, placeholder="e.g. Show top 5 open work orders or What is described in document XYZ...")

if st.button("Ask"):
    with st.spinner("Thinking..."):
        result = app.invoke({"question": user_q})
        answer=result.get("answer","No answer Found")
        #st.markdown(result)
        st.write(answer)