import streamlit as st
import psycopg2
import numpy as np
from typing import TypedDict, Optional
from sentence_transformers import SentenceTransformer
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

import sounddevice as sd
import queue
import json
import threading
from vosk import Model, KaldiRecognizer


import speech_recognition as sr
import pyttsx3
import time

# -------------------------------------------------
# ✅ Streamlit UI
# -------------------------------------------------
st.set_page_config(page_title="Voice RAG Assistant", layout="wide")
st.title("🎤 Voice Activated RAG Assistant")

wake_word = "buddy"
st.write(f"✅ Wake word: **{wake_word}**")


# -------------------------------------------------
# ✅ Load Vosk wake-word model
# -------------------------------------------------
MODEL_PATH = "vosk-model-small-en-us-0.15"
model = Model(MODEL_PATH)
recognizer = KaldiRecognizer(model, 16000)

audio_queue = queue.Queue()
wake_detected = st.session_state.get("wake_detected", False)

def audio_callback(indata, frames, time, status):
    audio_queue.put(bytes(indata))


def wake_word_listener():
    """Continuous loop to detect wake word."""
    with sd.RawInputStream(
        channels=1,
        callback=audio_callback,
        samplerate=16000,
        blocksize=8000,
        dtype='int16'
    ):
        while True:
            data = audio_queue.get()
            if recognizer.AcceptWaveform(data):
                text = json.loads(recognizer.Result())["text"].lower()

                if text.strip():
                    st.session_state.last_heard = text
                if wake_word in text:
                    st.session_state.wake_detected = True
                    st.session_state.last_heard = text


# -------------------------------------------------
# ✅ Start wake-word thread ONCE
# -------------------------------------------------
if "wake_thread_started" not in st.session_state:
    threading.Thread(target=wake_word_listener, daemon=True).start()
    st.session_state.wake_thread_started = True




if "history" not in st.session_state:
    st.session_state.history = [
        {
            "role": "assistant",
            "content": "👋 Hello! I'm your Automotive Technician Assistant. Say 'buddy' to start!"
        }
    ]
    st.session_state.context = ""
    st.session_state.active = False

# Display chat history
for msg in st.session_state.history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Initialize speech recognition & TTS
#recognizer = sr.Recognizer()
engine = pyttsx3.init()
engine.setProperty("rate", 175)

# 🎧 Function: Listen for Wake Word
def listen_for_wake_word():
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source)
        st.info("🎤 Say 'buddy' to wake me up...")
        audio = recognizer.listen(source, timeout=5, phrase_time_limit=4)
        try:
            text = recognizer.recognize_google(audio).lower()
            print(text)
            if "buddy" in text:
                st.success("👂 Wake word detected!")
                return True
        except sr.UnknownValueError:
            pass
        except sr.RequestError:
            st.error("Speech service unavailable.")
    return False

# 🎙️ Function: Capture user query after wake word
def capture_query():
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source)
        st.info("🎧 Listening for your query...")
        audio = recognizer.listen(source, timeout=6, phrase_time_limit=10)
        try:
            query = recognizer.recognize_google(audio)
            st.success(f"You said: {query}")
            return query
        except sr.UnknownValueError:
            st.warning("Sorry, could not understand your voice.")
        except sr.RequestError:
            st.error("Speech service unavailable.")
    return None



# ===============================
# 🔹 Define State using TypedDict
# ===============================
class QueryState(TypedDict):
    query: str
    result: Optional[str]
    context: Optional[str]

# ===============================
# 🔹 Azure OpenAI Configuration
# ===============================

# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


DB_URI='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'

EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
#engine = create_engine(DB_URI)
model = SentenceTransformer(EMBED_MODEL)


# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


# ===============================
# 🔹 SentenceTransformer Embedding
# ===============================
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ===============================
# 🔹 PostgreSQL Connection
# ===============================
def get_pg_connection():
    return psycopg2.connect(
        host="voiceassistantpsql.postgres.database.azure.com",
        dbname="voice_assistant_db",
        user="postgres",
        password="voice_password",
        port="5432"
    )

# ===============================
# 🔹 Router Node
# ===============================
def router_node(state: QueryState):
    """Decide whether to use SQL or vector search."""
    #q = state["query"].lower()
    q=state.get("query","").lower()
    #if q.strip().contains("work order") or " from " in q:
    if "work order" in q:
        next_node="db_agent"
    else:
        next_node="vector_agent"
    return {"next":next_node}

# ===============================
# 🔹 SQL Agent Node
# ===============================
def db_agent(state: QueryState):
    """Executes SQL queries directly in PostgreSQL."""
    query = state["query"]
    context = state.get("context", "")
    prompt = f"""
    You are an automotive assistant.
    If question involves work order details, use SQL to retrieve them.
    Otherwise, answer naturally.
    Previous context: {context}
    Question: {query}
    """
    
    db = SQLDatabase.from_uri(
        "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )

    
    sql_agent = create_sql_agent(
        llm=llm,
        db=db,
        verbose=True,
        top_k=5,  # optional
        agent_type="openai-tools",  # use the new LCEL-compatible type
    )

    # Run user query through the SQL agent
    try:
        result = sql_agent.invoke({"input": prompt})
        result_text = result.get("output", "No output from SQL Agent.")
    except Exception as e:
        result_text = f"Error executing SQL Agent: {e}"

    return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {result_text}",
        "result": result_text
    }
    
# ===============================
# 🔹 Vector Agent Node
# ===============================
def vector_agent(state: QueryState):
    """Performs semantic search using pgvector and SentenceTransformer."""
    query = state["query"]
    context = state.get("context", "")
    try:
        # Step 1: Encode the query into vector
        query_vector = embed_model.encode(query)
        query_vector = np.array(query_vector, dtype=np.float32).tolist()

        # Step 2: Retrieve similar content
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT content, 1 - (embedding <=> %s::vector) AS similarity
            FROM powertrain_pdf_docs
            ORDER BY embedding <=> %s::vector
            LIMIT 3;
        """, (query_vector, query_vector))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            return {"result": "⚠️ No similar content found in vector DB."}

        context = "\n".join([r[0] for r in rows])

        # Step 3: LLM call with retrieved context
        prompt = f"""
        You are automotive Technician Automotive assistant.
        Please give one step and wait for user response
        You provide step by step support.
        Use this context to answer the query.
        Dont repeat the same steps again and again, repeat only if asked.
        For first step alone, add first, for rest of the steps add next.
        When asked to summarise the steps, give all steps summarised and share
        \n\n Context:\n{context}
        \n\n query: {query}
        """
        response = llm.invoke(prompt)
        first_answer=response.content.strip()
        return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {first_answer}",
        "result": first_answer}

    except Exception as e:
        return {"result": f"⚠️ Vector Agent Error: {e}"}

# ===============================
# 🔹 LangGraph Workflow
# ===============================
graph = StateGraph(QueryState)
graph.add_node("router", router_node)
graph.add_node("db_agent", db_agent)
graph.add_node("vector_agent", vector_agent)

graph.add_conditional_edges(
    "router",
    lambda state:state["next"],
    {
        "db_agent": "db_agent",
        "vector_agent": "vector_agent"
    }
)

graph.add_edge("db_agent", END)
graph.add_edge("vector_agent", END)
graph.set_entry_point("router")

# Memory checkpoint
checkpointer = MemorySaver()
#app = graph.compile(checkpointer=checkpointer)
app = graph.compile()


# -------------------------------------------------
# ✅ Streamlit UI logic
# -------------------------------------------------

# Show last heard text
if "last_heard" in st.session_state:
    st.write("🎧 Heard:", st.session_state.last_heard)

# Wake word detected?
if st.session_state.get("wake_detected"):
    st.success("✅ Wake word detected! Ask your question:")

    user_query = st.text_input("Your question:")

    if st.button("Send"):
        if user_query:
            output = app.invoke({"query": user_query})
            st.subheader("Answer")
            st.write(output["result"])

else:
    st.info("Listening for wake word… (say buddy')")
