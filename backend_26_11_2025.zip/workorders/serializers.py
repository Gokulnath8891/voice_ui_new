from rest_framework import serializers
from django.contrib.auth.models import User
from .models import (
    Customer, Vehicle, WorkOrder, WorkOrderStep, 
    WorkOrderFeedback, WorkOrderSummary, TechnicianProfile, ServiceManagerProfile
)


class UserSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'role']
        
    def get_role(self, obj):
        if obj.groups.filter(name='Service Manager').exists():
            return 'Service Manager'
        elif obj.groups.filter(name='Technician').exists():
            return 'Technician'
        return 'Unknown'


class TechnicianProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = TechnicianProfile
        fields = ['user', 'employee_id', 'phone', 'specialization', 'created_at']


class ServiceManagerProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = ServiceManagerProfile
        fields = ['user', 'employee_id', 'phone', 'department', 'created_at']


class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ['id', 'first_name', 'last_name', 'email', 'phone', 'address', 'created_at']


class VehicleSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer(read_only=True)
    customer_id = serializers.IntegerField(write_only=True)
    
    class Meta:
        model = Vehicle
        fields = ['id', 'customer', 'customer_id', 'make', 'model', 'year', 'vin', 
                 'license_plate', 'mileage', 'created_at']


class WorkOrderStepSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkOrderStep
        fields = ['id', 'step_number', 'title', 'description', 'estimated_time', 
                 'is_completed', 'completed_at', 'created_at']


class WorkOrderFeedbackSerializer(serializers.ModelSerializer):
    technician = UserSerializer(read_only=True)
    step = WorkOrderStepSerializer(read_only=True)
    step_id = serializers.IntegerField(write_only=True)
    
    class Meta:
        model = WorkOrderFeedback
        fields = ['id', 'step', 'step_id', 'technician', 'feedback_text', 'time_spent', 
                 'issues_encountered', 'recommendations', 'created_at']
        
    def create(self, validated_data):
        validated_data['technician'] = self.context['request'].user
        validated_data['work_order_id'] = self.context['work_order_id']
        return super().create(validated_data)


class WorkOrderSummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkOrderSummary
        fields = ['id', 'summary_text', 'total_time_spent', 'total_steps_completed',
                 'major_issues_resolved', 'recommendations_for_customer', 
                 'created_at', 'updated_at']


class WorkOrderSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer(read_only=True)
    vehicle = VehicleSerializer(read_only=True)
    service_manager = UserSerializer(read_only=True)
    technician = UserSerializer(read_only=True)
    steps = WorkOrderStepSerializer(many=True, read_only=True)
    feedback = WorkOrderFeedbackSerializer(many=True, read_only=True)
    summary = WorkOrderSummarySerializer(read_only=True)
    
    # Write-only fields for creation
    customer_id = serializers.IntegerField(write_only=True)
    vehicle_id = serializers.IntegerField(write_only=True)
    technician_id = serializers.IntegerField(write_only=True, required=False)
    
    class Meta:
        model = WorkOrder
        fields = [
            'id', 'order_number', 'customer', 'vehicle', 'service_manager', 'technician',
            'customer_id', 'vehicle_id', 'technician_id',
            'title', 'description', 'status', 'priority', 'estimated_hours', 'actual_hours',
            'created_at', 'updated_at', 'assigned_at', 'started_at', 'completed_at',
            'steps', 'feedback', 'summary'
        ]
        read_only_fields = ['order_number', 'service_manager', 'created_at', 'updated_at']
        
    def create(self, validated_data):
        validated_data['service_manager'] = self.context['request'].user
        return super().create(validated_data)


class WorkOrderListSerializer(serializers.ModelSerializer):
    customer_name = serializers.SerializerMethodField()
    vehicle_info = serializers.SerializerMethodField()
    service_manager_name = serializers.SerializerMethodField()
    technician_name = serializers.SerializerMethodField()
    
    class Meta:
        model = WorkOrder
        fields = [
            'id', 'order_number', 'customer_name', 'vehicle_info', 
            'service_manager_name', 'technician_name', 'title', 'status', 
            'priority', 'created_at', 'assigned_at'
        ]
        
    def get_customer_name(self, obj):
        return f"{obj.customer.first_name} {obj.customer.last_name}"
        
    def get_vehicle_info(self, obj):
        return f"{obj.vehicle.year} {obj.vehicle.make} {obj.vehicle.model}"
        
    def get_service_manager_name(self, obj):
        return f"{obj.service_manager.first_name} {obj.service_manager.last_name}"
        
    def get_technician_name(self, obj):
        if obj.technician:
            return f"{obj.technician.first_name} {obj.technician.last_name}"
        return None