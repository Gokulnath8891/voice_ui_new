from rest_framework import permissions


class IsServiceManager(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.groups.filter(name='Service Manager').exists()


class IsTechnician(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.groups.filter(name='Technician').exists()


class IsServiceManagerOrReadOnlyTechnician(permissions.BasePermission):
    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
            
        # Service managers have full access
        if request.user.groups.filter(name='Service Manager').exists():
            return True
            
        # Technicians have read-only access
        if request.user.groups.filter(name='Technician').exists():
            return request.method in permissions.SAFE_METHODS
            
        return False


class CanViewOwnWorkOrders(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Service managers can view all work orders
        if request.user.groups.filter(name='Service Manager').exists():
            return True
            
        # Technicians can only view their assigned work orders
        if request.user.groups.filter(name='Technician').exists():
            return obj.technician == request.user
            
        return False


class CanSubmitFeedback(permissions.BasePermission):
    def has_permission(self, request, view):
        # Only technicians can submit feedback
        return request.user and request.user.groups.filter(name='Technician').exists()
        
    def has_object_permission(self, request, view, obj):
        # Technicians can only submit feedback for their assigned work orders
        return obj.technician == request.user