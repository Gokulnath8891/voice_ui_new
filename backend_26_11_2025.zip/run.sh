#!/bin/bash

# Voice Assistant v2 - Run Script
echo "Starting Voice Assistant v2..."

# Activate poetry environment and run Django development server
poetry run python manage.py runserver