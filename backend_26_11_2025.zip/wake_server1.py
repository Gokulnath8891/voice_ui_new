from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import azure.cognitiveservices.speech as speechsdk
import threading
import time

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

WAKEWORD = "hey buddy"
wake_detected_flag = False


def wake_word_loop():
    global wake_detected_flag

    speech_config = speechsdk.SpeechConfig(
        subscription = "1QD2Whn5LX4JPSORsLv7OP2zus76eJ86cLstg7zOLCHc3sVrqFYAJQQJ99BEACHYHv6XJ3w3AAAYACOGypYi",
region = "eastus2"
    )
    audio_config = speechsdk.AudioConfig(use_default_microphone=True)
    recognizer = speechsdk.SpeechRecognizer(
        speech_config=speech_config,
        audio_config=audio_config
    )

    def recognized(evt: speechsdk.SpeechRecognitionEventArgs):
        global wake_detected_flag
        text = evt.result.text.lower()
        print("Heard:", text)
        if WAKEWORD in text:
            wake_detected_flag = True

    recognizer.recognized.connect(recognized)
    recognizer.start_continuous_recognition()

    while True:
        time.sleep(0.1)


@app.get("/wake-status")
def wake_status():
    return {"wake_detected": wake_detected_flag}


@app.post("/reset-wake")
def reset_wake():
    global wake_detected_flag
    wake_detected_flag = False
    return {"status": "reset"}


@app.on_event("startup")
def start_background_thread():
    t = threading.Thread(target=wake_word_loop, daemon=True)
    t.start()