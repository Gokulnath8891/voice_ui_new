#!/usr/bin/env python
"""
Voice Assistant Dash Application
A comprehensive web interface for the voice-activated work order system
"""

import dash
from dash import dcc, html, Input, Output, State, clientside_callback, ClientsideFunction, ALL, MATCH
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import requests
from voice_proxy_system import voice_proxy
import json
import base64
from datetime import datetime, timedelta
import threading
import time
import speech_recognition as sr
import pyttsx3
from PIL import Image
import io
from chat_workflow_handler import detect_feedback_keywords, should_treat_as_feedback, workflow_handler

# Wake word detection disabled

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.FONT_AWESOME])
app.title = "Voice Assistant Work Order System"
app.config.suppress_callback_exceptions = True

# Add browser-based TTS support
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <script>
            // Enhanced Browser-based Text-to-Speech with voice selection
            function speakText(text) {
                if ('speechSynthesis' in window) {
                    // Stop any current speech
                    speechSynthesis.cancel();

                    const utterance = new SpeechSynthesisUtterance(text);
                    utterance.rate = 0.9;  // Slightly faster
                    utterance.volume = 1.0; // Full volume
                    utterance.pitch = 1.0;

                    // Wait for voices to load and use best available voice
                    const voices = speechSynthesis.getVoices();
                    if (voices.length > 0) {
                        // Try to find a good English voice
                        const englishVoice = voices.find(voice =>
                            voice.lang.startsWith('en') && voice.localService
                        ) || voices.find(voice =>
                            voice.lang.startsWith('en')
                        ) || voices[0];
                        utterance.voice = englishVoice;
                    }

                    // Add error handling
                    utterance.onerror = function(event) {
                        console.error('🔊 TTS Error:', event.error);
                        // Retry once on error
                        setTimeout(() => {
                            speechSynthesis.speak(new SpeechSynthesisUtterance(text));
                        }, 100);
                    };

                    utterance.onstart = function() {
                        console.log('🔊 TTS Started:', text.substring(0, 50) + '...');
                    };

                    utterance.onend = function() {
                        console.log('🔊 TTS Completed');
                    };

                    // Use a small delay to ensure browser is ready
                    setTimeout(() => {
                        speechSynthesis.speak(utterance);
                    }, 50);

                    console.log('🔊 Browser TTS Queued:', text.substring(0, 100) + '...');
                } else {
                    console.log('🔇 Browser TTS not available');
                }
            }

            // Make sure voices are loaded
            function ensureVoicesLoaded() {
                return new Promise((resolve) => {
                    const voices = speechSynthesis.getVoices();
                    if (voices.length > 0) {
                        resolve(voices);
                    } else {
                        speechSynthesis.addEventListener('voiceschanged', () => {
                            resolve(speechSynthesis.getVoices());
                        });
                    }
                });
            }

            // Auto-close chat after TTS completion
            function autoCloseChatAfterTTS(text) {
                if ('speechSynthesis' in window) {
                    // Stop any current speech
                    speechSynthesis.cancel();

                    const utterance = new SpeechSynthesisUtterance(text);
                    utterance.rate = 0.8;
                    utterance.volume = 0.9;
                    utterance.pitch = 1.0;

                    // Use default voice or first available voice
                    const voices = speechSynthesis.getVoices();
                    if (voices.length > 0) {
                        utterance.voice = voices[0];
                    }

                    // Close chat when TTS is finished
                    utterance.onend = function() {
                        console.log('🔊 TTS completed, closing chat in 2 seconds...');
                        setTimeout(function() {
                            // Trigger a click on chat toggle to close the chat
                            const chatToggle = document.querySelector('#chat-toggle');
                            if (chatToggle) {
                                chatToggle.click();
                            }
                        }, 2000); // 2 second delay after TTS finishes
                    };

                    speechSynthesis.speak(utterance);
                    console.log('🔊 Browser TTS with auto-close:', text.substring(0, 100) + '...');
                } else {
                    console.log('🔇 Browser TTS not available, closing chat in 5 seconds');
                    // Fallback: close after 5 seconds if no TTS
                    setTimeout(function() {
                        const chatToggle = document.querySelector('#chat-toggle');
                        if (chatToggle) {
                            chatToggle.click();
                        }
                    }, 5000);
                }
            }

            // Auto-scroll chat to bottom when new messages appear
            function autoScrollChat() {
                const chatContainer = document.getElementById('chat-messages');
                if (chatContainer) {
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                    console.log('📜 Auto-scrolled chat to bottom');
                }
            }

            // Auto-refresh work order cards
            function refreshWorkOrderCards() {
                // Trigger refresh by clicking an invisible refresh button
                const refreshBtn = document.querySelector('[id*="refresh-cards"]');
                if (refreshBtn) {
                    refreshBtn.click();
                    console.log('🔄 Refreshing work order cards');
                } else {
                    // Alternative: trigger page refresh of dashboard content
                    console.log('🔄 Refreshing dashboard content');
                    // Force re-render by triggering a callback
                    window.dispatchEvent(new CustomEvent('refreshDashboard'));
                }
            }

            // Expose TTS functions globally
            window.speakText = speakText;
            window.autoCloseChatAfterTTS = autoCloseChatAfterTTS;
            window.ensureVoicesLoaded = ensureVoicesLoaded;
            window.autoScrollChat = autoScrollChat;
            window.refreshWorkOrderCards = refreshWorkOrderCards;

            // Load voices and setup observers when page loads
            document.addEventListener('DOMContentLoaded', function() {
                ensureVoicesLoaded().then(() => {
                    console.log('✅ Browser TTS voices loaded');
                });

                // Setup chat auto-scroll observer
                const chatContainer = document.getElementById('chat-messages');
                if (chatContainer) {
                    const observer = new MutationObserver(function(mutations) {
                        mutations.forEach(function(mutation) {
                            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                                setTimeout(autoScrollChat, 100);
                                setTimeout(autoScrollChat, 300);
                                setTimeout(autoScrollChat, 600);
                            }
                        });
                    });

                    observer.observe(chatContainer, { childList: true, subtree: true });
                    console.log('📜 Chat auto-scroll observer initialized');
                }

                // Monitor chat window close to refresh cards
                const chatOffcanvas = document.querySelector('[id*="chat-offcanvas"]');
                if (chatOffcanvas) {
                    const chatObserver = new MutationObserver(function(mutations) {
                        mutations.forEach(function(mutation) {
                            if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                                const isOpen = chatOffcanvas.classList.contains('show');
                                if (!isOpen && mutation.oldValue && mutation.oldValue.includes('show')) {
                                    console.log('💡 Chat closed, refreshing work order cards in 1 second...');
                                    setTimeout(refreshWorkOrderCards, 1000);
                                }
                            }
                        });
                    });

                    chatObserver.observe(chatOffcanvas, {
                        attributes: true,
                        attributeOldValue: true,
                        attributeFilter: ['class']
                    });
                    console.log('🔄 Chat close observer initialized');
                }
            });
        </script>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# Global variables for session management
API_BASE_URL = "http://localhost:8000/api"
current_user = None
tts_engine = None
recognizer = None
microphone = None

chat_auto_opened = False
continuous_mode = False

# Initialize TTS and Speech Recognition
def initialize_speech_services():
    global tts_engine, recognizer, microphone
    
    # Initialize TTS (optional - can fail gracefully)
    try:
        tts_engine = pyttsx3.init()
        tts_engine.setProperty('rate', 175)
        tts_engine.setProperty('volume', 0.9)
        print("✅ TTS engine initialized successfully")
    except Exception as e:
        print(f"⚠️ TTS initialization failed: {e}")
        print("📢 TTS features will be disabled, but speech recognition will still work")
        tts_engine = None
    
    # Initialize Speech Recognition (required for voice features)
    try:
        print("🎤 Initializing speech recognition...")

        # Check if speech_recognition module is available
        import speech_recognition as sr_test
        print("✅ speech_recognition module loaded")

        # Initialize recognizer
        recognizer = sr.Recognizer()
        print("✅ Recognizer created")

        # Try to get microphone list first
        mic_list = sr.Microphone.list_microphone_names()
        print(f"🎤 Available microphones: {len(mic_list)}")
        if mic_list:
            print(f"🎤 Using microphone: {mic_list[0]}")

        # Initialize microphone
        microphone = sr.Microphone()
        print("✅ Microphone initialized")

        # Test microphone access (shorter duration to avoid hanging)
        print("🎤 Testing microphone access...")
        with microphone as source:
            recognizer.adjust_for_ambient_noise(source, duration=0.5)

        print("✅ Speech recognition initialized successfully")
        print("🎙️ Microphone is ready for voice commands")

    except ImportError as e:
        print(f"❌ speech_recognition module not available: {e}")
        print("💡 Install with: pip install SpeechRecognition pyaudio")
        recognizer = None
        microphone = None
    except OSError as e:
        print(f"❌ Microphone hardware error: {e}")
        print("💡 Check microphone connection and permissions")
        recognizer = None
        microphone = None
    except Exception as e:
        print(f"❌ Speech recognition initialization failed: {e}")
        print(f"💡 Error type: {type(e).__name__}")
        print("🔇 Voice features will be disabled")
        recognizer = None
        microphone = None

def test_microphone():
    """Test microphone functionality and return status"""
    global recognizer, microphone

    if not recognizer or not microphone:
        return False, "Speech recognition not initialized"

    try:
        print("🎤 Testing microphone...")
        with microphone as source:
            # Test microphone access with very short duration
            recognizer.adjust_for_ambient_noise(source, duration=0.1)

        print("✅ Microphone test passed")
        return True, "Microphone working"
    except Exception as e:
        print(f"❌ Microphone test failed: {e}")
        return False, f"Microphone error: {str(e)}"

def reinitialize_speech():
    """Try to reinitialize speech recognition"""
    global recognizer, microphone

    print("🔄 Attempting to reinitialize speech recognition...")

    try:
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()

        # Quick test
        with microphone as source:
            recognizer.adjust_for_ambient_noise(source, duration=0.2)

        print("✅ Speech recognition reinitialized successfully")
        return True
    except Exception as e:
        print(f"❌ Reinitialize failed: {e}")
        recognizer = None
        microphone = None
        return False

# Initialize speech services
initialize_speech_services()

# Test microphone after initialization
mic_status, mic_message = test_microphone()
print(f"🎤 Microphone status: {mic_message}")

# Wake word detection functions removed

# Utility functions
def encode_image(image_path):
    """Encode image to base64 for display in Dash"""
    try:
        with open(image_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode()
        return f"data:image/png;base64,{encoded_string}"
    except:
        return ""

def speak_text(text, is_completion=False):
    """Speak text using reliable browser TTS - simplified approach"""
    try:
        import time
        tts_data = {
            'text': text,
            'timestamp': time.time(),
            'is_completion': is_completion
        }

        # Store TTS data globally for callback access
        global current_tts_data
        current_tts_data = tts_data

        print(f"🔊 TTS prepared: {text[:100]}...")

        # The clientside callback will handle the actual TTS
        return tts_data

    except Exception as e:
        print(f"⚠️ TTS preparation error: {e}")
        current_tts_data = None
        return None

# Global variable to store current TTS data
current_tts_data = None

def trigger_tts(text, is_completion=False):
    """Trigger TTS through Dash store update"""
    global current_tts_data
    import time
    tts_data = {
        'text': text,
        'timestamp': time.time(),
        'is_completion': is_completion
    }
    current_tts_data = tts_data
    return tts_data

def listen_for_speech(timeout=5):
    """Listen for speech input"""
    if not recognizer or not microphone:
        return None
    
    try:
        with microphone as source:
            audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=10)
        
        # Use Google Speech Recognition
        text = recognizer.recognize_google(audio)
        return text
    except sr.WaitTimeoutError:
        return None
    except sr.UnknownValueError:
        return None
    except Exception as e:
        print(f"Speech recognition error: {e}")
        return None

# Logo path
LOGO_PATH = r"C:\Users\DELL\Downloads\lv_logo.png"
logo_encoded = encode_image(LOGO_PATH)

# Layout Components
def create_login_page():
    """Create the login page layout"""
    return dbc.Container([
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.Div([
                            html.Img(
                                src=logo_encoded,
                                style={
                                    'height': '100px',
                                    'width': 'auto',
                                    'display': 'block',
                                    'margin': '0 auto 30px auto'
                                }
                            ) if logo_encoded else html.Div(),
                            html.H3("Voice Assistant Work Order System", 
                                   className="text-center mb-4"),
                            html.Div(id="login-error", style={'color': 'red', 'textAlign': 'center'}),
                            dbc.Form([
                                dbc.Row([
                                    dbc.Label("Username", html_for="username-input"),
                                    dbc.Input(
                                        type="text",
                                        id="username-input",
                                        placeholder="Enter username",
                                        className="mb-3"
                                    )
                                ]),
                                dbc.Row([
                                    dbc.Label("Password", html_for="password-input"),
                                    dbc.Input(
                                        type="password",
                                        id="password-input",
                                        placeholder="Enter password",
                                        className="mb-3"
                                    )
                                ]),
                                dbc.Button(
                                    "Login",
                                    id="login-button",
                                    color="primary",
                                    className="w-100",
                                    size="lg"
                                )
                            ])
                        ])
                    ])
                ], className="shadow")
            ], width=6)
        ], justify="center", className="min-vh-100 d-flex align-items-center")
    ], fluid=True)

def create_dashboard_layout(user_role):
    """Create the main dashboard layout"""
    return html.Div([
        # Header
        dbc.Navbar([
            dbc.Container([
                dbc.Row([
                    dbc.Col([
                        html.Img(src=logo_encoded, height="40px") if logo_encoded else html.Div(),
                        dbc.NavbarBrand("Voice Assistant Work Orders", className="ms-2")
                    ]),
                    dbc.Col([
                        dbc.Nav([
                            dbc.NavItem([
                                dbc.Button(
                                    [html.I(className="fas fa-user me-2"), html.Span(id="user-display")],
                                    color="outline-light",
                                    size="sm"
                                )
                            ]),
                            dbc.NavItem([
                                dbc.Button(
                                    [html.I(className="fas fa-sign-out-alt me-2"), "Logout"],
                                    id="logout-button",
                                    color="outline-danger",
                                    size="sm",
                                    className="ms-2"
                                )
                            ])
                        ], className="ms-auto")
                    ])
                ], className="w-100 d-flex justify-content-between align-items-center")
            ], fluid=True)
        ], color="primary", dark=True),
        
        # Main Content
        dbc.Container([
            # Dashboard Content
            html.Div(id="dashboard-content"),
        ], fluid=True, className="mt-3"),
        
        # Chatbot
        create_chatbot_component(),
        
        # TTS components for browser speech synthesis
        dcc.Store(id='tts-store', data=None),
        html.Div(id='tts-trigger', style={'display': 'none'}),
        html.Div(id='tts-status', style={'display': 'none'}),
    ])

def create_technician_dashboard():
    """Create dashboard for technicians with tabs"""
    return html.Div([
        dbc.Row([
            dbc.Col([
                html.H4([html.I(className="fas fa-tasks me-2"), "My Work Orders"]),
                html.Hr(),
                dbc.Tabs([
                    dbc.Tab(
                        label="Active",
                        tab_id="active-tab",
                        label_style={"color": "#495057"},
                        active_label_style={"color": "#ffffff", "background-color": "#007bff"}
                    ),
                    dbc.Tab(
                        label="Completed",
                        tab_id="completed-tab",
                        label_style={"color": "#495057"},
                        active_label_style={"color": "#ffffff", "background-color": "#28a745"}
                    )
                ], 
                id="work-order-tabs", 
                active_tab="active-tab",
                className="mb-3"
                ),
                html.Div(id="technician-work-orders")
            ])
        ])
    ])

def create_manager_dashboard():
    """Create dashboard for service managers"""
    return html.Div([
        dbc.Row([
            dbc.Col([
                html.H4([html.I(className="fas fa-clipboard-list me-2"), "Work Order Management"]),
                html.Hr(),
                dbc.ButtonGroup([
                    dbc.Button("All", id="filter-all", color="primary", size="sm"),
                    dbc.Button("Pending", id="filter-pending", color="outline-warning", size="sm"),
                    dbc.Button("Assigned", id="filter-assigned", color="outline-info", size="sm"),
                    dbc.Button("In Progress", id="filter-progress", color="outline-primary", size="sm"),
                    dbc.Button("Completed", id="filter-completed", color="outline-success", size="sm"),
                ], className="mb-3"),
                html.Div(id="manager-work-orders")
            ])
        ])
    ])

def create_work_order_card(wo, show_progress=False, proxy_number=None, show_start_button=False):
    """Create a work order card component"""
    # Status color mapping
    status_colors = {
        'PENDING': 'warning',
        'ASSIGNED': 'info', 
        'IN_PROGRESS': 'primary',
        'COMPLETED': 'success',
        'CANCELLED': 'danger'
    }
    
    # Priority color mapping  
    priority_colors = {
        'LOW': 'success',
        'MEDIUM': 'warning',
        'HIGH': 'danger',
        'URGENT': 'danger'
    }
    
    # Only show progress bar if work has been started (progress > 0)
    progress_bar = None
    is_completed = wo.get('status', '').upper() == 'COMPLETED'
    progress_percentage = wo.get('progress', 0)
    has_progress = show_progress and wo.get('total_steps', 0) > 0 and not is_completed and progress_percentage > 0

    if has_progress:
        progress_bar = dbc.Progress(
            value=progress_percentage,
            color="success" if progress_percentage == 100 else "info",
            className="mt-2"
        )

    # If progress bar is available and status is ASSIGNED, display as IN-PROGRESS
    display_status = wo['status']
    if has_progress and wo.get('status', '').upper() == 'ASSIGNED':
        display_status = 'IN-PROGRESS'
    
    # Real-time step tracking for managers
    steps_display = None
    if show_progress and wo.get('steps'):
        steps_badges = []
        for step in wo['steps']:
            color = 'success' if step['is_completed'] else 'secondary'
            icon = 'check' if step['is_completed'] else 'clock'
            steps_badges.append(
                dbc.Badge([
                    html.I(className=f"fas fa-{icon} me-1"),
                    f"Step {step['step_number']}"
                ], color=color, className="me-1")
            )
        steps_display = html.Div([
            html.Small("Steps: ", className="text-muted"),
            *steps_badges
        ], className="mt-2")
    
    # Build header components
    header_content = []
    
    # Add proxy number if provided (for active items)
    if proxy_number is not None:
        header_content.append(
            dbc.Col([
                dbc.Badge(f"#{proxy_number}", color="primary", className="me-2"),
                html.H6(wo['order_number'], className="mb-0 d-inline"),
                html.Br(),
                dbc.Badge(display_status, color=status_colors.get(display_status, 'secondary'))
            ])
        )
    else:
        header_content.append(
            dbc.Col([
                html.H6(wo['order_number'], className="mb-0"),
                dbc.Badge(display_status, color=status_colors.get(display_status, 'secondary'))
            ])
        )
    
    header_content.append(
        dbc.Col([
            dbc.Badge(wo['priority'], color=priority_colors.get(wo['priority'], 'secondary'), className="float-end")
        ], width="auto")
    )
    
    return dbc.Card([
        dbc.CardHeader([
            dbc.Row(header_content)
        ]),
        dbc.CardBody([
            html.H6(wo['title'], className="card-title"),
            html.P(wo['description'], className="card-text text-muted small"),
            html.Hr(),
            dbc.Row([
                dbc.Col([
                    html.Small([html.I(className="fas fa-user me-1"), wo['customer_name']])
                ], width=6),
                dbc.Col([
                    html.Small([html.I(className="fas fa-car me-1"), wo['vehicle']])
                ], width=6)
            ]),
            dbc.Row([
                dbc.Col([
                    html.Small([html.I(className="fas fa-clock me-1"), f"{wo.get('estimated_hours', 0):.1f}h est."])
                ], width=6),
                dbc.Col([
                    html.Small([html.I(className="fas fa-calendar me-1"), 
                              datetime.fromisoformat(wo['created_at'].replace('Z', '+00:00')).strftime('%m/%d/%Y')])
                ], width=6)
            ]),
            progress_bar,
            steps_display,
            # Add start work button if requested
            create_start_work_button(wo, show_progress=show_progress) if show_start_button else None,
            # Add reset button for completed work orders
            create_reset_button(wo) if is_completed else None
        ])
    ], className="mb-3 shadow-sm")

def create_start_work_button(wo, show_progress=False):
    """Create start work button(s) with options for started work orders"""
    work_order_number = wo['order_number']

    # Check if work order has been started
    is_in_progress = wo.get('status', '').upper() == 'IN_PROGRESS'
    total_steps = wo.get('total_steps', 0)
    is_completed = wo.get('status', '').upper() == 'COMPLETED'
    progress_percentage = wo.get('progress', 0)

    # Check if work has been started (has progress > 0)
    has_started = progress_percentage > 0 and total_steps > 0 and not is_completed

    if has_started:
        # Work order has been started - show both Start Over and Resume options
        return html.Div([
            dbc.Row([
                dbc.Col([
                    dbc.Button(
                        [html.I(className="fas fa-redo me-2"), "Start Over"],
                        id={"type": "start-over-btn", "index": work_order_number},
                        color="warning",
                        size="sm",
                        className="w-100",
                        title="Start from the first step"
                    )
                ], width=6),
                dbc.Col([
                    dbc.Button(
                        [html.I(className="fas fa-play me-2"), "Resume"],
                        id={"type": "resume-work-btn", "index": work_order_number},
                        color="success",
                        size="sm",
                        className="w-100",
                        title="Continue from where you left off"
                    )
                ], width=6)
            ], className="g-2")
        ], className="mt-3")
    else:
        # Fresh start - work order not started yet
        return dbc.Button(
            [html.I(className="fas fa-play me-2"), "Start Work"],
            id={"type": "start-work-btn", "index": work_order_number},
            color="success",
            size="sm",
            className="mt-3 w-100"
        )

def create_reset_button(wo):
    """Create reset button for completed work orders"""
    work_order_number = wo['order_number']

    return dbc.Button(
        [html.I(className="fas fa-undo me-2"), "Reset"],
        id={"type": "reset-work-btn", "index": work_order_number},
        color="secondary",
        size="sm",
        className="mt-2 w-100",
        outline=True
    )

def create_chatbot_component():
    """Create the chatbot component"""
    return html.Div([
        # Chat toggle button
        dbc.Button(
            html.I(className="fas fa-comments", style={'fontSize': '24px'}),
            id="chat-toggle",
            color="primary",
            style={
                'position': 'fixed',
                'bottom': '20px',
                'right': '20px',
                'borderRadius': '50%',
                'width': '60px',
                'height': '60px',
                'zIndex': 1000,
                'boxShadow': '0 4px 8px rgba(0,0,0,0.3)'
            }
        ),
        
        # Chat window
        dbc.Offcanvas(
            id="chat-offcanvas",
            title=[
                html.I(className="fas fa-robot me-2"),
                "Voice Assistant",
                dbc.Badge("Voice Enabled", color="success", className="ms-2")
            ],
            is_open=False,
            placement="end",
            style={'width': '400px'},
            children=[
                html.Div([

                    # Chat messages
                    html.Div(
                        id="chat-messages",
                        style={
                            'height': '350px',
                            'overflowY': 'auto',
                            'border': '1px solid #ddd',
                            'borderRadius': '5px',
                            'padding': '10px',
                            'backgroundColor': '#f8f9fa',
                            'scrollBehavior': 'smooth'
                        }
                    ),
                    
                    # Voice proxy commands display
                    html.Div([
                        dbc.Card([
                            dbc.CardHeader([
                                html.I(className="fas fa-microphone me-2"),
                                "Voice Commands"
                            ]),
                            dbc.CardBody([
                                html.Div(id="voice-commands-display", style={
                                    'maxHeight': '200px',
                                    'overflowY': 'auto',
                                    'fontSize': '0.9em'
                                })
                            ])
                        ])
                    ], className="mt-3"),
                    
                    # Input area
                    html.Div([
                        dbc.InputGroup([
                            dbc.Input(
                                id="chat-input",
                                placeholder="Type your message or use voice input...",
                                type="text"
                            ),
                            dbc.Button(
                                html.I(className="fas fa-microphone"),
                                id="voice-button",
                                color="success",
                                outline=True
                            ),
                            dbc.Button(
                                html.I(className="fas fa-paper-plane"),
                                id="send-button",
                                color="primary"
                            )
                        ])
                    ], className="mt-3"),


                    # Voice status
                    html.Div(id="voice-status", className="mt-2 text-center"),
                    
                    # Hidden components for chat functionality
                    html.Div()  # Placeholder - stores moved to main layout
                ])
            ]
        )
    ])

# App layout
app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    dcc.Store(id='user-session', storage_type='session'),
    html.Div(id='page-content'),
    # Hidden placeholder divs for components that exist only in dashboard
    html.Div(id='user-display', style={'display': 'none'}),
    html.Div(id='technician-work-orders', style={'display': 'none'}),
    html.Div(id='manager-work-orders', style={'display': 'none'}),
    html.Div(id='dashboard-content', style={'display': 'none'}),
    html.Div(id='chat-messages', style={'display': 'none'}),
    dcc.Input(id='chat-input', style={'display': 'none'}),
    html.Div(id='voice-status', style={'display': 'none'}),
    html.Div(id='voice-commands-display', style={'display': 'none'}),
    # Dummy components for dashboard view (hidden) to prevent callback errors
    # Refresh trigger for work order cards
    dcc.Store(id='refresh-trigger', data={'timestamp': 0}),
    dbc.Tabs(id='work-order-tabs', style={'display': 'none'}),
    dcc.Store(id='current-workflow-session'),
    dbc.Offcanvas(id='chat-offcanvas', is_open=False, style={'display': 'none'}),
    # Manager dashboard filter buttons
    html.Button(id='filter-all', style={'display': 'none'}),
    html.Button(id='filter-pending', style={'display': 'none'}),
    html.Button(id='filter-assigned', style={'display': 'none'}),
    html.Button(id='filter-progress', style={'display': 'none'}),
    html.Button(id='filter-completed', style={'display': 'none'}),
    # Chat components
    html.Button(id='chat-toggle', style={'display': 'none'}),
    html.Button(id='voice-button', style={'display': 'none'}),
    html.Button(id='send-button', style={'display': 'none'}),
    html.Button(id='logout-button', style={'display': 'none'}),
    dcc.Store(id='work-orders-store', storage_type='memory'),
    dcc.Store(id='chat-context', storage_type='memory'),
    dcc.Store(id='chat-session'),
    dcc.Store(id='voice-listening'),
    dcc.Store(id='selected-work-order', storage_type='session'),
    dcc.Store(id='scroll-trigger', data=''),
    dcc.Interval(id='refresh-interval', interval=60*1000, n_intervals=0, disabled=True),  # Event-driven updates only
    dcc.Interval(id='voice-check-interval', interval=2000, n_intervals=0, disabled=True),  # Reduced frequency
    # Wake word components to match browser cache expectations
    dcc.Store(id='wake-word-status', data={'listening': False, 'chat_opened': False}),
    dcc.Interval(id='wake-word-check-interval', interval=999999999, n_intervals=0, disabled=True),
])

# Callbacks
@app.callback(
    Output('page-content', 'children'),
    Input('url', 'pathname'),
    State('user-session', 'data')
)
def display_page(pathname, user_data):
    if user_data is None:
        return create_login_page()
    else:
        user_role = user_data.get('role')
        return create_dashboard_layout(user_role)

@app.callback(
    [Output('user-session', 'data'),
     Output('login-error', 'children'),
     Output('url', 'pathname')],
    Input('login-button', 'n_clicks'),
    [State('username-input', 'value'),
     State('password-input', 'value')]
)
def handle_login(n_clicks, username, password):
    if not n_clicks:
        return dash.no_update, dash.no_update, dash.no_update
    
    if not username or not password:
        return None, "Please enter both username and password", dash.no_update
    
    try:
        response = requests.post(f"{API_BASE_URL}/login/", json={
            'username': username,
            'password': password
        })
        
        if response.status_code == 200:
            user_data = response.json()['user']
            return user_data, "", "/dashboard"
        else:
            error_msg = response.json().get('error', 'Login failed')
            return None, error_msg, dash.no_update
            
    except Exception as e:
        return None, f"Connection error: {str(e)}", dash.no_update

@app.callback(
    Output('dashboard-content', 'children'),
    Input('user-session', 'data')
)
def update_dashboard_content(user_data):
    if not user_data:
        return html.Div()
    
    role = user_data.get('role')
    if role == 'technician':
        return create_technician_dashboard()
    elif role == 'service_manager':
        return create_manager_dashboard()
    else:
        return html.Div("Unknown user role")

@app.callback(
    Output('user-display', 'children'),
    Input('user-session', 'data')
)
def update_user_display(user_data):
    if user_data:
        return f"{user_data.get('first_name', '')} {user_data.get('last_name', '')}"
    return ""

@app.callback(
    [Output('user-session', 'data', allow_duplicate=True),
     Output('url', 'pathname', allow_duplicate=True)],
    Input('logout-button', 'n_clicks'),
    prevent_initial_call=True
)
def handle_logout(n_clicks):
    if n_clicks:
        return None, "/"
    return dash.no_update, dash.no_update

def detect_work_order_in_message(message, user_data):
    """Detect if message contains work order number or proxy number and start workflow"""
    message_lower = message.lower().strip()
    
    # Try voice proxy first (proxy numbers like "1", "2", etc.)
    if message_lower.isdigit():
        proxy_number = int(message_lower)
        # Get work order from voice proxy
        work_order_number = voice_proxy.get_work_order_by_voice_id(proxy_number)
        if work_order_number:
            return start_work_order_workflow(work_order_number, user_data)
    
    # Try direct work order number patterns
    work_order_patterns = [
        r'^(\d+)$',                    # Just a number: "1", "2", etc.
        r'^wo[- ]?(\w+)$',            # wo-ABC123 or wo ABC123
        r'^work order[- ]?(\w+)$',    # work order ABC123
        r'^order[- ]?(\w+)$',         # order ABC123
        r'^(WO-\w+)$'                 # WO-ABC123
    ]
    
    import re
    for pattern in work_order_patterns:
        match = re.search(pattern, message_lower)
        if match:
            identifier = match.group(1)
            
            # If it's a pure number, try voice proxy first
            if identifier.isdigit():
                proxy_number = int(identifier)
                work_order_number = voice_proxy.get_work_order_by_voice_id(proxy_number)
                if work_order_number:
                    return start_work_order_workflow(work_order_number, user_data)
            
            # Try as direct work order number
            if identifier.upper().startswith('WO-'):
                return start_work_order_workflow(identifier.upper(), user_data)
            else:
                # Add WO- prefix if needed
                work_order_number = f"WO-{identifier.upper()}"
                return start_work_order_workflow(work_order_number, user_data)
    
    return None

def start_work_order_workflow(work_order_number, user_data):
    """Start workflow for a work order and return selected work order data"""
    try:
        print(f"🚀 Starting workflow from chat for: {work_order_number}")
        
        # Start work order session via API
        response = requests.post(f"{API_BASE_URL}/chat/query/", json={
            'query': f"work order {work_order_number}",
            'user_id': user_data['id']
        })
        
        if response.status_code == 200:
            result = response.json()
            print(f"📋 Started workflow session from chat: {result.get('session_id', 'unknown')}")
            
            # Return selected work order data
            return {
                'order_number': work_order_number,
                'session_id': result.get('session_id'),
                'current_step': result.get('current_step'),
                'workflow_type': result.get('type', 'work_order')
            }
        else:
            print(f"❌ Failed to start workflow from chat: {response.status_code}")
            return None
            
    except Exception as e:
        print(f"❌ Error starting work order from chat: {str(e)}")
        return None

@app.callback(
    Output('technician-work-orders', 'children'),
    [Input('user-session', 'data'),
     Input('work-order-tabs', 'active_tab'),
     Input('refresh-trigger', 'data')]
)
def update_technician_workorders(user_data, active_tab, refresh_trigger):
    if not user_data or user_data.get('role') != 'technician':
        return html.Div()
    
    try:
        # Reduced logging frequency - only log on error or significant events  
        response = requests.get(f"{API_BASE_URL}/technician/workorders/", 
                              params={'user_id': user_data['id']})
        
        if response.status_code == 200:
            work_orders = response.json()['work_orders']
            
            # Filter work orders based on active tab
            if active_tab == "active-tab":
                # Active tab: show pending and in-progress items
                filtered_orders = [wo for wo in work_orders if wo.get('status', '').lower() in ['pending', 'in-progress', 'assigned']]

                # Sort active tab orders: in-progress first, then assigned/pending
                def sort_priority(wo):
                    status = wo.get('status', '').lower()
                    if status == 'in-progress':
                        return 0  # Highest priority (at top)
                    elif status == 'assigned':
                        return 1  # Medium priority
                    elif status == 'pending':
                        return 2  # Lower priority
                    else:
                        return 3  # Lowest priority

                filtered_orders.sort(key=sort_priority)
                tab_name = "Active"
            elif active_tab == "completed-tab":
                # Completed tab: show completed items
                filtered_orders = [wo for wo in work_orders if wo.get('status', '').lower() == 'completed']
                tab_name = "Completed"
            else:
                # Default to all if tab not recognized
                filtered_orders = work_orders
                tab_name = "All"
            
            # Only log work order counts once when count changes
            current_count = len(filtered_orders)
            cache_key = f"{user_data['id']}_{active_tab}_count"
            if not hasattr(update_technician_workorders, '_last_counts'):
                update_technician_workorders._last_counts = {}

            if update_technician_workorders._last_counts.get(cache_key) != current_count:
                print(f"DEBUG: Found {current_count} {tab_name.lower()} work orders")
                update_technician_workorders._last_counts[cache_key] = current_count

            if filtered_orders:
                cards = []

                # Update voice proxy mapping for active items (only when mapping changes)
                if active_tab == "active-tab":
                    # Create custom mapping for active work orders only
                    mapping = {}
                    reverse_mapping = {}
                    for index, wo in enumerate(filtered_orders):
                        voice_id = index + 1
                        mapping[voice_id] = wo['order_number']
                        reverse_mapping[wo['order_number']] = voice_id

                    # Only update and log if mapping has changed
                    mapping_key = f"{user_data['id']}_mapping"
                    if not hasattr(update_technician_workorders, '_last_mappings'):
                        update_technician_workorders._last_mappings = {}

                    current_mapping_hash = hash(str(sorted(mapping.items())))
                    if update_technician_workorders._last_mappings.get(mapping_key) != current_mapping_hash:
                        voice_proxy._set_cached_mapping(mapping)
                        voice_proxy._set_reverse_mapping(reverse_mapping)
                        print(f"🎤 Updated voice proxy mapping with {len(mapping)} active work orders")
                        update_technician_workorders._last_mappings[mapping_key] = current_mapping_hash
                
                for index, wo in enumerate(filtered_orders):
                    # Add proxy numbers only for active items
                    proxy_number = index + 1 if active_tab == "active-tab" else None
                    # Show start button on ALL tabs (not just active)
                    show_start_button = True  # Changed from: active_tab == "active-tab"
                    cards.append(create_work_order_card(wo, show_progress=True, proxy_number=proxy_number, show_start_button=show_start_button))
                return html.Div(cards)
            else:
                if active_tab == "active-tab":
                    return dbc.Alert("No active work orders assigned to you.", color="info", className="text-center")
                elif active_tab == "completed-tab":
                    return dbc.Alert("No completed work orders found.", color="info", className="text-center")
                else:
                    return dbc.Alert("No work orders assigned to you yet.", color="info", className="text-center")
        else:
            return dbc.Alert(f"Failed to load work orders. Status: {response.status_code}", color="danger")
    
    except Exception as e:
        print(f"DEBUG: Exception in update_technician_workorders: {e}")
        return dbc.Alert(f"Error loading work orders: {str(e)}", color="danger")

@app.callback(
    Output('manager-work-orders', 'children'),
    [Input('user-session', 'data'),
     Input('filter-all', 'n_clicks'),
     Input('filter-pending', 'n_clicks'),
     Input('filter-assigned', 'n_clicks'),
     Input('filter-progress', 'n_clicks'),
     Input('filter-completed', 'n_clicks'),
     Input('refresh-trigger', 'data')]
)
def update_manager_workorders(user_data, *args):
    # Extract filter clicks (all except the last refresh_trigger argument)
    filter_clicks = args[:-1]
    refresh_trigger = args[-1]
    if not user_data or user_data.get('role') != 'service_manager':
        return html.Div()
    
    # Determine which filter was clicked
    ctx = dash.callback_context
    status_filter = 'all'
    if ctx.triggered:
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]
        if 'pending' in button_id:
            status_filter = 'pending'
        elif 'assigned' in button_id:
            status_filter = 'assigned'  
        elif 'progress' in button_id:
            status_filter = 'in_progress'
        elif 'completed' in button_id:
            status_filter = 'completed'
    
    try:
        response = requests.get(f"{API_BASE_URL}/manager/workorders/", params={
            'user_id': user_data['id'],
            'status': status_filter
        })
        
        if response.status_code == 200:
            work_orders = response.json()['work_orders']
            if work_orders:
                cards = [create_work_order_card(wo, show_progress=True, show_start_button=True) for wo in work_orders]
                return html.Div(cards)
            else:
                return dbc.Alert(f"No {status_filter} work orders found.", color="info")
        else:
            return dbc.Alert("Failed to load work orders.", color="danger")
    
    except Exception as e:
        return dbc.Alert(f"Error: {str(e)}", color="danger")

@app.callback(
    [Output('chat-offcanvas', 'is_open'),
     Output('chat-messages', 'children', allow_duplicate=True),
     Output('chat-input', 'value', allow_duplicate=True),
     Output('current-workflow-session', 'data', allow_duplicate=True)],
    Input('chat-toggle', 'n_clicks'),
    [State('chat-offcanvas', 'is_open'),
     State('user-session', 'data')],
    prevent_initial_call=True
)
def toggle_chat(n_clicks, is_open, user_data):
    if n_clicks:
        new_state = not is_open
        if new_state:  # Chat is being opened
            # Get technician's name for personalized greeting
            if user_data:
                first_name = user_data.get('first_name', 'there')
                last_name = user_data.get('last_name', '')
                if last_name:
                    full_name = f"{first_name} {last_name}"
                else:
                    full_name = first_name

                welcome_text = f"👋 Hello {full_name}! How can I help you today?"
                tts_text = f"Hello {full_name}! How can I help you today?"
            else:
                welcome_text = "👋 Hello! How can I help you today?"
                tts_text = "Hello! How can I help you today?"

            # Create welcome message and trigger TTS
            welcome_message = create_chat_message(welcome_text, "assistant")
            speak_text(tts_text)

            return True, [welcome_message], "", None
        else:  # Chat is being closed
            return False, dash.no_update, dash.no_update, dash.no_update
    return is_open, dash.no_update, dash.no_update, dash.no_update

@app.callback(
    [Output('chat-messages', 'children'),
     Output('chat-input', 'value'),
     Output('voice-status', 'children'),
     Output('current-workflow-session', 'data'),
     Output('work-order-tabs', 'active_tab', allow_duplicate=True),
     Output('selected-work-order', 'data', allow_duplicate=True),
     Output('chat-offcanvas', 'is_open', allow_duplicate=True)],
    [Input('send-button', 'n_clicks'),
     Input('voice-button', 'n_clicks'),
     Input('chat-input', 'n_submit')],
    [State('chat-input', 'value'),
     State('user-session', 'data'),
     State('chat-messages', 'children'),
     State('current-workflow-session', 'data'),
     State('chat-offcanvas', 'is_open')],
    prevent_initial_call=True
)
def handle_chat_interaction(send_clicks, voice_clicks, input_submit, message, user_data, current_messages, workflow_session, is_chat_open):
    if not user_data:
        return current_messages or [], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
    
    ctx = dash.callback_context
    if not ctx.triggered:
        return current_messages or [], message or "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
    
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    # Handle voice input
    if trigger_id == 'voice-button':
        return handle_voice_input(current_messages, user_data, workflow_session)
    
    # Handle text input
    if (trigger_id in ['send-button', 'chat-input']) and message and message.strip():
        # Check if message contains work order number or proxy number
        work_order_result = detect_work_order_in_message(message.strip(), user_data)
        if work_order_result:
            # Work order detected - switch to Active tab and close chat
            result = handle_text_input(message.strip(), current_messages, user_data, workflow_session)
            messages, chat_input, voice_status, workflow = result[:4]  # Take first 4 values
            return messages, chat_input, voice_status, workflow, "active-tab", work_order_result, False
        else:
            # Regular chat message
            return handle_text_input(message.strip(), current_messages, user_data, workflow_session)

    return current_messages or [], message or "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update

def handle_voice_input(current_messages, user_data, workflow_session):
    """Handle voice input from user"""
    global continuous_mode, chat_auto_opened

    # Check if speech recognition is available
    if not recognizer or not microphone:
        # Try to reinitialize
        if reinitialize_speech():
            status_message = create_chat_message("🎤 Speech recognition reinitialized. Trying again...", "system")
            messages = (current_messages or []) + [status_message]
        else:
            error_message = create_chat_message(
                "🔇 **Voice recognition is not available.**\n\n"
                "**Possible solutions:**\n"
                "• Check microphone connection\n"
                "• Grant microphone permissions\n"
                "• Install: `pip install SpeechRecognition pyaudio`\n"
                "• Use text input: Type 'step complete' instead",
                "system"
            )
            return (current_messages or []) + [error_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update

    # Test microphone before using
    mic_status, mic_message = test_microphone()
    if not mic_status:
        error_message = create_chat_message(f"🔇 Microphone test failed: {mic_message}\n\n💡 Use text input: Type 'step complete' instead", "system")
        return (current_messages or []) + [error_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
    
    try:
        # Show listening status
        listening_message = create_chat_message("🎤 Listening for your command...", "system")
        messages = (current_messages or []) + [listening_message]
        
        # Listen for speech
        speech_text = listen_for_speech(timeout=10)
        
        if speech_text:
            print(f"🎙️ Recognized speech: '{speech_text}'")
            # Process speech directly without wake word requirement
            return process_chat_query(speech_text, messages, user_data, workflow_session, is_voice=True)
        else:
            # No speech detected
            timeout_message = create_chat_message("⏰ No speech detected. Please try again.", "system")
            return messages + [timeout_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
            
    except Exception as e:
        error_message = create_chat_message(f"🔊 Voice input error: {str(e)}", "system")
        return (current_messages or []) + [error_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update

def handle_text_input(message, current_messages, user_data, workflow_session):
    """Handle text input from user"""
    global continuous_mode, chat_auto_opened
    
    # Process text input directly without wake word requirement
    return process_chat_query(message, current_messages, user_data, workflow_session, is_voice=False)

def process_chat_query(query, current_messages, user_data, workflow_session, is_voice=False):
    """Process chat query and return response"""
    try:
        # Add user message to chat
        user_message = create_chat_message(query, "user")
        messages = (current_messages or []) + [user_message]
        
        print(f"🔍 DEBUG: Processing query: '{query}'")
        print(f"🔍 DEBUG: Workflow session exists: {workflow_session is not None}")
        print(f"🔍 DEBUG: Feedback keywords detected: {detect_feedback_keywords(query)}")
        print(f"🔍 DEBUG: Should treat as feedback: {should_treat_as_feedback(query, workflow_session is not None)}")

        # Check if we have an active workflow session and this should be treated as feedback
        if workflow_session and should_treat_as_feedback(query, True):
            # Process as step feedback via Django API
            feedback_data = {
                'session_id': workflow_session.get('session_id'),
                'feedback': query,
                'user_id': user_data['id']
            }
            print(f"🔄 DEBUG: Sending feedback data: {feedback_data}")
            print(f"🔄 DEBUG: Workflow session: {workflow_session}")
            
            response = requests.post(f"{API_BASE_URL}/chat/feedback/", json=feedback_data)
            
            if response.status_code == 200:
                result = response.json()
            else:
                result = {'type': 'error', 'message': 'Failed to process feedback'}
            
            if result['type'] == 'error':
                error_message = create_chat_message(f"❌ {result['message']}", "system")
                return messages + [error_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
            
            elif result['type'] == 'next_step':
                # Show next step
                current_step = result['current_step']
                progress = result.get('progress', {})
                work_order_number = workflow_session.get('work_order_number')

                # Save user feedback to backend first
                if work_order_number:
                    workflow_handler.save_work_order_message(work_order_number, user_data['id'], create_chat_message(query, "user"))

                assistant_message = create_chat_message(result['message'], "assistant")
                step_message = create_chat_message(
                    f"📋 **Step {current_step['step_number']} Instructions:**\n{current_step['description']}",
                    "assistant"
                )

                if progress:
                    progress_message = create_chat_message(
                        f"📊 Progress: {progress['completed']}/{progress['total']} steps ({progress['percentage']:.1f}%)",
                        "system"
                    )
                    messages = messages + [assistant_message, progress_message, step_message]
                else:
                    messages = messages + [assistant_message, step_message]

                # Speak the instruction
                if result.get('tts_text'):
                    speak_text(result['tts_text'])

                # Add feedback prompt
                feedback_prompt = create_chat_message("✅ When you complete this step, type your feedback or say 'step complete'", "system")
                messages = messages + [feedback_prompt]

                # Save response messages to backend
                if work_order_number:
                    workflow_handler.save_work_order_message(work_order_number, user_data['id'], assistant_message)
                    workflow_handler.save_work_order_message(work_order_number, user_data['id'], step_message)
                    if progress:
                        progress_message = create_chat_message(
                            f"📊 Progress: {progress['completed']}/{progress['total']} steps ({progress['percentage']:.1f}%)",
                            "system"
                        )
                        workflow_handler.save_work_order_message(work_order_number, user_data['id'], progress_message)
                    workflow_handler.save_work_order_message(work_order_number, user_data['id'], feedback_prompt)

                # Update workflow session with current progress
                updated_workflow_session = workflow_session.copy() if workflow_session else {}
                if progress:
                    # Create a completed_steps array based on the progress info
                    completed_steps = []
                    for i in range(1, progress['completed'] + 1):
                        completed_steps.append({
                            'step_number': i,
                            'completed': True
                        })
                    updated_workflow_session['completed_steps'] = completed_steps

                    # Update work order info if available
                    if updated_workflow_session.get('work_order'):
                        updated_workflow_session['work_order']['completed_steps'] = progress['completed']

                return messages, "", "", updated_workflow_session, dash.no_update, dash.no_update, dash.no_update
            
            elif result['type'] in ['complete', 'work_order_complete']:
                # Workflow complete
                completion_message = create_chat_message(result['message'], "assistant")

                # Show enhanced summary
                summary_text = f"🎉 **Work Order Complete!**\n"

                # Add time tracking if available
                if result.get('total_time') is not None:
                    summary_text += f"⏱️ **Total time:** {result['total_time']:.1f} hours\n"

                    if result.get('estimated_time'):
                        summary_text += f"📋 **Estimated time:** {result['estimated_time']:.1f} hours\n"

                        time_variance = result.get('time_variance', 0)
                        if time_variance > 0:
                            summary_text += f"📈 **Time variance:** +{time_variance:.1f} hours (over estimate)\n"
                        elif time_variance < -0.5:
                            summary_text += f"📉 **Time variance:** {time_variance:.1f} hours (under estimate) 🎯\n"
                        else:
                            summary_text += f"✅ **Time variance:** {time_variance:.1f} hours (on target)\n"

                if result.get('total_steps'):
                    summary_text += f"📝 **Total steps completed:** {result['total_steps']}\n"

                summary_text += f"\n🙏 **Thank you for your professional work and detailed feedback!**"

                summary_message = create_chat_message(summary_text, "assistant")
                messages = messages + [completion_message, summary_message]

                # Speak completion message (will auto-close chat after TTS finishes)
                if result.get('tts_text'):
                    speak_text(result['tts_text'])

                # Keep chat open to show completion message, will auto-close after TTS
                return messages, "", "", None, dash.no_update, None, dash.no_update
        
        else:
            # New query - send to API
            response = requests.post(f"{API_BASE_URL}/chat/query/", json={
                'query': query,
                'user_id': user_data['id'],
                'type': 'voice' if is_voice else 'text'
            })
            
            if response.status_code == 200:
                result = response.json()
                response_type = result.get('type')
                
                if response_type == 'error':
                    error_message = create_chat_message(f"❌ {result['message']}", "system")
                    return messages + [error_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
                
                elif response_type == 'work_order_start':
                    # Work order workflow session already created by Django API
                    work_order = result['work_order']
                    current_step = result['current_step']
                    work_order_number = work_order.get('order_number', 'Unknown')

                    # Extract session_id from Django API response
                    session_id = result.get('session_id', 'default_session')

                    new_workflow_session = {
                        'session_id': session_id,
                        'type': 'work_order',
                        'work_order_number': work_order_number,
                        'work_order_id': work_order.get('id')
                    }

                    # Load work order specific chat history from backend
                    session_info = workflow_handler.switch_to_work_order(work_order_number, user_data['id'])

                    # Use backend stored chat history
                    messages = session_info['chat_history'].copy() if session_info['chat_history'] else []

                    # Add current user message if not already in history
                    user_message = create_chat_message(query, "user")
                    if not messages or messages[-1].get('content') != query:
                        messages.append(user_message)
                        # Save user message to backend
                        workflow_handler.save_work_order_message(work_order_number, user_data['id'], user_message)

                    # Add response messages
                    assistant_message = create_chat_message(result['message'], "assistant")
                    step_message = create_chat_message(
                        f"📋 **Step {current_step['step_number']} Instructions:**\n{current_step['description']}",
                        "assistant"
                    )

                    messages = messages + [assistant_message, step_message]

                    # Save response messages to backend
                    workflow_handler.save_work_order_message(work_order_number, user_data['id'], assistant_message)
                    workflow_handler.save_work_order_message(work_order_number, user_data['id'], step_message)
                    
                    # Speak the instruction
                    if result.get('tts_text'):
                        speak_text(result['tts_text'])
                    
                    # Add feedback prompt
                    feedback_prompt = create_chat_message("✅ When you complete this step, type your feedback or say 'step complete'", "system")
                    messages = messages + [feedback_prompt]
                    
                    print(f"📦 DEBUG: Returning new work order workflow session: {new_workflow_session}")
                    return messages, "", "", new_workflow_session, dash.no_update, dash.no_update, dash.no_update
                
                elif response_type == 'general_query_start':
                    # General query workflow session already created by Django API
                    query_info = result['query_info']
                    current_step = result['current_step']

                    # Extract session_id from Django API response
                    session_id = result.get('session_id', 'default_session')

                    new_workflow_session = {'session_id': session_id, 'type': 'general_query'}

                    # Show step instruction
                    assistant_message = create_chat_message(result['message'], "assistant")
                    step_message = create_chat_message(
                        f"📋 **Step {current_step['step_number']} Instructions:**\n{current_step['description']}",
                        "assistant"
                    )

                    messages = messages + [assistant_message, step_message]

                    # Speak the instruction
                    if result.get('tts_text'):
                        speak_text(result['tts_text'])

                    # Add feedback prompt
                    feedback_prompt = create_chat_message("✅ When you complete this step, type your feedback or say 'step complete'", "system")
                    messages = messages + [feedback_prompt]

                    return messages, "", "", new_workflow_session, dash.no_update, dash.no_update, dash.no_update

                elif response_type == 'simple_response':
                    assistant_message = create_chat_message(result.get('message', 'Processing...'), "assistant")

                    if result.get('tts_text'):
                        speak_text(result['tts_text'])
                    elif result.get('message'):
                        speak_text(result['message'])

                    return messages + [assistant_message], "", "", None, dash.no_update, dash.no_update, dash.no_update

                else:
                    # Generic response
                    assistant_message = create_chat_message(result.get('message', 'Processing...'), "assistant")
                    return messages + [assistant_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
            
            else:
                error_data = response.json() if response.content else {'error': 'Unknown error'}
                error_message = create_chat_message(f"❌ API Error: {error_data.get('error', 'Unknown error')}", "system")
                return messages + [error_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
    
    except Exception as e:
        error_message = create_chat_message(f"❌ Error: {str(e)}", "system")
        return (current_messages or []) + [error_message], "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update

def create_chat_message(content, sender):
    """Create a chat message component"""
    if sender == "user":
        return dbc.Card([
            dbc.CardBody([
                html.P(content, className="mb-0")
            ])
        ], color="primary", outline=True, className="mb-2 ms-auto", style={'maxWidth': '80%'})
    
    elif sender == "assistant":
        return dbc.Card([
            dbc.CardBody([
                html.Div([
                    html.I(className="fas fa-robot me-2"),
                    dcc.Markdown(content, className="mb-0 d-inline")
                ])
            ])
        ], color="success", outline=True, className="mb-2 me-auto", style={'maxWidth': '80%'})
    
    else:  # system
        return dbc.Alert(content, color="info", className="mb-2 small")

# Voice commands display callback
@app.callback(
    Output('voice-commands-display', 'children'),
    [Input('user-session', 'data'), Input('chat-offcanvas', 'is_open')]
)
def update_voice_commands_display(user_session, is_chat_open):
    """Update voice commands display when chat is opened"""
    if not is_chat_open or not user_session or not user_session.get('user_id'):
        return []
    
    try:
        user_id = user_session['user_id']
        
        # Make API call to get voice commands
        api_url = "http://localhost:8000/api/voice/commands/"
        headers = {'Content-Type': 'application/json'}
        data = {'user_id': user_id}
        
        response = requests.post(api_url, json=data, headers=headers)
        
        if response.status_code == 200:
            result = response.json()
            voice_commands = result.get('voice_commands', [])
            
            if not voice_commands:
                return [html.P("No voice commands available", className="text-muted small")]
            
            # Create voice command list
            command_items = []
            for i, command in enumerate(voice_commands[:10]):  # Show first 10 commands
                if command.startswith('📝 Voice ID'):
                    # Extract voice ID and description
                    parts = command.split(': ', 1)
                    if len(parts) == 2:
                        voice_id_part = parts[0].replace('📝 Voice ID ', '')
                        description = parts[1][:30] + "..." if len(parts[1]) > 30 else parts[1]
                        
                        command_items.append(
                            html.Div([
                                dbc.Badge(f"#{voice_id_part}", color="primary", className="me-2"),
                                html.Span(description, className="small")
                            ], className="mb-1")
                        )
            
            if command_items:
                return command_items + [
                    html.Hr(className="my-2"),
                    html.P("💡 Say: 'work order [number]' or use voice input", className="text-muted small mb-0")
                ]
            else:
                return [html.P("No work orders available", className="text-muted small")]
        
        else:
            return [html.P("Unable to load voice commands", className="text-danger small")]
    
    except Exception as e:
        print(f"Error loading voice commands: {e}")
        return [html.P("Error loading voice commands", className="text-danger small")]


# Auto-refresh work order cards when chat closes
@app.callback(
    Output('refresh-trigger', 'data'),
    Input('chat-offcanvas', 'is_open'),
    State('refresh-trigger', 'data'),
    prevent_initial_call=True
)
def trigger_refresh_on_chat_close(is_chat_open, current_trigger):
    """Trigger work order cards refresh when chat window closes"""
    if not is_chat_open:  # Chat was closed
        import time
        new_timestamp = time.time()

        # Add debounce mechanism to prevent rapid refreshes
        if current_trigger and 'timestamp' in current_trigger:
            last_refresh = current_trigger['timestamp']
            if new_timestamp - last_refresh < 2.0:  # Minimum 2 seconds between refreshes
                return dash.no_update

        print(f"🔄 Chat closed, triggering work order cards refresh (timestamp: {new_timestamp})")
        return {'timestamp': new_timestamp}
    return dash.no_update

# Exact recreation of original wake word callback to match browser cache hash
@app.callback(
    [Output('chat-offcanvas', 'is_open', allow_duplicate=True),
     Output('chat-messages', 'children', allow_duplicate=True),
     Output('chat-input', 'value', allow_duplicate=True),
     Output('current-workflow-session', 'data', allow_duplicate=True),
     Output('wake-word-status', 'data')],
    [Input('wake-word-check-interval', 'n_intervals')],
    [State('chat-offcanvas', 'is_open'),
     State('chat-messages', 'children'),
     State('user-session', 'data'),
     State('current-workflow-session', 'data'),
     State('wake-word-status', 'data')],
    prevent_initial_call=True
)
def check_wake_word_detection(n_intervals, is_chat_open, current_messages, user_session, workflow_session, wake_status):
    """Recreated wake word detection callback to handle browser cache - DISABLED"""
    # This callback exists only to satisfy browser cache expectations
    # The interval is disabled so this should never actually run
    # Always return no_update to prevent any functionality
    return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

# Combined Start Work callback - Open chat window AND auto-send work order query
@app.callback(
    [Output('chat-offcanvas', 'is_open', allow_duplicate=True),
     Output('chat-messages', 'children', allow_duplicate=True),
     Output('chat-input', 'value', allow_duplicate=True),
     Output('voice-status', 'children', allow_duplicate=True),
     Output('current-workflow-session', 'data', allow_duplicate=True)],
    [Input({'type': 'start-work-btn', 'index': dash.dependencies.ALL}, 'n_clicks')],
    [State('user-session', 'data'),
     State('chat-messages', 'children'),
     State('current-workflow-session', 'data')],
    prevent_initial_call=True
)
def handle_start_work_and_auto_send(n_clicks_list, user_data, current_messages, workflow_session):
    """Auto-send work order query when start work button is clicked"""
    print(f"🔥 START WORK CALLBACK TRIGGERED! n_clicks_list: {n_clicks_list}")
    print(f"🔥 user_data exists: {user_data is not None}")

    if not any(n_clicks_list) or not user_data:
        print(f"🔥 Early return - no clicks or no user data")
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

    # Find which button was clicked
    ctx = dash.callback_context
    print(f"🔥 Context triggered: {ctx.triggered}")
    if not ctx.triggered:
        print(f"🔥 No context triggered - returning")
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

    button_id = ctx.triggered[0]['prop_id'].split('.')[0]
    import json
    button_info = json.loads(button_id)
    work_order_number = button_info['index']

    print(f"🚀 Auto-sending query for work order: {work_order_number}")
    print(f"🔍 DEBUG: Current messages length: {len(current_messages) if current_messages else 0}")
    print(f"🔍 DEBUG: Workflow session: {workflow_session}")

    # Get work order details to check for existing progress
    work_order_data = None
    try:
        response = requests.get(f"{API_BASE_URL}/technician/workorders/",
                              params={'user_id': user_data['id']})
        if response.status_code == 200:
            work_orders = response.json().get('work_orders', [])
            for wo in work_orders:
                if wo['order_number'] == work_order_number:
                    work_order_data = wo
                    break
    except Exception as e:
        print(f"⚠️ Error fetching work order data: {e}")

    # Check if work order has been started (has steps generated)
    has_been_started = False
    if work_order_data:
        has_been_started = (work_order_data.get('status', '').upper() == 'IN_PROGRESS' and
                           work_order_data.get('total_steps', 0) > 0)

    # Show progress bar when starting work
    progress_style = {'display': 'block'}

    if has_been_started:
        # Work order has been started - show resumption flow
        print(f"🔄 Resuming work order {work_order_number} that has been started")
        resume_result = resume_workflow_session(work_order_number, work_order_data, current_messages, user_data)
        return True, resume_result[0], resume_result[1], resume_result[2], resume_result[3]
    else:
        # Fresh start - no steps generated yet
        # Step 1: Generate question using new /api/generate-question/ endpoint
        print(f"🆕 Starting new session for {work_order_number}")
        print(f"🤖 Step 1: Generating question from work order using LLM...")

        try:
            question_response = requests.post(
                f"{API_BASE_URL}/generate-question/",
                json={'work_order_number': work_order_number},
                timeout=10
            )

            if question_response.status_code == 200:
                question_data = question_response.json()
                generated_question = question_data.get('generated_question', '')
                print(f"✅ Generated question: {generated_question}")

                # Use the generated question as the query
                query = generated_question
            else:
                # Fallback to default query if endpoint fails
                print(f"⚠️ Question generation failed (status {question_response.status_code}), using fallback")
                query = f"help me fix {work_order_number}"
        except Exception as e:
            # Fallback to default query if request fails
            print(f"⚠️ Question generation error: {e}, using fallback")
            query = f"help me fix {work_order_number}"

        print(f"🔍 DEBUG: About to call process_chat_query with query: '{query}'")
        result = process_chat_query(query, current_messages, user_data, workflow_session, is_voice=False)
        print(f"🔍 DEBUG: process_chat_query returned {len(result)} values")
        print(f"🔍 DEBUG: First result (messages): {len(result[0]) if result[0] else 0} messages")
        return True, result[0], result[1], result[2], result[3]

# Start Over callback - Reset work order and start from first step
@app.callback(
    Output('chat-offcanvas', 'is_open', allow_duplicate=True),
    [Input({'type': 'start-over-btn', 'index': dash.dependencies.ALL}, 'n_clicks')],
    prevent_initial_call=True
)
def handle_start_over(n_clicks_list):
    """Handle start over button - open chat window"""
    if not any(n_clicks_list):
        return dash.no_update

    print(f"🔄 Start Over button clicked")
    return True

@app.callback(
    [Output('chat-messages', 'children', allow_duplicate=True),
     Output('chat-input', 'value', allow_duplicate=True),
     Output('voice-status', 'children', allow_duplicate=True),
     Output('current-workflow-session', 'data', allow_duplicate=True),
     Output('technician-work-orders', 'children', allow_duplicate=True),
     Output('manager-work-orders', 'children', allow_duplicate=True)],
    [Input({'type': 'start-over-btn', 'index': dash.dependencies.ALL}, 'n_clicks')],
    [State('user-session', 'data'),
     State('chat-messages', 'children'),
     State('current-workflow-session', 'data'),
     State('work-order-tabs', 'active_tab')],
    prevent_initial_call=True
)
def auto_send_start_over_query(n_clicks_list, user_data, current_messages, workflow_session, active_tab):
    """Auto-send start over query when start over button is clicked"""
    if not any(n_clicks_list) or not user_data:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

    # Find which button was clicked
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

    button_id = ctx.triggered[0]['prop_id'].split('.')[0]
    import json
    button_info = json.loads(button_id)
    work_order_number = button_info['index']

    # Send start over query - this will reset and start from first step
    query = f"start over {work_order_number}"
    print(f"🔄 Starting over for {work_order_number} - resetting backend session and chat history")

    # Reset backend session and chat history
    workflow_handler.reset_work_order_session(work_order_number, user_data['id'])

    # Process start over with clean backend session
    result = process_chat_query(query, [], user_data, None, is_voice=False)

    # Refresh work order views to remove progress bars
    current_tab = active_tab or 'assigned'
    technician_content = update_technician_workorders(user_data, current_tab, None)
    manager_content = update_manager_workorders(user_data, None, None, None, None, None, None)

    return result[0], result[1], result[2], result[3], technician_content, manager_content

# Resume callback - Continue from where user left off
@app.callback(
    Output('chat-offcanvas', 'is_open', allow_duplicate=True),
    [Input({'type': 'resume-work-btn', 'index': dash.dependencies.ALL}, 'n_clicks')],
    prevent_initial_call=True
)
def handle_resume_work(n_clicks_list):
    """Handle resume work button - open chat window"""
    if not any(n_clicks_list):
        return dash.no_update

    print(f"▶️ Resume work button clicked")
    return True

@app.callback(
    [Output('chat-messages', 'children', allow_duplicate=True),
     Output('chat-input', 'value', allow_duplicate=True),
     Output('voice-status', 'children', allow_duplicate=True),
     Output('current-workflow-session', 'data', allow_duplicate=True)],
    [Input({'type': 'resume-work-btn', 'index': dash.dependencies.ALL}, 'n_clicks')],
    [State('user-session', 'data'),
     State('chat-messages', 'children'),
     State('current-workflow-session', 'data')],
    prevent_initial_call=True
)
def auto_send_resume_query(n_clicks_list, user_data, current_messages, workflow_session):
    """Auto-send resume query when resume button is clicked"""
    if not any(n_clicks_list) or not user_data:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update

    # Find which button was clicked
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update

    button_id = ctx.triggered[0]['prop_id'].split('.')[0]
    import json
    button_info = json.loads(button_id)
    work_order_number = button_info['index']

    # Clear chat window and start fresh session for resume
    query = f"resume {work_order_number}"
    print(f"▶️ Resuming work for {work_order_number} - clearing chat window and starting from correct step")

    # Clear backend session for this work order and start fresh
    workflow_handler.reset_work_order_session(work_order_number, user_data['id'])

    # Process resume with empty chat messages (cleared chat window)
    result = process_chat_query(query, [], user_data, None, is_voice=False)

    return result[0], result[1], result[2], result[3]

def get_current_step_for_resumption(work_order_data):
    """Get the current step for work order resumption"""
    # Find the first incomplete step
    steps_data = work_order_data.get('steps', [])
    for step in steps_data:
        if not step.get('is_completed', False):
            return step

    # If all steps are completed, return the last step
    if steps_data:
        return steps_data[-1]

    # Fallback: create a basic step structure
    return {
        'step_number': 1,
        'title': 'Resume Work',
        'description': 'Continue with the next step.',
        'estimated_time': 1.0
    }

def resume_workflow_session(work_order_number, work_order_data, current_messages, user_data):
    """Resume workflow session by fetching existing session and displaying completed steps"""
    try:
        # Create session ID based on work order ID and user ID
        work_order_id = work_order_data.get('id')
        user_id = user_data.get('id')
        session_id = f"wo_{work_order_id}_{user_id}"

        print(f"🔍 Looking for existing workflow session: {session_id}")

        # Import workflow handler
        from chat_workflow_handler import workflow_handler

        # Get session status to check if it exists
        session_status = workflow_handler.get_session_status(session_id)

        # Try to get existing session data first
        session_data = workflow_handler._get_session(session_id)

        if not session_data:
            print(f"⚠️ No existing session found, creating new session for resumption...")
            # Create a new session for resumption based on database state
            current_step = get_current_step_for_resumption(work_order_data)

            # Create session manually to match expected structure
            from datetime import datetime
            session_data = {
                'type': 'work_order',
                'user_id': user_id,
                'work_order': work_order_data,
                'current_step_number': current_step['step_number'],
                'current_step': current_step,
                'step_start_time': datetime.now().isoformat(),
                'completed_steps': [],
                'awaiting_feedback': True
            }

            # Reconstruct completed steps from database
            completed_steps = []
            for step in work_order_data.get('steps', []):
                if step.get('is_completed', False):
                    # Find feedback for this step from database
                    try:
                        from workorders.models import WorkOrderFeedback
                        feedback_entry = WorkOrderFeedback.objects.filter(
                            work_order_id=work_order_data['id'],
                            step__step_number=step['step_number']
                        ).first()

                        feedback_text = feedback_entry.feedback_text if feedback_entry else 'Step completed'
                        time_spent = float(feedback_entry.time_spent) if feedback_entry else 0.0

                        completed_steps.append({
                            'step_number': step['step_number'],
                            'feedback': feedback_text,
                            'time_spent': time_spent,
                            'completed_at': step.get('completed_at', datetime.now().isoformat())
                        })
                    except Exception as e:
                        print(f"⚠️ Error getting feedback for step {step['step_number']}: {e}")

            session_data['completed_steps'] = completed_steps

            # Store the session
            workflow_handler._set_session(session_id, session_data)
            print(f"✅ Created new session: {session_id} with {len(completed_steps)} completed steps")
        else:
            print(f"✅ Found existing session: {session_id}")

        if session_data:
                # Start with clear chat and add resumption header
                messages = []

                # Add resumption header
                resume_header = create_chat_message(f"🔄 **Resuming Work Order {work_order_number}**", "system")
                messages.append(resume_header)

                # Display completed steps with feedback
                completed_steps = session_data.get('completed_steps', [])
                if completed_steps:
                    print(f"📋 Displaying {len(completed_steps)} completed steps")

                    for step_data in completed_steps:
                        step_number = step_data.get('step_number')
                        feedback = step_data.get('feedback', '')
                        completed_at = step_data.get('completed_at', '')

                        # Find step details from work order data
                        step_details = None
                        steps_data = work_order_data.get('steps', [])
                        for step in steps_data:
                            if step.get('step_number') == step_number:
                                step_details = step
                                break

                        if step_details:
                            # Show original step instruction
                            step_title = step_details.get('title', f'Step {step_number}')
                            step_description = step_details.get('description', '')

                            step_message = create_chat_message(
                                f"📋 **Step {step_number}: {step_title}**\n\n{step_description}",
                                "assistant"
                            )
                            messages.append(step_message)

                            # Show user feedback
                            if feedback:
                                feedback_message = create_chat_message(feedback, "user")
                                messages.append(feedback_message)

                            # Show completion confirmation
                            if completed_at:
                                try:
                                    from datetime import datetime
                                    dt = datetime.fromisoformat(completed_at.replace('Z', '+00:00'))
                                    time_str = dt.strftime('%m/%d %H:%M')
                                    completion_msg = f"✅ Step {step_number} completed at {time_str}"
                                except:
                                    completion_msg = f"✅ Step {step_number} completed"
                            else:
                                completion_msg = f"✅ Step {step_number} completed"

                            completion_message = create_chat_message(completion_msg, "system")
                            messages.append(completion_message)

                # Show current step if any
                current_step = session_data.get('current_step')
                if current_step and session_data.get('awaiting_feedback'):
                    current_step_number = current_step.get('step_number')
                    step_title = current_step.get('title', 'Next Step')
                    step_description = current_step.get('description', '')

                    # Display current step
                    current_step_text = f"📋 **Current Step {current_step_number}: {step_title}**\n\n"
                    current_step_text += f"{step_description}\n\n"
                    current_step_text += f"⏱️ Estimated time: {current_step.get('estimated_time', 'N/A')} hours"

                    current_step_message = create_chat_message(current_step_text, "assistant")
                    messages.append(current_step_message)

                    # Add feedback prompt
                    feedback_prompt = create_chat_message(
                        "✅ **Ready for your feedback!** Type your progress or say 'step complete' when finished.",
                        "system"
                    )
                    messages.append(feedback_prompt)

                    # Voice out the current step
                    completed_count = len(completed_steps)
                    total_steps = work_order_data.get('total_steps', 0)

                    if completed_count > 0:
                        tts_text = f"Welcome back! You have completed {completed_count} out of {total_steps} steps. "
                        tts_text += f"Your current step is: {step_title}. {step_description}. "
                        tts_text += "Please provide your feedback when you complete this step."
                    else:
                        tts_text = f"Resuming work order {work_order_number}. "
                        tts_text += f"Your current step is: {step_title}. {step_description}. "
                        tts_text += "Please provide your feedback when you complete this step."

                    speak_text(tts_text)

                    # Return with existing workflow session
                    workflow_session = {
                        'session_id': session_id,
                        'type': 'work_order'
                    }

                    return messages, "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update
                else:
                    # All steps completed
                    completion_message = create_chat_message(
                        f"🎉 All steps have been completed for {work_order_number}!",
                        "assistant"
                    )
                    messages.append(completion_message)
                    speak_text(f"All steps have been completed for work order {work_order_number}!", is_completion=True)

                    # Keep chat open to show completion message, will auto-close after TTS
                    return messages, "", "", None, dash.no_update, None, dash.no_update

        # Fallback: if no session data available
        print("⚠️ Unable to create or retrieve session data")
        query = f"help me fix {work_order_number}"
        return process_chat_query(query, current_messages, user_data, None, is_voice=False)

    except Exception as e:
        print(f"❌ Error resuming workflow session: {e}")
        import traceback
        traceback.print_exc()

        # Fallback: start fresh on error
        query = f"help me fix {work_order_number}"
        return process_chat_query(query, current_messages, user_data, None, is_voice=False)

def show_work_order_progress(work_order_number, work_order_data, current_messages, user_data, workflow_session):
    """Show existing progress and current step for work order resumption"""
    try:
        # Start with user's "Start Over" message
        user_message = create_chat_message(f"Start Over {work_order_number}", "user")
        messages = (current_messages or []) + [user_message]

        # Add work order summary
        summary_text = f"🔧 **Resuming Work Order {work_order_number}**\n"
        summary_text += f"📋 {work_order_data.get('title', 'Work Order')}\n"
        summary_text += f"🚗 Vehicle: {work_order_data.get('vehicle', 'N/A')}\n"
        summary_text += f"📊 Progress: {work_order_data.get('completed_steps', 0)}/{work_order_data.get('total_steps', 0)} steps"

        summary_message = create_chat_message(summary_text, "assistant")
        messages.append(summary_message)

        # Get detailed step history with feedback from API
        try:
            feedback_response = requests.get(f"{API_BASE_URL}/workorder/{work_order_data.get('id')}/feedback/",
                                           params={'user_id': user_data['id']})

            step_feedback_data = []
            if feedback_response.status_code == 200:
                step_feedback_data = feedback_response.json().get('feedback_history', [])
        except Exception as e:
            print(f"⚠️ Could not fetch feedback history: {e}")
            step_feedback_data = []

        # Show completed steps with their feedback
        completed_steps = work_order_data.get('completed_steps', 0)
        if completed_steps > 0:
            # Show each completed step with full details and feedback
            steps_data = work_order_data.get('steps', [])

            for step in steps_data:
                if step.get('is_completed', False):
                    step_num = step.get('step_number', 0)
                    step_title = step.get('title', f'Step {step_num}')
                    step_description = step.get('description', '')

                    # Create step instruction message (as if it was originally shown)
                    step_instruction = create_chat_message(
                        f"📋 **Step {step_num}: {step_title}**\n\n{step_description}",
                        "assistant"
                    )
                    messages.append(step_instruction)

                    # Find and show the feedback for this step
                    step_feedback = None
                    for feedback in step_feedback_data:
                        if feedback.get('step_number') == step_num:
                            step_feedback = feedback.get('feedback', '')
                            break

                    if step_feedback:
                        # Show the actual feedback provided
                        feedback_message = create_chat_message(step_feedback, "user")
                        messages.append(feedback_message)

                        # Show completion confirmation
                        completion_time = step.get('completed_at', '')
                        if completion_time:
                            try:
                                from datetime import datetime
                                dt = datetime.fromisoformat(completion_time.replace('Z', '+00:00'))
                                time_str = dt.strftime('%m/%d %H:%M')
                                completion_msg = f"✅ Step {step_num} completed at {time_str}"
                            except:
                                completion_msg = f"✅ Step {step_num} completed"
                        else:
                            completion_msg = f"✅ Step {step_num} completed"

                        completion_message = create_chat_message(completion_msg, "system")
                        messages.append(completion_message)
                    else:
                        # No feedback found, show generic completion
                        completion_message = create_chat_message(f"✅ Step {step_num}: {step_title} completed", "system")
                        messages.append(completion_message)
        else:
            # No completed steps yet, but work has been started
            progress_message = create_chat_message(
                "📝 **Work Order Started** - Ready to begin step-by-step workflow",
                "system"
            )
            messages.append(progress_message)

        # Find the current step that needs feedback (first incomplete step)
        current_step_data = get_current_step_for_resumption(work_order_data)
        total_steps = work_order_data.get('total_steps', 0)

        if current_step_data:
            current_step_number = current_step_data.get('step_number', 1)

            # Show the current step details
            current_step_text = f"📋 **Current Step {current_step_number}: {current_step_data.get('title', 'Next Step')}**\n\n"
            current_step_text += f"{current_step_data.get('description', 'Please complete this step.')}\n\n"
            current_step_text += f"⏱️ Estimated time: {current_step_data.get('estimated_time', 'N/A')} hours"

            current_step_message = create_chat_message(current_step_text, "assistant")
            messages.append(current_step_message)

            # Add feedback prompt
            feedback_prompt = create_chat_message(
                "✅ **Ready for your feedback!** Type your progress or say 'step complete' when finished.",
                "system"
            )
            messages.append(feedback_prompt)

            # Voice out the current step that requires feedback
            step_title = current_step_data.get('title', 'Next Step')
            step_description = current_step_data.get('description', 'Please complete this step.')

            # Create a more natural TTS message based on completed steps count
            completed_steps_count = len(session_data.get('completed_steps', []))
            if completed_steps_count > 0:
                tts_text = f"Welcome back! You have completed {completed_steps_count} out of {total_steps} steps. "
                tts_text += f"Your current step is: {step_title}. {step_description}. "
                tts_text += "Please provide your feedback when you complete this step."
            else:
                tts_text = f"Starting work order {work_order_number}. "
                tts_text += f"Your first step is: {step_title}. {step_description}. "
                tts_text += "Please provide your feedback when you complete this step."

            speak_text(tts_text)

            # Create or update workflow session
            new_workflow_session = {
                'session_id': f"wo_{work_order_data.get('id', 'unknown')}_{user_data['id']}",
                'type': 'work_order',
                'work_order_number': work_order_data.get('order_number', 'Unknown'),
                'work_order_id': work_order_data.get('id')
            }

            return messages, "", "", new_workflow_session, dash.no_update, dash.no_update, dash.no_update
        else:
            # No step data found, fall back to API query
            query = f"resume work order {work_order_number}"
            return process_chat_query(query, messages, user_data, workflow_session, is_voice=False)

    except Exception as e:
        print(f"❌ Error showing work order progress: {e}")
        error_message = create_chat_message(f"❌ Error loading progress for {work_order_number}", "system")
        messages = (current_messages or []) + [error_message]
        return messages, "", "", workflow_session, dash.no_update, dash.no_update, dash.no_update


# Complete step callback
@app.callback(
    [Output('selected-work-order', 'data', allow_duplicate=True),
     Output('step-feedback-input', 'value'),
     Output('in-progress-content', 'children', allow_duplicate=True)],
    [Input('complete-step-btn', 'n_clicks')],
    [State('step-feedback-input', 'value'),
     State('selected-work-order', 'data'),
     State('user-session', 'data')],
    prevent_initial_call=True
)
def handle_complete_step(n_clicks, feedback_text, selected_work_order, user_data):
    """Handle completing a step with feedback"""
    if not n_clicks or not selected_work_order or not user_data:
        return dash.no_update, dash.no_update, dash.no_update
    
    if not feedback_text or not feedback_text.strip():
        return dash.no_update, dash.no_update, dbc.Alert(
            "Please provide feedback before completing the step.", 
            color="warning", 
            dismissable=True
        )
    
    try:
        # Submit step feedback via API
        feedback_data = {
            'session_id': selected_work_order['session_id'],
            'feedback': feedback_text.strip(),
            'user_id': user_data['id']
        }
        
        response = requests.post(f"{API_BASE_URL}/chat/feedback/", json=feedback_data)
        
        if response.status_code == 200:
            result = response.json()
            
            if result['type'] == 'complete':
                # Work order completed
                return None, "", html.Div([
                    dbc.Alert([
                        html.H4([html.I(className="fas fa-check-circle me-2"), "Work Order Completed!"], className="alert-heading"),
                        html.P(result.get('message', 'Work order completed successfully!')),
                        html.Hr(),
                        html.P(f"Total time: {result.get('total_time', 0):.1f} hours", className="mb-0"),
                        html.P(f"Total steps: {result.get('total_steps', 0)}", className="mb-0")
                    ], color="success", className="text-center"),
                    
                    dbc.Button(
                        [html.I(className="fas fa-arrow-left me-2"), "Back to Active Tab"],
                        href="#",
                        id="back-to-active-btn",
                        color="primary",
                        className="w-100 mt-3"
                    )
                ])
            
            elif result['type'] == 'next_step':
                # Move to next step
                updated_work_order = selected_work_order.copy()
                updated_work_order['current_step'] = result['current_step']
                
                return updated_work_order, "", dash.no_update
            
            else:
                return dash.no_update, dash.no_update, dbc.Alert(
                    "Unexpected response from server", 
                    color="danger"
                )
        
        else:
            return dash.no_update, dash.no_update, dbc.Alert(
                f"Failed to submit feedback (Status: {response.status_code})", 
                color="danger"
            )
            
    except Exception as e:
        print(f"❌ Error completing step: {str(e)}")
        return dash.no_update, dash.no_update, dbc.Alert(
            f"Error: {str(e)}", 
            color="danger"
        )

if __name__ == '__main__':
    print("🚀 Starting Voice Assistant Dash App")
    print("📱 Open http://localhost:8050 in your browser")
    print("🎤 Make sure your microphone is working for voice commands")
    
    # Initialize voice proxy mappings for common users
    try:
        print("🎤 Initializing voice proxy system...")
        # Pre-generate mappings for common user IDs
        for user_id in [1, 2, 3, 4, 5]:
            mapping = voice_proxy.generate_voice_mapping(user_id)
            if mapping:
                print(f"   • User {user_id}: {len(mapping)} voice commands available")
        print("✅ Voice proxy system initialized")
    except Exception as e:
        print(f"⚠️ Voice proxy initialization failed: {e}")


    # TTS polling callback - disabled for event-driven updates
    # @app.callback(
    #     Output('tts-store', 'data'),
    #     Input('tts-check-interval', 'n_intervals'),
    #     prevent_initial_call=True
    # )
    # def check_tts_requests(n_intervals):
    #     """Check for TTS requests from file"""
    #     try:
    #         import json
    #         import os
    #         tts_file = '/tmp/tts_request.json'
    #
    #         if os.path.exists(tts_file):
    #             with open(tts_file, 'r') as f:
    #                 tts_data = json.load(f)
    #
    #             # Remove the file after reading to avoid repeats
    #             os.remove(tts_file)
    #             return tts_data
    #         else:
    #             return dash.no_update
    #     except Exception as e:
    #         print(f"⚠️ TTS polling error: {e}")
    #         return dash.no_update

# Enhanced clientside callback for immediate TTS triggering
app.clientside_callback(
    """
    function(tts_data) {
        if (tts_data && tts_data.text) {
            console.log('🔊 TTS Data Received:', tts_data);

            // Immediate TTS execution without delay
            setTimeout(function() {
                // Check if this is a completion message
                const text = tts_data.text.toLowerCase();
                const isCompletion = tts_data.is_completion ||
                                   text.includes('outstanding work') ||
                                   text.includes('successfully completed') ||
                                   text.includes('all steps have been completed') ||
                                   text.includes('congratulations') ||
                                   text.includes('work order complete');

                if (isCompletion && window.autoCloseChatAfterTTS) {
                    // Use auto-close TTS for completion messages
                    console.log('🔊 Using auto-close TTS for completion');
                    window.autoCloseChatAfterTTS(tts_data.text);
                } else if (window.speakText) {
                    // Use regular TTS for other messages
                    console.log('🔊 Using regular TTS');
                    window.speakText(tts_data.text);
                } else {
                    console.error('🔊 TTS functions not available');
                }
            }, 10); // Minimal delay for browser readiness
        } else {
            // No TTS data to process
        }
        return '';
    }
    """,
    Output('tts-trigger', 'children'),
    [Input('tts-store', 'data')],
    prevent_initial_call=True
)

# Callback to update TTS store when chat messages change
@app.callback(
    Output('tts-store', 'data', allow_duplicate=True),
    [Input('chat-messages', 'children')],
    prevent_initial_call=True
)
def update_tts_store(messages):
    """Update TTS store when new messages are added to chat"""
    global current_tts_data
    if current_tts_data:
        tts_to_send = current_tts_data
        current_tts_data = None  # Clear after sending
        print(f"🔊 TTS Store Updated: {tts_to_send['text'][:50]}...")
        return tts_to_send
    return dash.no_update


# Reset work order callback
@app.callback(
    [Output('technician-work-orders', 'children', allow_duplicate=True),
     Output('manager-work-orders', 'children', allow_duplicate=True)],
    [Input({'type': 'reset-work-btn', 'index': dash.dependencies.ALL}, 'n_clicks')],
    [State('user-session', 'data'),
     State('work-order-tabs', 'active_tab')],
    prevent_initial_call=True
)
def handle_reset_work_order(n_clicks_list, user_data, active_tab):
    """Handle resetting a completed work order back to ASSIGNED status"""
    if not any(n_clicks_list) or not user_data:
        return dash.no_update, dash.no_update

    # Find which reset button was clicked
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update, dash.no_update

    button_id = ctx.triggered[0]['prop_id'].split('.')[0]
    import json
    button_info = json.loads(button_id)
    work_order_number = button_info['index']

    print(f"🔄 Resetting work order: {work_order_number}")

    try:
        # Call API to reset the work order
        reset_response = requests.post(f"{API_BASE_URL}/workorder/reset/", json={
            'work_order_number': work_order_number,
            'user_id': user_data['id']
        })

        if reset_response.status_code == 200:
            print(f"✅ Successfully reset work order {work_order_number}")

            # Refresh both technician and manager views with updated data
            # Use the current active tab for technician view (default to 'assigned' if None)
            current_tab = active_tab or 'assigned'
            technician_content = update_technician_workorders(user_data, current_tab, None)
            manager_content = update_manager_workorders(user_data, None, None, None, None, None, None)

            print(f"🔄 Refreshed work order views after reset - Active tab: {current_tab}")
            return technician_content, manager_content
        else:
            print(f"❌ Failed to reset work order: {reset_response.status_code}")
            return dash.no_update, dash.no_update

    except Exception as e:
        print(f"❌ Error resetting work order: {e}")
        return dash.no_update, dash.no_update

if __name__ == "__main__":
    app.run(debug=False, host='0.0.0.0', port=8050)