"""
URL Configuration for Agentic RAG App
"""

from django.urls import path
from . import views

app_name = 'agentic_rag'

urlpatterns = [
    path('query/', views.query_agentic_rag, name='query'),
    path('health/', views.health_check, name='health'),
]
