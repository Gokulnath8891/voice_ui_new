"""
Agentic RAG Service Layer
Extracted from streamlit_vc_0811_thread_v1_agentic.py
Handles intelligent query routing, vector search, SQL queries, and multi-step RAG workflow
"""

import json
import requests
import numpy as np
import psycopg2
from typing import TypedDict, Optional, Dict, Any, List
from sentence_transformers import SentenceTransformer
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langgraph.checkpoint.memory import MemorySaver


# ===============================
# Configuration
# ===============================

# Azure OpenAI Configuration (Note: Endpoint should NOT have trailing slash)
AZURE_OPENAI_ENDPOINT = "https://voice-assitant-openai.openai.azure.com"
AZURE_OPENAI_API_KEY = "FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m"
AZURE_DEPLOYMENT_NAME = "gpt-4.1-mini"
AZURE_OPENAI_API_VERSION = "2024-12-01-preview"

# Database Configuration
DB_URI = "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
DB_HOST = "voiceassistantpsql.postgres.database.azure.com"
DB_NAME = "voice_assistant_db"
DB_USER = "postgres"
DB_PASSWORD = "voice_password"
DB_PORT = "5432"

# Vector Search Configuration
EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
MMR_FETCH_K = 50   # how many to fetch from pgvector before reranking
MMR_RETURN_K = 3   # how many docs to return after MMR
MMR_LAMBDA = 0.7   # balance between relevance and diversity


# ===============================
# Global Models (initialized once)
# ===============================

# Sentence Transformer for embeddings
model = SentenceTransformer(EMBED_MODEL)

# Azure OpenAI LLM
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    deployment_name=AZURE_DEPLOYMENT_NAME,
    api_version=AZURE_OPENAI_API_VERSION,
    temperature=0
)


# ===============================
# State Definition
# ===============================

class QueryState(TypedDict):
    """State object passed through the LangGraph workflow"""
    query: str
    result: Optional[str]
    context: Optional[str]
    rewritten_query: str
    query_embedding: list
    history: str
    route: str
    next: str  # for router decision
    # Agentic fields
    subqueries: list
    per_sub: list
    combined_context: str
    judge: dict


# ===============================
# Database Utilities
# ===============================

def get_pg_connection():
    """Create PostgreSQL connection"""
    return psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        port=DB_PORT
    )


# ===============================
# Embedding & Retrieval
# ===============================

def embed_with_sentence_transformer(text: str) -> np.ndarray:
    """
    Encode text into embedding vector using SentenceTransformer
    Returns: numpy array (float32)
    """
    vec = model.encode(text, convert_to_numpy=True)
    return np.array(vec, dtype=np.float32)


def mmr_retrieve_from_pgvector(
    query_embedding: np.ndarray,
    fetch_k: int = MMR_FETCH_K,
    top_k: int = MMR_RETURN_K,
    lambda_param: float = MMR_LAMBDA
) -> List[Dict[str, Any]]:
    """
    Maximal Marginal Relevance (MMR) retrieval from pgvector
    
    Args:
        query_embedding: Query vector
        fetch_k: Number of candidates to fetch
        top_k: Final number of documents to return
        lambda_param: Balance between relevance (1.0) and diversity (0.0)
    
    Returns:
        List of documents with id, content, and MMR score
    """
    conn = get_pg_connection()
    cur = conn.cursor()

    # Fetch top candidates using cosine distance
    cur.execute("""
        SELECT id, content, embedding
        FROM powertrain_pdf_docs
        ORDER BY embedding <#> (%s::vector)
        LIMIT %s;
    """, (query_embedding.tolist(), fetch_k))

    rows = cur.fetchall()
    cur.close()
    conn.close()

    if not rows:
        return []

    ids = [r[0] for r in rows]
    contents = [r[1] for r in rows]
    
    # Parse embeddings (handle both string and array formats)
    embs = np.array([
        np.fromstring(r[2].strip("[]"), sep=",", dtype=np.float32)
        if isinstance(r[2], str)
        else np.array(r[2], dtype=np.float32)
        for r in rows
    ], dtype=np.float32)

    # MMR selection
    selected = []
    selected_ids = []
    selected_docs = []

    for _ in range(min(top_k, len(embs))):
        mmr_scores = []
        for i, emb in enumerate(embs):
            if ids[i] in selected_ids:
                mmr_scores.append(-1e9)
                continue
            
            # Calculate relevance score
            relevance = float(np.dot(query_embedding, emb))
            
            # Calculate diversity penalty
            diversity = 0.0 if not selected else float(np.max([np.dot(emb, s) for s in selected]))
            
            # MMR formula
            score = lambda_param * relevance - (1 - lambda_param) * diversity
            mmr_scores.append(score)

        best_idx = int(np.argmax(mmr_scores))
        selected.append(embs[best_idx])
        selected_ids.append(ids[best_idx])
        selected_docs.append({
            "id": ids[best_idx],
            "content": contents[best_idx],
            "score": float(mmr_scores[best_idx])
        })

    return selected_docs


def rewrite_query_with_llm(original_query: str) -> str:
    """
    Use LLM to rewrite user query for better retrieval
    
    Args:
        original_query: Original user question
    
    Returns:
        Rewritten query optimized for vector search
    """
    prompt = f"""Rewrite the user's query to be a concise, clear, and retrieval-optimized search query.
Do NOT answer the user's question — only rewrite it for retrieval.

Original Query:
{original_query}

Rewritten query:"""

    try:
        url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{AZURE_DEPLOYMENT_NAME}/chat/completions?api-version={AZURE_OPENAI_API_VERSION}"
        
        headers = {
            "Content-Type": "application/json",
            "api-key": AZURE_OPENAI_API_KEY
        }
        
        body = {
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0,
            "max_tokens": 200
        }
        
        response = requests.post(url, headers=headers, json=body)
        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"]
    except Exception as e:
        print(f"Query rewrite failed: {e}")
        return original_query


def call_chat(prompt: str, model: str = AZURE_DEPLOYMENT_NAME, max_tokens: int = 300, temperature: float = 0.0) -> str:
    """
    Generic chat completion call to Azure OpenAI
    
    Args:
        prompt: User prompt
        model: Model deployment name
        max_tokens: Maximum tokens in response
        temperature: Sampling temperature
    
    Returns:
        LLM response text
    """
    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{AZURE_DEPLOYMENT_NAME}/chat/completions?api-version={AZURE_OPENAI_API_VERSION}"

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_OPENAI_API_KEY
    }

    body = {
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens
    }

    try:
        response = requests.post(url, headers=headers, json=body)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        return f"LLM call failed: {e}"


# ===============================
# LangGraph Nodes
# ===============================

def router_node(state: QueryState) -> Dict[str, str]:
    """
    Route query to either SQL agent or Vector agent based on query content
    
    Args:
        state: Current graph state
    
    Returns:
        Dict with 'next' key indicating next node
    """
    q = state.get("query", "").lower()
    
    if "work order" in q:
        next_node = "db_agent"
    else:
        next_node = "vector_agent"
    
    return {"next": next_node}


def db_agent(state: QueryState) -> Dict[str, Any]:
    """
    SQL Agent - Handles database queries for work orders
    
    Args:
        state: Current graph state
    
    Returns:
        Dict with query result and updated context
    """
    query = state["query"]
    context = state.get("context", "")
    
    prompt = f"""
    You are an automotive assistant.
    If question involves work order details, use SQL to retrieve them.
    Otherwise, answer naturally.
    Previous context: {context}
    Question: {query}
    """
    
    db = SQLDatabase.from_uri(DB_URI)
    
    sql_agent = create_sql_agent(
        llm=llm,
        db=db,
        verbose=True,
        top_k=5,
        agent_type="openai-tools",
    )

    try:
        result = sql_agent.invoke({"input": prompt})
        result_text = result.get("output", "No output from SQL Agent.")
    except Exception as e:
        result_text = f"Error executing SQL Agent: {e}"

    return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {result_text}",
        "result": result_text
    }


def vector_agent(state: QueryState) -> Dict[str, Any]:
    """
    Vector Agent - Handles semantic search using pgvector
    
    Args:
        state: Current graph state
    
    Returns:
        Dict with query result and retrieved context
    """
    query = state["query"]
    context = state.get("context", "")
    
    try:
        # Step 1: Encode query into vector
        query_vector = model.encode(query)
        query_vector = np.array(query_vector, dtype=np.float32).tolist()

        # Step 2: Retrieve similar content
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT content, 1 - (embedding <=> %s::vector) AS similarity
            FROM powertrain_pdf_docs
            ORDER BY embedding <=> %s::vector
            LIMIT 3;
        """, (query_vector, query_vector))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            return {"result": "⚠️ No similar content found in vector DB."}

        retrieved_context = "\n".join([r[0] for r in rows])

        # Step 3: LLM call with retrieved context
        prompt = f"""
        You are a helpful voice assistant for an automotive technician.
        Use the following context to answer the user's question.
        If there are multiple steps, just give one step and ask the user if they want to proceed for next step.
        If you don't know the answer, politely say so.
        Be brief and clear.
       
        Context:
        {retrieved_context}
        
        Query: {query}
        """
        response = llm.invoke(prompt)
        first_answer = response.content.strip()
        
        return {
            "query": query,
            "context": retrieved_context + f"\nUser: {query}\nAssistant: {first_answer}",
            "result": first_answer
        }

    except Exception as e:
        return {"result": f"⚠️ Vector Agent Error: {e}"}


# ===============================
# Agentic RAG Nodes
# ===============================

def agentic_planner_node(state: QueryState) -> Dict[str, List[str]]:
    """
    Decompose complex question into sub-questions (1-3)
    
    Args:
        state: Current graph state
    
    Returns:
        Dict with 'subqueries' list
    """
    user_q = state.get("query", "")
    
    prompt = f"""
You are a planning assistant. Given the user's question below, decide whether the query should be decomposed into multiple smaller sub-questions for retrieval.
- If simple, return a JSON array with the original question as single element.
- If complex, return a JSON array with 2-3 sub-questions that, when answered and combined, will answer the user's question.

Output ONLY a JSON array of strings (no extra commentary).

User question:
{user_q}
"""
    
    out = call_chat(prompt, max_tokens=300, temperature=0.0)
    
    # Try to parse JSON
    try:
        parsed = json.loads(out)
        if isinstance(parsed, list) and all(isinstance(x, str) for x in parsed):
            return {"subqueries": parsed}
    except Exception:
        # Fallback: split on '?' or take first 3 sentences
        parts = [p.strip() for p in user_q.replace('?', '.').split('.') if p.strip()]
        if len(parts) <= 1:
            return {"subqueries": [user_q]}
        else:
            return {"subqueries": parts[:3]}
    
    # Final fallback
    return {"subqueries": [user_q]}


def agentic_execute_node(state: QueryState) -> Dict[str, Any]:
    """
    For each subquery:
      - Rewrite with LLM
      - Embed with SentenceTransformer
      - Retrieve with MMR
    
    Args:
        state: Current graph state
    
    Returns:
        Dict with 'combined_context' and 'per_sub' retrieval details
    """
    subqueries = state.get("subqueries", [])
    aggregated_contexts = []
    per_sub = []
    
    for sq in subqueries:
        rewritten = rewrite_query_with_llm(sq)
        emb = embed_with_sentence_transformer(rewritten)
        docs = mmr_retrieve_from_pgvector(emb, fetch_k=MMR_FETCH_K, top_k=MMR_RETURN_K, lambda_param=MMR_LAMBDA)
        
        # Build textual context for this subquery
        snippet = "\n\n".join([f"[id:{d['id']}] {d['content']}" for d in docs])
        aggregated_contexts.append(snippet)
        
        per_sub.append({
            "subquery": sq,
            "rewritten": rewritten,
            "retrieved": docs
        })
    
    combined_context = "\n\n".join([c for c in aggregated_contexts if c])
    return {"combined_context": combined_context, "per_sub": per_sub}


def agentic_judge_node(state: QueryState) -> Dict[str, Dict]:
    """
    Judge whether retrieved context sufficiently answers the subqueries
    Provides detailed quality metrics for output validation
    
    Args:
        state: Current graph state
    
    Returns:
        Dict with 'judge' containing:
            - verdict: 'OK', 'NEEDS_MORE', 'PARTIAL'
            - confidence_score: 0.0-1.0
            - coverage_score: 0.0-1.0
            - quality_metrics: detailed breakdown
    """
    sub = state.get("per_sub", [])
    combined_context = state.get("combined_context", "")
    query = state.get("query", "")
    
    # Calculate retrieval metrics
    total_docs = sum(len(item.get("retrieved", [])) for item in sub)
    avg_score = 0.0
    if total_docs > 0:
        all_scores = [doc["score"] for item in sub for doc in item.get("retrieved", [])]
        avg_score = sum(all_scores) / len(all_scores) if all_scores else 0.0
    
    # Build enhanced evaluation prompt
    prompt_parts = [
        "You are a RAG quality evaluator. Assess if the retrieved context can answer the user's query.",
        f"\nOriginal Query: {query}",
        "\n--- RETRIEVED CONTEXT ---"
    ]
    
    for idx, item in enumerate(sub):
        prompt_parts.append(f"\nSubquery {idx+1}: {item['subquery']}")
        prompt_parts.append(f"Rewritten as: {item['rewritten']}")
        if item["retrieved"]:
            prompt_parts.append(f"Retrieved {len(item['retrieved'])} documents:")
            for doc_idx, doc in enumerate(item["retrieved"][:3]):
                preview = doc["content"][:300].replace('\n', ' ')
                prompt_parts.append(f"  Doc {doc_idx+1} (score: {doc['score']:.3f}): {preview}...")
        else:
            prompt_parts.append("(no documents retrieved)")
    
    prompt_parts.append("\n--- EVALUATION INSTRUCTIONS ---")
    prompt_parts.append("Provide a JSON response with:")
    prompt_parts.append('{')
    prompt_parts.append('  "verdict": "OK" | "PARTIAL" | "NEEDS_MORE",')
    prompt_parts.append('  "confidence": 0.0-1.0,  // How confident the context can answer the query')
    prompt_parts.append('  "coverage": 0.0-1.0,    // How much of the query is covered')
    prompt_parts.append('  "relevance": 0.0-1.0,   // How relevant the context is')
    prompt_parts.append('  "completeness": 0.0-1.0, // How complete the information is')
    prompt_parts.append('  "reasoning": "Brief explanation",')
    prompt_parts.append('  "missing_info": "What information is missing (if any)"')
    prompt_parts.append('}')
    
    prompt = "\n".join(prompt_parts)
    
    out = call_chat(prompt, max_tokens=400, temperature=0.0)
    
    # Parse JSON response
    try:
        # Try to extract JSON from response
        json_start = out.find('{')
        json_end = out.rfind('}') + 1
        if json_start >= 0 and json_end > json_start:
            json_str = out[json_start:json_end]
            parsed = json.loads(json_str)
            
            # Ensure all required fields exist
            judge_result = {
                "verdict": parsed.get("verdict", "OK"),
                "confidence_score": float(parsed.get("confidence", 0.5)),
                "coverage_score": float(parsed.get("coverage", 0.5)),
                "relevance_score": float(parsed.get("relevance", 0.5)),
                "completeness_score": float(parsed.get("completeness", 0.5)),
                "reasoning": parsed.get("reasoning", "Context appears sufficient"),
                "missing_info": parsed.get("missing_info", "None"),
                "retrieval_metrics": {
                    "total_documents": total_docs,
                    "avg_retrieval_score": round(avg_score, 3),
                    "subqueries_count": len(sub)
                }
            }
            
            return {"judge": judge_result}
    except Exception as e:
        print(f"Judge parsing error: {e}, raw output: {out[:200]}")
    
    # Fallback heuristic evaluation
    low = out.lower()
    
    # Calculate heuristic confidence based on keywords and retrieval scores
    confidence = 0.5
    if avg_score > 0.7:
        confidence += 0.2
    if total_docs >= len(sub) * 2:  # At least 2 docs per subquery
        confidence += 0.1
    
    # Determine verdict based on keywords
    if "insufficient" in low or "cannot answer" in low or "missing" in low:
        verdict = "NEEDS_MORE"
        confidence = max(0.3, confidence - 0.3)
    elif "partial" in low or "some information" in low:
        verdict = "PARTIAL"
    else:
        verdict = "OK"
    
    judge_result = {
        "verdict": verdict,
        "confidence_score": round(confidence, 2),
        "coverage_score": round(min(avg_score, 1.0), 2),
        "relevance_score": round(avg_score, 2),
        "completeness_score": round(confidence, 2),
        "reasoning": out[:300],
        "missing_info": "Unable to determine",
        "retrieval_metrics": {
            "total_documents": total_docs,
            "avg_retrieval_score": round(avg_score, 3),
            "subqueries_count": len(sub)
        },
        "note": "Fallback heuristic evaluation used"
    }
    
    return {"judge": judge_result}


def agentic_synthesizer_node(state: QueryState) -> Dict[str, str]:
    """
    Synthesize final answer from combined context and original query
    Includes answer validation and source citations
    
    Args:
        state: Current graph state
    
    Returns:
        Dict with 'result', 'context', and 'answer_validation'
    """
    combined_context = state.get("combined_context", "")
    user_q = state.get("query", "")
    judge = state.get("judge", {})
    per_sub = state.get("per_sub", [])
    
    # Get all document IDs for citation
    all_doc_ids = set()
    for item in per_sub:
        for doc in item.get("retrieved", []):
            all_doc_ids.add(doc["id"])
    
    prompt = f"""
You are a helpful automotive technical assistant. Use ONLY the context below to answer the user's question.

IMPORTANT RULES:
1. Base your answer ONLY on the provided context
2. If information is missing or unclear, explicitly state this
3. Cite sources using [id:X] format
4. Be specific and technical when needed
5. If you cannot answer confidently, say so and explain why

Context:
{combined_context}

User question:
{user_q}

Provide a clear, accurate answer with source citations [id:X]. If the answer is incomplete or uncertain, mention what additional information would be needed.
"""
    
    out = call_chat(prompt, max_tokens=512, temperature=0.0)
    
    # Validate the answer
    answer_validation = validate_answer(out, combined_context, user_q, judge)
    
    return {
        "result": out, 
        "context": combined_context,
        "answer_validation": answer_validation
    }


def validate_answer(answer: str, context: str, query: str, judge: Dict) -> Dict:
    """
    Validate the synthesized answer quality
    
    Args:
        answer: Generated answer
        context: Retrieved context
        query: Original query
        judge: Judge verdict from earlier stage
    
    Returns:
        Dict with validation metrics
    """
    # Extract citations from answer
    import re
    citations = re.findall(r'\[id:(\d+)\]', answer)
    citation_count = len(set(citations))
    
    # Check for uncertainty markers
    uncertainty_markers = [
        "i don't know", "not sure", "unclear", "cannot determine",
        "insufficient information", "would need", "additional information"
    ]
    has_uncertainty = any(marker in answer.lower() for marker in uncertainty_markers)
    
    # Calculate answer metrics
    answer_length = len(answer.split())
    context_length = len(context.split())
    
    # Check if answer addresses the query
    query_words = set(query.lower().split())
    answer_words = set(answer.lower().split())
    query_coverage = len(query_words.intersection(answer_words)) / len(query_words) if query_words else 0
    
    # Determine overall quality
    judge_confidence = judge.get("confidence_score", 0.5)
    
    if citation_count == 0:
        quality = "LOW - No citations"
        confidence = max(0.2, judge_confidence - 0.3)
    elif has_uncertainty:
        quality = "MEDIUM - Contains uncertainty"
        confidence = max(0.4, judge_confidence - 0.2)
    elif citation_count >= 2 and query_coverage > 0.5:
        quality = "HIGH - Well-cited and comprehensive"
        confidence = min(0.95, judge_confidence + 0.1)
    else:
        quality = "MEDIUM - Adequate"
        confidence = judge_confidence
    
    return {
        "quality": quality,
        "confidence": round(confidence, 2),
        "citation_count": citation_count,
        "cited_documents": list(set(citations)),
        "has_uncertainty": has_uncertainty,
        "answer_length_words": answer_length,
        "query_coverage": round(query_coverage, 2),
        "validation_passed": confidence >= 0.6,
        "recommendation": get_recommendation(confidence, has_uncertainty, citation_count)
    }


def get_recommendation(confidence: float, has_uncertainty: bool, citation_count: int) -> str:
    """
    Provide recommendation based on validation metrics
    
    Args:
        confidence: Confidence score
        has_uncertainty: Whether answer contains uncertainty
        citation_count: Number of citations
    
    Returns:
        Recommendation string
    """
    if confidence >= 0.8 and citation_count >= 2:
        return "✅ Answer is reliable and well-supported. Safe to use."
    elif confidence >= 0.6:
        return "⚠️ Answer is adequate but may benefit from verification."
    elif has_uncertainty:
        return "⚠️ Answer explicitly mentions missing information. Consider additional sources."
    elif citation_count == 0:
        return "❌ No citations found. Answer may not be grounded in retrieved context."
    else:
        return "❌ Low confidence answer. Recommend manual review or additional research."


# ===============================
# Additional Query Processing Nodes
# ===============================

def query_rewrite_node(state: QueryState) -> Dict[str, str]:
    """Rewrite query for better retrieval"""
    orig = state.get("query", "")
    rewritten = rewrite_query_with_llm(orig)
    return {"rewritten_query": rewritten}


def embed_rewritten_node(state: QueryState) -> Dict[str, list]:
    """Embed the rewritten query"""
    rewritten = state.get("rewritten_query", "")
    vec = embed_with_sentence_transformer(rewritten)
    return {"query_embedding": vec.tolist()}


def mmr_retrieve_node(state: QueryState) -> Dict[str, str]:
    """Retrieve documents using MMR"""
    qemb_list = state.get("query_embedding", None)
    if qemb_list is None:
        return {"context": ""}
    
    qemb = np.array(qemb_list, dtype=np.float32)
    docs = mmr_retrieve_from_pgvector(qemb, fetch_k=MMR_FETCH_K, top_k=MMR_RETURN_K, lambda_param=MMR_LAMBDA)
    context = "\n\n".join([f"[id:{d['id']}] {d['content']}" for d in docs])
    return {"context": context}


# ===============================
# LangGraph Workflow Setup
# ===============================

def build_agentic_rag_graph():
    """
    Build and compile the LangGraph workflow
    
    Returns:
        Compiled LangGraph app with checkpointer
    """
    graph = StateGraph(QueryState)
    
    # Add all nodes
    graph.add_node("router", router_node)
    graph.add_node("db_agent", db_agent)
    graph.add_node("vector_agent", vector_agent)
    
    # Agentic RAG nodes (Vector path)
    graph.add_node("agentic_planner", agentic_planner_node)
    graph.add_node("agentic_execute", agentic_execute_node)
    graph.add_node("agentic_judge", agentic_judge_node)
    graph.add_node("agentic_synthesizer", agentic_synthesizer_node)
    
    # Query processing nodes
    graph.add_node("rewrite_query", query_rewrite_node)
    graph.add_node("embed_rewritten", embed_rewritten_node)
    graph.add_node("mmr_retrieve", mmr_retrieve_node)
    
    # Set up edges
    graph.add_conditional_edges(
        "router",
        lambda state: state["next"],
        {
            "db_agent": "db_agent",
            "vector_agent": "agentic_planner"
        }
    )
    
    # Vector pipeline edges
    graph.add_edge("rewrite_query", "embed_rewritten")
    graph.add_edge("embed_rewritten", "mmr_retrieve")
    graph.add_edge("mmr_retrieve", "vector_agent")
    
    # Agentic RAG flow (Vector path)
    graph.add_edge("agentic_planner", "agentic_execute")
    graph.add_edge("agentic_execute", "agentic_judge")
    graph.add_edge("agentic_judge", "agentic_synthesizer")
    graph.add_edge("agentic_synthesizer", END)
    
    # Final edges to END
    graph.add_edge("db_agent", END)
    graph.add_edge("vector_agent", END)
    
    # Set entry point
    graph.set_entry_point("router")
    
    # Compile with memory checkpointer
    checkpointer = MemorySaver()
    app = graph.compile(checkpointer=checkpointer)
    
    return app, checkpointer


# ===============================
# Main Query Processing Function
# ===============================

def process_agentic_query(query: str, conversation_history: str = "", thread_id: str = "1") -> Dict[str, Any]:
    """
    Main function to process queries through the Agentic RAG pipeline
    
    Args:
        query: User's question
        conversation_history: Previous conversation context
        thread_id: Thread ID for maintaining conversation state
    
    Returns:
        Dict containing:
            - result: Final answer
            - context: Retrieved context used
            - per_sub: Per-subquery retrieval details (if agentic path)
            - judge: Judge verdict with quality metrics (if agentic path)
            - answer_validation: Answer quality validation
            - route: Which agent was used (db_agent or vector_agent)
    """
    # Build graph
    app, checkpointer = build_agentic_rag_graph()
    
    # Configuration with thread ID for conversation memory
    config = {"configurable": {"thread_id": thread_id}}
    
    # Prepare input state
    invocation_input = {
        "query": query,
        "history": conversation_history
    }
    
    # Execute graph
    try:
        output = app.invoke(invocation_input, config=config)
        
        # Extract results
        result = output.get("result") or output.get("answer", "⚠️ No result.")
        context = output.get("context", "")
        per_sub = output.get("per_sub", [])
        judge = output.get("judge", {})
        answer_validation = output.get("answer_validation", {})
        route = output.get("next", "unknown")
        
        # Calculate overall quality score
        judge_confidence = judge.get("confidence_score", 0.5) if judge else 0.5
        answer_confidence = answer_validation.get("confidence", 0.5) if answer_validation else 0.5
        overall_confidence = round((judge_confidence + answer_confidence) / 2, 2)
        
        return {
            "success": True,
            "result": result,
            "context": context,
            "per_sub": per_sub,
            "judge": judge,
            "answer_validation": answer_validation,
            "overall_confidence": overall_confidence,
            "validation_passed": overall_confidence >= 0.6,
            "route": route,
            "query": query
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "result": f"⚠️ Error processing query: {e}",
            "query": query,
            "validation_passed": False
        }
