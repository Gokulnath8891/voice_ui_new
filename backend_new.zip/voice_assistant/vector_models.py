from django.db import models
from pgvector.django import VectorField
import uuid


class DocumentCollection(models.Model):
    """Collection of documents for vector search"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    embedding_model = models.CharField(max_length=100, default='thenlper/gte-large')
    embedding_dimension = models.IntegerField(default=1024)  # gte-large dimension
    total_documents = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'document_collections'
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['is_active']),
        ]
    
    def __str__(self):
        return f"Collection: {self.name} ({self.total_documents} docs)"


class DocumentChunk(models.Model):
    """Individual document chunks with vector embeddings"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    collection = models.ForeignKey(DocumentCollection, on_delete=models.CASCADE, related_name='chunks')
    content = models.TextField()
    metadata = models.JSONField(default=dict, blank=True)
    source = models.CharField(max_length=500, blank=True)
    source_type = models.CharField(max_length=50, blank=True)  # pdf, txt, web, etc.
    chunk_index = models.IntegerField(default=0)  # Position in original document
    
    # Vector embedding field (1024 dimensions for gte-large)
    embedding = VectorField(dimensions=1024)
    
    # Metadata fields for better searching
    word_count = models.IntegerField(default=0)
    character_count = models.IntegerField(default=0)
    language = models.CharField(max_length=10, default='en')
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'document_chunks'
        indexes = [
            models.Index(fields=['collection', 'source']),
            models.Index(fields=['collection', 'source_type']),
            models.Index(fields=['created_at']),
            # Vector similarity index will be created via SQL
        ]
    
    def __str__(self):
        content_preview = self.content[:100] + '...' if len(self.content) > 100 else self.content
        return f"Chunk {self.chunk_index}: {content_preview}"
    
    def save(self, *args, **kwargs):
        # Update word and character counts
        if self.content:
            self.word_count = len(self.content.split())
            self.character_count = len(self.content)
        super().save(*args, **kwargs)


class SearchQuery(models.Model):
    """Log search queries for analytics and caching"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    collection = models.ForeignKey(DocumentCollection, on_delete=models.CASCADE, related_name='queries')
    query_text = models.TextField()
    query_embedding = VectorField(dimensions=1024)
    
    # Search parameters
    similarity_threshold = models.FloatField(default=0.7)
    max_results = models.IntegerField(default=5)
    
    # Results metadata
    results_count = models.IntegerField(default=0)
    highest_similarity = models.FloatField(null=True, blank=True)
    lowest_similarity = models.FloatField(null=True, blank=True)
    
    # Performance tracking
    search_time_ms = models.IntegerField(null=True, blank=True)
    embedding_time_ms = models.IntegerField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'search_queries'
        indexes = [
            models.Index(fields=['collection', 'created_at']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        query_preview = self.query_text[:50] + '...' if len(self.query_text) > 50 else self.query_text
        return f"Query: {query_preview}"


class SearchResult(models.Model):
    """Individual search results for a query"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    search_query = models.ForeignKey(SearchQuery, on_delete=models.CASCADE, related_name='results')
    document_chunk = models.ForeignKey(DocumentChunk, on_delete=models.CASCADE)
    similarity_score = models.FloatField()
    rank = models.IntegerField()  # Ranking in the result set
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'search_results'
        unique_together = ['search_query', 'document_chunk']
        indexes = [
            models.Index(fields=['search_query', 'rank']),
            models.Index(fields=['similarity_score']),
        ]
        ordering = ['rank']
    
    def __str__(self):
        return f"Result {self.rank}: {self.similarity_score:.3f} similarity"


class VectorSearchCache(models.Model):
    """Cache frequent search results"""
    query_hash = models.CharField(max_length=64, unique=True)  # SHA-256 hash of query + params
    collection = models.ForeignKey(DocumentCollection, on_delete=models.CASCADE)
    query_text = models.TextField()
    
    # Cache metadata
    cached_results = models.JSONField()  # Serialized search results
    results_count = models.IntegerField()
    cache_hits = models.IntegerField(default=0)
    
    # Cache management
    created_at = models.DateTimeField(auto_now_add=True)
    last_accessed = models.DateTimeField(auto_now=True)
    expires_at = models.DateTimeField()
    
    class Meta:
        db_table = 'vector_search_cache'
        indexes = [
            models.Index(fields=['query_hash']),
            models.Index(fields=['collection', 'last_accessed']),
            models.Index(fields=['expires_at']),
        ]
    
    def __str__(self):
        return f"Cache: {self.query_text[:50]}... ({self.cache_hits} hits)"


class VectorIndexStatus(models.Model):
    """Track vector index status and maintenance"""
    collection = models.OneToOneField(DocumentCollection, on_delete=models.CASCADE, related_name='index_status')
    
    # Index statistics
    total_vectors = models.IntegerField(default=0)
    index_size_mb = models.FloatField(default=0.0)
    
    # Index performance metrics
    average_search_time_ms = models.FloatField(default=0.0)
    last_rebuild_at = models.DateTimeField(null=True, blank=True)
    rebuild_in_progress = models.BooleanField(default=False)
    
    # Index health
    is_healthy = models.BooleanField(default=True)
    health_check_at = models.DateTimeField(auto_now=True)
    health_message = models.TextField(blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'vector_index_status'
    
    def __str__(self):
        return f"Index Status: {self.collection.name} - {'Healthy' if self.is_healthy else 'Issues'}"