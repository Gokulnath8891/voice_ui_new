import logging
from datetime import datetime, timedelta
from django.utils import timezone
from django.conf import settings
from django.contrib.auth.models import AnonymousUser
from .models import APIUsageLog

logger = logging.getLogger(__name__)


def get_client_ip(request):
    """Get client IP address from request"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


def log_api_usage(request, endpoint, status_code, processing_time_ms):
    """Log API usage for analytics and monitoring"""
    try:
        client_ip = get_client_ip(request)
        user = request.user if not isinstance(request.user, AnonymousUser) else None
        
        # Calculate request/response sizes (approximate)
        request_size = len(str(request.body)) if hasattr(request, 'body') else 0
        
        APIUsageLog.objects.create(
            user=user,
            ip_address=client_ip,
            endpoint=endpoint,
            method=request.method,
            status_code=status_code,
            processing_time_ms=processing_time_ms,
            request_size_bytes=request_size,
            response_size_bytes=None,  # Could be calculated if needed
            user_agent=request.META.get('HTTP_USER_AGENT', '')[:500]
        )
    except Exception as e:
        logger.error(f"Failed to log API usage: {str(e)}")


def check_rate_limit(user, client_ip, limit_per_hour=None):
    """Check if user/IP has exceeded rate limit"""
    try:
        if limit_per_hour is None:
            limit_per_hour = getattr(settings, 'RATE_LIMIT_PER_HOUR', 100)
        
        # Check rate limit for the past hour
        one_hour_ago = timezone.now() - timedelta(hours=1)
        
        if user and not isinstance(user, AnonymousUser):
            # Check rate limit for authenticated user
            recent_requests = APIUsageLog.objects.filter(
                user=user,
                created_at__gte=one_hour_ago
            ).count()
        else:
            # Check rate limit for IP address
            recent_requests = APIUsageLog.objects.filter(
                ip_address=client_ip,
                created_at__gte=one_hour_ago,
                user__isnull=True
            ).count()
        
        return recent_requests < limit_per_hour
    
    except Exception as e:
        logger.error(f"Rate limit check failed: {str(e)}")
        # Fail open - allow request if rate limit check fails
        return True


def cleanup_old_logs(days_to_keep=30):
    """Clean up old API usage logs"""
    try:
        cutoff_date = timezone.now() - timedelta(days=days_to_keep)
        deleted_count = APIUsageLog.objects.filter(created_at__lt=cutoff_date).delete()[0]
        logger.info(f"Cleaned up {deleted_count} old API usage logs")
        return deleted_count
    except Exception as e:
        logger.error(f"Failed to clean up old logs: {str(e)}")
        return 0


def validate_audio_file(audio_file):
    """Validate uploaded audio file"""
    max_size = getattr(settings, 'MAX_AUDIO_FILE_SIZE', 50 * 1024 * 1024)  # 50MB
    allowed_types = ['audio/wav', 'audio/mpeg', 'audio/mp3', 'audio/m4a', 'audio/ogg']
    
    # Check file size
    if audio_file.size > max_size:
        raise ValueError(f"Audio file too large. Maximum size is {max_size // (1024*1024)}MB")
    
    # Check content type
    if audio_file.content_type not in allowed_types:
        raise ValueError(f"Unsupported audio format. Allowed types: {', '.join(allowed_types)}")
    
    return True


def validate_text_length(text, max_length=5000):
    """Validate text length for TTS"""
    if len(text) > max_length:
        raise ValueError(f"Text too long. Maximum length is {max_length} characters")
    
    word_count = len(text.split())
    if word_count > 1000:
        raise ValueError("Text too long. Maximum 1000 words allowed")
    
    return True


def format_error_response(message, details=None, status_code=500):
    """Format standardized error response"""
    response_data = {
        'status': 'error',
        'message': message,
        'timestamp': timezone.now().isoformat()
    }
    
    if details:
        response_data['details'] = details
    
    return response_data


def sanitize_query(query):
    """Sanitize search query input"""
    if not query or not isinstance(query, str):
        raise ValueError("Query must be a non-empty string")
    
    # Remove excessive whitespace
    query = ' '.join(query.split())
    
    # Basic length validation
    if len(query) < 3:
        raise ValueError("Query must be at least 3 characters long")
    
    if len(query) > 1000:
        raise ValueError("Query too long. Maximum 1000 characters allowed")
    
    return query


def get_session_or_create(request, session_id=None):
    """Get existing session or create new one"""
    from .models import VoiceSession
    
    if session_id:
        try:
            session = VoiceSession.objects.get(session_id=session_id)
            return session
        except VoiceSession.DoesNotExist:
            pass
    
    # Create new session
    return VoiceSession.objects.create(
        user=request.user if not isinstance(request.user, AnonymousUser) else None
    )


def calculate_audio_duration(audio_file_path):
    """Calculate audio duration (basic estimation)"""
    try:
        import os
        import wave
        
        if os.path.exists(audio_file_path) and audio_file_path.endswith('.wav'):
            with wave.open(audio_file_path, 'r') as wav_file:
                frames = wav_file.getnframes()
                sample_rate = wav_file.getframerate()
                duration = frames / float(sample_rate)
                return duration
    except Exception as e:
        logger.warning(f"Could not calculate audio duration: {str(e)}")
    
    return None


def estimate_processing_time(text_length, operation_type='tts'):
    """Estimate processing time for different operations"""
    base_times = {
        'speech_recognition': 100,  # ms per second of audio (rough estimate)
        'semantic_search': 500,     # ms base time for search
        'tts': 50,                  # ms per word
        'summarization': 1000       # ms base time for summarization
    }
    
    if operation_type == 'tts':
        # Estimate based on word count
        word_count = len(text_length.split()) if isinstance(text_length, str) else text_length
        return base_times['tts'] * word_count
    
    return base_times.get(operation_type, 1000)


def is_service_healthy(service_name):
    """Check if a specific service is healthy"""
    try:
        if service_name == 'speech':
            from .services import get_speech_service
            get_speech_service()
            return True
        elif service_name == 'search':
            from .services import get_search_service
            get_search_service()
            return True
        elif service_name == 'tts':
            from .services import get_tts_service
            get_tts_service()
            return True
    except Exception as e:
        logger.error(f"Service {service_name} health check failed: {str(e)}")
        return False
    
    return False


def get_service_configuration():
    """Get current service configuration status"""
    config_status = {
        'azure_speech': {
            'configured': bool(settings.AZURE_SPEECH_KEY and settings.AZURE_SPEECH_REGION),
            'key_present': bool(settings.AZURE_SPEECH_KEY),
            'region_set': bool(settings.AZURE_SPEECH_REGION)
        },
        'azure_openai': {
            'configured': bool(settings.AZURE_OPENAI_KEY and settings.AZURE_OPENAI_ENDPOINT),
            'key_present': bool(settings.AZURE_OPENAI_KEY),
            'endpoint_set': bool(settings.AZURE_OPENAI_ENDPOINT),
            'deployment_name': settings.AZURE_OPENAI_DEPLOYMENT_NAME
        },
        'vector_store': {
            'configured': bool(settings.VECTOR_STORE_PATH and settings.VECTOR_COLLECTION_NAME),
            'path_set': bool(settings.VECTOR_STORE_PATH),
            'collection_name': settings.VECTOR_COLLECTION_NAME
        }
    }
    
    return config_status