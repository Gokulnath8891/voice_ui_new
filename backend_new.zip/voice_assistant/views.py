import os
import time
import tempfile
import logging
from datetime import datetime, timedelta
from django.http import HttpResponse, Http404, FileResponse
from django.utils import timezone
from django.db.models import Count, Avg
from django.core.exceptions import ValidationError
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status, permissions
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth.models import AnonymousUser

from .models import (
    VoiceSession, SpeechRecognitionRequest, SemanticSearchRequest,
    RelevantChunk, TextToSpeechRequest, APIUsageLog
)
from .serializers import (
    VoiceSessionSerializer, SpeechRecognitionInputSerializer,
    SpeechRecognitionOutputSerializer, SemanticSearchInputSerializer,
    SemanticSearchOutputSerializer, TextToSpeechInputSerializer,
    SessionResponseSerializer, VoiceAssistantStatsSerializer
)
from .services import get_speech_service, get_search_service, get_tts_service
from .utils import log_api_usage, get_client_ip, check_rate_limit

logger = logging.getLogger(__name__)


class CreateVoiceSessionView(APIView):
    """Create a new voice assistant session"""
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        try:
            # Create new session
            session = VoiceSession.objects.create(
                user=request.user if not isinstance(request.user, AnonymousUser) else None
            )
            
            serializer = SessionResponseSerializer({
                'session_id': session.session_id,
                'created_at': session.created_at,
            })
            
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        except Exception as e:
            logger.error(f"Session creation error: {str(e)}")
            return Response({
                'status': 'error',
                'message': 'Failed to create session',
                'details': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class SpeechRecognitionView(APIView):
    """Speech Recognition API - Convert audio to text"""
    permission_classes = [permissions.AllowAny]
    parser_classes = [MultiPartParser, FormParser]
    
    def post(self, request):
        start_time = time.time()
        client_ip = get_client_ip(request)
        
        # Check rate limiting
        if not check_rate_limit(request.user, client_ip):
            return Response({
                'status': 'error',
                'message': 'Rate limit exceeded. Try again later.'
            }, status=status.HTTP_429_TOO_MANY_REQUESTS)
        
        # Validate input
        input_serializer = SpeechRecognitionInputSerializer(data=request.data)
        if not input_serializer.is_valid():
            return Response({
                'status': 'error',
                'message': 'Invalid input',
                'details': input_serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
        
        audio_file = input_serializer.validated_data['audio_file']
        
        # Get or create session
        session_id = request.data.get('session_id')
        if session_id:
            try:
                session = VoiceSession.objects.get(session_id=session_id)
            except VoiceSession.DoesNotExist:
                session = VoiceSession.objects.create(
                    user=request.user if not isinstance(request.user, AnonymousUser) else None
                )
        else:
            session = VoiceSession.objects.create(
                user=request.user if not isinstance(request.user, AnonymousUser) else None
            )
        
        # Create speech recognition request record
        speech_request = SpeechRecognitionRequest.objects.create(
            session=session,
            audio_file_name=audio_file.name,
            audio_format=audio_file.content_type,
            audio_duration=None,  # Will be updated after processing
            status='PROCESSING'
        )
        
        try:
            # Process speech recognition
            speech_service = get_speech_service()
            result = speech_service.recognize_from_file(audio_file)
            
            # Update speech request record
            speech_request.recognized_text = result.get('recognized_text')
            speech_request.confidence_score = result.get('confidence_score')
            speech_request.processing_time_ms = result.get('processing_time_ms')
            speech_request.status = 'SUCCESS' if result.get('status') == 'success' else 'FAILED'
            speech_request.error_message = result.get('error')
            speech_request.save()
            
            # Update session
            session.total_requests += 1
            session.save()
            
            # Prepare response
            response_data = {
                'status': result.get('status'),
                'recognized_text': result.get('recognized_text'),
                'confidence_score': result.get('confidence_score'),
                'processing_time_ms': result.get('processing_time_ms'),
                'session_id': str(session.session_id)
            }
            
            if result.get('status') != 'success':
                response_data['error'] = result.get('error')
            
            # Log API usage
            processing_time = int((time.time() - start_time) * 1000)
            log_api_usage(
                request, '/api/v1/speech/recognize', 
                status.HTTP_200_OK, processing_time
            )
            
            return Response(response_data, status=status.HTTP_200_OK)
        
        except Exception as e:
            # Update speech request record
            speech_request.status = 'FAILED'
            speech_request.error_message = str(e)
            speech_request.save()
            
            logger.error(f"Speech recognition error: {str(e)}")
            
            # Log API usage
            processing_time = int((time.time() - start_time) * 1000)
            log_api_usage(
                request, '/api/v1/speech/recognize',
                status.HTTP_500_INTERNAL_SERVER_ERROR, processing_time
            )
            
            return Response({
                'status': 'error',
                'message': 'Speech recognition failed',
                'details': str(e),
                'session_id': str(session.session_id)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class SemanticSearchView(APIView):
    """Semantic Search API - Search and summarize"""
    permission_classes = [permissions.AllowAny]
    parser_classes = [JSONParser]
    
    def post(self, request):
        start_time = time.time()
        client_ip = get_client_ip(request)
        
        # Check rate limiting
        if not check_rate_limit(request.user, client_ip):
            return Response({
                'status': 'error',
                'message': 'Rate limit exceeded. Try again later.'
            }, status=status.HTTP_429_TOO_MANY_REQUESTS)
        
        # Validate input
        input_serializer = SemanticSearchInputSerializer(data=request.data)
        if not input_serializer.is_valid():
            return Response({
                'status': 'error',
                'message': 'Invalid input',
                'details': input_serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
        
        validated_data = input_serializer.validated_data
        
        # Get or create session
        session_id = request.data.get('session_id')
        if session_id:
            try:
                session = VoiceSession.objects.get(session_id=session_id)
            except VoiceSession.DoesNotExist:
                session = VoiceSession.objects.create(
                    user=request.user if not isinstance(request.user, AnonymousUser) else None
                )
        else:
            session = VoiceSession.objects.create(
                user=request.user if not isinstance(request.user, AnonymousUser) else None
            )
        
        # Create search request record
        search_request = SemanticSearchRequest.objects.create(
            session=session,
            query_text=validated_data['query'],
            max_chunks=validated_data['max_chunks'],
            similarity_threshold=validated_data['similarity_threshold'],
            status='PROCESSING'
        )
        
        try:
            # Process semantic search
            search_service = get_search_service()
            result = search_service.search_and_summarize(
                query=validated_data['query'],
                max_chunks=validated_data['max_chunks'],
                similarity_threshold=validated_data['similarity_threshold']
            )
            
            # Update search request record
            search_request.summary_text = result.get('summary')
            search_request.chunks_found = len(result.get('relevant_chunks', []))
            search_request.processing_time_ms = result.get('processing_time_ms')
            search_request.status = 'SUCCESS' if result.get('status') == 'success' else 'FAILED'
            search_request.error_message = result.get('error')
            search_request.save()
            
            # Save relevant chunks
            if result.get('relevant_chunks'):
                for rank, chunk in enumerate(result['relevant_chunks']):
                    RelevantChunk.objects.create(
                        search_request=search_request,
                        content=chunk['content'],
                        similarity_score=chunk['similarity_score'],
                        source=chunk.get('source', 'unknown'),
                        rank=rank + 1
                    )
            
            # Update session
            session.total_requests += 1
            session.save()
            
            # Prepare response
            response_data = {
                'status': result.get('status'),
                'query': result.get('query'),
                'summary': result.get('summary'),
                'relevant_chunks': result.get('relevant_chunks', []),
                'processing_time_ms': result.get('processing_time_ms'),
                'session_id': str(session.session_id)
            }
            
            if result.get('status') != 'success':
                response_data['error'] = result.get('error')
            
            # Log API usage
            processing_time = int((time.time() - start_time) * 1000)
            log_api_usage(
                request, '/api/v1/search/query',
                status.HTTP_200_OK, processing_time
            )
            
            return Response(response_data, status=status.HTTP_200_OK)
        
        except Exception as e:
            # Update search request record
            search_request.status = 'FAILED'
            search_request.error_message = str(e)
            search_request.save()
            
            logger.error(f"Semantic search error: {str(e)}")
            
            # Log API usage
            processing_time = int((time.time() - start_time) * 1000)
            log_api_usage(
                request, '/api/v1/search/query',
                status.HTTP_500_INTERNAL_SERVER_ERROR, processing_time
            )
            
            return Response({
                'status': 'error',
                'message': 'Semantic search failed',
                'details': str(e),
                'session_id': str(session.session_id)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class TextToSpeechView(APIView):
    """Text-to-Speech API - Convert text to audio"""
    permission_classes = [permissions.AllowAny]
    parser_classes = [JSONParser]
    
    def post(self, request):
        start_time = time.time()
        client_ip = get_client_ip(request)
        
        # Check rate limiting
        if not check_rate_limit(request.user, client_ip):
            return Response({
                'status': 'error',
                'message': 'Rate limit exceeded. Try again later.'
            }, status=status.HTTP_429_TOO_MANY_REQUESTS)
        
        # Validate input
        input_serializer = TextToSpeechInputSerializer(data=request.data)
        if not input_serializer.is_valid():
            return Response({
                'status': 'error',
                'message': 'Invalid input',
                'details': input_serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
        
        validated_data = input_serializer.validated_data
        text = validated_data['text']
        voice_settings = validated_data.get('voice_settings', {})
        
        # Get or create session
        session_id = request.data.get('session_id')
        if session_id:
            try:
                session = VoiceSession.objects.get(session_id=session_id)
            except VoiceSession.DoesNotExist:
                session = VoiceSession.objects.create(
                    user=request.user if not isinstance(request.user, AnonymousUser) else None
                )
        else:
            session = VoiceSession.objects.create(
                user=request.user if not isinstance(request.user, AnonymousUser) else None
            )
        
        # Create TTS request record
        tts_request = TextToSpeechRequest.objects.create(
            session=session,
            input_text=text,
            text_length=len(text),
            voice_rate=voice_settings.get('rate', 150),
            voice_volume=voice_settings.get('volume', 0.8),
            voice_name=voice_settings.get('voice', 'default'),
            status='PROCESSING'
        )
        
        try:
            # Process text-to-speech
            tts_service = get_tts_service()
            result = tts_service.synthesize_speech(text, voice_settings)
            
            # Update TTS request record
            tts_request.audio_file_path = result.get('audio_file_path')
            tts_request.audio_duration = result.get('estimated_duration')
            tts_request.processing_time_ms = result.get('processing_time_ms')
            tts_request.status = 'SUCCESS' if result.get('status') == 'success' else 'FAILED'
            tts_request.error_message = result.get('error')
            tts_request.save()
            
            # Update session
            session.total_requests += 1
            session.save()
            
            if result.get('status') == 'success':
                # Return audio file as streaming response
                audio_file_path = result['audio_file_path']
                
                if os.path.exists(audio_file_path):
                    # Log API usage
                    processing_time = int((time.time() - start_time) * 1000)
                    log_api_usage(
                        request, '/api/v1/speech/synthesize',
                        status.HTTP_200_OK, processing_time
                    )
                    
                    # Return file response
                    response = FileResponse(
                        open(audio_file_path, 'rb'),
                        content_type='audio/wav',
                        as_attachment=False
                    )
                    response['X-Session-ID'] = str(session.session_id)
                    response['X-Processing-Time'] = str(result.get('processing_time_ms'))
                    
                    # Schedule cleanup of temporary file
                    # TODO: Implement background task to clean up temp files
                    
                    return response
                else:
                    raise FileNotFoundError("Generated audio file not found")
            else:
                return Response({
                    'status': 'error',
                    'message': 'Text-to-speech conversion failed',
                    'details': result.get('error'),
                    'session_id': str(session.session_id)
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        except Exception as e:
            # Update TTS request record
            tts_request.status = 'FAILED'
            tts_request.error_message = str(e)
            tts_request.save()
            
            logger.error(f"TTS error: {str(e)}")
            
            # Log API usage
            processing_time = int((time.time() - start_time) * 1000)
            log_api_usage(
                request, '/api/v1/speech/synthesize',
                status.HTTP_500_INTERNAL_SERVER_ERROR, processing_time
            )
            
            return Response({
                'status': 'error',
                'message': 'Text-to-speech conversion failed',
                'details': str(e),
                'session_id': str(session.session_id)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class VoiceAssistantStatsView(APIView):
    """Get voice assistant usage statistics"""
    permission_classes = [permissions.AllowAny]
    
    def get(self, request):
        try:
            # Calculate statistics
            total_sessions = VoiceSession.objects.count()
            total_speech_requests = SpeechRecognitionRequest.objects.count()
            total_search_requests = SemanticSearchRequest.objects.count()
            total_tts_requests = TextToSpeechRequest.objects.count()
            
            # Average processing times
            avg_processing_times = []
            
            for model in [SpeechRecognitionRequest, SemanticSearchRequest, TextToSpeechRequest]:
                avg_time = model.objects.filter(
                    status='SUCCESS',
                    processing_time_ms__isnull=False
                ).aggregate(avg_time=Avg('processing_time_ms'))
                if avg_time['avg_time']:
                    avg_processing_times.append(avg_time['avg_time'])
            
            average_processing_time = sum(avg_processing_times) / len(avg_processing_times) if avg_processing_times else 0
            
            # Success rate calculation
            total_requests = total_speech_requests + total_search_requests + total_tts_requests
            successful_requests = (
                SpeechRecognitionRequest.objects.filter(status='SUCCESS').count() +
                SemanticSearchRequest.objects.filter(status='SUCCESS').count() +
                TextToSpeechRequest.objects.filter(status='SUCCESS').count()
            )
            
            success_rate = (successful_requests / total_requests * 100) if total_requests > 0 else 0
            
            # Most common queries (top 10)
            common_queries = SemanticSearchRequest.objects.values('query_text').annotate(
                count=Count('query_text')
            ).order_by('-count')[:10]
            
            most_common_queries = [item['query_text'][:100] for item in common_queries]
            
            stats_data = {
                'total_sessions': total_sessions,
                'total_speech_requests': total_speech_requests,
                'total_search_requests': total_search_requests,
                'total_tts_requests': total_tts_requests,
                'average_processing_time_ms': round(average_processing_time, 2),
                'success_rate': round(success_rate, 2),
                'most_common_queries': most_common_queries
            }
            
            serializer = VoiceAssistantStatsSerializer(stats_data)
            return Response(serializer.data, status=status.HTTP_200_OK)
        
        except Exception as e:
            logger.error(f"Stats error: {str(e)}")
            return Response({
                'status': 'error',
                'message': 'Failed to retrieve statistics',
                'details': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET'])
@permission_classes([permissions.AllowAny])
def health_check(request):
    """Health check endpoint for voice assistant services"""
    try:
        # Check database connectivity
        VoiceSession.objects.count()
        
        # Check service availability (basic imports)
        service_status = {
            'database': 'healthy',
            'speech_service': 'unknown',
            'search_service': 'unknown',
            'tts_service': 'unknown'
        }
        
        # Try to initialize services
        try:
            get_speech_service()
            service_status['speech_service'] = 'healthy'
        except Exception as e:
            service_status['speech_service'] = f'error: {str(e)}'
        
        try:
            get_search_service()
            service_status['search_service'] = 'healthy'
        except Exception as e:
            service_status['search_service'] = f'error: {str(e)}'
        
        try:
            get_tts_service()
            service_status['tts_service'] = 'healthy'
        except Exception as e:
            service_status['tts_service'] = f'error: {str(e)}'
        
        return Response({
            'status': 'healthy',
            'timestamp': timezone.now(),
            'services': service_status
        }, status=status.HTTP_200_OK)
    
    except Exception as e:
        return Response({
            'status': 'unhealthy',
            'timestamp': timezone.now(),
            'error': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
