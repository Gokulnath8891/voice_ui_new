from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from sentence_transformers import SentenceTransformer
from openai import AzureOpenAI
from dotenv import load_dotenv
import os
import psycopg2
import numpy as np
from sqlalchemy import create_engine, text
from sentence_transformers import SentenceTransformer
from PyPDF2 import PdfReader
from sqlalchemy import create_engine, text
import os
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI
from typing import TypedDict
from langgraph.checkpoint.memory import MemorySaver

#load_dotenv()

DB_URI='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'

EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
engine = create_engine(DB_URI)
model = SentenceTransformer(EMBED_MODEL)

class QAState(TypedDict):
    question:str
    answer:str

# -----------------------
# LLM (Azure OpenAI)
# -----------------------
llm = AzureChatOpenAI(
    azure_deployment=AZURE_DEPLOYMENT_NAME,
    openai_api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
)

# Embedding model
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ------------------ Vector Retrieval ------------------
"""
def get_vector_context(query: str) -> str:
    conn = psycopg2.connect(os.getenv("VECTOR_DB_URL"))
    cur = conn.cursor()
    q_emb = embed_model.encode([query])[0]
    cur.execute("SELECT text, embedding FROM documents;")
    docs = cur.fetchall()
    cur.close()
    conn.close()

    sims = []
    for text, emb in docs:
        emb = np.array(emb)
        sim = np.dot(emb, q_emb) / (np.linalg.norm(emb) * np.linalg.norm(q_emb))
        sims.append((text, sim))
    sims.sort(key=lambda x: x[1], reverse=True)
    top_texts = [t for t, _ in sims[:3]]
    return "\n".join(top_texts)
"""
def retrieve(engine, model, query, top_k=3):
    query_emb = model.encode([query])[0].tolist()
    query_emb_str="[" +",".join([str(x) for x in query_emb])+"]"
    with engine.connect() as conn:
        results = conn.execute(
            text(f"""
                SELECT doc_name, content,
                       1 - (embedding <=> '{query_emb_str}'::vector) AS similarity
                FROM powertrain_pdf_docs
                ORDER BY embedding <=> '{query_emb_str}'::vector
                LIMIT :k
            """),
            {"k": top_k}
        ).fetchall()
    print("\n🔍 Top Matches:")
    for r in results:
        print(f"\n📄 {r.doc_name} | Similarity: {r.similarity:.3f}\n{r.content[:300]}...")
    return results

# ------------------ SQL Agent ------------------
def query_sql_db(query: str) -> str:
    conn = psycopg2.connect(os.getenv("DB_URL"))
    cur = conn.cursor()
    try:
        cur.execute(query)
        rows = cur.fetchall()
        columns = [desc[0] for desc in cur.description]
        return f"Columns: {columns}\nRows: {rows}"
    except Exception as e:
        return str(e)
    finally:
        cur.close()
        conn.close()

client = AzureOpenAI(
    azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION
)
AZURE_MODEL=AZURE_DEPLOYMENT_NAME

# ------------------ Routing Logic ------------------
def decide_route(question: str) -> str:
    """Use LLM to decide whether question is SQL or RAG."""
    prompt = f"Decide whether the following question should go to 'sql' or 'vector':\n\n{question}"
    res= client.chat.completions.create(
        model=AZURE_MODEL,
        messages=[{"role": "user", "content": prompt}]
    )
    decision = res.choices[0].message.content.lower()
    print(decision)
    if "sql" in decision:
        return "sql"
    else:
        return "vector"

# ------------------ Answer Generator ------------------

llm = AzureChatOpenAI(  
            azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


db = SQLDatabase.from_uri(
    "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )

def ask_db(query: str):
    """Ask natural language question to the database agent."""
    
    agent_executor = create_sql_agent(
    llm=llm,
    db=db,
    agent_type="openai-tools", # new API (replaces legacy AgentType.ZERO_SHOT_REACT)
    verbose=True)

    response = agent_executor.invoke({"input": query})
    print("\nUser:", query)
    print("Agent:", response["output"])


def ask_llm(context, question):
    try:
        from langchain_openai import AzureChatOpenAI
        llm = AzureChatOpenAI(
            azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview'
        )
        prompt = f"""
        Use the following context to answer the question:

        Context:
        {context}

        Question:
        {question}
        """
        response = llm.invoke(prompt).content
        print("\n🤖 LLM Answer:\n", response)
        return response
    except Exception as e:
        print("⚠️ LLM step skipped:", e)


def llm_answer(state:QAState):
    q = state["question"]
    route = decide_route(q)
    
    if route == "sql":
        answer = ask_db(q)
	
    if route== "vector":
        print(route,'test')
        results = retrieve(engine, model, q, top_k=3)
        context = "\n".join([r.content for r in results])
        answer = ask_llm(context,q)
    
    return {"answer": answer}

# ------------------ LangGraph Workflow ------------------
#workflow = StateGraph({"question": str, "answer": str})

workflow = StateGraph(QAState)
#workflow.add_node("router",router_node)
#workflow.add_node()
workflow.add_node("llm_answer", llm_answer)
workflow.set_entry_point("llm_answer")
workflow.add_edge("llm_answer", END)
checkpointer=MemorySaver
app = workflow.compile()
