#!/usr/bin/env python3
"""
Work Order Progress Reset Script

This script resets the progress of specified work orders by:
1. Clearing workflow sessions from cache
2. Resetting work order status and timestamps
3. Clearing step completion status
4. Removing feedback entries

Usage:
    python reset_work_progress.py WO-B66BF292 WO-E3A29636
    python reset_work_progress.py --all  # Reset all work orders
"""

import os
import sys
import django
from datetime import datetime

# Add the project directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
django.setup()

from workorders.models import WorkOrder, WorkOrderStep, WorkOrderFeedback
from chat_workflow_handler import workflow_handler
from django.core.cache import cache


class WorkOrderProgressResetService:
    """Service to reset work order progress"""

    def __init__(self):
        self.reset_stats = {
            'work_orders_reset': 0,
            'steps_reset': 0,
            'feedback_cleared': 0,
            'sessions_cleared': 0,
            'errors': []
        }

    def reset_work_order(self, order_number):
        """Reset progress for a specific work order"""
        try:
            print(f"🔄 Resetting progress for {order_number}...")

            # Find the work order
            try:
                work_order = WorkOrder.objects.get(order_number=order_number)
                print(f"   ✅ Found work order: {work_order.title}")
            except WorkOrder.DoesNotExist:
                error_msg = f"❌ Work order {order_number} not found"
                print(error_msg)
                self.reset_stats['errors'].append(error_msg)
                return False

            # 1. Clear workflow sessions for all potential users
            sessions_cleared = self._clear_workflow_sessions(work_order)

            # 2. Reset work order status and timestamps
            self._reset_work_order_status(work_order)

            # 3. Reset step completion status
            steps_reset = self._reset_work_order_steps(work_order)

            # 4. Clear feedback entries
            feedback_cleared = self._clear_work_order_feedback(work_order)

            # Update statistics
            self.reset_stats['work_orders_reset'] += 1
            self.reset_stats['steps_reset'] += steps_reset
            self.reset_stats['feedback_cleared'] += feedback_cleared
            self.reset_stats['sessions_cleared'] += sessions_cleared

            print(f"   ✅ Reset complete for {order_number}")
            print(f"      • Sessions cleared: {sessions_cleared}")
            print(f"      • Steps reset: {steps_reset}")
            print(f"      • Feedback cleared: {feedback_cleared}")

            return True

        except Exception as e:
            error_msg = f"❌ Error resetting {order_number}: {str(e)}"
            print(error_msg)
            self.reset_stats['errors'].append(error_msg)
            return False

    def _clear_workflow_sessions(self, work_order):
        """Clear workflow sessions for the work order"""
        sessions_cleared = 0

        # Try to clear sessions for common user IDs (1-10)
        # Since we can't enumerate cache keys, we'll try common user IDs
        for user_id in range(1, 11):
            session_id = f"wo_{work_order.id}_{user_id}"

            try:
                # Check if session exists
                session_data = workflow_handler._get_session(session_id)
                if session_data:
                    workflow_handler._delete_session(session_id)
                    sessions_cleared += 1
                    print(f"      • Cleared session: {session_id}")
            except Exception as e:
                # Session might not exist, which is fine
                pass

        return sessions_cleared

    def _reset_work_order_status(self, work_order):
        """Reset work order status and timestamps"""
        # Reset status to ASSIGNED (or PENDING if no technician)
        if work_order.technician:
            work_order.status = 'ASSIGNED'
        else:
            work_order.status = 'PENDING'

        # Clear progress timestamps
        work_order.started_at = None
        work_order.completed_at = None
        work_order.actual_hours = None

        work_order.save()
        print(f"      • Reset status to: {work_order.status}")

    def _reset_work_order_steps(self, work_order):
        """Reset all work order steps to incomplete"""
        steps = WorkOrderStep.objects.filter(work_order=work_order)
        steps_count = steps.count()

        # Reset all steps to incomplete
        steps.update(
            is_completed=False,
            completed_at=None
        )

        print(f"      • Reset {steps_count} steps to incomplete")
        return steps_count

    def _clear_work_order_feedback(self, work_order):
        """Clear all feedback for the work order"""
        feedback_entries = WorkOrderFeedback.objects.filter(work_order=work_order)
        feedback_count = feedback_entries.count()

        # Delete all feedback entries
        feedback_entries.delete()

        print(f"      • Cleared {feedback_count} feedback entries")
        return feedback_count

    def reset_all_work_orders(self):
        """Reset all work orders in the system"""
        print("⚠️  WARNING: Resetting ALL work orders in the system!")
        confirm = input("Are you sure? Type 'YES' to continue: ")

        if confirm != 'YES':
            print("❌ Reset cancelled")
            return False

        work_orders = WorkOrder.objects.all()
        total_count = work_orders.count()

        print(f"🔄 Resetting {total_count} work orders...")

        for work_order in work_orders:
            self.reset_work_order(work_order.order_number)

        return True

    def print_summary(self):
        """Print reset operation summary"""
        print("\n" + "="*50)
        print("📊 RESET SUMMARY")
        print("="*50)
        print(f"Work Orders Reset: {self.reset_stats['work_orders_reset']}")
        print(f"Steps Reset: {self.reset_stats['steps_reset']}")
        print(f"Feedback Cleared: {self.reset_stats['feedback_cleared']}")
        print(f"Sessions Cleared: {self.reset_stats['sessions_cleared']}")

        if self.reset_stats['errors']:
            print(f"\n❌ Errors ({len(self.reset_stats['errors'])}):")
            for error in self.reset_stats['errors']:
                print(f"   {error}")
        else:
            print("\n✅ No errors encountered")

        print("="*50)


def main():
    """Main function to handle command line arguments"""
    if len(sys.argv) < 2:
        print("Usage: python reset_work_progress.py WO-B66BF292 WO-E3A29636")
        print("       python reset_work_progress.py --all")
        sys.exit(1)

    reset_service = WorkOrderProgressResetService()

    print("🔄 Work Order Progress Reset Tool")
    print("="*50)

    if sys.argv[1] == '--all':
        # Reset all work orders
        reset_service.reset_all_work_orders()
    else:
        # Reset specific work orders
        work_order_numbers = sys.argv[1:]

        print(f"Resetting {len(work_order_numbers)} work order(s):")
        for order_number in work_order_numbers:
            print(f"  • {order_number}")

        print()

        # Process each work order
        for order_number in work_order_numbers:
            reset_service.reset_work_order(order_number)
            print()  # Add spacing between work orders

    # Print summary
    reset_service.print_summary()


if __name__ == "__main__":
    main()