#!/usr/bin/env python
"""
PDF to Vector Database Processor

This script processes PDF files from a docs folder and stores them in PostgreSQL vector database
for consumption by the voice assistant's semantic search system.

Usage:
    python pdf_to_vectordb.py --docs-folder ./docs --collection-name my_docs
    python pdf_to_vectordb.py --single-file ./docs/document.pdf
    python pdf_to_vectordb.py --docs-folder ./docs --reset --verbose

Author: Voice Assistant Team
Version: 2.0.0
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
import json
from datetime import datetime
import hashlib
import re
from contextlib import contextmanager

# Add Django project to path
project_root = Path(__file__).parent
sys.path.append(str(project_root))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
import django
django.setup()

# PDF processing imports (with graceful fallbacks)
PyPDF2 = None
pdfplumber = None
PdfReader = None
try:
    import PyPDF2
except ImportError:
    pass

try:
    import pdfplumber
except ImportError:
    pass

try:
    from pypdf import PdfReader
except ImportError:
    pass

if not PyPDF2 and not pdfplumber and not PdfReader:
    print("❌ No PDF processing libraries available")
    print("Install with: poetry run pip install PyPDF2 pypdf pdfplumber")
    sys.exit(1)

# Text splitting imports (with fallbacks)
RecursiveCharacterTextSplitter = None
try:
    from langchain.text_splitter import RecursiveCharacterTextSplitter
except ImportError:
    try:
        from langchain_text_splitters import RecursiveCharacterTextSplitter
    except ImportError:
        print("⚠️  Advanced text splitting not available. Using simple chunking.")
        RecursiveCharacterTextSplitter = None

# Voice assistant imports
from voice_assistant.postgres_service import get_postgres_vector_service
from voice_assistant.vector_models import DocumentCollection, DocumentChunk

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


# ============================================================================
# Custom Exceptions
# ============================================================================

class PDFProcessingError(Exception):
    """Base exception for PDF processing errors"""
    pass


class PDFExtractionError(PDFProcessingError):
    """Raised when PDF text extraction fails"""
    pass


class VectorStorageError(PDFProcessingError):
    """Raised when vector storage operations fail"""
    pass


class ConfigurationError(PDFProcessingError):
    """Raised when configuration is invalid"""
    pass


# ============================================================================
# Configuration Classes
# ============================================================================

class ExtractionMethod(Enum):
    """PDF extraction methods"""
    PDFPLUMBER = "pdfplumber"
    PYPDF2 = "PyPDF2"
    PYPDF = "pypdf"
    UNKNOWN = "unknown"


@dataclass
class ProcessingConfig:
    """Configuration for PDF processing"""
    chunk_size: int = 1000
    chunk_overlap: int = 200
    min_chunk_length: int = 50
    min_text_length: int = 100
    skip_existing: bool = True
    batch_size: int = 10

    def validate(self) -> None:
        """Validate configuration parameters"""
        if self.chunk_size <= 0:
            raise ConfigurationError("chunk_size must be positive")
        if self.chunk_overlap < 0:
            raise ConfigurationError("chunk_overlap cannot be negative")
        if self.chunk_overlap >= self.chunk_size:
            raise ConfigurationError("chunk_overlap must be less than chunk_size")
        if self.min_chunk_length <= 0:
            raise ConfigurationError("min_chunk_length must be positive")


@dataclass
class ProcessingStats:
    """Statistics for PDF processing"""
    processed_files: int = 0
    failed_files: int = 0
    skipped_files: int = 0
    total_chunks: int = 0
    total_pages: int = 0
    start_time: datetime = field(default_factory=datetime.now)
    failed_file_paths: List[str] = field(default_factory=list)

    @property
    def total_files(self) -> int:
        """Total files encountered"""
        return self.processed_files + self.failed_files + self.skipped_files

    @property
    def success_rate(self) -> float:
        """Success rate as percentage"""
        if self.total_files == 0:
            return 0.0
        return (self.processed_files / self.total_files) * 100

    @property
    def elapsed_time(self) -> float:
        """Elapsed time in seconds"""
        return (datetime.now() - self.start_time).total_seconds()

    def to_dict(self) -> Dict[str, Any]:
        """Convert stats to dictionary"""
        return {
            "processed_files": self.processed_files,
            "failed_files": self.failed_files,
            "skipped_files": self.skipped_files,
            "total_files": self.total_files,
            "total_chunks": self.total_chunks,
            "total_pages": self.total_pages,
            "success_rate": round(self.success_rate, 2),
            "elapsed_time": round(self.elapsed_time, 2),
            "failed_file_paths": self.failed_file_paths
        }


# ============================================================================
# PDF Processing Classes
# ============================================================================

class PDFProcessor:
    """Process PDF files and extract text content with improved error handling"""

    def __init__(self, config: ProcessingConfig):
        """
        Initialize PDF processor with configuration

        Args:
            config: ProcessingConfig instance with processing parameters
        """
        self.config = config
        config.validate()

        # Initialize text splitter if available
        if RecursiveCharacterTextSplitter:
            self.text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=config.chunk_size,
                chunk_overlap=config.chunk_overlap,
                separators=["\n\n", "\n", ". ", " ", ""]
            )
            logger.info("Initialized advanced text splitter")
        else:
            self.text_splitter = None
            logger.warning("Advanced text splitting not available. Using simple chunking.")

        # Track available extraction methods
        self._available_methods = self._detect_available_methods()
        logger.info(f"Available PDF extraction methods: {[m.value for m in self._available_methods]}")

    def _detect_available_methods(self) -> List[ExtractionMethod]:
        """Detect which PDF extraction methods are available"""
        methods = []
        if pdfplumber:
            methods.append(ExtractionMethod.PDFPLUMBER)
        if PyPDF2:
            methods.append(ExtractionMethod.PYPDF2)
        if PdfReader:
            methods.append(ExtractionMethod.PYPDF)
        return methods
    
    def extract_text_from_pdf(self, pdf_path: Path) -> Tuple[str, Dict[str, Any]]:
        """
        Extract text content and metadata from PDF with fallback mechanisms

        Args:
            pdf_path: Path to PDF file

        Returns:
            Tuple of (extracted_text, metadata_dict)

        Raises:
            PDFExtractionError: If all extraction methods fail
        """
        if not pdf_path.exists():
            raise PDFExtractionError(f"PDF file not found: {pdf_path}")

        if not pdf_path.suffix.lower() == '.pdf':
            raise PDFExtractionError(f"Not a PDF file: {pdf_path}")

        try:
            metadata = self._get_file_metadata(pdf_path)
            text_content = ""

            # Try each available extraction method in order of preference
            extraction_errors = []
            for method in self._available_methods:
                try:
                    text_content, method_metadata = self._extract_with_method(pdf_path, method)
                    if text_content:
                        metadata.update(method_metadata)
                        metadata["extraction_method"] = method.value
                        logger.debug(f"Successfully extracted text using {method.value}")
                        break
                except Exception as e:
                    extraction_errors.append(f"{method.value}: {str(e)}")
                    logger.debug(f"Extraction failed with {method.value}: {e}")

            if not text_content:
                error_msg = f"All extraction methods failed for {pdf_path.name}. Errors: {'; '.join(extraction_errors)}"
                raise PDFExtractionError(error_msg)

            # Clean and validate text
            text_content = self.clean_text(text_content)

            if len(text_content) < self.config.min_text_length:
                raise PDFExtractionError(
                    f"Extracted text too short ({len(text_content)} chars, "
                    f"minimum {self.config.min_text_length})"
                )

            # Update metadata with text statistics
            metadata.update({
                "word_count": len(text_content.split()),
                "character_count": len(text_content)
            })

            return text_content, metadata

        except PDFExtractionError:
            raise
        except Exception as e:
            raise PDFExtractionError(f"Unexpected error extracting from {pdf_path}: {e}")

    def _get_file_metadata(self, pdf_path: Path) -> Dict[str, Any]:
        """Extract file system metadata"""
        stat_info = pdf_path.stat()
        return {
            "filename": pdf_path.name,
            "file_size": stat_info.st_size,
            "created_at": datetime.fromtimestamp(stat_info.st_ctime).isoformat(),
            "modified_at": datetime.fromtimestamp(stat_info.st_mtime).isoformat(),
            "pages": 0,
            "extraction_method": ExtractionMethod.UNKNOWN.value
        }

    def _extract_with_method(self, pdf_path: Path, method: ExtractionMethod) -> Tuple[str, Dict[str, Any]]:
        """Extract text using specific method"""
        if method == ExtractionMethod.PDFPLUMBER:
            return self._extract_with_pdfplumber(pdf_path)
        elif method == ExtractionMethod.PYPDF2:
            return self._extract_with_pypdf2(pdf_path)
        elif method == ExtractionMethod.PYPDF:
            return self._extract_with_pypdf(pdf_path)
        else:
            raise PDFExtractionError(f"Unsupported extraction method: {method}")

    def _extract_with_pdfplumber(self, pdf_path: Path) -> Tuple[str, Dict[str, Any]]:
        """Extract text using pdfplumber"""
        text_content = ""
        metadata = {}

        with pdfplumber.open(pdf_path) as pdf:
            metadata["pages"] = len(pdf.pages)

            for page_num, page in enumerate(pdf.pages):
                page_text = page.extract_text()
                if page_text:
                    text_content += f"\n--- Page {page_num + 1} ---\n{page_text}\n"

            # Extract PDF metadata
            if pdf.metadata:
                metadata.update(self._normalize_pdf_metadata(pdf.metadata))

        return text_content, metadata

    def _extract_with_pypdf2(self, pdf_path: Path) -> Tuple[str, Dict[str, Any]]:
        """Extract text using PyPDF2"""
        text_content = ""
        metadata = {}

        with open(pdf_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            metadata["pages"] = len(pdf_reader.pages)

            for page_num, page in enumerate(pdf_reader.pages):
                page_text = page.extract_text()
                if page_text:
                    text_content += f"\n--- Page {page_num + 1} ---\n{page_text}\n"

            # Extract metadata
            if pdf_reader.metadata:
                metadata.update(self._normalize_pdf_metadata(pdf_reader.metadata, prefix="/"))

        return text_content, metadata

    def _extract_with_pypdf(self, pdf_path: Path) -> Tuple[str, Dict[str, Any]]:
        """Extract text using pypdf"""
        text_content = ""
        metadata = {}

        pdf_reader = PdfReader(pdf_path)
        metadata["pages"] = len(pdf_reader.pages)

        for page_num, page in enumerate(pdf_reader.pages):
            page_text = page.extract_text()
            if page_text:
                text_content += f"\n--- Page {page_num + 1} ---\n{page_text}\n"

        # Extract metadata
        if pdf_reader.metadata:
            metadata.update(self._normalize_pdf_metadata(pdf_reader.metadata, prefix="/"))

        return text_content, metadata

    def _normalize_pdf_metadata(self, pdf_metadata: Dict, prefix: str = "") -> Dict[str, str]:
        """Normalize PDF metadata to consistent format"""
        normalized = {}
        fields = ["Title", "Author", "Subject", "Creator", "Producer", "Keywords"]

        for field in fields:
            key = f"{prefix}{field}" if prefix else field
            value = pdf_metadata.get(key, "")
            if value:
                normalized[field.lower()] = str(value).strip()

        return normalized
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize extracted text"""
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = re.sub(r'\n\s*\n', '\n\n', text)
        text = re.sub(r' +', ' ', text)
        
        # Remove page markers if they're creating noise
        text = re.sub(r'\n--- Page \d+ ---\n', '\n\n', text)
        
        # Strip leading/trailing whitespace
        text = text.strip()
        
        return text
    
    def chunk_text(self, text: str, metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Split text into chunks for vector storage

        Args:
            text: Text to chunk
            metadata: Base metadata to include in each chunk

        Returns:
            List of chunk dictionaries with content and metadata
        """
        if not text:
            return []

        try:
            if self.text_splitter:
                text_chunks = self.text_splitter.split_text(text)
                chunk_method = "recursive"
            else:
                text_chunks = self._simple_chunk_text(text)
                chunk_method = "simple"

            chunks = []
            valid_chunk_index = 0

            for i, chunk_text in enumerate(text_chunks):
                chunk_text = chunk_text.strip()

                # Skip chunks that are too small
                if len(chunk_text) < self.config.min_chunk_length:
                    logger.debug(f"Skipping chunk {i} (too short: {len(chunk_text)} chars)")
                    continue

                chunk_metadata = metadata.copy()
                chunk_metadata.update({
                    "chunk_index": valid_chunk_index,
                    "original_chunk_index": i,
                    "chunk_method": chunk_method,
                    "chunk_size": len(chunk_text),
                    "chunk_word_count": len(chunk_text.split())
                })

                chunks.append({
                    "content": chunk_text,
                    "metadata": chunk_metadata,
                    "chunk_index": valid_chunk_index
                })

                valid_chunk_index += 1

            # Update total chunks in metadata
            for chunk in chunks:
                chunk["metadata"]["total_chunks"] = len(chunks)

            logger.debug(f"Created {len(chunks)} chunks (method: {chunk_method})")
            return chunks

        except Exception as e:
            logger.error(f"Failed to chunk text: {e}")
            # Fallback: treat entire text as single chunk
            return [{
                "content": text,
                "metadata": {**metadata, "chunk_index": 0, "total_chunks": 1, "chunk_method": "fallback"},
                "chunk_index": 0
            }]

    def _simple_chunk_text(self, text: str) -> List[str]:
        """
        Simple text chunking fallback when advanced splitter unavailable

        Args:
            text: Text to chunk

        Returns:
            List of text chunks
        """
        chunks = []
        words = text.split()

        # Estimate words per chunk (rough estimate: 5 chars per word)
        words_per_chunk = self.config.chunk_size // 5
        overlap_words = self.config.chunk_overlap // 5

        for i in range(0, len(words), words_per_chunk - overlap_words):
            chunk_words = words[i:i + words_per_chunk]
            if chunk_words:
                chunks.append(" ".join(chunk_words))

        return chunks


# ============================================================================
# Vector Database Manager
# ============================================================================

class PDFToVectorDB:
    """
    Main class for processing PDFs and storing in vector database

    Handles the orchestration of PDF extraction, text chunking, and storage
    in PostgreSQL vector database with improved error handling and statistics.
    """

    def __init__(
        self,
        collection_name: str = "pdf_documents",
        config: Optional[ProcessingConfig] = None
    ):
        """
        Initialize PDF to Vector DB processor

        Args:
            collection_name: Name of the vector database collection
            config: Processing configuration (uses defaults if not provided)
        """
        self.collection_name = collection_name
        self.config = config or ProcessingConfig()
        self.pdf_processor = PDFProcessor(self.config)
        self.vector_service = None
        self.stats = ProcessingStats()
        self._processed_hashes: Set[str] = set()

        logger.info(f"Initialized PDFToVectorDB for collection: {collection_name}")
    
    def initialize_vector_service(self) -> None:
        """
        Initialize vector service and collection

        Raises:
            VectorStorageError: If initialization fails
        """
        try:
            self.vector_service = get_postgres_vector_service(self.collection_name)
            logger.info(f"✅ Initialized vector collection: {self.collection_name}")
        except Exception as e:
            error_msg = f"Failed to initialize vector service: {e}"
            logger.error(f"❌ {error_msg}")
            raise VectorStorageError(error_msg) from e
    
    def process_single_pdf(self, pdf_path: Path, source_folder: str = "") -> bool:
        """
        Process a single PDF file and store in vector database

        Args:
            pdf_path: Path to PDF file
            source_folder: Source folder for organizational purposes

        Returns:
            True if processing succeeded, False otherwise
        """
        try:
            logger.info(f"📄 Processing: {pdf_path.name}")

            # Check if file already exists in database
            if self.config.skip_existing and self._is_file_already_processed(pdf_path):
                logger.info(f"⏭️  Skipping already processed file: {pdf_path.name}")
                self.stats.skipped_files += 1
                return True

            # Extract text and metadata
            try:
                text_content, base_metadata = self.pdf_processor.extract_text_from_pdf(pdf_path)
            except PDFExtractionError as e:
                logger.error(f"❌ Extraction failed for {pdf_path.name}: {e}")
                self.stats.failed_files += 1
                self.stats.failed_file_paths.append(str(pdf_path))
                return False

            # Prepare comprehensive metadata
            file_metadata = self._prepare_file_metadata(pdf_path, base_metadata, source_folder)

            # Chunk text
            chunks = self.pdf_processor.chunk_text(text_content, file_metadata)

            if not chunks:
                logger.warning(f"⚠️  No chunks created for: {pdf_path.name}")
                self.stats.failed_files += 1
                self.stats.failed_file_paths.append(str(pdf_path))
                return False

            # Prepare documents for vector storage
            documents = self._prepare_documents(chunks, pdf_path)

            # Store in vector database
            try:
                added_count = self.vector_service.add_documents(documents)
            except Exception as e:
                raise VectorStorageError(f"Failed to add documents to vector DB: {e}") from e

            # Update statistics
            self.stats.processed_files += 1
            self.stats.total_chunks += added_count
            self.stats.total_pages += base_metadata.get("pages", 0)

            logger.info(f"✅ Processed {pdf_path.name}: {added_count} chunks, {base_metadata.get('pages', 0)} pages")
            return True

        except VectorStorageError as e:
            logger.error(f"❌ Storage error for {pdf_path.name}: {e}")
            self.stats.failed_files += 1
            self.stats.failed_file_paths.append(str(pdf_path))
            return False
        except Exception as e:
            logger.error(f"❌ Unexpected error processing {pdf_path.name}: {e}")
            self.stats.failed_files += 1
            self.stats.failed_file_paths.append(str(pdf_path))
            return False

    def _prepare_file_metadata(
        self,
        pdf_path: Path,
        base_metadata: Dict[str, Any],
        source_folder: str
    ) -> Dict[str, Any]:
        """Prepare comprehensive metadata for file"""
        file_hash = self._calculate_file_hash(pdf_path)
        self._processed_hashes.add(file_hash)

        file_metadata = base_metadata.copy()
        file_metadata.update({
            "filename": pdf_path.name,
            "filepath": str(pdf_path),
            "source_folder": source_folder,
            "file_hash": file_hash,
            "processed_at": datetime.now().isoformat(),
            "collection_name": self.collection_name
        })

        return file_metadata

    def _prepare_documents(self, chunks: List[Dict[str, Any]], pdf_path: Path) -> List[Dict[str, Any]]:
        """Prepare document list for vector storage"""
        documents = []
        for chunk in chunks:
            documents.append({
                "content": chunk["content"],
                "metadata": chunk["metadata"],
                "source": str(pdf_path),
                "source_type": "pdf",
                "chunk_index": chunk["chunk_index"],
                "language": "en"  # TODO: Add language detection
            })
        return documents
    
    def process_folder(self, docs_folder: Path, recursive: bool = True) -> ProcessingStats:
        """
        Process all PDF files in a folder

        Args:
            docs_folder: Path to folder containing PDFs
            recursive: Whether to search subdirectories

        Returns:
            ProcessingStats object with results

        Raises:
            ValueError: If folder doesn't exist or is not a directory
        """
        if not docs_folder.exists():
            raise ValueError(f"Docs folder does not exist: {docs_folder}")

        if not docs_folder.is_dir():
            raise ValueError(f"Path is not a directory: {docs_folder}")

        # Find all PDF files
        pdf_files = self._find_pdf_files(docs_folder, recursive)

        if not pdf_files:
            logger.warning(f"⚠️  No PDF files found in {docs_folder}")
            return self.stats

        logger.info(f"📚 Found {len(pdf_files)} PDF files in {docs_folder}")
        logger.info(f"⚙️  Processing with chunk_size={self.config.chunk_size}, "
                   f"overlap={self.config.chunk_overlap}")

        # Process each PDF
        for i, pdf_path in enumerate(pdf_files, 1):
            try:
                logger.info(f"[{i}/{len(pdf_files)}] Processing {pdf_path.name}")
                self.process_single_pdf(pdf_path, str(docs_folder))
            except KeyboardInterrupt:
                logger.info("⚡ Processing interrupted by user")
                break
            except Exception as e:
                logger.error(f"❌ Unexpected error processing {pdf_path.name}: {e}")
                continue

        return self.stats

    def _find_pdf_files(self, docs_folder: Path, recursive: bool) -> List[Path]:
        """Find all PDF files in folder"""
        if recursive:
            pdf_files = sorted(docs_folder.glob("**/*.pdf"))
        else:
            pdf_files = sorted(docs_folder.glob("*.pdf"))

        # Filter out hidden files and system files
        pdf_files = [f for f in pdf_files if not any(part.startswith('.') for part in f.parts)]

        return pdf_files
    
    def _is_file_already_processed(self, pdf_path: Path) -> bool:
        """
        Check if file is already in the database

        Args:
            pdf_path: Path to PDF file

        Returns:
            True if file already processed, False otherwise
        """
        try:
            file_hash = self._calculate_file_hash(pdf_path)

            # Check in-memory cache first
            if file_hash in self._processed_hashes:
                return True

            # Check if document with this hash exists in database
            existing = DocumentChunk.objects.filter(
                collection__name=self.collection_name,
                metadata__file_hash=file_hash
            ).exists()

            if existing:
                self._processed_hashes.add(file_hash)

            return existing
        except Exception as e:
            logger.debug(f"Error checking if file processed: {e}")
            return False

    @staticmethod
    def _calculate_file_hash(file_path: Path) -> str:
        """
        Calculate MD5 hash of file for duplicate detection

        Args:
            file_path: Path to file

        Returns:
            MD5 hash as hexadecimal string
        """
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    
    def print_statistics(self) -> None:
        """Print comprehensive processing statistics"""
        stats_dict = self.stats.to_dict()

        print("\n" + "=" * 70)
        print("📊 PROCESSING STATISTICS".center(70))
        print("=" * 70)
        print(f"✅ Successfully processed:  {stats_dict['processed_files']:>5} files")
        print(f"❌ Failed:                  {stats_dict['failed_files']:>5} files")
        print(f"⏭️  Skipped (duplicate):     {stats_dict['skipped_files']:>5} files")
        print(f"📄 Total files:             {stats_dict['total_files']:>5}")
        print("-" * 70)
        print(f"📑 Total chunks created:    {stats_dict['total_chunks']:>5}")
        print(f"📖 Total pages processed:   {stats_dict['total_pages']:>5}")
        print(f"✨ Success rate:            {stats_dict['success_rate']:>5.1f}%")
        print(f"⏱️  Elapsed time:            {stats_dict['elapsed_time']:>5.1f}s")

        if self.vector_service:
            try:
                collection_stats = self.vector_service.get_collection_stats()
                print("-" * 70)
                print(f"🗂️  Collection:              {collection_stats.get('name', 'unknown')}")
                print(f"📚 Total docs in DB:        {collection_stats.get('total_documents', 0):>5}")
            except Exception as e:
                logger.debug(f"Could not fetch collection stats: {e}")

        if stats_dict['failed_files'] > 0 and stats_dict['failed_file_paths']:
            print("-" * 70)
            print("❌ Failed files:")
            for failed_file in stats_dict['failed_file_paths'][:10]:  # Show max 10
                print(f"   • {Path(failed_file).name}")
            if len(stats_dict['failed_file_paths']) > 10:
                print(f"   ... and {len(stats_dict['failed_file_paths']) - 10} more")

        print("=" * 70)


# ============================================================================
# CLI and Main Function
# ============================================================================

def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="Process PDF files and store them in PostgreSQL vector database",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process all PDFs in a folder
  python pdf_to_vectordb.py --docs-folder ./docs

  # Process single file
  python pdf_to_vectordb.py --single-file ./docs/manual.pdf

  # Custom settings with reset
  python pdf_to_vectordb.py --docs-folder ./docs --collection-name technical_docs --reset

  # Custom chunking parameters
  python pdf_to_vectordb.py --docs-folder ./docs --chunk-size 1500 --chunk-overlap 300

  # Test search after processing
  python pdf_to_vectordb.py --docs-folder ./docs --test-search "installation guide"

  # Verbose mode for debugging
  python pdf_to_vectordb.py --docs-folder ./docs --verbose
        """
    )

    # Input options
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument(
        "--docs-folder",
        type=str,
        help="Path to folder containing PDF files"
    )
    input_group.add_argument(
        "--single-file",
        type=str,
        help="Path to single PDF file"
    )

    # Configuration options
    parser.add_argument(
        "--collection-name",
        type=str,
        default="pdf_documents",
        help="Name of vector collection (default: pdf_documents)"
    )
    parser.add_argument(
        "--chunk-size",
        type=int,
        default=1000,
        help="Text chunk size in characters (default: 1000)"
    )
    parser.add_argument(
        "--chunk-overlap",
        type=int,
        default=200,
        help="Overlap between chunks in characters (default: 200)"
    )
    parser.add_argument(
        "--min-chunk-length",
        type=int,
        default=50,
        help="Minimum chunk length to keep (default: 50)"
    )

    # Processing options
    parser.add_argument(
        "--recursive",
        action="store_true",
        default=True,
        help="Process PDFs in subfolders recursively (default: True)"
    )
    parser.add_argument(
        "--no-skip-existing",
        action="store_true",
        help="Reprocess files even if already in database"
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset collection (delete all existing documents)"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging"
    )

    # Test options
    parser.add_argument(
        "--test-search",
        type=str,
        help="Test search after processing with given query"
    )

    return parser.parse_args()


def main():
    """Main entry point for PDF to Vector DB processor"""
    args = parse_arguments()

    # Configure logging
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.debug("Verbose logging enabled")

    try:
        # Create processing configuration
        config = ProcessingConfig(
            chunk_size=args.chunk_size,
            chunk_overlap=args.chunk_overlap,
            min_chunk_length=args.min_chunk_length,
            skip_existing=not args.no_skip_existing
        )

        # Validate configuration
        try:
            config.validate()
        except ConfigurationError as e:
            logger.error(f"❌ Configuration error: {e}")
            sys.exit(1)

        logger.info(f"🚀 Starting PDF to Vector DB processor")
        logger.info(f"📁 Collection: {args.collection_name}")
        logger.info(f"⚙️  Config: chunk_size={config.chunk_size}, overlap={config.chunk_overlap}")

        # Initialize processor
        processor = PDFToVectorDB(
            collection_name=args.collection_name,
            config=config
        )

        # Initialize vector service
        processor.initialize_vector_service()

        # Reset collection if requested
        if args.reset:
            logger.warning(f"🗑️  Resetting collection: {args.collection_name}")
            confirm = input("Are you sure you want to delete all documents? (yes/no): ")
            if confirm.lower() == 'yes':
                DocumentCollection.objects.filter(name=args.collection_name).delete()
                processor.initialize_vector_service()  # Reinitialize after reset
                logger.info("✅ Collection reset complete")
            else:
                logger.info("❌ Reset cancelled")
                sys.exit(0)

        # Process files
        if args.single_file:
            pdf_path = Path(args.single_file)
            if not pdf_path.exists():
                logger.error(f"❌ File not found: {pdf_path}")
                sys.exit(1)

            logger.info(f"📄 Processing single file: {pdf_path}")
            success = processor.process_single_pdf(pdf_path)

            if not success:
                logger.error(f"❌ Failed to process {pdf_path}")
                sys.exit(1)

        elif args.docs_folder:
            docs_folder = Path(args.docs_folder)
            if not docs_folder.exists():
                logger.error(f"❌ Folder not found: {docs_folder}")
                sys.exit(1)

            processor.process_folder(docs_folder, recursive=args.recursive)

        # Print statistics
        processor.print_statistics()

        # Test search if requested
        if args.test_search:
            logger.info(f"\n🔍 Testing search with query: '{args.test_search}'")
            try:
                result = processor.vector_service.search_similar(args.test_search, max_results=3)

                if result['status'] == 'success':
                    print(f"\n🎯 Search Results ({len(result['relevant_chunks'])} found):")
                    for i, chunk in enumerate(result['relevant_chunks'][:3], 1):
                        print(f"\n  Result {i}:")
                        print(f"    Similarity: {chunk['similarity_score']:.3f}")
                        print(f"    Source: {Path(chunk['source']).name}")
                        print(f"    Content: {chunk['content'][:200]}...")
                else:
                    logger.error(f"❌ Search test failed: {result.get('error', 'Unknown error')}")
            except Exception as e:
                logger.error(f"❌ Search test error: {e}")

        # Check for failures and set exit code
        if processor.stats.failed_files > 0:
            logger.warning(f"⚠️  Completed with {processor.stats.failed_files} failed files")
            sys.exit(1)

        logger.info("🎉 Processing completed successfully!")

    except KeyboardInterrupt:
        logger.info("\n⚡ Process interrupted by user")
        sys.exit(130)
    except (ConfigurationError, VectorStorageError, PDFExtractionError) as e:
        logger.error(f"❌ Error: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()