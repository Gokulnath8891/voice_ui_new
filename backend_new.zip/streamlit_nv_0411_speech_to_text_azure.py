import streamlit as st
import psycopg2
import numpy as np
from typing import TypedDict, Optional
from sentence_transformers import SentenceTransformer
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

import sounddevice as sd
import queue
import json
import threading
from vosk import Model, KaldiRecognizer


import speech_recognition as sr
import pyttsx3
import time
import azure.cognitiveservices.speech as speechsdk

# app.py
import os
import base64
import time
import threading
import queue
import streamlit as st
import psycopg2
import numpy as np
from sentence_transformers import SentenceTransformer
import azure.cognitiveservices.speech as speechsdk
from typing import TypedDict, Optional




# ===============================
# 🔹 Define State using TypedDict
# ===============================
class QueryState(TypedDict):
    query: str
    result: Optional[str]
    context: Optional[str]

# ===============================
# 🔹 Azure OpenAI Configuration
# ===============================

# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


DB_URI='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'

EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
#engine = create_engine(DB_URI)
model = SentenceTransformer(EMBED_MODEL)


# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


# ===============================
# 🔹 SentenceTransformer Embedding
# ===============================
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ===============================
# 🔹 PostgreSQL Connection
# ===============================
def get_pg_connection():
    return psycopg2.connect(
        host="voiceassistantpsql.postgres.database.azure.com",
        dbname="voice_assistant_db",
        user="postgres",
        password="voice_password",
        port="5432"
    )

# ===============================
# 🔹 Router Node
# ===============================
def router_node(state: QueryState):
    """Decide whether to use SQL or vector search."""
    #q = state["query"].lower()
    q=state.get("query","").lower()
    #if q.strip().contains("work order") or " from " in q:
    if "work order" in q:
        next_node="db_agent"
    else:
        next_node="vector_agent"
    return {"next":next_node}

# ===============================
# 🔹 SQL Agent Node
# ===============================
def db_agent(state: QueryState):
    """Executes SQL queries directly in PostgreSQL."""
    query = state["query"]
    context = state.get("context", "")
    prompt = f"""
    You are an automotive assistant.
    If question involves work order details, use SQL to retrieve them.
    Otherwise, answer naturally.
    Previous context: {context}
    Question: {query}
    """
    
    db = SQLDatabase.from_uri(
        "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )

    
    sql_agent = create_sql_agent(
        llm=llm,
        db=db,
        verbose=True,
        top_k=5,  # optional
        agent_type="openai-tools",  # use the new LCEL-compatible type
    )

    # Run user query through the SQL agent
    try:
        result = sql_agent.invoke({"input": prompt})
        result_text = result.get("output", "No output from SQL Agent.")
    except Exception as e:
        result_text = f"Error executing SQL Agent: {e}"

    return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {result_text}",
        "result": result_text
    }
    
# ===============================
# 🔹 Vector Agent Node
# ===============================
def vector_agent(state: QueryState):
    """Performs semantic search using pgvector and SentenceTransformer."""
    query = state["query"]
    context = state.get("context", "")
    try:
        # Step 1: Encode the query into vector
        query_vector = embed_model.encode(query)
        query_vector = np.array(query_vector, dtype=np.float32).tolist()

        # Step 2: Retrieve similar content
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT content, 1 - (embedding <=> %s::vector) AS similarity
            FROM powertrain_pdf_docs
            ORDER BY embedding <=> %s::vector
            LIMIT 3;
        """, (query_vector, query_vector))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            return {"result": "⚠️ No similar content found in vector DB."}

        context = "\n".join([r[0] for r in rows])

        # Step 3: LLM call with retrieved context
        prompt = f"""
        You are automotive Technician Automotive assistant.
        Please give one step and wait for user response
        You provide step by step support.
        Use this context to answer the query.
        Dont repeat the same steps again and again, repeat only if asked.
        For first step alone, add first, for rest of the steps add next.
        When asked to summarise the steps, give all steps summarised and share
        \n\n Context:\n{context}
        \n\n query: {query}
        """
        response = llm.invoke(prompt)
        first_answer=response.content.strip()
        return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {first_answer}",
        "result": first_answer}

    except Exception as e:
        return {"result": f"⚠️ Vector Agent Error: {e}"}

# ===============================
# 🔹 LangGraph Workflow
# ===============================
graph = StateGraph(QueryState)
graph.add_node("router", router_node)
graph.add_node("db_agent", db_agent)
graph.add_node("vector_agent", vector_agent)

graph.add_conditional_edges(
    "router",
    lambda state:state["next"],
    {
        "db_agent": "db_agent",
        "vector_agent": "vector_agent"
    }
)

graph.add_edge("db_agent", END)
graph.add_edge("vector_agent", END)
graph.set_entry_point("router")

# Memory checkpoint
checkpointer = MemorySaver()
#app = graph.compile(checkpointer=checkpointer)
app = graph.compile()


# ----------------------------
# Azure Speech config
# ----------------------------
AZURE_SPEECH_KEY='1QD2Whn5LX4JPSORsLv7OP2zus76eJ86cLstg7zOLCHc3sVrqFYAJQQJ99BEACHYHv6XJ3w3AAAYACOGypYi'
AZURE_SPEECH_REGION='eastus2'
WAKEWORD_TABLE='2cd0bba2-bdfb-478c-8df7-383bbce3e3ff.table'

speech_config = speechsdk.SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
speech_config.speech_recognition_language = "en-US"
speech_config.speech_synthesis_output_format = speechsdk.SpeechSynthesisOutputFormat.Audio16Khz128KBitRateMonoMp3

keyword_model = speechsdk.KeywordRecognitionModel(WAKEWORD_TABLE)

# ----------------------------
# Background wake-word thread
# ----------------------------
wake_queue = queue.Queue() # main thread checks this
print(wake_queue)

def wake_word_listener(stop_event: threading.Event, wake_q: queue.Queue):
    """
    Runs in background thread. Starts continuous keyword recognition and places events on wake_q when wake word detected.
    """
    try:
        audio_cfg = speechsdk.AudioConfig(use_default_microphone=True)
        recognizer = speechsdk.KeywordRecognizer(audio_cfg)

        # Handler for recognized keyword
        def recognized_cb(evt):
            # evt is a KeywordRecognitionModel result; put simple flag into queue
            wake_q.put(("wake", time.time()))

        # Handler for canceled/failed
        def canceled_cb(evt):
            # Put cancel or log; not fatal
            wake_q.put(("cancel", str(evt.reason)))

        recognizer.recognized.connect(recognized_cb)
        recognizer.canceled.connect(canceled_cb)

        # Start keyword recognition (non-blocking)
        start_future = recognizer.start_keyword_recognition_async(keyword_model)
        start_future.get() # wait until started

        # Keep running until stop_event set
        while not stop_event.is_set():
            time.sleep(0.1)

        # Stop recognition when asked
        stop_future = recognizer.stop_keyword_recognition_async()
        stop_future.get()
    except Exception as e:
        wake_q.put(("error", str(e)))

# ----------------------------
# Helpers: listen for query & synthesize
# ----------------------------
def listen_for_query_once(timeout: int = 10):
    audio_cfg = speechsdk.AudioConfig(use_default_microphone=True)
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_cfg)
    # one-shot recognition
    res = recognizer.recognize_once()
    if res.reason == speechsdk.ResultReason.RecognizedSpeech:
        return res.text
    return None

def synthesize_and_get_audio_html(text: str):
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=None)
    res = synthesizer.speak_text_async(text).get()
    if res.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        audio_bytes = res.audio_data
        b64 = base64.b64encode(audio_bytes).decode()
        audio_html = f'<audio autoplay controls style="width:100%"><source src="data:audio/mp3;base64,{b64}" type="audio/mp3"></audio>'
        return audio_html
    else:
        return None

# ----------------------------
# Streamlit UI (local continuous wake-word)
# ----------------------------
st.set_page_config(page_title="Automotive Assistant (Local Wake-word)", layout="wide")
st.title("🚗 Automotive Technician Assistant — Local Wake-Word 'Hey Buddy'")

# session
if "history" not in st.session_state:
    st.session_state.history = [
        {"role": "assistant", "content": "👋 Hello! Say 'Hey Buddy' to start, or type your question."}
    ]
if "context" not in st.session_state:
    st.session_state.context = ""
if "wake_thread" not in st.session_state:
    st.session_state.wake_thread = None
if "wake_stop" not in st.session_state:
    st.session_state.wake_stop = None

# render history
for msg in st.session_state.history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

col1, col2, col3 = st.columns([1.2, 1, 1])
with col1:
    if st.button("▶️ Start Wake-Word Listener (local)"):
        if st.session_state.wake_thread is None or not st.session_state.wake_thread.is_alive():
            stop_evt = threading.Event()
            st.session_state.wake_stop = stop_evt
            t = threading.Thread(target=wake_word_listener, args=(stop_evt, wake_queue), daemon=True)
            t.start()
            st.session_state.wake_thread = t
            st.success("Wake-word listener started. Say 'Hey Buddy' near your microphone.")
        else:
            st.info("Wake-word listener already running.")

with col2:
    if st.button("⏸️ Stop Wake-Word Listener"):
        if st.session_state.wake_stop:
            st.session_state.wake_stop.set()
            st.session_state.wake_thread = None
            st.session_state.wake_stop = None
            st.success("Wake-word listener stopped.")
        else:
            st.info("Wake-word listener not running.")

with col3:
    typed = st.text_input("Or type your question here")
    if st.button("Send Text"):
        if typed.strip():
            st.session_state.history.append({"role": "user", "content": typed})
            output = app.invoke({"query": typed, "context": st.session_state.context, "result": None})
            res = output.get("result", "No result")
            st.session_state.context = output.get("context", st.session_state.context)
            st.session_state.history.append({"role": "assistant", "content": res})
            with st.chat_message("assistant"):
                st.markdown(res)
                audio_html = synthesize_and_get_audio_html(res)
                if audio_html:
                    st.markdown(audio_html, unsafe_allow_html=True)
        else:
            st.warning("Type something first.")

# ------------------------------------------------------------------
# Main UI loop: poll wake_queue for events (non-blocking)
# ------------------------------------------------------------------
# Use short repeated sleeps by re-running Streamlit script; polling queue is fine.
if not wake_queue.empty():
    ev, payload = wake_queue.get()
    if ev == "wake":
        st.info("🔔 Wake word detected! Listening for your question...")
        # one-shot listen to capture the user's spoken query
        q = listen_for_query_once()
        if q:
            st.session_state.history.append({"role": "user", "content": q})
            with st.chat_message("user"):
                st.markdown(q)

            # run LangGraph
            with st.spinner("Processing..."):
                output = app.invoke({"query": q, "context": st.session_state.context, "result": None})

            res = output.get("result", "No result")
            st.session_state.context = output.get("context", st.session_state.context)
            st.session_state.history.append({"role": "assistant", "content": res})

            with st.chat_message("assistant"):
                st.markdown(res)
                audio_html = synthesize_and_get_audio_html(res)
                if audio_html:
                    st.markdown(audio_html, unsafe_allow_html=True)

        else:
            st.warning("Could not capture a spoken question. Try again.")
    elif ev == "cancel":
        st.warning(f"Wake recognizer canceled: {payload}")
    elif ev == "error":
        st.error(f"Wake-word listener error: {payload}")