#!/usr/bin/env python3
"""
Work Order Status Checker

This script checks the current status and progress of work orders.

Usage:
    python check_work_order_status.py WO-B66BF292 WO-E3A29636
"""

import os
import sys
import django
from datetime import datetime

# Add the project directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
django.setup()

from workorders.models import WorkOrder, WorkOrderStep, WorkOrderFeedback
from chat_workflow_handler import workflow_handler


def check_work_order_status(order_number):
    """Check the status of a specific work order"""
    try:
        print(f"📋 Checking status for {order_number}...")

        # Find the work order
        try:
            work_order = WorkOrder.objects.get(order_number=order_number)
        except WorkOrder.DoesNotExist:
            print(f"   ❌ Work order {order_number} not found")
            return False

        # Basic work order info
        print(f"   📝 Title: {work_order.title}")
        print(f"   📊 Status: {work_order.status}")
        print(f"   👤 Technician: {work_order.technician.get_full_name() if work_order.technician else 'Not assigned'}")
        print(f"   📅 Created: {work_order.created_at.strftime('%Y-%m-%d %H:%M')}")

        if work_order.started_at:
            print(f"   🏁 Started: {work_order.started_at.strftime('%Y-%m-%d %H:%M')}")
        if work_order.completed_at:
            print(f"   ✅ Completed: {work_order.completed_at.strftime('%Y-%m-%d %H:%M')}")

        # Steps info
        steps = WorkOrderStep.objects.filter(work_order=work_order).order_by('step_number')
        total_steps = steps.count()
        completed_steps = steps.filter(is_completed=True).count()

        print(f"   📋 Steps: {completed_steps}/{total_steps} completed")

        if total_steps > 0:
            print(f"   📝 Step Details:")
            for step in steps:
                status_icon = "✅" if step.is_completed else "⏳"
                completed_info = f" (completed: {step.completed_at.strftime('%m/%d %H:%M')})" if step.completed_at else ""
                print(f"      {status_icon} Step {step.step_number}: {step.title}{completed_info}")

        # Feedback info
        feedback_count = WorkOrderFeedback.objects.filter(work_order=work_order).count()
        print(f"   💬 Feedback entries: {feedback_count}")

        if feedback_count > 0:
            feedback_entries = WorkOrderFeedback.objects.filter(work_order=work_order).order_by('created_at')
            print(f"   💬 Recent feedback:")
            for feedback in feedback_entries[:3]:  # Show last 3
                print(f"      • Step {feedback.step.step_number}: {feedback.feedback_text[:50]}...")

        # Check for workflow sessions
        print(f"   🔄 Workflow Sessions:")
        sessions_found = 0
        for user_id in range(1, 11):
            session_id = f"wo_{work_order.id}_{user_id}"
            try:
                session_data = workflow_handler._get_session(session_id)
                if session_data:
                    sessions_found += 1
                    session_type = session_data.get('type', 'unknown')
                    awaiting_feedback = session_data.get('awaiting_feedback', False)
                    completed_count = len(session_data.get('completed_steps', []))
                    print(f"      • {session_id}: {session_type}, completed: {completed_count}, awaiting: {awaiting_feedback}")
            except:
                pass

        if sessions_found == 0:
            print(f"      • No active workflow sessions found")

        print()
        return True

    except Exception as e:
        print(f"   ❌ Error checking {order_number}: {str(e)}")
        return False


def main():
    """Main function to handle command line arguments"""
    if len(sys.argv) < 2:
        print("Usage: python check_work_order_status.py WO-B66BF292 WO-E3A29636")
        sys.exit(1)

    work_order_numbers = sys.argv[1:]

    print("📊 Work Order Status Checker")
    print("="*50)

    for order_number in work_order_numbers:
        check_work_order_status(order_number)

    print("="*50)


if __name__ == "__main__":
    main()