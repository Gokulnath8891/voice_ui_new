import streamlit as st
import azure.cognitiveservices.speech as speechsdk
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
import tempfile
import os
import psycopg2
import numpy as np
from typing import TypedDict, Optional
from sentence_transformers import SentenceTransformer
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command
import streamlit as st
import azure.cognitiveservices.speech as speechsdk
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from pydub import AudioSegment
import base64
import tempfile
import pyttsx3
from streamlit_TTS import auto_play, text_to_speech, text_to_audio
from gtts.lang import tts_langs
import io
from gtts import gTTS
# MMR / retrieval params
# For all-MiniLM-L6-v2: embedding dim = 384 -> ensure your pgvector column uses VECTOR(384)
MMR_FETCH_K = 50   # how many to fetch from pgvector before reranking
MMR_RETURN_K = 5   # how many docs to return after MMR
MMR_LAMBDA = 0.7
# ---------- TTS ----------
def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def greet_user(name="User"):
    speak(f"Hi, {name}. How may I help you today?")
    log_event(f"Greeted user {name}")


# ---------- Logging ----------
def log_event(message):
    with open("assistant_log.txt", "a", encoding="utf-8") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"[{timestamp}] {message}\n")


# -----------------------------
# Azure Configuration
# -----------------------------
AZURE_SPEECH_KEY = "BsDXPQTKwsh9ABh5jDIigsKc25GxXrQnX8FzEuKKxoI15upppkULJQQJ99BFACYeBjFXJ3w3AAAYACOG11aU"
AZURE_SPEECH_REGION = "eastus"


# ===============================
# 🔹 Define State using TypedDict
# ===============================
class QueryState(TypedDict):
    query: str
    result: Optional[str]
    context: Optional[str]
    rewritten_query: str
    query_embedding: list
    history: str
    
# ===============================
# 🔹 Azure OpenAI Configuration
# ===============================

# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


DB_URI='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'

EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
#engine = create_engine(DB_URI)
model = SentenceTransformer(EMBED_MODEL)

# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
temperature=0
)

def embed_with_sentence_transformer(text: str) -> np.ndarray:
    # returns numpy array (float32)
    vec = EMBED_MODEL.encode(text, convert_to_numpy=True)
    return np.array(vec, dtype=np.float32)


def mmr_retrieve_from_pgvector(query_embedding: np.ndarray, fetch_k=MMR_FETCH_K, top_k=MMR_RETURN_K, lambda_param=MMR_LAMBDA):
    """
    - query_embedding: numpy array float32
    - fetch_k: how many candidates to fetch using pgvector ANN
    - top_k: how many final docs to return
    Returns list of dicts: [{"id": id, "content": content, "score": ...}, ...]
    """
    conn = get_pg_conn()
    cur = conn.cursor()
    # Pass list for pgvector binding; ensure your psycopg2 + pgvector adapter works with list
    cur.execute("""
        SELECT id, content, embedding
        FROM documents
        ORDER BY embedding <#> %s
        LIMIT %s;
    """, (query_embedding.tolist(), fetch_k))
    rows = cur.fetchall()
    cur.close()
    conn.close()

    if not rows:
        return []

    ids = [r[0] for r in rows]
    contents = [r[1] for r in rows]
    embs = np.array([r[2] for r in rows], dtype=np.float32)

    selected = []
    selected_ids = []
    selected_docs = []

    for _ in range(min(top_k, len(embs))):
        mmr_scores = []
        for i, emb in enumerate(embs):
            if ids[i] in selected_ids:
                mmr_scores.append(-1e9)
                continue
            relevance = float(np.dot(query_embedding, emb))
            diversity = 0.0 if not selected else float(np.max([np.dot(emb, s) for s in selected]))
            score = lambda_param * relevance - (1 - lambda_param) * diversity
            mmr_scores.append(score)

        best_idx = int(np.argmax(mmr_scores))
        selected.append(embs[best_idx])
        selected_ids.append(ids[best_idx])
        selected_docs.append({
            "id": ids[best_idx],
            "content": contents[best_idx],
            "score": float(mmr_scores[best_idx])
        })

    return selected_docs

# ---------------------------
# Query rewriting node (uses LLM to rewrite for retrieval)
# ---------------------------
def rewrite_query_with_llm(original_query: str) -> str:
    """
    Use Azure/OpenAI chat to rewrite a user query to improve retrieval.
    Returns rewritten query string.
    """
    prompt = f"""Rewrite the user's query to be a concise, clear, and retrieval-optimized search query.
Do NOT answer the user's question — only rewrite it for retrieval.

Original Query:
{original_query}

Rewritten query:"""

    try:
        resp = llm.ChatCompletion.create(
            engine=AZURE_DEPLOYMENT_NAME,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=128,
            temperature=0.0,
        )
        rewritten = resp.choices[0].message["content"].strip()
        return rewritten
    except Exception:
        return original_query

# ===============================
# 🔹 SentenceTransformer Embedding
# ===============================
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ===============================
# 🔹 PostgreSQL Connection
# ===============================
def get_pg_connection():
    return psycopg2.connect(
        host="voiceassistantpsql.postgres.database.azure.com",
        dbname="voice_assistant_db",
        user="postgres",
        password="voice_password",
        port="5432"
    )

# ===============================
# 🔹 Router Node
# ===============================
def router_node(state: QueryState):
    """Decide whether to use SQL or vector search."""
    #q = state["query"].lower()
    q=state.get("query","").lower()
    #if q.strip().contains("work order") or " from " in q:
    if "work order" in q:
        next_node="db_agent"
    else:
        next_node="vector_agent"
    return {"next":next_node}

# ===============================
# 🔹 SQL Agent Node
# ===============================
def db_agent(state: QueryState):
    """Executes SQL queries directly in PostgreSQL."""
    query = state["query"]
    context = state.get("context", "")
    prompt = f"""
    You are an automotive assistant.
    If question involves work order details, use SQL to retrieve them.
    Otherwise, answer naturally.
    Previous context: {context}
    Question: {query}
    """
    
    db = SQLDatabase.from_uri(
        "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )

    
    sql_agent = create_sql_agent(
        llm=llm,
        db=db,
        verbose=True,
        top_k=5,  # optional
        agent_type="openai-tools",  # use the new LCEL-compatible type
    )

    # Run user query through the SQL agent
    try:
        result = sql_agent.invoke({"input": prompt})
        result_text = result.get("output", "No output from SQL Agent.")
    except Exception as e:
        result_text = f"Error executing SQL Agent: {e}"

    return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {result_text}",
        "result": result_text
    }
    
# ===============================
# 🔹 Vector Agent Node
# ===============================
def vector_agent(state: QueryState):
    """Performs semantic search using pgvector and SentenceTransformer."""
    query = state["query"]
    context = state.get("context", "")
    try:
        # Step 1: Encode the query into vector
        query_vector = embed_model.encode(query)
        query_vector = np.array(query_vector, dtype=np.float32).tolist()

        # Step 2: Retrieve similar content
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT content, 1 - (embedding <=> %s::vector) AS similarity
            FROM powertrain_pdf_docs
            ORDER BY embedding <=> %s::vector
            LIMIT 3;
        """, (query_vector, query_vector))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            return {"result": "⚠️ No similar content found in vector DB."}

        context = "\n".join([r[0] for r in rows])

        # Step 3: LLM call with retrieved context
        prompt = f"""
        You are a helpful voice assistant for an automotive technician.
        Use the following context to answer the user's question.
        If there are multiple steps, just give one step and ask the user if they want to proceed for next step.
        If you don’t know the answer, politely say No.
        Be brief and clear.
       
        \n\n Context:\n{context}
        \n\n query: {query}
        """
        response = llm.invoke(prompt)
        first_answer=response.content.strip()
        return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {first_answer}",
        "result": first_answer}

    except Exception as e:
        return {"result": f"⚠️ Vector Agent Error: {e}"}

# ===============================
# 🔹 LangGraph Workflow
# ===============================
graph = StateGraph(QueryState)
graph.add_node("router", router_node)
graph.add_node("db_agent", db_agent)
graph.add_node("vector_agent", vector_agent)

def query_rewrite_node(state):
    orig = state.get("query", "")
    rewritten = rewrite_query_with_llm(orig)
    return {"rewritten_query": rewritten}

def embed_rewritten_node(state):
    rewritten = state.get("rewritten_query", "")
    vec = embed_with_sentence_transformer(rewritten)
    # store as list for serialization across graph
    return {"query_embedding": vec.tolist()}

def mmr_retrieve_node(state):
    qemb_list = state.get("query_embedding", None)
    if qemb_list is None:
        return {"context": ""}
    qemb = np.array(qemb_list, dtype=np.float32)
    docs = mmr_retrieve_from_pgvector(qemb, fetch_k=MMR_FETCH_K, top_k=MMR_RETURN_K, lambda_param=MMR_LAMBDA)
    context = "\n\n".join([f"[id:{d['id']}] {d['content']}" for d in docs])
    return {"context": context}

graph.add_node("rewrite_query", query_rewrite_node)
graph.add_node("embed_rewritten", embed_rewritten_node)
graph.add_node("mmr_retrieve", mmr_retrieve_node)

graph.add_conditional_edges(
    "router",
    lambda state:state["next"],
    {
        "db_agent": "db_agent",
        "vector_agent": "vector_agent"
    }
)

# Vector pipeline edges
graph.add_edge("rewrite_query", "embed_rewritten")
graph.add_edge("embed_rewritten", "mmr_retrieve")
graph.add_edge("mmr_retrieve", "vector_agent")

# Final edges to END
#END = "END"
graph.add_edge("db_agent", END)
graph.add_edge("vector_agent", END)
graph.set_entry_point("router")

# Compile graph
#from langgraph.checkpointer import MemorySaver
#checkpointer = MemorySaver()
#app = graph.compile(checkpointer=checkpointer)

#graph.add_edge("db_agent", END)
#graph.add_edge("vector_agent", END)
#graph.set_entry_point("router")

# Memory checkpoint
checkpointer = MemorySaver()
app = graph.compile(checkpointer=checkpointer)
config={"configurable":{"thread_id":"1"}}
#app = graph.compile()
#workflow = graph.compile()
# -----------------------------
# Azure STT
# -----------------------------
def azure_stt_from_file(audio_path):
    speech_config = speechsdk.SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
    audio_input = speechsdk.AudioConfig(filename=audio_path)
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_input)
    result = recognizer.recognize_once()
    if result.reason == speechsdk.ResultReason.RecognizedSpeech:
        return result.text
    return ""

# -----------------------------
# Azure TTS (returns bytes)
# -----------------------------
def azure_tts_to_bytes(text):
    speech_config = speechsdk.SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
    speech_config.speech_synthesis_voice_name = "en-US-JennyNeural"
    out_path = tempfile.mktemp(suffix=".wav")
    audio_output = speechsdk.AudioConfig(filename=out_path)
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_output)
    synthesizer.speak_text_async(text).get()
    with open(out_path, "rb") as f:
        audio_bytes = f.read()
    return audio_bytes

# -----------------------------
# Streamlit UI
# -----------------------------
st.title("🎤 Work Order Assistant")

if "history" not in st.session_state:
    st.session_state.history = []
    st.session_state.context = ""

if "messages" not in st.session_state:
    tts_1=gTTS(text="Hello! How can I help you today?", lang='en')
    mp3_bytes_1=io.BytesIO()
    tts_1.write_to_fp(mp3_bytes_1)
    mp3_bytes_1.seek(0)
    #st.success("speech generated")
    #st.audio(mp3_bytes, format="audio/mp3")
    b64_1 = base64.b64encode(mp3_bytes_1.read()).decode()
    # Autoplay HTML audio (hidden)
    audio_html_1 = f"""
    <audio autoplay="true" style="display:none;">
        <source src="data:audio/mp3;base64,{b64_1}" type="audio/mp3">
    </audio>
    """
    st.markdown(audio_html_1, unsafe_allow_html=True)
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! How can I help you today?"}
    ]
   

# Display chat messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])
        if "audio" in msg:
            st.audio(msg["audio"], format="audio/wav")
    
for msg in st.session_state.history:
    with st.chat_message(msg["role"]):
         st.markdown(msg["content"])
# -----------------------------
# Input: Mic or Text
# -----------------------------
col1, col2 = st.columns([1,1])

with col1:
    audio_bytes = st.audio_input("🎙️ Speak your query")

with col2:
    user_text = st.text_input("Or type your message here...")

# -----------------------------
# Function to process input
# -----------------------------
def process_input(query_text):
    if not query_text.strip():
        return
    #st.session_state.messages.append({"role": "user", "content": query_text})
    st.session_state.history.append({"role": "user", "content": query_text})
    output_state = app.invoke({"query": query_text,"context": st.session_state.context},config=config)
      # Run the LangGraph
    
    answer = output_state.get("result", "No response from LangGraph")
    
    #result = output_state.get("result", "⚠️ No result key found.")

    st.session_state.context = output_state.get("context", st.session_state.context)
    st.session_state.history.append({"role": "assistant", "content": answer})

    audio_out = azure_tts_to_bytes(answer)
    """
    st.session_state.messages.append({
            "role": "assistant",
            "content": answer,
            "audio": audio_out})
    """
    tts=gTTS(text=answer, lang='en')
    mp3_bytes=io.BytesIO()
    tts.write_to_fp(mp3_bytes)
    mp3_bytes.seek(0)
    #st.success("speech generated")
    #st.audio(mp3_bytes, format="audio/mp3")
    b64 = base64.b64encode(mp3_bytes.read()).decode()

        # Autoplay HTML audio (hidden)
    audio_html = f"""
    <audio autoplay="true" style="display:none;">
        <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
    </audio>
    """

    st.markdown(audio_html, unsafe_allow_html=True)
    st.success("✅ Speaking...")

if audio_bytes is not None:
    # Read raw bytes from UploadedFile
    audio_content = audio_bytes.read()  # ✅ Now this is bytes

    # Write to temporary WAV file
    temp_audio = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    temp_audio.write(audio_content)
    temp_audio.flush()

    # Send to Azure STT
    stt_text = azure_stt_from_file(temp_audio.name)
    process_input(stt_text)
# -----------------------------
# Process Text Input
# -----------------------------
st.session_state.chat_log = []
if user_text:
    process_input(user_text)
    #async for event in graph.astream_events({"messages":query_text},config,version='v2'):
     #   print(event)
    
with st.expander("🧠 Conversation History"):
        for role, msg in st.session_state.chat_log:
            st.markdown(f"**{role}**: {msg}")

with st.subheader("💬 Live Conversation"):
     for role, msg in st.session_state.chat_log:
        if role == "🧑":
            st.markdown(f"<div style='color:blue'><b>{role}</b>: {msg}</div>", unsafe_allow_html=True)
        else:
            st.markdown(f"<div style='color:green'><b>{role}</b>: {msg}</div>", unsafe_allow_html=True)

with st.expander("📜 Assistant Log"):
     if os.path.exists("assistant_log.txt"):
        with open("assistant_log.txt", "r", encoding="utf-8") as f:
             st.text(f.read())
     else:
        st.info("No logs yet.")

