import streamlit as st
import psycopg2
import numpy as np
from typing import TypedDict, Optional
from sentence_transformers import SentenceTransformer
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI

#from langgraph.checkpoint import MemorySaver

# ===============================
# 🔹 Define State using TypedDict
# ===============================
class QueryState(TypedDict):
    query: str
    result: Optional[str]
    context: Optional[str]

# ===============================
# 🔹 Azure OpenAI Configuration
# ===============================

# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


DB_URI='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'

EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
#engine = create_engine(DB_URI)
model = SentenceTransformer(EMBED_MODEL)


# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


# ===============================
# 🔹 SentenceTransformer Embedding
# ===============================
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ===============================
# 🔹 PostgreSQL Connection
# ===============================
def get_pg_connection():
    return psycopg2.connect(
        host="voiceassistantpsql.postgres.database.azure.com",
        dbname="voice_assistant_db",
        user="postgres",
        password="voice_password",
        port="5432"
    )

# ===============================
# 🔹 Router Node
# ===============================
def router_node(state: QueryState):
    """Decide whether to use SQL or vector search."""
    #q = state["query"].lower()
    q=state.get("query","").lower()
    #if q.strip().contains("work order") or " from " in q:
    if "work order" in q:
        next_node="db_agent"
    else:
        next_node="vector_agent"
    return {"next":next_node}

# ===============================
# 🔹 SQL Agent Node
# ===============================
def db_agent(state: QueryState):
    """Executes SQL queries directly in PostgreSQL."""
    query = state["query"]
    """
    try:
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute(query)
        rows = cur.fetchall()
        cur.close()
        conn.close()

        result = "\n".join(str(r) for r in rows)
        return {"result": f"✅ SQL Agent Result:\n{result}"}

    except Exception as e:
        return {"result": f"⚠️ SQL Error: {e}"}
    """
    
    db = SQLDatabase.from_uri(
        "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )

    
    sql_agent = create_sql_agent(
        llm=llm,
        db=db,
        verbose=True,
        top_k=5,  # optional
        agent_type="openai-tools",  # use the new LCEL-compatible type
    )

    # Run user query through the SQL agent
    try:
        result = sql_agent.invoke({"input": query})
        if isinstance(result,dict):
            answer = result.get("output", "No result returned.")
        else:
            answer=str(result)
        if not answer:
            answer="no matching records"
    except Exception as e:
        answer = f"DB Agent Error: {str(e)}"

    return {"answer": answer}
# ===============================
# 🔹 Vector Agent Node
# ===============================
def vector_agent(state: QueryState):
    """Performs semantic search using pgvector and SentenceTransformer."""
    query = state["query"]
    try:
        # Step 1: Encode the query into vector
        query_vector = embed_model.encode(query)
        query_vector = np.array(query_vector, dtype=np.float32).tolist()

        # Step 2: Retrieve similar content
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT content, 1 - (embedding <=> %s::vector) AS similarity
            FROM powertrain_pdf_docs
            ORDER BY embedding <=> %s::vector
            LIMIT 3;
        """, (query_vector, query_vector))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            return {"result": "⚠️ No similar content found in vector DB."}

        context = "\n".join([r[0] for r in rows])

        # Step 3: LLM call with retrieved context
        prompt = f"Use this context to answer the query.\n\nContext:\n{context}\n\nQuestion: {query}"
        response = llm.invoke(prompt)

        return {"result": response.content, "context": context}

    except Exception as e:
        return {"result": f"⚠️ Vector Agent Error: {e}"}

# ===============================
# 🔹 LangGraph Workflow
# ===============================
graph = StateGraph(QueryState)
graph.add_node("router", router_node)
graph.add_node("db_agent", db_agent)
graph.add_node("vector_agent", vector_agent)

graph.add_conditional_edges(
    "router",
    lambda state:state["next"],
    {
        "db_agent": "db_agent",
        "vector_agent": "vector_agent"
    }
)

graph.add_edge("db_agent", END)
graph.add_edge("vector_agent", END)
graph.set_entry_point("router")

# Memory checkpoint
#checkpointer = MemorySaver()
#app = graph.compile(checkpointer=checkpointer)
app = graph.compile()

# ===============================
# 🔹 Streamlit UI
# ===============================
st.title("🧭 LangGraph + Azure OpenAI + SentenceTransformer + PostgreSQL (pgvector)")

query = st.text_input("Enter your question or SQL query:")

if st.button("Run"):
    if not query.strip():
        st.warning("Please enter a query.")
    else:
        input_state = {"query": query, "result": None, "context": None}
        output_state = app.invoke(input_state)

        st.subheader("🧩 Graph Output State")
        st.json(output_state)

        result = output_state.get("result", "⚠️ No result returned.")
        st.success(result)

        if output_state.get("context"):
            st.subheader("🔍 Retrieved Context")
            st.info(output_state["context"])
