"""
Wake Word Detection API Views

Implements RESTful endpoints for wake word detection control and monitoring
as specified in the WAKE_WORD_USAGE.md documentation.
"""

import json
import logging
import time
from typing import Optional, Dict, Any

from django.http import JsonResponse, StreamingHttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.utils.decorators import method_decorator
from django.conf import settings
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated

from .detector import WakeWordDetector, VoiceAssistantWithWakeWord, WakeWordDetection
from .models import WakeWordSession, WakeWordDetectionEvent, WakeWordSettings

logger = logging.getLogger(__name__)

# Global wake word detector instance
_global_detector: Optional[WakeWordDetector] = None
_global_assistant: Optional[VoiceAssistantWithWakeWord] = None


class WakeWordAPIView(APIView):
    """Base API view for wake word detection endpoints"""
    
    permission_classes = [IsAuthenticated]
    
    def get_user_settings(self):
        """Get or create user-specific wake word settings"""
        try:
            return WakeWordSettings.get_default_settings(user=self.request.user)
        except Exception as e:
            logger.error(f"Error getting user settings: {e}")
            return None


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def start_wake_word(request):
    """
    Start wake word detection
    POST /api/v1/wakeword/start
    """
    global _global_detector, _global_assistant
    
    try:
        # Check if already running
        if _global_detector and _global_detector.is_listening:
            return Response({
                "status": "success",
                "message": "Wake word detection is already running",
                "wake_word": _global_detector.wake_word,
                "listening": True
            })
        
        # Get user settings
        try:
            user_settings = WakeWordSettings.get_default_settings(user=request.user)
            wake_word = user_settings.wake_word_phrase
            confidence_threshold = user_settings.confidence_threshold
            language = user_settings.language
        except Exception as e:
            logger.warning(f"Could not get user settings, using defaults: {e}")
            wake_word = "hey buddy"
            confidence_threshold = 0.7
            language = "en-US"
        
        # Create voice assistant with wake word detection
        _global_assistant = VoiceAssistantWithWakeWord(wake_word=wake_word)
        _global_detector = _global_assistant.start()
        
        if _global_detector:
            # Create session record
            session = WakeWordSession.objects.create(
                user=request.user,
                session_id=_global_detector.session_id,
                wake_word_phrase=wake_word,
                confidence_threshold=confidence_threshold,
                language=language,
                is_active=True,
                azure_region=getattr(settings, 'AZURE_SPEECH_REGION', ''),
                client_ip=get_client_ip(request),
                user_agent=request.META.get('HTTP_USER_AGENT', '')
            )
            
            logger.info(f"Wake word detection started for user {request.user.username}")
            
            return Response({
                "status": "success",
                "message": "Wake word detection started",
                "wake_word": wake_word,
                "listening": True,
                "session_id": _global_detector.session_id,
                "confidence_threshold": confidence_threshold
            })
        else:
            return Response({
                "status": "error",
                "message": "Failed to start wake word detection",
                "listening": False
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
    except Exception as e:
        logger.error(f"Error starting wake word detection: {e}")
        return Response({
            "status": "error",
            "message": f"Failed to start wake word detection: {str(e)}",
            "listening": False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def stop_wake_word(request):
    """
    Stop wake word detection
    POST /api/v1/wakeword/stop
    """
    global _global_detector, _global_assistant
    
    try:
        if not _global_detector or not _global_detector.is_listening:
            return Response({
                "status": "success",
                "message": "Wake word detection is not running",
                "listening": False
            })
        
        # Stop the assistant
        if _global_assistant:
            _global_assistant.stop()
        
        # End active sessions
        WakeWordSession.objects.filter(
            user=request.user,
            is_active=True
        ).update(
            is_active=False,
            ended_at=timezone.now()
        )
        
        _global_detector = None
        _global_assistant = None
        
        logger.info(f"Wake word detection stopped for user {request.user.username}")
        
        return Response({
            "status": "success",
            "message": "Wake word detection stopped",
            "listening": False
        })
        
    except Exception as e:
        logger.error(f"Error stopping wake word detection: {e}")
        return Response({
            "status": "error",
            "message": f"Failed to stop wake word detection: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def wake_word_status(request):
    """
    Get wake word detection status
    GET /api/v1/wakeword/status
    """
    global _global_detector
    
    try:
        if _global_detector:
            detector_status = _global_detector.get_status()
            
            # Get recent detections from database
            recent_detections = []
            recent_events = WakeWordDetectionEvent.objects.filter(
                session__user=request.user,
                wake_word_detected=True
            ).order_by('-timestamp')[:5]
            
            for event in recent_events:
                recent_detections.append({
                    "timestamp": event.timestamp.timestamp(),
                    "wake_word_detected": event.wake_word_detected,
                    "full_text": event.full_text,
                    "command_text": event.command_text,
                    "confidence": event.confidence_score,
                    "session_id": event.session.session_id
                })
            
            return Response({
                "status": "success",
                "listening": detector_status.get("listening", False),
                "processing": detector_status.get("processing", False),
                "wake_word": detector_status.get("wake_word", ""),
                "detection_count": detector_status.get("detection_count", 0),
                "session_id": detector_status.get("session_id", ""),
                "confidence_threshold": detector_status.get("confidence_threshold", 0.7),
                "language": detector_status.get("language", "en-US"),
                "uptime_seconds": detector_status.get("uptime_seconds", 0),
                "recent_detections": recent_detections,
                "voice_pipeline_available": detector_status.get("voice_pipeline_available", False)
            })
        else:
            return Response({
                "status": "success",
                "listening": False,
                "processing": False,
                "wake_word": "",
                "detection_count": 0,
                "recent_detections": []
            })
            
    except Exception as e:
        logger.error(f"Error getting wake word status: {e}")
        return Response({
            "status": "error",
            "message": f"Failed to get status: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def process_wake_word_command(request):
    """
    Process a wake word command through the pipeline
    POST /api/v1/wakeword/process
    """
    try:
        data = json.loads(request.body)
        command_text = data.get('command_text', '').strip()
        
        if not command_text:
            return Response({
                "status": "error",
                "message": "command_text is required"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        logger.info(f"Processing wake word command: '{command_text}'")
        
        # Process through voice assistant pipeline
        try:
            from voice_assistant.postgres_service import get_postgres_vector_service
            
            voice_pipeline = get_postgres_vector_service("general_docs")
            result = voice_pipeline.search_similar(
                query=command_text,
                max_results=3,
                similarity_threshold=0.5
            )
            
            if result["status"] == "success":
                return Response({
                    "status": "success",
                    "command_text": command_text,
                    "summary": result.get("summary", ""),
                    "relevant_chunks": result.get("relevant_chunks", []),
                    "wake_word_triggered": True,
                    "processing_time_ms": result.get("processing_time_ms", 0)
                })
            else:
                return Response({
                    "status": "error",
                    "message": f"Voice pipeline failed: {result.get('error', 'Unknown error')}",
                    "command_text": command_text
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                
        except ImportError:
            return Response({
                "status": "error",
                "message": "Voice assistant pipeline not available",
                "command_text": command_text
            }, status=status.HTTP_503_SERVICE_UNAVAILABLE)
            
    except json.JSONDecodeError:
        return Response({
            "status": "error",
            "message": "Invalid JSON in request body"
        }, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        logger.error(f"Error processing wake word command: {e}")
        return Response({
            "status": "error",
            "message": f"Failed to process command: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@csrf_exempt
@require_http_methods(["GET"])
def wake_word_stream(request):
    """
    Stream wake word detections using Server-Sent Events
    GET /api/v1/wakeword/stream
    """
    global _global_detector
    
    def event_stream():
        """Generate Server-Sent Events for wake word detections"""
        yield 'data: {"status": "connected", "message": "Wake word stream started"}\n\n'
        
        last_check = time.time()
        
        while True:
            try:
                if _global_detector and _global_detector.is_listening:
                    # Get recent detection
                    detection = _global_detector.get_recent_detection(timeout=1.0)
                    
                    if detection:
                        detection_data = {
                            "timestamp": detection.timestamp,
                            "wake_word_detected": detection.wake_word_detected,
                            "full_text": detection.full_text,
                            "command_text": detection.command_text,
                            "confidence": detection.confidence,
                            "session_id": detection.session_id,
                            "processing_time_ms": detection.processing_time_ms
                        }
                        yield f'data: {json.dumps(detection_data)}\n\n'
                    
                    # Send periodic heartbeat
                    current_time = time.time()
                    if current_time - last_check > 30:  # Every 30 seconds
                        heartbeat = {
                            "status": "heartbeat",
                            "listening": _global_detector.is_listening,
                            "timestamp": current_time
                        }
                        yield f'data: {json.dumps(heartbeat)}\n\n'
                        last_check = current_time
                else:
                    # Not listening, send status update
                    status_update = {
                        "status": "not_listening",
                        "message": "Wake word detection is not active",
                        "timestamp": time.time()
                    }
                    yield f'data: {json.dumps(status_update)}\n\n'
                    time.sleep(5)  # Check every 5 seconds when not listening
                    
            except Exception as e:
                error_data = {
                    "status": "error",
                    "message": f"Stream error: {str(e)}",
                    "timestamp": time.time()
                }
                yield f'data: {json.dumps(error_data)}\n\n'
                time.sleep(2)
    
    response = StreamingHttpResponse(
        event_stream(),
        content_type='text/event-stream'
    )
    response['Cache-Control'] = 'no-cache'
    response['Connection'] = 'keep-alive'
    response['Access-Control-Allow-Origin'] = '*'
    response['Access-Control-Allow-Headers'] = 'Cache-Control'
    
    return response


def get_client_ip(request):
    """Get client IP address from request"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


# Class-based views for more complex functionality
class WakeWordSettingsView(APIView):
    """Manage wake word settings"""
    
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """Get user's wake word settings"""
        try:
            settings = WakeWordSettings.get_default_settings(user=request.user)
            
            return Response({
                "status": "success",
                "settings": {
                    "wake_word_phrase": settings.wake_word_phrase,
                    "confidence_threshold": settings.confidence_threshold,
                    "language": settings.language,
                    "microphone_sensitivity": settings.microphone_sensitivity,
                    "noise_suppression": settings.noise_suppression,
                    "auto_gain_control": settings.auto_gain_control,
                    "max_command_length_seconds": settings.max_command_length_seconds,
                    "processing_timeout_seconds": settings.processing_timeout_seconds,
                    "enable_continuous_listening": settings.enable_continuous_listening,
                    "enable_voice_assistant": settings.enable_voice_assistant,
                    "enable_tts_response": settings.enable_tts_response,
                    "default_collection_name": settings.default_collection_name
                }
            })
            
        except Exception as e:
            logger.error(f"Error getting wake word settings: {e}")
            return Response({
                "status": "error",
                "message": f"Failed to get settings: {str(e)}"
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def post(self, request):
        """Update wake word settings"""
        try:
            data = request.data
            settings = WakeWordSettings.get_default_settings(user=request.user)
            
            # Update settings fields
            if 'wake_word_phrase' in data:
                settings.wake_word_phrase = data['wake_word_phrase']
            if 'confidence_threshold' in data:
                settings.confidence_threshold = float(data['confidence_threshold'])
            if 'language' in data:
                settings.language = data['language']
            if 'microphone_sensitivity' in data:
                settings.microphone_sensitivity = float(data['microphone_sensitivity'])
            if 'noise_suppression' in data:
                settings.noise_suppression = bool(data['noise_suppression'])
            if 'auto_gain_control' in data:
                settings.auto_gain_control = bool(data['auto_gain_control'])
            if 'enable_voice_assistant' in data:
                settings.enable_voice_assistant = bool(data['enable_voice_assistant'])
            if 'enable_tts_response' in data:
                settings.enable_tts_response = bool(data['enable_tts_response'])
            
            settings.save()
            
            logger.info(f"Wake word settings updated for user {request.user.username}")
            
            return Response({
                "status": "success",
                "message": "Settings updated successfully"
            })
            
        except Exception as e:
            logger.error(f"Error updating wake word settings: {e}")
            return Response({
                "status": "error",
                "message": f"Failed to update settings: {str(e)}"
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class WakeWordAnalyticsView(APIView):
    """Wake word analytics and statistics"""
    
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """Get wake word analytics"""
        try:
            from datetime import datetime, timedelta
            from django.db.models import Sum, Avg, Count
            
            # Get date range (default to last 7 days)
            days = int(request.GET.get('days', 7))
            start_date = timezone.now().date() - timedelta(days=days)
            
            # Get user's sessions
            sessions = WakeWordSession.objects.filter(
                user=request.user,
                started_at__date__gte=start_date
            )
            
            # Get detection events
            events = WakeWordDetectionEvent.objects.filter(
                session__user=request.user,
                timestamp__date__gte=start_date
            )
            
            # Calculate statistics
            total_sessions = sessions.count()
            total_detections = events.filter(wake_word_detected=True).count()
            successful_commands = events.filter(processing_successful=True).count()
            failed_commands = events.filter(was_processed=True, processing_successful=False).count()
            
            avg_confidence = events.filter(wake_word_detected=True).aggregate(
                avg_conf=Avg('confidence_score')
            )['avg_conf'] or 0
            
            avg_processing_time = events.filter(processing_time_ms__gt=0).aggregate(
                avg_time=Avg('processing_time_ms')
            )['avg_time'] or 0
            
            # Success rate
            total_commands = successful_commands + failed_commands
            success_rate = (successful_commands / total_commands * 100) if total_commands > 0 else 0
            
            return Response({
                "status": "success",
                "analytics": {
                    "period_days": days,
                    "total_sessions": total_sessions,
                    "total_detections": total_detections,
                    "successful_commands": successful_commands,
                    "failed_commands": failed_commands,
                    "success_rate_percentage": round(success_rate, 2),
                    "average_confidence": round(avg_confidence, 3),
                    "average_processing_time_ms": round(avg_processing_time, 2),
                    "most_active_day": "Not implemented yet",  # TODO: Implement
                    "common_commands": "Not implemented yet"   # TODO: Implement
                }
            })
            
        except Exception as e:
            logger.error(f"Error getting wake word analytics: {e}")
            return Response({
                "status": "error",
                "message": f"Failed to get analytics: {str(e)}"
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)