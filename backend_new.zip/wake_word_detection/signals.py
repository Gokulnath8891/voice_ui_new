"""
Wake Word Detection Django Signals

Signal handlers for automatic analytics updates and session management.
"""

import logging
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from django.utils import timezone

from .models import WakeWordDetectionEvent, WakeWordSession, WakeWordAnalytics

logger = logging.getLogger(__name__)


@receiver(post_save, sender=WakeWordDetectionEvent)
def update_analytics_on_detection(sender, instance, created, **kwargs):
    """
    Update analytics when new detection event is created
    
    This signal is already defined in models.py but we can add additional
    processing here if needed.
    """
    if created:
        logger.debug(f"New detection event created: {instance.id}")
        
        # Additional processing could go here
        # For example, triggering notifications, webhooks, etc.
        
        # Check if we should trigger any notifications
        if hasattr(instance.session, 'user') and instance.session.user:
            user_settings = instance.session.user.wakeworksettings_set.filter(is_active=True).first()
            if user_settings and user_settings.enable_detection_logging:
                logger.info(f"Wake word detected for user {instance.session.user.username}: {instance.command_text}")


@receiver(pre_delete, sender=WakeWordSession)
def cleanup_session_on_delete(sender, instance, **kwargs):
    """Clean up related data when session is deleted"""
    logger.info(f"Cleaning up session: {instance.session_id}")
    
    # End the session if it's still active
    if instance.is_active:
        instance.is_active = False
        instance.ended_at = timezone.now()
        instance.save()


# Additional signals for session management
@receiver(post_save, sender=WakeWordSession)
def handle_session_creation(sender, instance, created, **kwargs):
    """Handle new session creation"""
    if created:
        logger.info(f"New wake word session created: {instance.session_id} for user {instance.user}")
        
        # Could add session initialization logic here
        # For example, setting up monitoring, notifications, etc.