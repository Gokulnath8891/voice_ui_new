"""
Django Management Command: Wake Word Test

Usage:
    python manage.py wake_word_test
    python manage.py wake_word_test --basic
    python manage.py wake_word_test --interactive
"""

import os
import time
import signal
import sys
from django.core.management.base import BaseCommand, CommandError

from wake_word_detection.detector import WakeWordDetector, VoiceAssistantWithWakeWord


class Command(BaseCommand):
    help = 'Test wake word detection functionality'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.detector = None
        self.assistant = None
        self.running = False

    def add_arguments(self, parser):
        parser.add_argument(
            '--basic',
            action='store_true',
            help='Run basic wake word detection test'
        )
        parser.add_argument(
            '--interactive',
            action='store_true',
            help='Run interactive test mode'
        )
        parser.add_argument(
            '--duration',
            type=int,
            default=60,
            help='Test duration in seconds (default: 60)'
        )
        parser.add_argument(
            '--wake-word',
            default='hey buddy',
            help='Wake word to test (default: "hey buddy")'
        )

    def signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        self.stdout.write("\n🛑 Test interrupted...")
        self.cleanup()
        sys.exit(0)

    def cleanup(self):
        """Cleanup resources"""
        self.running = False
        if self.detector:
            self.detector.cleanup()
        if self.assistant:
            self.assistant.stop()

    def test_basic(self, wake_word, duration):
        """Basic wake word detection test"""
        self.stdout.write("🧪 Running Basic Wake Word Test")
        self.stdout.write("=" * 40)

        detection_count = 0

        def test_callback(command_text):
            nonlocal detection_count
            detection_count += 1
            self.stdout.write(f"✅ Detection #{detection_count}: '{command_text}'")

        try:
            # Create detector
            self.detector = WakeWordDetector(
                wake_word=wake_word,
                callback=test_callback,
                confidence_threshold=0.7
            )

            self.stdout.write(f"🎤 Testing wake word: '{wake_word}'")
            self.stdout.write(f"⏱️ Duration: {duration} seconds")
            self.stdout.write("💬 Try saying the wake word followed by any command")

            if self.detector.start_listening():
                self.stdout.write("✅ Detection started")
                
                # Run test for specified duration
                end_time = time.time() + duration
                self.running = True
                
                while self.running and time.time() < end_time and self.detector.is_listening:
                    remaining = int(end_time - time.time())
                    if remaining % 15 == 0 and remaining > 0:
                        self.stdout.write(f"⏰ {remaining} seconds remaining...")
                        time.sleep(1)
                    time.sleep(1)

                # Test results
                self.stdout.write(f"\n📊 Test Results:")
                self.stdout.write(f"   • Duration: {duration} seconds")
                self.stdout.write(f"   • Detections: {detection_count}")
                self.stdout.write(f"   • Rate: {detection_count/duration:.3f} detections/sec")
                self.stdout.write(f"   • Status: {'✅ PASS' if detection_count > 0 else '⚠️ NO DETECTIONS'}")
                
            else:
                raise CommandError("Failed to start wake word detection")

        except Exception as e:
            raise CommandError(f"Basic test failed: {e}")

    def test_interactive(self, wake_word):
        """Interactive wake word test"""
        self.stdout.write("🎯 Interactive Wake Word Test")
        self.stdout.write("=" * 40)

        def interactive_callback(command_text):
            self.stdout.write(f"\n✅ WAKE WORD DETECTED!")
            self.stdout.write(f"📝 Command: '{command_text}'")
            self.stdout.write(f"⏰ Time: {time.strftime('%H:%M:%S')}")
            self.stdout.write("🎤 Listening for next command...")

        try:
            # Create detector
            self.detector = WakeWordDetector(
                wake_word=wake_word,
                callback=interactive_callback,
                confidence_threshold=0.7
            )

            self.stdout.write(f"🎤 Interactive test with wake word: '{wake_word}'")
            self.stdout.write("🎯 Example commands:")
            self.stdout.write(f"   • '{wake_word}, how does the engine work?'")
            self.stdout.write(f"   • '{wake_word}, what is brake maintenance?'")
            self.stdout.write(f"   • '{wake_word}, tell me about airbags'")
            self.stdout.write("\n🛑 Press Ctrl+C to stop")

            if self.detector.start_listening():
                self.stdout.write("✅ Interactive test started")
                self.stdout.write("🎧 Listening...")

                # Keep running until interrupted
                self.running = True
                start_time = time.time()

                while self.running and self.detector.is_listening:
                    time.sleep(1)
                    
                    # Show periodic status
                    if int(time.time() - start_time) % 30 == 0 and int(time.time() - start_time) > 0:
                        status = self.detector.get_status()
                        self.stdout.write(f"\n📊 Status: {status['detection_count']} detections so far")
                        time.sleep(1)  # Prevent duplicate messages

            else:
                raise CommandError("Failed to start interactive test")

        except KeyboardInterrupt:
            self.stdout.write("\n⏹️ Interactive test stopped by user")
        except Exception as e:
            raise CommandError(f"Interactive test failed: {e}")

    def handle(self, *args, **options):
        # Setup signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)

        # Check Azure credentials
        if not os.getenv('AZURE_SPEECH_KEY') or not os.getenv('AZURE_SPEECH_REGION'):
            raise CommandError(
                'Azure Speech credentials not configured. '
                'Set AZURE_SPEECH_KEY and AZURE_SPEECH_REGION environment variables.'
            )

        wake_word = options['wake_word']
        duration = options['duration']

        self.stdout.write("🎤 Wake Word Detection Test Suite")
        self.stdout.write("=" * 50)
        self.stdout.write(f"✅ Azure region: {os.getenv('AZURE_SPEECH_REGION')}")

        try:
            if options['basic']:
                self.test_basic(wake_word, duration)
            elif options['interactive']:
                self.test_interactive(wake_word)
            else:
                # Default: run basic test
                self.test_basic(wake_word, duration)

        except KeyboardInterrupt:
            self.stdout.write("\n⏹️ Test interrupted by user")
        except Exception as e:
            self.cleanup()
            raise CommandError(f"Test failed: {e}")
        finally:
            self.cleanup()
            self.stdout.write("🧹 Test cleanup completed")