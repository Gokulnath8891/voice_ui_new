import streamlit as st
from streamlit_chat_widget import chat_input_widget
from streamlit_extras.bottom_container import bottom #pip install streamlit_extras

def main():
    st.title("My Custom Chat Application")
    
    # Initialize chat history in Streamlit session state
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    # Display the chat history
    for message in st.session_state.chat_history:
        st.write(message)

    # Display the chat input widget at the bottom
    with bottom():
        user_input = chat_input_widget()

    # Process the user's input from the widget
    if user_input:
        if "text" in user_input:
            user_text =user_input["text"]
            st.session_state.chat_history.append(f"You: {user_text}")
        elif "audioFile" in user_input:
            audio_bytes = bytes(user_input["audioFile"])
            st.audio(audio_bytes)

if __name__ == "__main__":
    main()