import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FeedbackService } from './feedback.service';
import { AuthService } from './auth.service';
import { environment } from 'src/environments/environment';

describe('FeedbackService', () => {
  let service: FeedbackService;
  let httpMock: HttpTestingController;
  let authService: jasmine.SpyObj<AuthService>;

  beforeEach(() => {
    const authServiceSpy = jasmine.createSpyObj('AuthService', ['getToken']);

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        FeedbackService,
        { provide: AuthService, useValue: authServiceSpy }
      ]
    });

    service = TestBed.inject(FeedbackService);
    httpMock = TestBed.inject(HttpTestingController);
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should submit feedback successfully', () => {
    const mockToken = 'test-token';
    const mockResponse = { status: 'success', message: 'Feedback recorded successfully' };
    
    authService.getToken.and.returnValue(mockToken);

    service.submitFeedback('session-123', 1, 'positive', 'Great response!').subscribe(
      response => {
        expect(response.status).toBe('success');
        expect(response.message).toBe('Feedback recorded successfully');
      }
    );

    const req = httpMock.expectOne(`${environment.apiUrl}/chat/feedback/`);
    expect(req.request.method).toBe('POST');
    expect(req.request.headers.get('Authorization')).toBe(`Bearer ${mockToken}`);
    expect(req.request.body).toEqual({
      session_id: 'session-123',
      step_number: 1,
      feedback: 'positive',
      notes: 'Great response!'
    });

    req.flush(mockResponse);
  });

  it('should get feedback history', () => {
    const mockToken = 'test-token';
    const mockFeedbacks = {
      feedbacks: [
        { id: 1, session_id: 'session-123', step_number: 1, feedback: 'positive', notes: '', created_at: '2025-12-10' }
      ]
    };
    
    authService.getToken.and.returnValue(mockToken);

    service.getFeedbackHistory(123).subscribe(
      response => {
        expect(response.feedbacks.length).toBe(1);
        expect(response.feedbacks[0].feedback).toBe('positive');
      }
    );

    const req = httpMock.expectOne(`${environment.apiUrl}/workorder/123/feedback/`);
    expect(req.request.method).toBe('GET');
    expect(req.request.headers.get('Authorization')).toBe(`Bearer ${mockToken}`);

    req.flush(mockFeedbacks);
  });
});
