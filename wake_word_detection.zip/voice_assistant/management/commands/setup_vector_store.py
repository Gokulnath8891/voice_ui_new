from django.core.management.base import BaseCommand, CommandError
from django.db import connection
import json


class Command(BaseCommand):
    help = 'Setup PostgreSQL vector store with sample data'

    def add_arguments(self, parser):
        parser.add_argument(
            '--collection-name',
            type=str,
            default='default',
            help='Name of the vector collection to create'
        )
        parser.add_argument(
            '--sample-data',
            action='store_true',
            help='Add sample documents for testing'
        )
        parser.add_argument(
            '--reset',
            action='store_true',
            help='Reset existing collection (WARNING: This will delete all data)'
        )

    def handle(self, *args, **options):
        collection_name = options['collection_name']
        
        self.stdout.write(
            self.style.SUCCESS(f'Setting up vector store: {collection_name}')
        )
        
        try:
            # Import models
            from voice_assistant.vector_models import DocumentCollection, DocumentChunk
            from voice_assistant.postgres_service import get_postgres_vector_service
            
            # Reset collection if requested
            if options['reset']:
                if DocumentCollection.objects.filter(name=collection_name).exists():
                    self.stdout.write(
                        self.style.WARNING(f'Resetting collection: {collection_name}')
                    )
                    DocumentCollection.objects.filter(name=collection_name).delete()
            
            # Initialize vector service (this creates the collection)
            vector_service = get_postgres_vector_service(collection_name)
            
            self.stdout.write(
                self.style.SUCCESS(f'✓ Collection "{collection_name}" initialized')
            )
            
            # Add sample data if requested
            if options['sample_data']:
                self.add_sample_documents(vector_service)
            
            # Display collection stats
            stats = vector_service.get_collection_stats()
            self.stdout.write('\nCollection Statistics:')
            self.stdout.write(f'  Name: {stats["name"]}')
            self.stdout.write(f'  Total Documents: {stats["total_documents"]}')
            self.stdout.write(f'  Embedding Model: {stats["embedding_model"]}')
            self.stdout.write(f'  Embedding Dimension: {stats["embedding_dimension"]}')
            self.stdout.write(f'  Active: {stats["is_active"]}')
            
            if 'total_searches' in stats:
                self.stdout.write(f'  Total Searches: {stats["total_searches"]}')
                self.stdout.write(f'  Avg Search Time: {stats["average_search_time_ms"]}ms')
            
            self.stdout.write(
                self.style.SUCCESS('\n✓ Vector store setup completed!')
            )
            
        except ImportError as e:
            raise CommandError(f'Vector models not available. Ensure PostgreSQL with pgvector is configured: {e}')
        except Exception as e:
            raise CommandError(f'Error setting up vector store: {e}')

    def add_sample_documents(self, vector_service):
        """Add sample documents for testing"""
        sample_docs = [
            {
                'content': 'Machine learning is a subset of artificial intelligence that focuses on algorithms that can learn from data without being explicitly programmed.',
                'metadata': {'topic': 'machine_learning', 'difficulty': 'beginner'},
                'source': 'ml_basics.txt',
                'source_type': 'text',
                'chunk_index': 1
            },
            {
                'content': 'Deep learning uses neural networks with multiple layers to model and understand complex patterns in data. It is particularly effective for image recognition and natural language processing.',
                'metadata': {'topic': 'deep_learning', 'difficulty': 'intermediate'},
                'source': 'deep_learning_guide.txt',
                'source_type': 'text',
                'chunk_index': 1
            },
            {
                'content': 'Natural language processing (NLP) is a branch of artificial intelligence that helps computers understand, interpret and manipulate human language.',
                'metadata': {'topic': 'nlp', 'difficulty': 'beginner'},
                'source': 'nlp_intro.txt',
                'source_type': 'text',
                'chunk_index': 1
            },
            {
                'content': 'Vector databases store high-dimensional vectors and enable fast similarity searches. They are essential for applications like recommendation systems and semantic search.',
                'metadata': {'topic': 'vector_databases', 'difficulty': 'intermediate'},
                'source': 'vector_db_overview.txt',
                'source_type': 'text',
                'chunk_index': 1
            },
            {
                'content': 'Large language models (LLMs) are neural networks trained on vast amounts of text data. They can generate human-like text and perform various language tasks.',
                'metadata': {'topic': 'llm', 'difficulty': 'advanced'},
                'source': 'llm_explained.txt',
                'source_type': 'text',
                'chunk_index': 1
            }
        ]
        
        self.stdout.write('Adding sample documents...')
        count = vector_service.add_documents(sample_docs)
        self.stdout.write(
            self.style.SUCCESS(f'✓ Added {count} sample documents')
        )
        
        # Test search
        self.stdout.write('\nTesting search functionality...')
        result = vector_service.search_similar("What is machine learning?", max_results=3)
        
        if result['status'] == 'success':
            self.stdout.write(f'✓ Search test successful! Found {len(result["relevant_chunks"])} results')
            self.stdout.write(f'  Processing time: {result["processing_time_ms"]}ms')
            
            for i, chunk in enumerate(result['relevant_chunks'][:2]):
                self.stdout.write(f'  Result {i+1}: {chunk["similarity_score"]:.3f} similarity')
                self.stdout.write(f'    {chunk["content"][:100]}...')
        else:
            self.stdout.write(
                self.style.ERROR(f'✗ Search test failed: {result.get("error", "Unknown error")}')
            )