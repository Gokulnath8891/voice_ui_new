import secrets
import string
alphabet = string.ascii_letters + string.digits

# for a 20-character password
password = ''.join(secrets.choice(alphabet) for i in range(50))

print("Password Generated..")
print(password)