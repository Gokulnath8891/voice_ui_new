import streamlit as st
import requests
import time

API = "http://localhost:8000"

st.title("Wake Word Detection (Azure STT + Streamlit)")

#if st.button("Start Listening"):
requests.get(f"{API}/start")
st.success("Listening for speech...")

last_text_box = st.empty()
wake_box = st.empty()

while True:
      data = requests.get(f"{API}/status").json()

      last_text_box.write(f"**Detected speech:** `{data['last_text']}`")

      if data["wake_detected"]:
         wake_box.success("✅ Wake word **HEY BUDDY** detected!")
         break

      time.sleep(0.3)

