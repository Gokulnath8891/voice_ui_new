#!/usr/bin/env python
"""
Voice-Friendly Work Order Proxy System
Provides easy-to-say numeric aliases for complex work order IDs
"""

import os
import sys
import django
from pathlib import Path

# Setup Django
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
django.setup()

import re
from typing import Optional, Dict, List, Tuple
from django.core.cache import cache
from workorders.models import WorkOrder


class VoiceWorkOrderProxy:
    """Maps voice-friendly numeric IDs to actual work order numbers"""
    
    def __init__(self):
        self.cache_timeout = 3600  # 1 hour
        self.cache_key_prefix = "voice_proxy_"
    
    def _get_cached_mapping(self) -> Dict[int, str]:
        """Get cached mapping of voice IDs to work order numbers"""
        return cache.get(f"{self.cache_key_prefix}mapping", {})
    
    def _set_cached_mapping(self, mapping: Dict[int, str]):
        """Cache the mapping of voice IDs to work order numbers"""
        cache.set(f"{self.cache_key_prefix}mapping", mapping, self.cache_timeout)
    
    def _get_reverse_mapping(self) -> Dict[str, int]:
        """Get reverse mapping from work order numbers to voice IDs"""
        return cache.get(f"{self.cache_key_prefix}reverse", {})
    
    def _set_reverse_mapping(self, reverse_mapping: Dict[str, int]):
        """Cache the reverse mapping"""
        cache.set(f"{self.cache_key_prefix}reverse", reverse_mapping, self.cache_timeout)
    
    def generate_voice_mapping(self, user_id: Optional[int] = None) -> Dict[int, Dict]:
        """Generate voice-friendly mappings for work orders assigned to a user"""
        try:
            # Get work orders for the user or all if no user specified
            if user_id:
                work_orders = WorkOrder.objects.filter(technician=user_id).order_by('id')
            else:
                work_orders = WorkOrder.objects.all().order_by('id')
            
            mapping = {}
            reverse_mapping = {}
            voice_id = 1
            
            for wo in work_orders:
                mapping[voice_id] = {
                    'order_number': wo.order_number,
                    'description': wo.description[:50] + "..." if len(wo.description) > 50 else wo.description,
                    'vehicle': str(wo.vehicle) if wo.vehicle else "Unknown Vehicle",
                    'status': wo.status,
                    'priority': wo.priority
                }
                reverse_mapping[wo.order_number] = voice_id
                voice_id += 1
            
            # Cache the mappings
            self._set_cached_mapping({k: v['order_number'] for k, v in mapping.items()})
            self._set_reverse_mapping(reverse_mapping)
            
            return mapping
            
        except Exception as e:
            print(f"❌ Error generating voice mapping: {e}")
            return {}
    
    def get_work_order_by_voice_id(self, voice_id: int) -> Optional[str]:
        """Get actual work order number from voice ID"""
        mapping = self._get_cached_mapping()
        return mapping.get(voice_id)
    
    def get_voice_id_by_work_order(self, order_number: str) -> Optional[int]:
        """Get voice ID from work order number"""
        reverse_mapping = self._get_reverse_mapping()
        return reverse_mapping.get(order_number)
    
    def extract_voice_command_work_order(self, text: str) -> Optional[str]:
        """Extract work order from voice command using various patterns"""
        text_lower = text.lower().strip()
        
        # Voice-friendly patterns that are easy to say
        voice_patterns = [
            # Simple numeric patterns
            r'work order (\d+)',           # "work order 123"
            r'order (\d+)',                # "order 123"
            r'ticket (\d+)',               # "ticket 123"
            r'wo (\d+)',                   # "wo 123"
            r'number (\d+)',               # "number 123"
            
            # Natural speech patterns
            r'job (\d+)',                  # "job 123"
            r'task (\d+)',                 # "task 123"
            r'work (\d+)',                 # "work 123"
            
            # With wake words
            r'hey buddy.*work order (\d+)',
            r'hey buddy.*order (\d+)',
            r'hey buddy.*wo (\d+)',
            
            # Still support original format as fallback
            r'wo[- ]([a-f0-9]{8})',        # WO-12345678 or wo 12345678
            r'work order wo[- ]([a-f0-9]{8})',  # work order WO-12345678
        ]
        
        for pattern in voice_patterns:
            match = re.search(pattern, text_lower)
            if match:
                identifier = match.group(1)
                
                # If it's a numeric voice ID, convert to actual work order
                if identifier.isdigit():
                    voice_id = int(identifier)
                    actual_order = self.get_work_order_by_voice_id(voice_id)
                    if actual_order:
                        return actual_order
                    else:
                        # If no mapping found, try to regenerate mapping
                        print(f"🔄 Voice ID {voice_id} not found, regenerating mapping...")
                        self.generate_voice_mapping()
                        actual_order = self.get_work_order_by_voice_id(voice_id)
                        return actual_order
                
                # If it's a hex ID (original format), return as WO- format
                elif len(identifier) == 8 and all(c in '0123456789abcdef' for c in identifier):
                    return f"WO-{identifier.upper()}"
        
        return None
    
    def get_voice_commands_help(self, user_id: Optional[int] = None) -> List[str]:
        """Get list of available voice commands for the user"""
        mapping = self.generate_voice_mapping(user_id)
        
        commands = []
        commands.append("🎤 Voice-Friendly Work Order Commands:")
        commands.append("=" * 50)
        
        if not mapping:
            commands.append("No work orders found.")
            return commands
        
        for voice_id, details in mapping.items():
            vehicle = details['vehicle']
            description = details['description']
            commands.append(f"📝 Voice ID {voice_id}: {description}")
            commands.append(f"   Vehicle: {vehicle}")
            commands.append(f"   🗣️ Say: 'Hey buddy, work order {voice_id}'")
            commands.append(f"   🗣️ Or: 'Start order {voice_id}'")
            commands.append("")
        
        commands.append("💡 Other voice patterns that work:")
        commands.append("   • 'Hey buddy, order 123'")
        commands.append("   • 'WO 123'")
        commands.append("   • 'Job 123'")
        commands.append("   • 'Ticket 123'")
        
        return commands


# Global voice proxy instance
voice_proxy = VoiceWorkOrderProxy()


def enhance_voice_work_order_extraction(text: str) -> Optional[str]:
    """Enhanced work order extraction that includes voice proxy support"""
    
    # First try the voice proxy system
    proxy_result = voice_proxy.extract_voice_command_work_order(text)
    if proxy_result:
        return proxy_result
    
    # Fallback to original extraction method
    text_lower = text.lower().strip()
    
    # Original patterns for direct WO- format
    original_patterns = [
        r'WO-([A-Z0-9]{6,8})',          # WO-ABC123 (exact format)
        r'wo[- ]([a-z0-9]{6,8})',       # wo-abc123 or wo abc123
        r'work order ([A-Z0-9\-]{8,12})', # work order WO-ABC123
    ]
    
    for pattern in original_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            identifier = match.group(1)
            # Ensure WO- prefix
            if not identifier.startswith('WO-'):
                identifier = f"WO-{identifier}"
            return identifier.upper()
    
    return None


def get_user_voice_commands(user_id: int) -> List[str]:
    """Get voice commands available for a specific user"""
    return voice_proxy.get_voice_commands_help(user_id)


def initialize_voice_proxy_for_user(user_id: int):
    """Initialize voice proxy mapping for a specific user"""
    mapping = voice_proxy.generate_voice_mapping(user_id)
    print(f"🎤 Generated {len(mapping)} voice-friendly work order commands for user {user_id}")
    return mapping


if __name__ == "__main__":
    # Test the voice proxy system
    proxy = VoiceWorkOrderProxy()
    
    print("🎤 Voice Work Order Proxy System Test")
    print("=" * 50)
    
    # Generate mapping for testing
    mapping = proxy.generate_voice_mapping()
    print(f"Generated {len(mapping)} voice mappings")
    
    # Test voice commands
    test_commands = [
        "hey buddy, work order 1",
        "start order 2",
        "wo 3",
        "job 5",
        "help me with ticket 1",
        "work order WO-BC98DC79"  # Original format
    ]
    
    for cmd in test_commands:
        result = proxy.extract_voice_command_work_order(cmd)
        print(f"'{cmd}' -> {result}")
    
    # Show help
    help_commands = proxy.get_voice_commands_help()
    for line in help_commands[:10]:  # Show first 10 lines
        print(line)