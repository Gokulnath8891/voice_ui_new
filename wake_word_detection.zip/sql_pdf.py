"""
import os
from sqlalchemy import create_engine, text
from pgvector.sqlalchemy import Vector
from langchain_community.utilities import SQLDatabase
#from langchain.agents import create_sql_agent
from langchain_community.agent_toolkits import create_sql_agent
#from langchain.agents.agent_types import AgentType
from langchain.chains import RetrievalQA
from langchain_openai import AzureChatOpenAI
from langchain.docstore.document import Document
from sentence_transformers import SentenceTransformer
from flask import Flask, request, jsonify
"""
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI
#from langchain.agents import AgentExecutor

db = SQLDatabase.from_uri(
    "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )
# ---------------- CONFIG ----------------
#DB_URI = os.environ.get("DB_URI") # "postgresql://postgres:pass@localhost:5432/yourdb"
#DB_URI = "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
#TABLE_NAME = 'powertrain_pdf_docs' #os.environ.get("TABLE_NAME", "pdf_docs")
#EMBED_MODEL_NAME = "all-MiniLM-L6-v2"

#AZURE_ENDPOINT = os.environ.get("AZURE_ENDPOINT")
#AZURE_KEY = os.environ.get("AZURE_KEY")
#AZURE_DEPLOYMENT = os.environ.get("AZURE_DEPLOYMENT", "gpt-4o-mini")

#if not DB_URI:
 #   raise RuntimeError("Set DB_URI environment variable")

# ---------------- INIT ----------------
#app = Flask(__name__)
#engine = create_engine(DB_URI)
#embed_model = SentenceTransformer(EMBED_MODEL_NAME)



llm = AzureChatOpenAI(  
            azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


# ===============================
# 3. Create SQL Agent
# ===============================
agent_executor = create_sql_agent(
    llm=llm,
    db=db,
    agent_type="openai-tools", # new API (replaces legacy AgentType.ZERO_SHOT_REACT)
    verbose=True,
)


# ===============================
# 4. Query Interface
# ===============================
def ask_db(query: str):
    """Ask natural language question to the database agent."""
    response = agent_executor.invoke({"input": query})
    print("\nUser:", query)
    print("Agent:", response["output"])

# ===============================
# 5. Test
# ===============================
if __name__ == "__main__":
    user_query = input("\nEnter your query: ")
    ask_db(user_query)
    #ask_db("Show average price grouped by category.")