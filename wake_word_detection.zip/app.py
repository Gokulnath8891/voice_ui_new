import streamlit as st
import time
import requests

FASTAPI_URL = "http://localhost:8000"

st.title("🎤 Streamlit + FastAPI Wake Word Detection")

status = st.empty()
result = st.empty()

status.info("Listening for wake word... (API Loop Running)")
wakebox =st.empty()
# Poll FastAPI every 300ms
while True:
    try:
        data = requests.get(f"{FASTAPI_URL}/wake-status").json()
        if data["wake_detected"]:
            print(1)
            result.success("✅ Wake word detected!")
            requests.post(f"{FASTAPI_URL}/reset-wake")
            break
    except Exception as e:
        st.error(f"FastAPI unreachable: {e}")
        break

    time.sleep(0.3)

status.info("Wake word detected. Ready for next steps.")