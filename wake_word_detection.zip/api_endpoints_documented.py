"""
Enhanced API Endpoints with OpenAPI/Swagger Documentation
This file adds comprehensive documentation to the existing api_endpoints.py
"""

from drf_spectacular.utils import extend_schema, OpenApiParameter, OpenApiExample, OpenApiResponse
from drf_spectacular.types import OpenApiTypes
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from api_endpoints import api_endpoints
import json

# =============================================================================
# AUTHENTICATION ENDPOINTS
# =============================================================================

@extend_schema(
    tags=['Authentication'],
    summary='User Login',
    description='''
    Authenticate user with username and password. Returns user details including role.
    
    **Roles:**
    - `technician`: Can view and complete assigned work orders
    - `service_manager`: Can view all work orders and assign them to technicians
    ''',
    request={
        'application/json': {
            'type': 'object',
            'properties': {
                'username': {'type': 'string', 'example': 'john_smith'},
                'password': {'type': 'string', 'example': 'demo123'}
            },
            'required': ['username', 'password']
        }
    },
    responses={
        200: OpenApiResponse(
            description='Login successful',
            response={
                'type': 'object',
                'properties': {
                    'success': {'type': 'boolean', 'example': True},
                    'user': {
                        'type': 'object',
                        'properties': {
                            'id': {'type': 'integer', 'example': 1},
                            'username': {'type': 'string', 'example': 'john_smith'},
                            'first_name': {'type': 'string', 'example': 'John'},
                            'last_name': {'type': 'string', 'example': 'Smith'},
                            'role': {'type': 'string', 'enum': ['technician', 'service_manager'], 'example': 'technician'}
                        }
                    }
                }
            }
        ),
        401: OpenApiResponse(description='Invalid credentials'),
        400: OpenApiResponse(description='Missing username or password'),
    },
    examples=[
        OpenApiExample(
            'Technician Login',
            value={'username': 'alex_wilson_tech', 'password': 'password123'},
            request_only=True,
        ),
        OpenApiExample(
            'Manager Login',
            value={'username': 'john_smith_sm', 'password': 'password123'},
            request_only=True,
        ),
        OpenApiExample(
            'Successful Response',
            value={
                'success': True,
                'user': {
                    'id': 1,
                    'username': 'alex_wilson_tech',
                    'first_name': 'Alex',
                    'last_name': 'Wilson',
                    'role': 'technician'
                }
            },
            response_only=True,
        ),
    ]
)
@api_view(['POST'])
def login_view(request):
    """Wrapper for api_endpoints.login with documentation"""
    return api_endpoints.login(request)


# =============================================================================
# WORK ORDER ENDPOINTS
# =============================================================================

@extend_schema(
    tags=['Work Orders'],
    summary='Get Technician Work Orders',
    description='''
    Retrieve top 10 work orders assigned to the logged-in technician.
    Returns work orders with progress tracking and step completion status.
    ''',
    parameters=[
        OpenApiParameter(
            name='user_id',
            type=OpenApiTypes.INT,
            location=OpenApiParameter.QUERY,
            required=True,
            description='The technician user ID',
            examples=[
                OpenApiExample('Example', value=1)
            ]
        ),
    ],
    responses={
        200: OpenApiResponse(
            description='Work orders retrieved successfully',
            response={
                'type': 'object',
                'properties': {
                    'work_orders': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'id': {'type': 'integer', 'example': 101},
                                'order_number': {'type': 'string', 'example': 'WO-2024-001'},
                                'title': {'type': 'string', 'example': 'Oil Change Service'},
                                'description': {'type': 'string'},
                                'status': {'type': 'string', 'enum': ['PENDING', 'ASSIGNED', 'IN_PROGRESS', 'COMPLETED']},
                                'priority': {'type': 'string', 'enum': ['LOW', 'MEDIUM', 'HIGH', 'URGENT']},
                                'customer_name': {'type': 'string', 'example': 'John Doe'},
                                'vehicle': {'type': 'string', 'example': '2020 Toyota Camry'},
                                'created_at': {'type': 'string', 'format': 'date-time'},
                                'estimated_hours': {'type': 'number', 'format': 'float', 'example': 2.5},
                                'actual_hours': {'type': 'number', 'format': 'float', 'example': 1.8},
                                'progress': {'type': 'number', 'format': 'float', 'example': 65.0},
                                'total_steps': {'type': 'integer', 'example': 8},
                                'completed_steps': {'type': 'integer', 'example': 5}
                            }
                        }
                    }
                }
            }
        ),
        400: OpenApiResponse(description='User ID required'),
        404: OpenApiResponse(description='User not found'),
    }
)
@api_view(['GET'])
def get_technician_workorders_view(request):
    """Wrapper for api_endpoints.get_technician_work_orders with documentation"""
    return api_endpoints.get_technician_work_orders(request)


@extend_schema(
    tags=['Work Orders'],
    summary='Get Manager Work Orders',
    description='''
    Retrieve work orders for service manager dashboard with optional status filtering.
    Includes detailed step information for each work order.
    ''',
    parameters=[
        OpenApiParameter(
            name='user_id',
            type=OpenApiTypes.INT,
            location=OpenApiParameter.QUERY,
            required=True,
            description='The service manager user ID'
        ),
        OpenApiParameter(
            name='status',
            type=OpenApiTypes.STR,
            location=OpenApiParameter.QUERY,
            required=False,
            description='Filter by work order status',
            enum=['all', 'pending', 'assigned', 'in_progress', 'completed'],
            examples=[
                OpenApiExample('All Orders', value='all'),
                OpenApiExample('In Progress Only', value='in_progress'),
            ]
        ),
    ],
    responses={
        200: OpenApiResponse(description='Work orders retrieved successfully'),
        400: OpenApiResponse(description='User ID required'),
        404: OpenApiResponse(description='User not found'),
    }
)
@api_view(['GET'])
def get_manager_workorders_view(request):
    """Wrapper for api_endpoints.get_manager_work_orders with documentation"""
    return api_endpoints.get_manager_work_orders(request)


# =============================================================================
# CHAT & WORKFLOW ENDPOINTS
# =============================================================================

@extend_schema(
    tags=['Chat & Workflow'],
    summary='Process Chat Query',
    description='''
    Process natural language queries from the chatbot interface.
    
    **Capabilities:**
    - Start work order workflow by work order number
    - Resume incomplete work orders
    - Reset and restart completed work orders
    - Answer general maintenance questions
    
    **Special Commands:**
    - `"work order WO-XXX"` - Start specific work order
    - `"start over WO-XXX"` - Reset and restart work order
    - `"resume WO-XXX"` - Resume from last incomplete step
    ''',
    request={
        'application/json': {
            'type': 'object',
            'properties': {
                'query': {'type': 'string', 'example': 'work order WO-2024-001'},
                'user_id': {'type': 'integer', 'example': 1},
                'type': {'type': 'string', 'enum': ['text', 'voice'], 'example': 'text'}
            },
            'required': ['query', 'user_id']
        }
    },
    responses={
        200: OpenApiResponse(
            description='Query processed successfully',
            response={
                'type': 'object',
                'properties': {
                    'type': {
                        'type': 'string',
                        'enum': ['work_order_start', 'simple_response', 'error']
                    },
                    'session_id': {'type': 'string'},
                    'work_order': {'type': 'object'},
                    'current_step': {'type': 'object'},
                    'message': {'type': 'string'},
                    'instruction': {'type': 'string'},
                    'tts_text': {'type': 'string'}
                }
            }
        ),
        400: OpenApiResponse(description='Missing required parameters'),
        404: OpenApiResponse(description='User not found'),
    },
    examples=[
        OpenApiExample(
            'Start Work Order',
            value={
                'query': 'work order WO-2024-001',
                'user_id': 1,
                'type': 'text'
            },
            request_only=True,
        ),
        OpenApiExample(
            'Resume Work Order',
            value={
                'query': 'resume WO-2024-001',
                'user_id': 1,
                'type': 'text'
            },
            request_only=True,
        ),
        OpenApiExample(
            'Start Over',
            value={
                'query': 'start over WO-2024-001',
                'user_id': 1,
                'type': 'text'
            },
            request_only=True,
        ),
    ]
)
@api_view(['POST'])
def process_chat_query_view(request):
    """Wrapper for api_endpoints.process_chat_query with documentation"""
    return api_endpoints.process_chat_query(request)


@extend_schema(
    tags=['Chat & Workflow'],
    summary='Submit Step Feedback',
    description='''
    Submit feedback for the current step and advance to the next step.
    
    **Flow:**
    1. User completes a step
    2. Submits feedback describing what was done
    3. System validates and marks step complete
    4. Returns next step or completion message
    ''',
    request={
        'application/json': {
            'type': 'object',
            'properties': {
                'session_id': {'type': 'string', 'example': 'wo_101_1_abc123'},
                'feedback': {'type': 'string', 'example': 'Completed draining old oil. Oil was dark and needed replacement.'},
                'user_id': {'type': 'integer', 'example': 1}
            },
            'required': ['session_id', 'feedback', 'user_id']
        }
    },
    responses={
        200: OpenApiResponse(
            description='Feedback processed successfully',
            response={
                'type': 'object',
                'properties': {
                    'type': {
                        'type': 'string',
                        'enum': ['next_step', 'complete', 'error']
                    },
                    'current_step': {'type': 'object'},
                    'message': {'type': 'string'},
                    'tts_text': {'type': 'string'},
                    'progress': {'type': 'object'},
                    'total_steps': {'type': 'integer'},
                    'total_time': {'type': 'number'},
                    'estimated_time': {'type': 'number'},
                    'time_variance': {'type': 'number'}
                }
            }
        ),
        400: OpenApiResponse(description='Missing required parameters'),
        404: OpenApiResponse(description='Session not found'),
    }
)
@api_view(['POST'])
def process_session_feedback_view(request):
    """Wrapper for api_endpoints.process_session_feedback with documentation"""
    return api_endpoints.process_session_feedback(request)


# =============================================================================
# VOICE ASSISTANT ENDPOINTS
# =============================================================================

@extend_schema(
    tags=['Voice Assistant'],
    summary='Get Available Voice Commands',
    description='Retrieve list of available voice commands and their descriptions',
    responses={
        200: OpenApiResponse(
            description='Voice commands retrieved successfully',
            response={
                'type': 'object',
                'properties': {
                    'commands': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'command': {'type': 'string'},
                                'description': {'type': 'string'},
                                'example': {'type': 'string'}
                            }
                        }
                    }
                }
            }
        )
    }
)
@api_view(['GET'])
def get_voice_commands_view(request):
    """Wrapper for api_endpoints.get_voice_commands with documentation"""
    return api_endpoints.get_voice_commands(request)


@extend_schema(
    tags=['Voice Assistant'],
    summary='Initialize Voice Proxy',
    description='Initialize the voice proxy system for voice command mapping',
    parameters=[
        OpenApiParameter(
            name='user_id',
            type=OpenApiTypes.INT,
            location=OpenApiParameter.QUERY,
            required=True,
            description='User ID for context'
        ),
    ],
    responses={
        200: OpenApiResponse(
            description='Voice proxy initialized successfully',
            response={
                'type': 'object',
                'properties': {
                    'success': {'type': 'boolean'},
                    'message': {'type': 'string'}
                }
            }
        )
    }
)
@api_view(['GET'])
def init_voice_proxy_view(request):
    """Wrapper for api_endpoints.init_voice_proxy with documentation"""
    return api_endpoints.init_voice_proxy(request)


# =============================================================================
# FEEDBACK & HISTORY ENDPOINTS
# =============================================================================

@extend_schema(
    tags=['Work Orders'],
    summary='Get Work Order Feedback History',
    description='Retrieve complete feedback history for a specific work order',
    parameters=[
        OpenApiParameter(
            name='work_order_id',
            type=OpenApiTypes.INT,
            location=OpenApiParameter.PATH,
            required=True,
            description='Work order ID'
        ),
    ],
    responses={
        200: OpenApiResponse(
            description='Feedback history retrieved successfully',
            response={
                'type': 'object',
                'properties': {
                    'success': {'type': 'boolean'},
                    'work_order_id': {'type': 'integer'},
                    'work_order_number': {'type': 'string'},
                    'feedback_history': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'step_number': {'type': 'integer'},
                                'feedback': {'type': 'string'},
                                'time_spent': {'type': 'number'},
                                'submitted_at': {'type': 'string', 'format': 'date-time'},
                                'user_id': {'type': 'integer'}
                            }
                        }
                    }
                }
            }
        ),
        404: OpenApiResponse(description='Work order not found'),
    }
)
@api_view(['GET'])
def get_workorder_feedback_view(request, work_order_id):
    """Wrapper for api_endpoints.get_work_order_feedback_history with documentation"""
    return api_endpoints.get_work_order_feedback_history(request, work_order_id)


@extend_schema(
    tags=['Work Orders'],
    summary='Reset Work Order',
    description='''
    Reset a completed work order back to ASSIGNED status.
    
    **Actions performed:**
    - Change status to ASSIGNED
    - Clear all step completions
    - Delete feedback history
    - Delete workflow session
    - Delete work order summary
    
    **Note:** Only completed work orders can be reset.
    ''',
    request={
        'application/json': {
            'type': 'object',
            'properties': {
                'work_order_number': {'type': 'string', 'example': 'WO-2024-001'},
                'user_id': {'type': 'integer', 'example': 1}
            },
            'required': ['work_order_number', 'user_id']
        }
    },
    responses={
        200: OpenApiResponse(
            description='Work order reset successfully',
            response={
                'type': 'object',
                'properties': {
                    'success': {'type': 'boolean'},
                    'message': {'type': 'string'},
                    'work_order_number': {'type': 'string'},
                    'new_status': {'type': 'string'}
                }
            }
        ),
        400: OpenApiResponse(description='Only completed work orders can be reset'),
        404: OpenApiResponse(description='Work order not found'),
    }
)
@api_view(['POST'])
def reset_workorder_view(request):
    """Wrapper for api_endpoints.reset_work_order with documentation"""
    return api_endpoints.reset_work_order(request)
