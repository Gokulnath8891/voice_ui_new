# Automotive Service Work Order Management System

This project is a **Django + Django REST Framework (DRF)** based backend for managing automotive service work orders, technicians, and service managers.  
It uses **JWT authentication** (`djangorestframework-simplejwt`) and **role-based permissions** to ensure secure access control.

---

## Features

- **User Management**
  - Users authenticated using Django’s built-in authentication.
  - JWT authentication for secure login/logout.
  - Default role assignment (Technician) when a user is created (via API or Django Admin).
  - Role-based groups: **Technician** and **Service Manager**.

- **Work Order Management**
  - Service Managers can create and assign work orders to technicians.
  - Technicians can only view their assigned work orders.
  - Work order steps are tracked with feedback from technicians.
  - Summary table automatically records aggregated feedback and steps.

- **Role-Based Permissions**
  - **Service Managers**: Full CRUD on WorkOrders, can assign technicians.
  - **Technicians**: Read-only access to their assigned work orders, can submit feedback.

---

## Data Models

1. **User (Django default)**
   - Extended via `Group` roles (`Technician`, `Service Manager`).

2. **TechnicianProfile**
   - Links a Django user to technician-specific details.

3. **ServiceManagerProfile**
   - Links a Django user to service manager-specific details.

4. **Customer**
   - Basic customer information.

5. **Vehicle**
   - Belongs to a customer.

6. **WorkOrder**
   - Assigned to a customer’s vehicle.
   - Assigned by a service manager.
   - Worked on by a technician.

7. **WorkOrderStep**
   - Detailed step entries for each work order.

8. **WorkOrderFeedback**
   - Captures technician feedback for each step.

9. **WorkOrderSummary**
   - Aggregated summary (200–300 words) of steps and feedback.

---

## API Endpoints

### Authentication
- `POST /api/auth/login/` → Login (JWT token).
- `POST /api/auth/refresh/` → Refresh token.

### Users & Roles
- `POST /api/users/` → Register new user (default role: Technician).
- `GET /api/users/me/` → Get logged-in user details.

### Work Orders
- `GET /api/workorders/` → List work orders (filtered by role).
- `POST /api/workorders/` → Create work order (**Service Manager only**).
- `PATCH /api/workorders/{id}/assign/` → Assign technician (**Service Manager only**).

### Feedback & Steps
- `POST /api/workorders/{id}/steps/` → Add work order steps.
- `POST /api/workorders/{id}/feedback/` → Submit feedback.
- `GET /api/workorders/{id}/summary/` → View summary.

---

## Signals

- **Default Group Assignment**: When a new user is created (via API or Admin), they are automatically added to the **Technician** group unless explicitly assigned to **Service Manager**.

---

## Installation

1. Clone repository:
   ```bash
   git clone https://github.com/your-repo/workorder-system.git
   cd workorder-system
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Apply migrations:
   ```bash
   python manage.py migrate
   ```

4. Create superuser:
   ```bash
   python manage.py createsuperuser
   ```

5. Run server:
   ```bash
   python manage.py runserver
   ```

---

## Tech Stack

- **Backend**: Django, Django REST Framework
- **Auth**: JWT (`djangorestframework-simplejwt`)
- **Database**: PostgreSQL / MySQL / SQLite (configurable)
- **Role Management**: Django Groups & Permissions

---

## Future Enhancements

- Real-time notifications for assigned work orders.
- Reporting dashboards for managers.
- Mobile app integration for technicians.
