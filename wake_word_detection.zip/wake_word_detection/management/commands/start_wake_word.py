"""
Django Management Command: Start Wake Word Detection

Usage:
    python manage.py start_wake_word
    python manage.py start_wake_word --wake-word "computer"
    python manage.py start_wake_word --confidence 0.8
"""

import os
import time
import signal
import sys
from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.models import User

from wake_word_detection.detector import VoiceAssistantWithWakeWord
from wake_word_detection.models import WakeWordSettings


class Command(BaseCommand):
    help = 'Start wake word detection service'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.assistant = None
        self.detector = None
        self.running = False

    def add_arguments(self, parser):
        parser.add_argument(
            '--wake-word',
            default='hey buddy',
            help='Wake word phrase to detect (default: "hey buddy")'
        )
        parser.add_argument(
            '--confidence',
            type=float,
            default=0.7,
            help='Confidence threshold for detection (default: 0.7)'
        )
        parser.add_argument(
            '--user',
            type=str,
            help='Username to associate with the session'
        )
        parser.add_argument(
            '--language',
            default='en-US',
            help='Recognition language (default: en-US)'
        )
        parser.add_argument(
            '--daemon',
            action='store_true',
            help='Run as a background daemon'
        )

    def signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        self.stdout.write("\n🛑 Shutdown signal received...")
        self.cleanup()
        sys.exit(0)

    def cleanup(self):
        """Cleanup resources"""
        self.running = False
        if self.assistant:
            self.assistant.stop()
        if self.detector:
            self.detector.cleanup()

    def handle(self, *args, **options):
        # Setup signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)

        # Validate arguments
        wake_word = options['wake_word']
        confidence = options['confidence']
        language = options['language']
        username = options.get('user')

        if confidence < 0.1 or confidence > 1.0:
            raise CommandError('Confidence must be between 0.1 and 1.0')

        # Check Azure credentials
        if not os.getenv('AZURE_SPEECH_KEY') or not os.getenv('AZURE_SPEECH_REGION'):
            raise CommandError(
                'Azure Speech credentials not configured. '
                'Set AZURE_SPEECH_KEY and AZURE_SPEECH_REGION environment variables.'
            )

        # Get user if specified
        user = None
        if username:
            try:
                user = User.objects.get(username=username)
                self.stdout.write(f"✅ Using user: {username}")
            except User.DoesNotExist:
                raise CommandError(f'User "{username}" not found')

        # Create/update user settings if user provided
        if user:
            settings, created = WakeWordSettings.objects.get_or_create(
                user=user,
                is_active=True,
                defaults={
                    'wake_word_phrase': wake_word,
                    'confidence_threshold': confidence,
                    'language': language
                }
            )
            if not created:
                settings.wake_word_phrase = wake_word
                settings.confidence_threshold = confidence
                settings.language = language
                settings.save()

        self.stdout.write("🎤 Starting Wake Word Detection Service")
        self.stdout.write("=" * 50)
        self.stdout.write(f"Wake Word: '{wake_word}'")
        self.stdout.write(f"Confidence: {confidence}")
        self.stdout.write(f"Language: {language}")
        self.stdout.write(f"Region: {os.getenv('AZURE_SPEECH_REGION')}")
        
        if user:
            self.stdout.write(f"User: {username}")

        try:
            # Create voice assistant
            self.assistant = VoiceAssistantWithWakeWord(wake_word=wake_word)
            
            # Start the assistant
            self.detector = self.assistant.start()
            
            if self.detector:
                self.stdout.write("✅ Wake word detection started successfully")
                self.stdout.write("💬 Example commands:")
                self.stdout.write(f"   • '{wake_word}, how does the engine work?'")
                self.stdout.write(f"   • '{wake_word}, tell me about brake systems'")
                self.stdout.write(f"   • '{wake_word}, what is vehicle maintenance?'")
                self.stdout.write("\n🛑 Press Ctrl+C to stop")

                # Main loop
                self.running = True
                start_time = time.time()
                last_status_time = start_time

                while self.running and self.detector.is_listening:
                    time.sleep(1)
                    
                    # Show periodic status (every 60 seconds)
                    current_time = time.time()
                    if current_time - last_status_time >= 60:
                        status = self.detector.get_status()
                        uptime = int(current_time - start_time)
                        
                        self.stdout.write(f"\n📊 Status Update:")
                        self.stdout.write(f"   🎤 Listening: {status['listening']}")
                        self.stdout.write(f"   🎯 Detections: {status['detection_count']}")
                        self.stdout.write(f"   ⏱️  Uptime: {uptime} seconds")
                        self.stdout.write(f"   🎧 Still listening for '{wake_word}'...")
                        
                        last_status_time = current_time

            else:
                raise CommandError("Failed to start wake word detection")

        except KeyboardInterrupt:
            self.stdout.write("\n⏹️ Service stopped by user")
        except Exception as e:
            self.cleanup()
            raise CommandError(f"Error starting wake word detection: {e}")
        finally:
            self.cleanup()
            self.stdout.write("🧹 Service cleanup completed")
            self.stdout.write("👋 Wake word detection service stopped")