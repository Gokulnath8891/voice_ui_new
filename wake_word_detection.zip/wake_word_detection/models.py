"""
Wake Word Detection Django Models

Models for tracking wake word detection sessions, events, and statistics.
"""

from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta
import uuid
import json


class WakeWordSession(models.Model):
    """Track wake word detection sessions"""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    session_id = models.CharField(max_length=100, unique=True)
    
    # Session configuration
    wake_word_phrase = models.CharField(max_length=100, default="hey buddy")
    confidence_threshold = models.FloatField(default=0.7)
    language = models.CharField(max_length=10, default="en-US")
    
    # Session status
    is_active = models.BooleanField(default=False)
    started_at = models.DateTimeField(auto_now_add=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    
    # Statistics
    detection_count = models.IntegerField(default=0)
    successful_commands = models.IntegerField(default=0)
    failed_commands = models.IntegerField(default=0)
    
    # Technical details
    azure_region = models.CharField(max_length=50, blank=True)
    client_ip = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    
    class Meta:
        db_table = 'wake_word_sessions'
        indexes = [
            models.Index(fields=['user', 'started_at']),
            models.Index(fields=['is_active']),
            models.Index(fields=['started_at']),
        ]
        ordering = ['-started_at']
    
    def __str__(self):
        return f"Session {self.session_id} - {self.wake_word_phrase}"
    
    @property
    def duration(self):
        """Get session duration"""
        end_time = self.ended_at or timezone.now()
        return end_time - self.started_at
    
    @property
    def success_rate(self):
        """Calculate success rate percentage"""
        total = self.successful_commands + self.failed_commands
        if total == 0:
            return 0.0
        return (self.successful_commands / total) * 100
    
    def end_session(self):
        """End the session"""
        self.is_active = False
        self.ended_at = timezone.now()
        self.save()


class WakeWordDetectionEvent(models.Model):
    """Individual wake word detection events"""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    session = models.ForeignKey(WakeWordSession, on_delete=models.CASCADE, related_name='detections')
    
    # Detection data
    timestamp = models.DateTimeField(auto_now_add=True)
    wake_word_detected = models.BooleanField(default=False)
    full_text = models.TextField()
    command_text = models.TextField(blank=True)
    confidence_score = models.FloatField()
    
    # Processing information
    processing_time_ms = models.IntegerField(default=0)
    was_processed = models.BooleanField(default=False)
    processing_successful = models.BooleanField(default=False)
    error_message = models.TextField(blank=True)
    
    # Response data
    response_chunks_count = models.IntegerField(default=0)
    response_summary = models.TextField(blank=True)
    tts_generated = models.BooleanField(default=False)
    
    # Metadata
    raw_azure_result = models.JSONField(default=dict, blank=True)
    custom_metadata = models.JSONField(default=dict, blank=True)
    
    class Meta:
        db_table = 'wake_word_detection_events'
        indexes = [
            models.Index(fields=['session', 'timestamp']),
            models.Index(fields=['wake_word_detected']),
            models.Index(fields=['timestamp']),
            models.Index(fields=['confidence_score']),
        ]
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"Detection {self.id} - {self.command_text[:50]}"
    
    def save(self, *args, **kwargs):
        # Update session statistics
        if self.pk is None:  # New instance
            if self.wake_word_detected:
                self.session.detection_count += 1
            
            if self.processing_successful:
                self.session.successful_commands += 1
            elif self.was_processed and not self.processing_successful:
                self.session.failed_commands += 1
            
            self.session.save()
        
        super().save(*args, **kwargs)


class WakeWordCommand(models.Model):
    """Track processed wake word commands"""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    detection_event = models.OneToOneField(WakeWordDetectionEvent, on_delete=models.CASCADE, related_name='command')
    
    # Command processing
    command_text = models.TextField()
    normalized_command = models.TextField(blank=True)  # Cleaned/normalized version
    command_category = models.CharField(max_length=50, blank=True)  # e.g., "question", "request", "control"
    
    # Voice assistant integration
    vector_search_performed = models.BooleanField(default=False)
    search_query = models.TextField(blank=True)
    search_results_count = models.IntegerField(default=0)
    highest_similarity_score = models.FloatField(null=True, blank=True)
    
    # AI processing
    ai_summary_generated = models.BooleanField(default=False)
    summary_text = models.TextField(blank=True)
    summary_confidence = models.FloatField(null=True, blank=True)
    
    # Audio output
    tts_generated = models.BooleanField(default=False)
    audio_file_path = models.CharField(max_length=500, blank=True)
    audio_duration_seconds = models.FloatField(null=True, blank=True)
    
    # Performance metrics
    total_processing_time_ms = models.IntegerField(default=0)
    search_time_ms = models.IntegerField(default=0)
    ai_processing_time_ms = models.IntegerField(default=0)
    tts_time_ms = models.IntegerField(default=0)
    
    # Results
    status = models.CharField(max_length=20, choices=[
        ('success', 'Success'),
        ('partial', 'Partial Success'),
        ('failed', 'Failed'),
        ('timeout', 'Timeout')
    ], default='success')
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'wake_word_commands'
        indexes = [
            models.Index(fields=['created_at']),
            models.Index(fields=['status']),
            models.Index(fields=['command_category']),
        ]
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Command: {self.command_text[:50]} - {self.status}"


class WakeWordSettings(models.Model):
    """Global wake word detection settings"""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    
    # Wake word configuration
    wake_word_phrase = models.CharField(max_length=100, default="hey buddy")
    confidence_threshold = models.FloatField(default=0.7)
    language = models.CharField(max_length=10, default="en-US")
    
    # Audio settings
    microphone_sensitivity = models.FloatField(default=1.0)
    noise_suppression = models.BooleanField(default=True)
    auto_gain_control = models.BooleanField(default=True)
    
    # Processing settings
    max_command_length_seconds = models.IntegerField(default=10)
    processing_timeout_seconds = models.IntegerField(default=30)
    enable_continuous_listening = models.BooleanField(default=True)
    
    # Integration settings
    enable_voice_assistant = models.BooleanField(default=True)
    enable_tts_response = models.BooleanField(default=True)
    default_collection_name = models.CharField(max_length=100, default="general_docs")
    
    # Performance settings
    max_concurrent_sessions = models.IntegerField(default=5)
    session_timeout_minutes = models.IntegerField(default=60)
    cleanup_old_data_days = models.IntegerField(default=30)
    
    # Notification settings
    enable_detection_logging = models.BooleanField(default=True)
    enable_error_notifications = models.BooleanField(default=True)
    webhook_url = models.URLField(blank=True)
    
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'wake_word_settings'
        indexes = [
            models.Index(fields=['user', 'is_active']),
            models.Index(fields=['is_active']),
        ]
    
    def __str__(self):
        user_str = f" for {self.user.username}" if self.user else ""
        return f"Wake Word Settings{user_str} - {self.wake_word_phrase}"
    
    @classmethod
    def get_default_settings(cls, user=None):
        """Get or create default settings for user"""
        settings, created = cls.objects.get_or_create(
            user=user,
            is_active=True,
            defaults={
                'wake_word_phrase': 'hey buddy',
                'confidence_threshold': 0.7,
                'language': 'en-US'
            }
        )
        return settings


class WakeWordAnalytics(models.Model):
    """Analytics and performance tracking"""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    # Time period
    date = models.DateField()
    hour = models.IntegerField(null=True, blank=True)  # Hour of day (0-23)
    
    # Metrics
    total_detections = models.IntegerField(default=0)
    successful_commands = models.IntegerField(default=0)
    failed_commands = models.IntegerField(default=0)
    false_positives = models.IntegerField(default=0)
    
    # Performance metrics
    avg_confidence_score = models.FloatField(default=0.0)
    avg_processing_time_ms = models.FloatField(default=0.0)
    avg_response_time_ms = models.FloatField(default=0.0)
    
    # Popular commands
    top_commands = models.JSONField(default=list, blank=True)
    command_categories = models.JSONField(default=dict, blank=True)
    
    # System metrics
    active_sessions = models.IntegerField(default=0)
    total_session_time_seconds = models.IntegerField(default=0)
    error_count = models.IntegerField(default=0)
    
    # User metrics
    unique_users = models.IntegerField(default=0)
    returning_users = models.IntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'wake_word_analytics'
        indexes = [
            models.Index(fields=['date', 'hour']),
            models.Index(fields=['date']),
        ]
        unique_together = ['date', 'hour']
        ordering = ['-date', '-hour']
    
    def __str__(self):
        hour_str = f" {self.hour}:00" if self.hour is not None else ""
        return f"Analytics {self.date}{hour_str} - {self.total_detections} detections"
    
    @classmethod
    def get_or_create_for_period(cls, date, hour=None):
        """Get or create analytics record for time period"""
        analytics, created = cls.objects.get_or_create(
            date=date,
            hour=hour,
            defaults={
                'total_detections': 0,
                'successful_commands': 0,
                'failed_commands': 0
            }
        )
        return analytics, created
    
    def update_metrics(self, detection_event: WakeWordDetectionEvent):
        """Update analytics with new detection event"""
        if detection_event.wake_word_detected:
            self.total_detections += 1
            
        if detection_event.processing_successful:
            self.successful_commands += 1
        elif detection_event.was_processed:
            self.failed_commands += 1
            
        # Update averages
        self.avg_confidence_score = (
            (self.avg_confidence_score * (self.total_detections - 1) + detection_event.confidence_score) 
            / self.total_detections
        )
        
        if detection_event.processing_time_ms > 0:
            current_avg_count = self.successful_commands + self.failed_commands
            if current_avg_count > 0:
                self.avg_processing_time_ms = (
                    (self.avg_processing_time_ms * (current_avg_count - 1) + detection_event.processing_time_ms)
                    / current_avg_count
                )
        
        self.save()


# Signal handlers for automatic analytics updates
from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=WakeWordDetectionEvent)
def update_analytics_on_detection(sender, instance, created, **kwargs):
    """Update analytics when new detection event is created"""
    if created:
        from django.utils import timezone
        
        # Daily analytics
        daily_analytics, _ = WakeWordAnalytics.get_or_create_for_period(
            date=instance.timestamp.date()
        )
        daily_analytics.update_metrics(instance)
        
        # Hourly analytics
        hourly_analytics, _ = WakeWordAnalytics.get_or_create_for_period(
            date=instance.timestamp.date(),
            hour=instance.timestamp.hour
        )
        hourly_analytics.update_metrics(instance)