"""
Wake Word Detection Core Module

This module implements the core wake word detection functionality using Azure Speech SDK
with "Hey Buddy" as the trigger phrase, following the WAKE_WORD_USAGE.md documentation.
"""

import os
import sys
import time
import threading
import logging
from typing import Callable, Optional, Dict, Any, List
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from queue import Queue, Empty
import json

from django.conf import settings
from django.utils import timezone

# Azure Speech SDK (with graceful fallback)
try:
    import azure.cognitiveservices.speech as speechsdk
    AZURE_SPEECH_AVAILABLE = True
except ImportError:
    AZURE_SPEECH_AVAILABLE = False
    speechsdk = None

logger = logging.getLogger(__name__)


@dataclass
class WakeWordDetection:
    """Data class for wake word detection events"""
    timestamp: float
    wake_word_detected: bool
    full_text: str
    command_text: str
    confidence: float
    session_id: str
    processing_time_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)

    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict())


class WakeWordDetector:
    """
    Core wake word detector class that listens for "Hey Buddy" wake word
    and processes the following command using Azure Speech SDK.
    """

    def __init__(
        self,
        subscription_key: Optional[str] = None,
        region: Optional[str] = None,
        wake_word: str = "hey buddy",
        confidence_threshold: float = 0.7,
        callback: Optional[Callable[[str], None]] = None,
        language: str = "en-US"
    ):
        """
        Initialize wake word detector
        
        Args:
            subscription_key: Azure Speech Service key
            region: Azure region
            wake_word: Wake word phrase to detect
            confidence_threshold: Minimum confidence for detection
            callback: Callback function for processing detected commands
            language: Recognition language
        """
        if not AZURE_SPEECH_AVAILABLE:
            raise ImportError("Azure Speech SDK not available. Install with: pip install azure-cognitiveservices-speech")

        # Configuration
        self.subscription_key = subscription_key or getattr(settings, 'AZURE_SPEECH_KEY', None)
        self.region = region or getattr(settings, 'AZURE_SPEECH_REGION', None)
        self.wake_word = wake_word.lower()
        self.confidence_threshold = confidence_threshold
        self.callback = callback
        self.language = language

        if not self.subscription_key or not self.region:
            raise ValueError("Azure Speech credentials not configured. Set AZURE_SPEECH_KEY and AZURE_SPEECH_REGION")

        # State management
        self.is_listening = False
        self.is_processing = False
        self.session_id = f"session_{int(time.time())}"
        self.detection_count = 0
        
        # Threading
        self.listen_thread = None
        self.stop_event = threading.Event()
        
        # Detection history
        self.recent_detections: Queue = Queue(maxsize=100)
        self.detection_history: List[WakeWordDetection] = []
        
        # Azure Speech components
        self.speech_config = None
        self.audio_config = None
        self.speech_recognizer = None
        
        # Initialize Azure Speech
        self._setup_azure_speech()

    def _setup_azure_speech(self):
        """Setup Azure Speech SDK components"""
        try:
            # Create speech configuration
            self.speech_config = speechsdk.SpeechConfig(
                subscription=self.subscription_key,
                region=self.region
            )
            self.speech_config.speech_recognition_language = self.language
            
            # Enable detailed results for confidence scores
            self.speech_config.output_format = speechsdk.OutputFormat.Detailed
            
            # Use default microphone
            self.audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
            
            # Create speech recognizer
            self.speech_recognizer = speechsdk.SpeechRecognizer(
                speech_config=self.speech_config,
                audio_config=self.audio_config
            )
            
            # Setup event handlers
            self.speech_recognizer.recognized.connect(self._on_recognized)
            self.speech_recognizer.session_started.connect(self._on_session_started)
            self.speech_recognizer.session_stopped.connect(self._on_session_stopped)
            self.speech_recognizer.canceled.connect(self._on_canceled)
            
            logger.info(f"Azure Speech SDK initialized successfully for region: {self.region}")
            
        except Exception as e:
            logger.error(f"Failed to setup Azure Speech SDK: {e}")
            raise

    def _on_session_started(self, evt):
        """Handle session started event"""
        logger.info("Speech recognition session started")

    def _on_session_stopped(self, evt):
        """Handle session stopped event"""
        logger.info("Speech recognition session stopped")

    def _on_canceled(self, evt):
        """Handle recognition canceled event"""
        logger.warning(f"Speech recognition canceled: {evt.reason}")
        if evt.reason == speechsdk.CancellationReason.Error:
            logger.error(f"Error details: {evt.error_details}")

    def _on_recognized(self, evt):
        """
        Handle speech recognition result
        
        This is the core method that processes recognized speech and
        determines if the wake word was detected.
        """
        if self.stop_event.is_set():
            return
            
        try:
            result = evt.result
            logger.debug(f"Recognition result reason: {result.reason}")
            
            if result.reason == speechsdk.ResultReason.RecognizedSpeech:
                recognized_text = result.text.strip()
                
                if not recognized_text:
                    logger.debug("Empty recognition result, skipping")
                    return
                
                logger.info(f"Recognized speech: '{recognized_text}'")
                
                # Get confidence score from detailed results
                confidence = self._extract_confidence(result)
                logger.info(f"Recognition confidence: {confidence:.3f}")
                
                # Check for wake word detection
                wake_word_detected, command_text = self._process_wake_word(recognized_text)
                
                if wake_word_detected:
                    logger.info(f"Wake word detected! Command: '{command_text}', Confidence: {confidence:.3f}")
                    
                    if confidence >= self.confidence_threshold:
                        # Create detection event
                        detection = WakeWordDetection(
                            timestamp=time.time(),
                            wake_word_detected=True,
                            full_text=recognized_text,
                            command_text=command_text,
                            confidence=confidence,
                            session_id=self.session_id
                        )
                        
                        self._handle_wake_word_detection(detection)
                    else:
                        logger.info(f"Wake word detected but confidence too low: {confidence:.3f} < {self.confidence_threshold}")
                else:
                    logger.debug(f"No wake word detected in: '{recognized_text}'")
            
            elif result.reason == speechsdk.ResultReason.NoMatch:
                logger.debug("No speech could be recognized")
            elif result.reason == speechsdk.ResultReason.Canceled:
                logger.warning("Recognition was canceled")
                    
        except Exception as e:
            logger.error(f"Error processing recognized speech: {e}", exc_info=True)

    def _extract_confidence(self, result) -> float:
        """Extract confidence score from recognition result"""
        try:
            # Try to get confidence from detailed results
            if hasattr(result, 'json') and result.json:
                result_json = json.loads(result.json)
                logger.debug(f"Azure result JSON: {result_json}")
                
                if 'NBest' in result_json and result_json['NBest']:
                    confidence = result_json['NBest'][0].get('Confidence', 0.0)
                    logger.debug(f"Extracted confidence from NBest: {confidence}")
                    return confidence
                
                # Try alternative confidence extraction methods
                if 'Confidence' in result_json:
                    confidence = result_json['Confidence']
                    logger.debug(f"Extracted confidence directly: {confidence}")
                    return confidence
            
            # Try other properties of the result
            if hasattr(result, 'properties'):
                confidence_str = result.properties.get('Speech.Phrase.Confidence', '0.8')
                confidence = float(confidence_str)
                logger.debug(f"Extracted confidence from properties: {confidence}")
                return confidence
            
            logger.debug("No confidence score found, using default: 0.8")
            return 0.8  # Default confidence if not available
        except Exception as e:
            logger.debug(f"Error extracting confidence: {e}, using default: 0.8")
            return 0.8

    def _process_wake_word(self, recognized_text: str) -> tuple[bool, str]:
        """
        Process recognized text to detect wake word and extract command
        
        Args:
            recognized_text: The recognized speech text
            
        Returns:
            Tuple of (wake_word_detected, command_text)
        """
        text_lower = recognized_text.lower()
        original_text = recognized_text
        
        logger.debug(f"Processing text: '{recognized_text}'")
        logger.debug(f"Looking for wake word: '{self.wake_word}'")
        
        # Check if wake word is present
        if self.wake_word not in text_lower:
            logger.debug("Wake word not found in text")
            return False, ""
        
        # Extract command text after wake word
        wake_word_index = text_lower.find(self.wake_word)
        command_start = wake_word_index + len(self.wake_word)
        
        # Get the command part using original case
        command_text = original_text[command_start:].strip()
        
        # Remove common punctuation and separators at the beginning
        command_text = command_text.lstrip('.,!?:;-').strip()
        
        # Remove common punctuation at the end
        command_text = command_text.rstrip('.,!?').strip()
        
        logger.debug(f"Extracted command: '{command_text}'")
        
        # Ensure we have a meaningful command
        if len(command_text) < 2:
            logger.debug("Command too short, rejecting")
            return False, ""
        
        # Additional validation - check if it's just punctuation or whitespace
        if not command_text.replace(' ', '').replace(',', '').replace('.', ''):
            logger.debug("Command contains only punctuation, rejecting")
            return False, ""
        
        return True, command_text

    def _handle_wake_word_detection(self, detection: WakeWordDetection):
        """
        Handle a wake word detection event
        
        Args:
            detection: WakeWordDetection instance
        """
        start_time = time.time()
        
        try:
            # Update statistics
            self.detection_count += 1
            
            # Add to history
            self.detection_history.append(detection)
            
            # Keep only recent detections (last 100)
            if len(self.detection_history) > 100:
                self.detection_history = self.detection_history[-100:]
            
            # Add to queue for real-time streaming
            try:
                self.recent_detections.put_nowait(detection)
            except:
                pass  # Queue full, ignore
            
            logger.info(f"Wake word detected! Command: '{detection.command_text}' (confidence: {detection.confidence:.2f})")
            
            # Process command
            if self.callback and detection.command_text:
                try:
                    # Run callback in separate thread to avoid blocking recognition
                    processing_thread = threading.Thread(
                        target=self._process_command_async,
                        args=(detection.command_text,),
                        daemon=True
                    )
                    processing_thread.start()
                except Exception as e:
                    logger.error(f"Error starting command processing thread: {e}")
            
            # Update processing time
            processing_time = int((time.time() - start_time) * 1000)
            detection.processing_time_ms = processing_time
            
        except Exception as e:
            logger.error(f"Error handling wake word detection: {e}")

    def _process_command_async(self, command_text: str):
        """Process command asynchronously to avoid blocking recognition"""
        try:
            self.is_processing = True
            if self.callback:
                self.callback(command_text)
        except Exception as e:
            logger.error(f"Error in command callback: {e}")
        finally:
            self.is_processing = False

    def start_listening(self) -> bool:
        """
        Start continuous wake word detection
        
        Returns:
            True if started successfully, False otherwise
        """
        if self.is_listening:
            logger.warning("Wake word detection is already running")
            return True
        
        try:
            logger.info(f"Starting wake word detection for: '{self.wake_word}'")
            
            # Reset stop event
            self.stop_event.clear()
            
            # Start continuous recognition
            self.speech_recognizer.start_continuous_recognition()
            
            # Update state
            self.is_listening = True
            self.session_id = f"session_{int(time.time())}"
            
            # Start monitoring thread
            self.listen_thread = threading.Thread(
                target=self._monitor_recognition,
                daemon=True
            )
            self.listen_thread.start()
            
            logger.info("Wake word detection started successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start wake word detection: {e}")
            self.is_listening = False
            return False

    def _monitor_recognition(self):
        """Monitor recognition thread"""
        try:
            while not self.stop_event.is_set():
                time.sleep(1)
        except Exception as e:
            logger.error(f"Error in recognition monitoring: {e}")

    def stop_listening(self) -> bool:
        """
        Stop wake word detection
        
        Returns:
            True if stopped successfully, False otherwise
        """
        if not self.is_listening:
            logger.warning("Wake word detection is not running")
            return True
        
        try:
            logger.info("Stopping wake word detection")
            
            # Signal stop
            self.stop_event.set()
            
            # Stop continuous recognition
            if self.speech_recognizer:
                self.speech_recognizer.stop_continuous_recognition()
            
            # Update state
            self.is_listening = False
            
            # Wait for monitoring thread to finish
            if self.listen_thread and self.listen_thread.is_alive():
                self.listen_thread.join(timeout=2)
            
            logger.info("Wake word detection stopped successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error stopping wake word detection: {e}")
            return False

    def get_status(self) -> Dict[str, Any]:
        """
        Get current status of wake word detector
        
        Returns:
            Dictionary with status information
        """
        recent_detections = []
        temp_detections = []
        
        # Get recent detections from queue
        while not self.recent_detections.empty():
            try:
                detection = self.recent_detections.get_nowait()
                temp_detections.append(detection.to_dict())
            except Empty:
                break
        
        # Get last 5 from history
        recent_from_history = self.detection_history[-5:] if self.detection_history else []
        for detection in recent_from_history:
            recent_detections.append(detection.to_dict())
        
        return {
            "listening": self.is_listening,
            "processing": self.is_processing,
            "wake_word": self.wake_word,
            "detection_count": self.detection_count,
            "session_id": self.session_id,
            "confidence_threshold": self.confidence_threshold,
            "language": self.language,
            "recent_detections": recent_detections[-10:],  # Last 10 detections
            "uptime_seconds": time.time() - float(self.session_id.split('_')[1]) if self.session_id else 0
        }

    def get_recent_detection(self, timeout: float = 1.0) -> Optional[WakeWordDetection]:
        """
        Get the next recent detection (blocking call)
        
        Args:
            timeout: Maximum time to wait for detection
            
        Returns:
            WakeWordDetection instance or None if timeout
        """
        try:
            return self.recent_detections.get(timeout=timeout)
        except Empty:
            return None

    def cleanup(self):
        """Cleanup resources"""
        try:
            self.stop_listening()
            
            if self.speech_recognizer:
                # Disconnect event handlers
                self.speech_recognizer.recognized.disconnect_all()
                self.speech_recognizer.session_started.disconnect_all()
                self.speech_recognizer.session_stopped.disconnect_all()
                self.speech_recognizer.canceled.disconnect_all()
            
            logger.info("Wake word detector cleanup completed")
            
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.cleanup()


class VoiceAssistantWithWakeWord:
    """
    Complete voice assistant with wake word detection integration
    
    This class integrates wake word detection with the voice assistant pipeline
    for full "Hey Buddy" -> Speech -> Search -> TTS functionality.
    """

    def __init__(self, wake_word: str = "hey buddy"):
        self.wake_word = wake_word
        self.detector = None
        self.voice_pipeline = None

    def _setup_voice_pipeline(self):
        """Setup voice assistant pipeline integration"""
        try:
            # Import here to avoid circular imports
            from voice_assistant.postgres_service import get_postgres_vector_service
            self.voice_pipeline = get_postgres_vector_service("general_docs")
            logger.info("Voice assistant pipeline initialized")
        except Exception as e:
            logger.warning(f"Voice pipeline not available: {e}")

    def _process_wake_word_command(self, command_text: str):
        """Process wake word command through voice assistant pipeline"""
        try:
            logger.info(f"Processing wake word command: '{command_text}'")
            
            if self.voice_pipeline:
                # Use the voice assistant pipeline
                result = self.voice_pipeline.search_similar(
                    query=command_text,
                    max_results=3,
                    similarity_threshold=0.5
                )
                
                if result["status"] == "success":
                    logger.info(f"Found {len(result['relevant_chunks'])} relevant chunks")
                    if result.get("summary"):
                        logger.info(f"AI Summary: {result['summary'][:100]}...")
                else:
                    logger.warning(f"Voice pipeline failed: {result.get('error', 'Unknown error')}")
            else:
                logger.info(f"No voice pipeline available. Command: {command_text}")
                
        except Exception as e:
            logger.error(f"Error processing wake word command: {e}")

    def start(self) -> Optional[WakeWordDetector]:
        """
        Start the voice assistant with wake word detection
        
        Returns:
            WakeWordDetector instance if successful, None otherwise
        """
        try:
            # Setup voice pipeline
            self._setup_voice_pipeline()
            
            # Create wake word detector
            self.detector = WakeWordDetector(
                wake_word=self.wake_word,
                callback=self._process_wake_word_command
            )
            
            # Start detection
            if self.detector.start_listening():
                logger.info(f"Voice assistant with wake word '{self.wake_word}' started successfully")
                return self.detector
            else:
                logger.error("Failed to start wake word detection")
                return None
                
        except Exception as e:
            logger.error(f"Failed to start voice assistant with wake word: {e}")
            return None

    def stop(self):
        """Stop the voice assistant"""
        if self.detector:
            self.detector.stop_listening()
            self.detector.cleanup()
            self.detector = None
            logger.info("Voice assistant with wake word stopped")

    def get_status(self) -> Dict[str, Any]:
        """Get status of voice assistant"""
        if self.detector:
            status = self.detector.get_status()
            status["voice_pipeline_available"] = self.voice_pipeline is not None
            return status
        else:
            return {"listening": False, "voice_pipeline_available": False}