import os
from azure.identity import DefaultAzureCredential
import psycopg2


# Step 1: Get Azure AD access token
def get_azure_access_token():
    try:
        credential = DefaultAzureCredential()
        token = credential.get_token("https://ossrdbms-aad.database.windows.net/.default")
        access_token = token.token
    except Exception as e:
        print("⚠️ Could not retrieve Azure AD token:", e)
        access_token = None

    
    return access_token