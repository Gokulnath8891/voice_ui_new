"""
URL configuration for workorder_system project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from api_endpoints import api_endpoints
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView, SpectacularRedocView

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # API Documentation (Swagger/OpenAPI)
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    
    # Authentication
    path('api/auth/', include('authentication.urls')),
    
    # Dash App API endpoints - MUST come before generic includes to avoid conflicts
    path('api/login/', api_endpoints.login, name='api_login'),
    path('api/technician/workorders/', api_endpoints.get_technician_work_orders, name='technician_workorders'),
    path('api/manager/workorders/', api_endpoints.get_manager_work_orders, name='manager_workorders'),
    path('api/chat/query/', api_endpoints.process_chat_query, name='chat_query'),
    path('api/chat/feedback/', api_endpoints.process_session_feedback, name='session_feedback'),
    path('api/voice/commands/', api_endpoints.get_voice_commands, name='voice_commands'),
    path('api/voice/init/', api_endpoints.init_voice_proxy, name='voice_init'),
    path('api/workorder/<int:work_order_id>/feedback/', api_endpoints.get_work_order_feedback_history, name='workorder_feedback_history'),
    path('api/workorder/reset/', api_endpoints.reset_work_order, name='reset_workorder'),
    
    # Generic app includes - these should come after specific endpoints
    path('api/', include('workorders.urls')),
    path('api/', include('voice_assistant.urls')),
    path('api/v1/wakeword/', include('wake_word_detection.urls')),
]

# Serve static files in development
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
