from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User, Group
from workorders.models import TechnicianProfile


@receiver(post_save, sender=User)
def create_user_profile_and_assign_group(sender, instance, created, **kwargs):
    if created:
        # Check if user already belongs to Service Manager group
        if not instance.groups.filter(name='Service Manager').exists():
            # Assign to Technician group by default
            technician_group, _ = Group.objects.get_or_create(name='Technician')
            instance.groups.add(technician_group)
            
            # Create TechnicianProfile
            TechnicianProfile.objects.create(
                user=instance,
                employee_id=f"TECH-{instance.id:04d}"
            )


@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    # Update profile if it exists
    if hasattr(instance, 'technician_profile'):
        instance.technician_profile.save()
    elif hasattr(instance, 'service_manager_profile'):
        instance.service_manager_profile.save()