import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface ChatMessage {
  text: string;
  isVoice?: boolean;
  autoOpen?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class ChatCommunicationService {
  private readonly messageSubject = new Subject<ChatMessage>();
  
  // Observable stream
  message$ = this.messageSubject.asObservable();

  /**
   * Send a message to the chat widget
   * @param text - The text message to send
   * @param isVoice - Whether to play voice output (default: true)
   * @param autoOpen - Whether to auto-open the chat widget (default: true)
   */
  sendMessage(text: string, isVoice: boolean = true, autoOpen: boolean = true) {
    this.messageSubject.next({ text, isVoice, autoOpen });
  }
}
