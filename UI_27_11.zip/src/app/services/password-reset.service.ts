import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, switchMap } from 'rxjs/operators';

export interface ForgotPasswordRequest {
  email: string;
}

export interface ForgotPasswordResponse {
  success: boolean;
  message: string;
}

export interface ResetPasswordRequest {
  token: string;
  password: string;
  confirmPassword: string;
}

export interface ResetPasswordResponse {
  success: boolean;
  message: string;
}

export interface ValidateTokenRequest {
  token: string;
}

export interface ValidateTokenResponse {
  valid: boolean;
  expired: boolean;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class PasswordResetService {
  private apiUrl = '/api/auth'; // Replace with your actual API URL

  constructor(private http: HttpClient) {}

  /**
   * Send password reset email
   */
  forgotPassword(request: ForgotPasswordRequest): Observable<ForgotPasswordResponse> {
    // In a real application, this would make an HTTP call to your backend
    // return this.http.post<ForgotPasswordResponse>(`${this.apiUrl}/forgot-password`, request);
    
    // For demo purposes, simulate the API call
    return this.simulateForgotPasswordAPI(request);
  }

  /**
   * Validate password reset token
   */
  validateResetToken(request: ValidateTokenRequest): Observable<ValidateTokenResponse> {
    // In a real application:
    // return this.http.post<ValidateTokenResponse>(`${this.apiUrl}/validate-reset-token`, request);
    
    // For demo purposes, simulate the API call
    return this.simulateValidateTokenAPI(request);
  }

  /**
   * Reset password with valid token
   */
  resetPassword(request: ResetPasswordRequest): Observable<ResetPasswordResponse> {
    // In a real application:
    // return this.http.post<ResetPasswordResponse>(`${this.apiUrl}/reset-password`, request);
    
    // For demo purposes, simulate the API call
    return this.simulateResetPasswordAPI(request);
  }

  /**
   * Demo implementation - simulate forgot password API
   */
  private simulateForgotPasswordAPI(request: ForgotPasswordRequest): Observable<ForgotPasswordResponse> {
    return of(null).pipe(
      delay(2000), // Simulate network delay
      switchMap(() => {
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(request.email)) {
          return throwError(() => new Error('Invalid email format'));
        }

        // Simulate different scenarios
        if (request.email.includes('notfound')) {
          return of({
            success: false,
            message: 'No account found with this email address.'
          });
        }

        // Success case
        return of({
          success: true,
          message: `Password reset instructions have been sent to ${request.email}`
        });
      })
    );
  }

  /**
   * Demo implementation - simulate token validation API
   */
  private simulateValidateTokenAPI(request: ValidateTokenRequest): Observable<ValidateTokenResponse> {
    return of(null).pipe(
      delay(1000),
      switchMap(() => {
        // Simulate different token scenarios
        if (!request.token || request.token.length < 10) {
          return of({
            valid: false,
            expired: false,
            message: 'Invalid reset token'
          });
        }

        if (request.token.includes('expired')) {
          return of({
            valid: false,
            expired: true,
            message: 'Reset token has expired. Please request a new password reset.'
          });
        }

        // Valid token
        return of({
          valid: true,
          expired: false,
          message: 'Token is valid'
        });
      })
    );
  }

  /**
   * Demo implementation - simulate reset password API
   */
  private simulateResetPasswordAPI(request: ResetPasswordRequest): Observable<ResetPasswordResponse> {
    return of(null).pipe(
      delay(2000),
      switchMap(() => {
        // Validate passwords match
        if (request.password !== request.confirmPassword) {
          return throwError(() => new Error('Passwords do not match'));
        }

        // Validate password strength
        if (request.password.length < 8) {
          return throwError(() => new Error('Password must be at least 8 characters long'));
        }

        // Success case
        return of({
          success: true,
          message: 'Password has been successfully reset'
        });
      })
    );
  }

  /**
   * Generate a demo reset token (for testing purposes)
   */
  generateDemoResetToken(): string {
    return 'demo-reset-token-' + Math.random().toString(36).substr(2, 9);
  }

  /**
   * Generate demo reset URL (for testing purposes)
   */
  generateDemoResetUrl(token: string, baseUrl: string = window.location.origin): string {
    return `${baseUrl}/reset-password?token=${token}`;
  }
}
