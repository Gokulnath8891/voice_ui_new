import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../services/auth.service';

// Import interfaces from work-order service
export interface StartWorkRequest {
  query: string;
  user_id: number;
  type: 'text' | 'voice';
}

export interface WorkOrderStartResponse {
  type: 'work_order_start' | 'error';
  session_id?: string;
  message: string;
  tts_text?: string;
  work_order?: any;
  current_step?: any;
}

export interface AgenticRagRequest {
  query: string;
}

export interface RetrievedDocument {
  id: string;
  content: string;
  score: number;
}

export interface PerSubQuery {
  subquery: string;
  rewritten: string;
  retrived: RetrievedDocument[];
}

export interface Judge {
  reason: string;
  verdict: string;
}

export interface AgenticRagResponse {
  success: boolean;
  route: string;
  result: string;
  query: string;
  per_sub?: PerSubQuery[];
  judge?: Judge;
  context?: string;
  response?: string;
  tts_text?: string;
}

@Injectable({
  providedIn: 'root',
})
export class VoiceApiService {
  private readonly API_BASE_URL = environment.baseUrl;
  private readonly VOICE_ENDPOINT = `${this.API_BASE_URL}/search/query`;
  private readonly CHAT_ENDPOINT = `${this.API_BASE_URL}/chat`;
  private readonly CHAT_QUERY_ENDPOINT = `${environment.apiUrl}/chat/query/`;
  private readonly AGENTIC_RAG_ENDPOINT = `${environment.apiUrl}/agentic-rag/query/`;

  constructor(
    private readonly http: HttpClient,
    private readonly authService: AuthService
  ) {}

  async sendVoiceMessage(transcribedText: string): Promise<{ response: string; audioResponse?: Blob }> {
    try {
      console.log(this.VOICE_ENDPOINT,"this.VOICE_ENDPOINT");
      const response = await fetch(this.VOICE_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: transcribedText,
          max_chunks: 5,
          similarity_threshold: 0.7,
        }),
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const contentType = response.headers.get('content-type');

      if (contentType?.includes('application/json')) {
        const jsonResponse = await response.json();
        return {
          response: jsonResponse.summary || jsonResponse.response || jsonResponse.answer || 'No response available',
        };
      } else if (contentType?.includes('audio')) {
        const audioResponse = await response.blob();
        return {
          response: response.headers.get('x-response-text') || 'Audio response received',
          audioResponse,
        };
      } else {
        throw new Error('Unexpected response format');
      }
    } catch (error) {
      console.error('Voice API error:', error);
      throw new Error('Failed to process voice message');
    }
  }

  async sendTextToAPI(text: string): Promise<string> {
    try {
      // Check if this is a work order request
      // Pattern 1: "help me fix WO-20241009" or "help me to fix WO-20241009"
      // Pattern 2: "help me fix work order 20241009" or "help me to fix work order 20241009"
      // Updated patterns to capture full number including variations like "20 24 10 01"
      const workOrderPattern1 = /help\s+me\s+(?:to\s+)?fix\s+(?:wo[-\s]?)?(\d+(?:\s*\d+)*)/i;
      const workOrderPattern2 = /help\s+me\s+(?:to\s+)?fix\s+work\s+order\s+(\d+(?:\s*\d+)*)/i;
      
      let match = workOrderPattern2.exec(text); // Try "work order" pattern first
      let workOrderNumber = '';
      
      if (match) {
        // Remove spaces from the number (in case speech recognition separates digits)
        const numberPart = match[1].replaceAll(/\s+/g, '');
        workOrderNumber = `WO-${numberPart}`;
        console.log('[VoiceAPI] Work order detected (pattern 2):', workOrderNumber);
      } else {
        match = workOrderPattern1.exec(text);
        if (match) {
          // Remove spaces from the number
          const numberPart = match[1].replaceAll(/\s+/g, '');
          workOrderNumber = `WO-${numberPart}`;
          console.log('[VoiceAPI] Work order detected (pattern 1):', workOrderNumber);
        }
      }
      
      if (workOrderNumber) {
        console.log('[VoiceAPI] 📋 Final work order number:', workOrderNumber);
        const userId = 1; // TODO: Get from auth service
        
        // Call the work order start API
        const workOrderResponse = await this.startWorkOrder(workOrderNumber, userId, 'voice');
        
        if (workOrderResponse.type === 'work_order_start') {
          let responseText = workOrderResponse.message;
          
          if (workOrderResponse.current_step) {
            responseText += `\n\nStep ${workOrderResponse.current_step.step_number}:\n${workOrderResponse.current_step.description}`;
            
            if (workOrderResponse.current_step.estimated_time) {
              responseText += `\n\nEstimated time: ${workOrderResponse.current_step.estimated_time}`;
            }
          }
          
          return responseText;
        } else {
          return workOrderResponse.message || 'Error starting work order';
        }
      }
      
      // For non-work-order queries, use the agentic RAG endpoint
      console.log('[VoiceAPI] Using agentic RAG endpoint for general query');
      return await this.queryAgenticRag(text);
    } catch (error) {
      console.error('Chat API error:', error);
      throw new Error('Failed to get chat response');
    }
  }

  /**
   * Start work order via chat API
   */
  async startWorkOrder(workOrderNumber: string, userId: number, type: 'text' | 'voice'): Promise<WorkOrderStartResponse> {
    try {
      // Get authentication token
      const token = this.authService.getToken();
      if (!token) {
        throw new Error('Authentication required. Please log in.');
      }

      const payload: StartWorkRequest = {
        query: `help me fix ${workOrderNumber}`,
        user_id: userId,
        type
      };

      const response = await fetch(this.CHAT_QUERY_ENDPOINT, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication failed. Please log in again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result: WorkOrderStartResponse = await response.json();
      
      // Store session ID for future feedback submissions
      if (result.session_id) {
        sessionStorage.setItem('current_session_id', result.session_id);
        sessionStorage.setItem('current_work_order', workOrderNumber);
      }
      
      return result;
    } catch (error) {
      console.error('Work order start API error:', error);
      return {
        type: 'error',
        message: 'Failed to start work order. Please try again.'
      };
    }
  }

  /**
   * Query agentic RAG endpoint for general queries
   * Returns the result field from the response
   */
  async queryAgenticRag(query: string): Promise<string> {
    try {
      // Get authentication token
      const token = this.authService.getToken();
      if (!token) {
        throw new Error('Authentication required. Please log in.');
      }

      const payload: AgenticRagRequest = {
        query
      };

      console.log('[VoiceAPI] Calling agentic RAG with query:', query);

      const response = await fetch(this.AGENTIC_RAG_ENDPOINT, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication failed. Please log in again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result: AgenticRagResponse = await response.json();
      
      console.log('[VoiceAPI] Agentic RAG full response:', result);
      
      // Return the result field from the new format
      // Fallback to old format if needed
      if(result.success && result.result) {
        console.log('[VoiceAPI] Returning result:', result.result);
        console.log('[VoiceAPI] Route:', result.route);
        console.log('[VoiceAPI] Query', result.query);
        if(result.per_sub){
          console.log('[VoiceAPI] Per Sub Queries:', result.per_sub.length);
        }
        if(result.judge){
          console.log('[VoiceAPI] Judge Verdict:', result.judge.verdict);
        }
        return result.result;
      }

      // Fallbacks to old format
      return result.response || result.tts_text || 'No response available';
    } catch (error) {
      console.error('Agentic RAG API error:', error);
      throw new Error('Failed to get response from agentic RAG. Please try again.');
    }
  }

  speakText(text: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if ('speechSynthesis' in globalThis) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;

        utterance.onend = () => resolve();
        utterance.onerror = (event) => reject(new Error(`Speech synthesis error: ${event.error}`));

        speechSynthesis.speak(utterance);
      } else {
        reject(new Error('Speech synthesis not supported'));
      }
    });
  }
}
