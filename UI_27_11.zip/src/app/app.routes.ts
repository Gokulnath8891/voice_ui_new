import {Routes} from '@angular/router';
import { WorkOrderComponent } from './work-orders/work-order.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
// import {NotFoundComponent} from '@wame/ngx-frf-utilities';
import { authGuard, loginGuard } from './guards/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    title: 'Voice Assistant - Login',
    canActivate: [loginGuard]
  },
  {
    path: 'forgot-password',
    component: ForgotPasswordComponent,
    title: 'Voice Assistant - Forgot Password',
    canActivate: [loginGuard]
  },
  {
    path: 'reset-password',
    component: ResetPasswordComponent,
    title: 'Voice Assistant - Reset Password',
    canActivate: [loginGuard]
  },
  {
    path: 'work-order',
    component: WorkOrderComponent,
    title: 'Voice Assistant - Work Orders',
    canActivate: [authGuard]
  },
  {
    path: 'profile',
    component: ProfileComponent,
    title: 'Voice Assistant - Profile',
    canActivate: [authGuard]
  },
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full',
  },
  {
    path: '404',
    component: LoginComponent,
  },
  {
    path: '**',
    redirectTo: '/404',
  },
];
