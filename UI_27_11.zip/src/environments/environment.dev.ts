/**This file contains a constant object that has properties that are necessary
 * for the build found in the `dev` configuration in `angular.json`.
 */

export const environment = {
  production: true,
  apiUrl: 'http://localhost:8000/api',
  baseUrl: '',
  openidUrl: '',
  openidClientId: '',
  openidResource: '',
};
