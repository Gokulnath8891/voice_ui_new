export interface RuntimeConfig {
    azureSpeech: {
        subscriptionKey: string;
        region: string;
        language: string;
    };
    apiUrl?: string;
    baseUrl?: string;
}