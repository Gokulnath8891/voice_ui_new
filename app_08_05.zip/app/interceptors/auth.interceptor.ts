import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401) {
        // Clear any stored authentication data
        sessionStorage.clear();
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
        
        console.warn('[AuthInterceptor] 401 Unauthorized - Redirecting to login');
        
        // Redirect to login page
        router.navigate(['/login'], {
          queryParams: { returnUrl: router.url }
        });
      }
      
      return throwError(() => error);
    })
  );
};
