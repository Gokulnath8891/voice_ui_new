import {Component, OnInit, OnDestroy} from '@angular/core';
import {NavigationEnd, Router, RouterOutlet} from '@angular/router';
import {filter} from 'rxjs/operators';
import {CommonModule} from '@angular/common';
import {NavComponent} from './nav/nav.component';
import {ToastModule} from 'primeng/toast';
import {FooterComponent} from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { ChatWidgetComponent } from './chat-widget/chat-widget.component';
import { Subscription } from 'rxjs';
import { VoiceRecognitionService } from './services/voice-recognition.service';

/** Class for the app component that is bootstrapped to run the application
 */
@Component({
  selector: 'body',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: true,
  imports: [CommonModule, NavComponent, ToastModule, RouterOutlet, HeaderComponent, FooterComponent, ChatWidgetComponent],
})
export class AppComponent implements OnInit, OnDestroy {
  /** string used to hold the url for the skipToMain link */
  skipToMain: string;
  
  /** boolean to track if we're on the login page */
  isLoginPage: boolean = false;

  /** boolean to show/hide chat widget */
  showBot: boolean = false;

  private wakeWordSubscription?: Subscription;

  /** constructor for setting up DI in this component */
  constructor(private readonly router: Router, private voiceService: VoiceRecognitionService) {}

  /** this class requires this method to implement the OnInit interface */
  ngOnInit(): void {
    // Check initial route
    this.checkIfLoginPage(this.router.url);
    
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.setSkipLinkUrl(event.urlAfterRedirects);
        this.checkIfLoginPage(event.urlAfterRedirects);
      });
    
    // Start wake word detection
    this.startWakeWordDetection();
  }

  ngOnDestroy() {
    if (this.wakeWordSubscription) {
      this.wakeWordSubscription.unsubscribe();
    }
    this.voiceService.stopWakeWordDetection();
  }

  /**
   * setSkipLinkUrl takes in a url string and processes whether
   * the skipToMain link should be updated to use the new value
   * @param currentUrl the new url to refer to
   */
  private setSkipLinkUrl(currentUrl: string): void {
    if (!currentUrl.endsWith('#app-content')) {
      this.skipToMain = `${currentUrl}#app-content`;
    }
  }

  /**
   * checkIfLoginPage determines if the current route is an authentication page
   * @param currentUrl the current url to check
   */
  private checkIfLoginPage(currentUrl: string): void {
    const authPages = ['/login', '/forgot-password', '/reset-password'];
    this.isLoginPage = authPages.some(page => 
      currentUrl === page || currentUrl.startsWith(page + '?') || currentUrl.startsWith(page + '/')
    );
  }

  private startWakeWordDetection() {
    // Listen for wake word
    this.wakeWordSubscription = this.voiceService.onWakeWordDetected.subscribe(() => {
      console.log('Wake word detected: hey buddy');
      this.showBot = true;
      this.voiceService.stopWakeWordDetection();
      
      // Start listening for user input after opening widget
      setTimeout(() => {
        this.voiceService.enableContinuousListening();
        this.voiceService.start();
      }, 500);
    });

    // Start wake word detection
    this.voiceService.startWakeWordDetection();
  }

  toggleBot() {
    this.showBot = !this.showBot;
    
    if (!this.showBot) {
      this.voiceService.stop();
      // Restart wake word detection when widget is closed
      this.startWakeWordDetection();
    } else {
      this.voiceService.stopWakeWordDetection();
      this.voiceService.enableContinuousListening();
      this.voiceService.start();
    }
  }
}
