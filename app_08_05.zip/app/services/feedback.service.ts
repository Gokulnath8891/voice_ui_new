import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AuthService } from './auth.service';
import { ApiRequestManagerService } from './api-request-manager.service';

export interface FeedbackRequest {
  session_id: string;
  step_number: number;
  feedback: 'positive' | 'negative';
  notes: string;
  user_id: number;
}

export interface WorkOrderFeedbackRequest {
  step_id: number;
  feedback_text: string;
  time_spent: number;
}

export interface CurrentStep {
  id?: number;
  step_number: number;
  title: string;
  description: string;
  instruction: string;
  estimated_time: number;
}

export interface Progress {
  completed: number;
  total: number;
  percentage: number;
}

export interface FeedbackResponse {
  status?: string;
  message: string;
  type?: string;
  tts_text?: string;
  current_step?: CurrentStep;
  next_step?: CurrentStep; // For work order feedback endpoint
  progress?: Progress;
  instruction?: string;
  total_steps?: number;
  total_time?: number | string;
  completed_steps?: number; // For work order feedback endpoint
}

export interface FeedbackHistoryItem {
  id: number;
  session_id: string;
  step_number: number;
  feedback: 'positive' | 'negative';
  notes: string;
  created_at: string;
}

export interface FeedbackHistoryResponse {
  feedbacks: FeedbackHistoryItem[];
}

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  private readonly apiUrl = environment.apiUrl;

  constructor(
    private readonly http: HttpClient,
    private readonly authService: AuthService,
    private readonly apiRequestManager: ApiRequestManagerService
  ) {}

  /**
   * Submit feedback for a chat/work order step
   */
  submitFeedback(
    sessionId: string, 
    stepNumber: number, 
    feedback: 'positive' | 'negative', 
    notes: string = '',
    userId: number = 1
  ): Observable<FeedbackResponse> {
    console.log(`[FeedbackService] 🎯 submitFeedback called:`, { sessionId, stepNumber, feedback });

    const payload: FeedbackRequest = {
      session_id: sessionId,
      step_number: stepNumber,
      feedback: feedback,
      notes: notes,
      user_id: userId
    };

    console.log(`[FeedbackService] 📤 Making HTTP POST to: chat/feedback/`);

    // Use the centralized API request manager
    // It will automatically handle deduplication
    return this.apiRequestManager.post<FeedbackResponse>(
      'chat/feedback/',
      payload
    );
  }

  /**
   * Submit feedback for resumed work order step
   */
  submitWorkOrderFeedback(
    workOrderId: number,
    stepId: number,
    feedbackText: string,
    timeSpent: number = 0.5
  ): Observable<FeedbackResponse> {
    console.log(`[FeedbackService] 🎯 submitWorkOrderFeedback called:`, { workOrderId, stepId });

    const payload: WorkOrderFeedbackRequest = {
      step_id: stepId,
      feedback_text: feedbackText,
      time_spent: timeSpent
    };

    console.log(`[FeedbackService] 📤 Making HTTP POST to: workorders/${workOrderId}/feedback/`);

    // Use the centralized API request manager
    // It will automatically handle deduplication
    return this.apiRequestManager.post<FeedbackResponse>(
      `workorders/${workOrderId}/feedback/`,
      payload
    );
  }

  /**
   * Get feedback history for a work order
   */
  getFeedbackHistory(workorderId: number): Observable<FeedbackHistoryResponse> {
    const token = this.authService.getToken();
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    return this.http.get<FeedbackHistoryResponse>(
      `${this.apiUrl}/workorder/${workorderId}/feedback/`,
      { headers }
    );
  }
}
