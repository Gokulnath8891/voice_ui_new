import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { RuntimeConfig } from "../models/runtime-config.interface";
import { environment } from "../../environments/environment";

/*
    * Service to load runtime configuration from external config file
    * This allows injecting secrets at contrainer startup without rebuilding the Angular app
*/

@Injectable({
  providedIn: "root"
})
export class RuntimeConfigService {
  private config: RuntimeConfig | null = null;

  constructor(private http: HttpClient) {}

  /** Load configuration from assets/config.json
   * This file is generated at container startup with injected secrets
  */

  async loadConfig(): Promise<void> {
    try {
        this.config = await this.http.get<RuntimeConfig>("/assets/config.json").toPromise();

        // Merge runtime config with environment variables, giving precedence to runtime config
        if(this.config?.azureSpeech?.subscriptionKey) {
            environment.azureSpeech.subscriptionKey = this.config.azureSpeech.subscriptionKey;
        }
        if(this.config?.azureSpeech?.region) {
            environment.azureSpeech.region = this.config.azureSpeech.region;
        }   
        if(this.config?.azureSpeech?.language) {
            environment.azureSpeech.language = this.config.azureSpeech.language;
        }
        if(this.config?.apiUrl) {
            environment.apiUrl = this.config.apiUrl;
        }  
        if(this.config?.baseUrl) {
            environment.baseUrl = this.config.baseUrl;
        }
    } catch (error) {
        console.warn("Failed to load runtime configuration:", error);
    }
}
getConfig(): RuntimeConfig | null {
    return this.config;
}
}
