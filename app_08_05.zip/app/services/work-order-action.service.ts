import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface WorkOrderAction {
  orderNumber: string;
  action: 'start' | 'resume' | 'restart';
  apiResponse?: string; // API response text to display in modal
}

@Injectable({
  providedIn: 'root'
})
export class WorkOrderActionService {
  private readonly actionSubject = new Subject<WorkOrderAction>();
  
  // Observable stream for work order actions
  action$ = this.actionSubject.asObservable();

  /**
   * Trigger a work order action
   */
  triggerAction(orderNumber: string, action: 'start' | 'resume' | 'restart', apiResponse?: string) {
    console.log('[WorkOrderActionService] 🚀 Triggering action:', action, 'for order:', orderNumber);
    if (apiResponse) {
      console.log('[WorkOrderActionService] 📝 API Response:', apiResponse);
    }
    this.actionSubject.next({ orderNumber, action, apiResponse });
  }
}
