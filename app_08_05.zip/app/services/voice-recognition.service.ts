import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VoiceRecognitionService {
  recognition: any;
  isListening = false;
  text = '';
  tempWords = '';
  
  public onResult = new Subject<string>();
  public onWakeWordDetected = new Subject<void>();
  
  private wakeWordActive = false;
  private continuousListening = false;

  constructor() {
    this.initVoiceRecognition();
  }

  initVoiceRecognition() {
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      
      this.recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result) => result.transcript)
          .join('')
          .toLowerCase();

        if (this.wakeWordActive && transcript.includes('hey buddy')) {
          this.onWakeWordDetected.next();
          this.text = '';
          return;
        }

        this.text = transcript;
        this.tempWords = transcript;
        this.onResult.next(transcript);
      };

      this.recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
      };

      this.recognition.onend = () => {
        this.isListening = false;
        if (this.continuousListening || this.wakeWordActive) {
          setTimeout(() => {
            if (this.isListening) {
              try {
                this.recognition.start();
              } catch (e) {
                console.error('Error restarting recognition:', e);
              }
            }
          }, 100);
        }
      };
    } else {
      console.error('Speech recognition not supported');
    }
  }

  start() {
    if (this.recognition && !this.isListening) {
      try {
        this.recognition.start();
        this.isListening = true;
      } catch (e) {
        console.error('Error starting recognition:', e);
      }
    }
  }

  stop() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
        this.isListening = false;
      } catch (e) {
        console.error('Error stopping recognition:', e);
      }
    }
  }

  startWakeWordDetection() {
    this.wakeWordActive = true;
    this.continuousListening = true;
    this.start();
  }

  stopWakeWordDetection() {
    this.wakeWordActive = false;
    this.continuousListening = false;
    this.stop();
  }

  enableContinuousListening() {
    this.continuousListening = true;
    if (this.recognition) {
      this.recognition.continuous = true;
    }
  }

  disableContinuousListening() {
    this.continuousListening = false;
    if (this.recognition) {
      this.recognition.continuous = false;
    }
  }
}