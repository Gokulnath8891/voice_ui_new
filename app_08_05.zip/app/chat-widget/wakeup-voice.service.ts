import {Injectable, NgZone} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class WakeupVoiceService {
  private recognition: any;
  private isActive = false;
  private restartTimeout: any = null;
  private wakeWord = 'hey buddy';
  private wakeupCallbacks: Array<() => void> = []; // Support multiple callbacks
  private workOrderCallbacks: Array<(transcript: string) => void> = []; // Support multiple callbacks

  constructor(private readonly zone: NgZone) {
    console.log('[VoiceWakeup] Service initialized');

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.error('[VoiceWakeup] SpeechRecognition is not supported in this browser.');
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.lang = 'en-US';
    this.recognition.interimResults = false;
    this.recognition.maxAlternatives = 1;

    this.recognition.onstart = () => {
      console.log('[VoiceWakeup] ✅ Recognition started');
    };

    this.recognition.onerror = (event: any) => {
      console.error(`[VoiceWakeup] ❌ Error: ${event.error}`);

      switch (event.error) {
        case 'no-speech':
          // Normal - just continue
          break;
        case 'audio-capture':
        case 'not-allowed':
          console.log('[VoiceWakeup] 🚫 Microphone access issue - stopping');
          this.isActive = false;
          break;
        case 'aborted':
          console.log('[VoiceWakeup] ⚠️ Aborted by another service');
          // Don't change isActive - we want to restart
          break;
        default:
          console.log(`[VoiceWakeup] Unknown error: ${event.error}`);
          break;
      }
    };

    this.recognition.onresult = (event: any) => {
      const transcript = event.results[event.resultIndex][0].transcript.trim().toLowerCase();
      console.log('[VoiceWakeup] 🎤 Speech:', `"${transcript}"`);
      
      // Check wake word
      const normalizedTranscript = transcript.replace(/[,.!?]/g, '').trim();
      const normalizedWakeWord = this.wakeWord.replace(/[,.!?]/g, '').trim();
      
      if (normalizedTranscript.includes(normalizedWakeWord)) {
        console.log('[VoiceWakeup] ✅ Wake word detected!');
        // Call all registered wakeup callbacks
        this.zone.run(() => {
          this.wakeupCallbacks.forEach(callback => {
            try {
              callback();
            } catch (error) {
              console.error('[VoiceWakeup] Error in wakeup callback:', error);
            }
          });
        });
        return;
      }
      
      // Check work order commands
      const workOrderPattern = /(?:help\s+me\s+(?:to\s+)?fix|start|resume|restart)\s+(?:work\s*order|wo)\s+(\d+(?:\s*\d+)*)/i;
      if (workOrderPattern.test(transcript)) {
        console.log('[VoiceWakeup] 🎯 Work order command!');
        // Call all registered work order callbacks
        this.zone.run(() => {
          this.workOrderCallbacks.forEach(callback => {
            try {
              callback(transcript);
            } catch (error) {
              console.error('[VoiceWakeup] Error in work order callback:', error);
            }
          });
        });
      }
    };

    this.recognition.onend = () => {
      console.log('[VoiceWakeup] 🛑 Recognition ended. isActive:', this.isActive);
      
      // Clear any existing restart
      if (this.restartTimeout) {
        clearTimeout(this.restartTimeout);
        this.restartTimeout = null;
      }
      
      // Auto-restart only if still active
      if (this.isActive) {
        console.log('[VoiceWakeup] 🔄 Auto-restarting in 1s...');
        this.restartTimeout = setTimeout(() => {
          if (this.isActive) {
            this.internalStart();
          }
        }, 1000);
      }
    };
  }

  /**
   * Internal start method
   */
  private internalStart(): void {
    if (!this.recognition) return;
    
    try {
      this.recognition.start();
      console.log('[VoiceWakeup] ▶️ Start() called');
    } catch (error: any) {
      if (error.message && error.message.includes('already started')) {
        console.log('[VoiceWakeup] ℹ️ Already started');
      } else {
        console.error('[VoiceWakeup] ❌ Start error:', error.message);
      }
    }
  }

  /**
   * Register callbacks for wake word detection
   */
  startListening(callback: () => void, workOrderCallback?: (transcript: string) => void): void {
    if (!this.recognition) {
      console.error('[VoiceWakeup] Cannot start - no recognition');
      return;
    }

    console.log('[VoiceWakeup] 🎤 Registering callbacks. Current isActive:', this.isActive);
    
    // Add callbacks to arrays (avoid duplicates)
    if (!this.wakeupCallbacks.includes(callback)) {
      this.wakeupCallbacks.push(callback);
      console.log('[VoiceWakeup] ✅ Wakeup callback registered. Total:', this.wakeupCallbacks.length);
    }
    
    if (workOrderCallback && !this.workOrderCallbacks.includes(workOrderCallback)) {
      this.workOrderCallbacks.push(workOrderCallback);
      console.log('[VoiceWakeup] ✅ Work order callback registered. Total:', this.workOrderCallbacks.length);
    }

    // Start recognition if not already active
    if (!this.isActive) {
      this.isActive = true;
      this.internalStart();
    } else {
      console.log('[VoiceWakeup] ℹ️ Already listening, callbacks added');
    }
  }

  /**
   * Unregister specific callbacks
   */
  unregisterCallbacks(callback: () => void, workOrderCallback?: (transcript: string) => void): void {
    console.log('[VoiceWakeup] 🔕 Unregistering callbacks');
    
    // Remove specific callbacks
    const wakeupIndex = this.wakeupCallbacks.indexOf(callback);
    if (wakeupIndex > -1) {
      this.wakeupCallbacks.splice(wakeupIndex, 1);
      console.log('[VoiceWakeup] ✅ Wakeup callback removed. Remaining:', this.wakeupCallbacks.length);
    }
    
    if (workOrderCallback) {
      const workOrderIndex = this.workOrderCallbacks.indexOf(workOrderCallback);
      if (workOrderIndex > -1) {
        this.workOrderCallbacks.splice(workOrderIndex, 1);
        console.log('[VoiceWakeup] ✅ Work order callback removed. Remaining:', this.workOrderCallbacks.length);
      }
    }
    
    // Only stop if no more callbacks
    if (this.wakeupCallbacks.length === 0 && this.workOrderCallbacks.length === 0) {
      console.log('[VoiceWakeup] ⚠️ No more callbacks, stopping listener');
      this.stopListening();
    }
  }

  /**
   * Force restart
   */
  forceRestart(): void {
    console.log('[VoiceWakeup] 🔄 FORCE RESTART');
    
    this.isActive = true;
    
    if (this.restartTimeout) {
      clearTimeout(this.restartTimeout);
      this.restartTimeout = null;
    }
    
    try {
      this.recognition.stop();
    } catch (e) {
      // Ignore
    }
    
    setTimeout(() => {
      if (this.isActive) {
        console.log('[VoiceWakeup] ♻️ Restarting after force...');
        this.internalStart();
      }
    }, 500);
  }

  /**
   * Stop - only call when app is destroyed
   */
  stopListening(): void {
    if (!this.recognition) return;

    console.log('[VoiceWakeup] 🛑 STOP called');
    console.warn('[VoiceWakeup] ⚠️ This should only be called on app destroy!');
    console.trace('[VoiceWakeup] Stop called from:');
    
    // Clear all callbacks
    this.wakeupCallbacks = [];
    this.workOrderCallbacks = [];
    
    this.isActive = false;
    
    if (this.restartTimeout) {
      clearTimeout(this.restartTimeout);
      this.restartTimeout = null;
    }
    
    try {
      this.recognition.stop();
    } catch (error) {
      console.error('[VoiceWakeup] Stop error:', error);
    }
  }

  /**
   * Check if active
   */
  isCurrentlyListening(): boolean {
    return this.isActive;
  }

  /**
   * Get status
   */
  getStatus(): { isListening: boolean; hasRecognition: boolean; wakeWord: string; shouldKeepListening: boolean; callbackCount: number } {
    return {
      isListening: this.isActive,
      hasRecognition: !!this.recognition,
      wakeWord: this.wakeWord,
      shouldKeepListening: this.isActive,
      callbackCount: this.wakeupCallbacks.length + this.workOrderCallbacks.length
    };
  }
}
