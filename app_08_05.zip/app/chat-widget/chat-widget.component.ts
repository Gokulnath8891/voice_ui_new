import {Component, OnInit, OnDestroy, ChangeDetectorRef} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ButtonModule} from 'primeng/button';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {AvatarModule} from 'primeng/avatar';
import {FormsModule} from '@angular/forms';
import {TooltipModule} from 'primeng/tooltip';
import {Router} from '@angular/router';
import {VoiceApiService} from './voice-api.service';
import {WakeupVoiceService} from './wakeup-voice.service';
import {ChatCommunicationService} from '../services/chat-communication.service';
import {FeedbackService} from '../services/feedback.service';
import {WorkOrderActionService} from '../services/work-order-action.service';
import {AzureSpeechService} from '../services/azure-speech.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-chat-widget',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    InputTextareaModule,
    AvatarModule,
    FormsModule,
    TooltipModule,
  ],
  templateUrl: './chat-widget.component.html',
  styleUrls: ['./chat-widget.component.scss'],
})
export class ChatWidgetComponent implements OnInit, OnDestroy {
  
  isChatOpen = false;
  userInput = '';
  isRecording = false;
  isListening = false;
  isProcessing = false;
  isUserTyping = false; // Track if user is actively typing
  isVoicePlaying = false; // Track if voice output is playing
  isFeedbackInProgress = false; // Track if feedback is being submitted
  private readonly mediaRecorder: MediaRecorder | null = null;
  private readonly audioChunks: Blob[] = [];
  private autoOpenTimer: any = null;
  private autoCloseTimer: any = null;
  private readonly AUTO_CLOSE_DELAY = 30000; // 30 seconds
  private messageSubscription: Subscription | null = null;
  private azureSpeechResultSubscription: Subscription | null = null;
  private azureSpeechErrorSubscription: Subscription | null = null;
  private azureSpeechEndSubscription: Subscription | null = null;
  messages: {
    text: string; 
    sender: 'user' | 'bot'; 
    avatar: string; 
    isProcessing?: boolean;
    isVoice?: boolean;
    stepNumber?: number;
    sessionId?: string;
    feedback?: 'positive' | 'negative' | null;
  }[] = [
    {text: 'Hello! How can I help you today?', sender: 'bot', avatar: '🤖'},
  ];
  private currentStepNumber = 0;
  private currentSessionId = '';

  // Store callbacks for cleanup
  private wakeupCallback: (() => void) | null = null;
  private workOrderCallback: ((transcript: string) => void) | null = null;

  constructor(
    private readonly voiceApiService: VoiceApiService,
    private readonly voiceWakeup: WakeupVoiceService,
    private readonly chatService: ChatCommunicationService,
    private readonly cdr: ChangeDetectorRef,
    private readonly feedbackService: FeedbackService,
    private readonly router: Router,
    private readonly workOrderActionService: WorkOrderActionService,
    private readonly azureSpeechService: AzureSpeechService
  ) {
    const instanceId = crypto.randomUUID();
    this.currentSessionId = instanceId;
    console.log(`[ChatWidget] 🏗️ Component constructor called [Instance: ${instanceId}]`);
    console.trace('[ChatWidget] Constructor call stack');
    this.initializeMediaRecorder();
    this.initializeAzureSpeech();
  }

  ngOnInit() {
    console.log('[ChatWidget] Component initialized - ngOnInit called');
    // Get session ID if available
    const sessionId = sessionStorage.getItem('current_session_id');
    if (sessionId) {
      this.currentSessionId = sessionId;
    }

    // Subscribe to incoming messages from other components
    this.messageSubscription = this.chatService.message$.subscribe(async (message) => {
      if (message.autoOpen && !this.isChatOpen) {
        this.toggleChat();
      }
      
      // Increment step number for tracking
      this.currentStepNumber++;
      
      // Add bot message with feedback tracking
      this.messages.push({
        text: message.text,
        sender: 'bot',
        avatar: '🤖',
        sessionId: this.currentSessionId,
        stepNumber: this.currentStepNumber,
        feedback: null
      });
      
      this.scrollToBottom();
      
      // Play voice if requested
      if (message.isVoice) {
        try {
          this.isVoicePlaying = true;
          await this.voiceApiService.speakText(message.text);
          this.isVoicePlaying = false;
          this.chatService.notifyVoiceComplete();
        } catch (error) {
          console.error('Error with text-to-speech:', error);
          this.isVoicePlaying = false;
        }
      }
    });
    
    // Start wake word listener after component is fully initialized
    // This uses Web Speech API, not Azure Speech
    setTimeout(() => {
      console.log('[ChatWidget] 🚀 Initializing wake word listener (Web Speech API)...');
      this.initializeWakeWordListener();
    }, 500);
  }

  private async initializeMediaRecorder() {
    // We're now using speech recognition instead of MediaRecorder
    // This method is kept for compatibility but doesn't initialize MediaRecorder
    console.log('Using Speech Recognition API instead of MediaRecorder');
  }

  private initializeAzureSpeech() {
    console.log('[ChatWidget] 🎤 Initializing Azure Speech Service');
    
    // Unsubscribe from any existing subscriptions to prevent duplicates
    if (this.azureSpeechResultSubscription) {
      console.warn('[ChatWidget] ⚠️ Found existing Azure Speech result subscription - unsubscribing');
      this.azureSpeechResultSubscription.unsubscribe();
      this.azureSpeechResultSubscription = null;
    }
    
    if (this.azureSpeechErrorSubscription) {
      console.warn('[ChatWidget] ⚠️ Found existing Azure Speech error subscription - unsubscribing');
      this.azureSpeechErrorSubscription.unsubscribe();
      this.azureSpeechErrorSubscription = null;
    }
    
    if (this.azureSpeechEndSubscription) {
      console.warn('[ChatWidget] ⚠️ Found existing Azure Speech end subscription - unsubscribing');
      this.azureSpeechEndSubscription.unsubscribe();
      this.azureSpeechEndSubscription = null;
    }
    
    // Subscribe to recognition results
    this.azureSpeechResultSubscription = this.azureSpeechService.onResult$.subscribe(
      async (result) => {
        console.log(`[ChatWidget] ${result.isFinal ? '✅ Final' : '🎤 Interim'} result:`, result.transcript);
        
        // Only process final results
        if (result.isFinal && result.transcript.trim()) {
          const finalTranscript = result.transcript.trim();
          
          console.log('[ChatWidget] ✅ Processing Azure Speech final result:', finalTranscript);
          
          // Stop recognition to process this result
          this.isRecording = false;
          await this.azureSpeechService.stopContinuousRecognition();
          
          // Add user message with voice indicator
          this.messages.push({
            text: finalTranscript,
            sender: 'user',
            avatar: '🧑',
            isVoice: true
          });

          this.cdr.detectChanges();
          this.scrollToBottom();

          // Send transcribed text to API and get voice response
          await this.sendTranscriptToAPI(finalTranscript, true, true);
        }
      }
    );

    // Subscribe to recognition errors
    this.azureSpeechErrorSubscription = this.azureSpeechService.onError$.subscribe(
      (error) => {
        console.error('[ChatWidget] ❌ Azure Speech error:', error);
        this.isRecording = false;
        
        // Don't show error for "already in progress" as it's expected
        if (!error.includes('already in progress')) {
          // Show user-friendly error message
          if (error.includes('authorization') || error.includes('Forbidden')) {
            this.showErrorMessage('Speech service authentication failed. Please check your Azure credentials.');
          } else if (error.includes('network') || error.includes('timeout')) {
            this.showErrorMessage('Network error. Please check your internet connection and try again.');
          } else {
            this.showErrorMessage('Voice recognition failed. Please try again.');
          }
        }
      }
    );

    // Subscribe to recognition end events
    this.azureSpeechEndSubscription = this.azureSpeechService.onEnd$.subscribe(
      () => {
        console.log('[ChatWidget] 🛑 Azure Speech recognition ended');
        this.isRecording = false;
        this.cdr.detectChanges();
      }
    );
  }

  private async sendVoiceToAPI(audioBlob: Blob): Promise<void> {
    // This method is no longer used since we're using browser speech recognition
    // The voice input is now handled through the speech recognition API directly
    console.warn('sendVoiceToAPI called but not used in speech recognition mode');
  }

  private async sendTranscriptToAPI(transcript: string, isVoiceInput: boolean = false, userMessageAlreadyAdded: boolean = false): Promise<void> {
    try {
      // Reset auto-close timer on user interaction
      this.resetAutoCloseTimer();
      
      console.log('[ChatWidget] 🔍 === PROCESSING TRANSCRIPT ===');
      console.log('[ChatWidget] 🔍 Raw transcript:', `"${transcript}"`);
      console.log('[ChatWidget] 📏 Transcript length:', transcript.length);
      console.log('[ChatWidget] 🎤 Is voice input:', isVoiceInput);
      console.log('[ChatWidget] 💬 User message already added:', userMessageAlreadyAdded);
      
      // Update session ID if changed
      const sessionId = sessionStorage.getItem('current_session_id');
      if (sessionId) {
        this.currentSessionId = sessionId;
      }

      // Add processing indicator for bot response
      const botMessageIndex = this.messages.length;
      this.messages.push({
        text: '🤔 Thinking...',
        sender: 'bot',
        avatar: '🤖',
        isProcessing: true,
      });

      this.cdr.detectChanges();
      this.scrollToBottom();

      // Get response from chat API, passing the input type
      console.log('[ChatWidget] 🔵 Calling sendTextToAPI with isVoiceInput:', isVoiceInput);
      const apiResponse = await this.voiceApiService.sendTextToAPI(transcript, isVoiceInput);
      const botResponse = apiResponse.text;
      
      console.log('[ChatWidget] 📦 Full apiResponse received:', apiResponse);

      // Extract work order number from transcript first
      const workOrderPattern = /(?:help\s+me\s+(?:to\s+)?fix|start|resume|restart)\s+(?:work\s*order|wo)\s+(\d+(?:\s*\d+)*)/i;
      const transcriptMatch = transcript.match(workOrderPattern);
      const hasWorkOrderInTranscript = !!transcriptMatch;

      // Check if this is a work order modal response
      if ((apiResponse.route === 'wo_current' && apiResponse.isWorkOrder) || hasWorkOrderInTranscript) {
        console.log('[ChatWidget] 🎯 Work order command detected!');
        
        // Extract work order number from transcript
        const workOrderNumber = transcriptMatch ? transcriptMatch[1].replace(/\s+/g, '') : null;
        
        if (workOrderNumber) {
          console.log('[ChatWidget] 🚀 Opening modal for work order:', workOrderNumber);
          
          const workOrderData = {
            workOrderId: `WO-${workOrderNumber}`,
            apiResponse: botResponse,
            transcript: transcript
          };
          
          // Pause voice recognition before navigating
          this.pauseVoiceRecognition();
          
          // Close the chat widget
          this.toggleChat();
          
          // Navigate and open modal
          try {
            await this.router.navigate(['/work-order']);
            console.log('[ChatWidget] ✅ Navigation completed');
          } catch (navError) {
            console.error('[ChatWidget] ❌ Navigation error:', navError);
          }
          
          // Trigger action after navigation with API response
          setTimeout(() => {
            console.log('[ChatWidget] 🎬 Triggering action to open modal');
            this.workOrderActionService.triggerAction(`WO-${workOrderNumber}`, 'start', botResponse);
          }, 300);
          
          return;
        }
      }

      // Increment step number for tracking
      this.currentStepNumber++;

      // Update bot message with actual response and voice indicator
      this.messages[botMessageIndex] = {
        text: botResponse,
        sender: 'bot',
        avatar: '🤖',
        isVoice: isVoiceInput,
        sessionId: this.currentSessionId,
        stepNumber: this.currentStepNumber,
        feedback: null
      };

      this.cdr.detectChanges();
      this.scrollToBottom();

      // Speak the response using text-to-speech (only if input was voice)
      if (isVoiceInput) {
        if (this.isVoicePlaying) {
          console.warn('[ChatWidget] ⚠️ Voice already playing, skipping duplicate');
          return;
        }
        
        try {
          console.log('[ChatWidget] 🔊 Starting voice output for bot response');
          this.isVoicePlaying = true;
          await this.voiceApiService.speakText(botResponse);
          this.isVoicePlaying = false;
          console.log('[ChatWidget] ✅ Voice output completed');
          this.chatService.notifyVoiceComplete();
        } catch (ttsError) {
          console.error('[ChatWidget] ❌ Error with text-to-speech:', ttsError);
          this.isVoicePlaying = false;
        }
      }
      
      // Reset auto-close timer after bot responds
      this.resetAutoCloseTimer();
    } catch (error) {
      console.error('Chat API error:', error);
      this.messages[this.messages.length - 1] = {
        text: 'Sorry, I encountered an error. Please try again.',
        sender: 'bot',
        avatar: '🤖',
      };
      this.cdr.detectChanges();
      this.scrollToBottom();
    }
  }

  private showErrorMessage(message: string): void {
    this.messages.push({
      text: message,
      sender: 'bot',
      avatar: '🤖',
    });
    this.scrollToBottom();
  }

  get isSpeechSupported(): boolean {
    return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  }

  get isMediaRecorderSupported(): boolean {
    // We're not using MediaRecorder anymore, so return false
    return false;
  }

  /**
   * Resume AudioContext if suspended (required by browser policy)
   * Must be called on user interaction (click, touch, etc.)
   */
  private resumeAudioContextIfNeeded(): void {
    // Check if there's a global AudioContext that needs resuming
    if (typeof AudioContext !== 'undefined' || typeof (window as any).webkitAudioContext !== 'undefined') {
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      
      // Try to access and resume any suspended AudioContext
      try {
        // Note: Azure Speech SDK manages its own AudioContext
        // But we can still trigger user gesture for browser permissions
        console.log('[ChatWidget] 🔊 User interaction detected - audio permissions granted');
      } catch (error) {
        console.warn('[ChatWidget] ⚠️ AudioContext resume warning (can be ignored):', error);
      }
    }
  }

  startVoiceInput() {
    if (this.isProcessing) return;
    
    // Check if Azure Speech is already recording
    if (this.isRecording) {
      console.warn('[ChatWidget] ⚠️ Azure Speech already recording, ignoring start request');
      return;
    }
    
    // Check if Azure Speech service is already active
    if (this.azureSpeechService.isActive()) {
      console.warn('[ChatWidget] ⚠️ Azure Speech service already active, stopping first...');
      this.azureSpeechService.stopContinuousRecognition()
        .then(() => {
          console.log('[ChatWidget] ✅ Stopped previous session, starting new one...');
          setTimeout(() => this.startVoiceInputInternal(), 500);
        })
        .catch(() => {
          console.log('[ChatWidget] ⚠️ Error stopping, trying to start anyway...');
          this.startVoiceInputInternal();
        });
      return;
    }
    
    this.startVoiceInputInternal();
  }

  private startVoiceInputInternal(): void {
    // Resume AudioContext on user interaction
    this.resumeAudioContextIfNeeded();
    
    // Reset auto-close timer
    this.resetAutoCloseTimer();
    this.isRecording = true;
    
    console.log('[ChatWidget] 🎤 Starting Azure Speech recognition...');
    
    const started = this.azureSpeechService.startContinuousRecognition();
    if (!started) {
      console.error('[ChatWidget] ❌ Failed to start Azure Speech');
      this.isRecording = false;
      this.showErrorMessage('Failed to start voice recognition. Please try again.');
      
      // DON'T restart wake word - it should already be running
      console.log('[ChatWidget] ℹ️ Wake word listener should still be active');
    } else {
      console.log('[ChatWidget] ✅ Azure Speech started successfully');
    }
  }

  stopVoiceInput() {
    if (this.isRecording) {
      console.log('[ChatWidget] 🛑 Stopping Azure Speech recognition...');
      this.isRecording = false;
      this.azureSpeechService.stopContinuousRecognition()
        .catch(error => {
          console.error('[ChatWidget] ❌ Error stopping recognition:', error);
        });
    }
  }

  /**
   * Pause voice recognition (for modal usage)
   */
  pauseVoiceRecognition(): void {
    console.log('[ChatWidget] ⏸️ Pausing ONLY Azure Speech (NOT wake word)...');
    this.stopVoiceInput();
    // DON'T stop wake word listener - let it keep running
  }

  /**
   * Resume voice recognition (after modal closes)
   */
  resumeVoiceRecognition(): void {
    console.log('[ChatWidget] ▶️ Resuming after modal (wake word already running)...');
    // Wake word listener is still running - no action needed
  }

  // toggleVoiceInput() {
  //   if (this.isProcessing) return;

  //   if (this.isListening || this.isRecording) {
  //     this.stopVoiceInput();
  //   } else {
  //     this.startVoiceInput();
  //   }
  // }
  toggleVoiceInput() {
    if (this.isProcessing) return;
    if (this.isRecording) {
      this.stopVoiceInput();
    } else {
      this.startVoiceInput();
    }
  }

  toggleChat() {
    console.log('[ChatWidget] toggleChat called. Current state:', this.isChatOpen, '-> New state:', !this.isChatOpen);
    
    // Resume AudioContext on user interaction to comply with browser policies
    this.resumeAudioContextIfNeeded();
    
    this.isChatOpen = !this.isChatOpen;

    if (this.autoOpenTimer) {
      clearTimeout(this.autoOpenTimer);
      this.autoOpenTimer = null;
    }

    if (this.isChatOpen) {
      setTimeout(() => this.scrollToBottom(), 100);
      this.resetAutoCloseTimer();
    } else {
      this.clearAutoCloseTimer();
    }
  }

  /**
   * Reset the auto-close timer - called when user interacts with chat
   */
  private resetAutoCloseTimer(): void {
    this.clearAutoCloseTimer();
    
    console.log('[ChatWidget] Starting auto-close timer (30 seconds)');
    this.autoCloseTimer = setTimeout(() => {
      // Don't close if any activity is in progress
      const hasActivity = this.isRecording || 
                         this.isProcessing || 
                         this.isUserTyping || 
                         this.isVoicePlaying || 
                         this.isFeedbackInProgress;
      
      if (this.isChatOpen && !hasActivity) {
        console.log('[ChatWidget] Auto-closing due to inactivity');
        this.isChatOpen = false;
        this.startWakeWordListener();
      } else if (hasActivity) {
        console.log('[ChatWidget] Activity detected, resetting timer');
        this.resetAutoCloseTimer(); // Reset timer if activity is in progress
      }
    }, this.AUTO_CLOSE_DELAY);
  }

  /**
   * Clear the auto-close timer
   */
  private clearAutoCloseTimer(): void {
    if (this.autoCloseTimer) {
      clearTimeout(this.autoCloseTimer);
      this.autoCloseTimer = null;
    }
  }

  /**
   * Initialize wake word listener using Web Speech API
   */
  private initializeWakeWordListener(): void {
    console.log('[ChatWidget] 🎧 === INITIALIZING WAKE WORD LISTENER ===');
    
    // Check current status
    const status = this.voiceWakeup.getStatus();
    console.log('[ChatWidget] Current status:', status);
    
    // Define callbacks
    this.wakeupCallback = () => {
      // Wake word detected
      console.log('[ChatWidget] 👂 *** WAKE WORD DETECTED ***');
      
      if (this.isRecording) {
        console.log('[ChatWidget] ⚠️ Already recording, ignoring');
        return;
      }

      if (!this.isChatOpen) {
        console.log('[ChatWidget] 💬 Opening chat...');
        this.toggleChat();
        setTimeout(() => this.toggleVoiceInput(), 500);
      } else {
        console.log('[ChatWidget] 💬 Starting voice input...');
        this.toggleVoiceInput();
      }
    };
    
    this.workOrderCallback = async (transcript: string) => {
      // Work order command
      console.log('[ChatWidget] 🎯 === WORK ORDER COMMAND ===');
      console.log('[ChatWidget] 📋 Command:', transcript);
      
      if (this.isRecording) {
        console.log('[ChatWidget] ⚠️ Already recording, ignoring');
        return;
      }

      if (!this.isChatOpen) {
        this.toggleChat();
      }

      this.messages.push({
        text: transcript,
        sender: 'user',
        avatar: '🧑',
        isVoice: true
      });

      this.cdr.detectChanges();
      this.scrollToBottom();

      await this.sendTranscriptToAPI(transcript, true, true);
    };
    
    // Register callbacks with the service
    this.voiceWakeup.startListening(this.wakeupCallback, this.workOrderCallback);
    
    console.log('[ChatWidget] ✅ Wake word listener initialized');
  }

  /**
   * This method is no longer needed - wake word listener runs continuously
   */
  private startWakeWordListener(): void {
    console.log('[ChatWidget] ℹ️ Wake word listener already running (no action needed)');
  }

  /**
   * This method is no longer needed - wake word listener runs continuously
   */
  private ensureWakeWordListenerActive(): void {
    // Do nothing - wake word listener runs independently
  }

  async sendMessage() {
    this.isRecording = false;

    if (!this.userInput.trim() || this.isProcessing) return;

    // User sent message, no longer typing
    this.isUserTyping = false;

    // Reset auto-close timer on user interaction
    this.resetAutoCloseTimer();

    const messageText = this.userInput.trim();
    this.userInput = '';

    // Add user message (text input, not voice)
    this.messages.push({
      text: messageText,
      sender: 'user',
      avatar: '🧑',
      isVoice: false
    });

    this.cdr.detectChanges();
    this.scrollToBottom();

    // Send to API and get response (not voice input)
    await this.sendTranscriptToAPI(messageText, false, true);
  }

  ngOnDestroy() {
    console.log('[ChatWidget] Component destroyed. Cleaning up resources...');
    if (this.autoOpenTimer) {
      clearTimeout(this.autoOpenTimer);
    }
    if (this.autoCloseTimer) {
      clearTimeout(this.autoCloseTimer);
    }
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
    
    // Clean up Azure Speech subscriptions
    if (this.azureSpeechResultSubscription) {
      this.azureSpeechResultSubscription.unsubscribe();
    }
    if (this.azureSpeechErrorSubscription) {
      this.azureSpeechErrorSubscription.unsubscribe();
    }
    if (this.azureSpeechEndSubscription) {
      this.azureSpeechEndSubscription.unsubscribe();
    }
    
    // Stop Azure Speech recognition
    if (this.azureSpeechService.isActive()) {
      this.azureSpeechService.stopContinuousRecognition();
    }
    
    // Unregister callbacks instead of stopping listener
    if (this.wakeupCallback) {
      console.log('[ChatWidget] 🔕 Unregistering wake word callbacks');
      this.voiceWakeup.unregisterCallbacks(this.wakeupCallback, this.workOrderCallback || undefined);
    }
  }

  /**
   * Handle input focus - user is typing
   */
  onInputFocus(): void {
    console.log('[ChatWidget] User started typing');
    this.isUserTyping = true;
    this.clearAutoCloseTimer(); // Stop timer while typing
  }

  /**
   * Handle input blur - user stopped typing
   */
  onInputBlur(): void {
    console.log('[ChatWidget] User stopped typing');
    this.isUserTyping = false;
    // Only restart timer if input is empty
    if (!this.userInput.trim()) {
      this.resetAutoCloseTimer();
    }
  }

  /**
   * Handle input change - track typing activity
   */
  onInputChange(): void {
    // If user clears the input while typing, restart timer
    if (!this.userInput.trim() && !this.isUserTyping) {
      this.resetAutoCloseTimer();
    }
  }

  minimizeChat() {
    this.isChatOpen = false;
  }

  handleEnterKey(event: KeyboardEvent) {
    if (!event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  adjustTextareaHeight(event: any) {
    const textarea = event.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  }

  getVoiceButtonClass(): string {
    let baseClass = 'p-button-rounded voice-btn';
    if (this.isRecording) {
      baseClass += ' recording-active';
    }
    return baseClass;
  }

  getVoiceTooltip(): string {
    if (this.isRecording) {
      return 'Stop recording';
    } else if (this.isProcessing) {
      return 'Processing...';
    } else {
      return 'Start voice input';
    }
  }

  sendQuickMessage(message: string) {
    this.userInput = message;
    this.sendMessage();
  }

  getCurrentTime(): string {
    return new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
  }

  scrollToBottom() {
    setTimeout(() => {
      const messagesContainer = document.querySelector('.chat-messages');
      if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      }
    }, 50);
  }
  
  /**
   * Submit feedback for a bot message
   */
  submitFeedback(message: any, isPositive: boolean): void {
    if (!message.sessionId || message.stepNumber === undefined) {
      console.warn('[ChatWidget] Cannot submit feedback - missing session or step info');
      return;
    }

    const feedback = isPositive ? 'positive' : 'negative';
    
    console.log('[ChatWidget] Submitting feedback:', {
      sessionId: message.sessionId,
      stepNumber: message.stepNumber,
      feedback: feedback
    });

    this.isFeedbackInProgress = true;

    this.feedbackService.submitFeedback(
      message.sessionId,
      message.stepNumber,
      feedback,
      '' // No notes for now
    ).subscribe({
      next: (response) => {
        console.log('[ChatWidget] Feedback submitted successfully:', response);
        
        // Update message feedback state
        message.feedback = feedback;
        this.cdr.detectChanges();

        // Check if there's a next step to display
        // Don't await here - handle async operations inside the handlers
        if (response.type === 'next_step' && response.message) {
          // Call without await to avoid blocking
          this.handleNextStepResponse(response).catch(error => {
            console.error('[ChatWidget] Error handling next step:', error);
          });
        } else if (response.type === 'work_order_complete') {
          // Call without await to avoid blocking
          this.handleWorkOrderComplete(response).catch(error => {
            console.error('[ChatWidget] Error handling completion:', error);
          });
        } else {
          // No next step, just mark as complete
          this.isFeedbackInProgress = false;
        }
      },
      error: (error) => {
        console.error('[ChatWidget] Failed to submit feedback:', error);
        alert('Failed to submit feedback. Please try again.');
        this.isFeedbackInProgress = false;
      }
    });
  }

  /**
   * Handle next step response after feedback
   */
  private async handleNextStepResponse(response: any): Promise<void> {
    // Store completed step for UI update
    if (response.progress?.completed) {
      sessionStorage.setItem('completed_step', response.progress.completed.toString());
    }

    // Increment step number for the new message
    this.currentStepNumber++;

    // Format the response message
    let responseMessage = response.message;
    
    // Add tts_text if available
    if (response.tts_text) {
      responseMessage += `\n\n${response.tts_text}`;
    }

    // Add estimated time if available
    if (response.current_step?.estimated_time) {
      responseMessage += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
    }

    // Add progress info
    if (response.progress) {
      responseMessage += `\n\nProgress: ${response.progress.completed}/${response.progress.total} steps (${response.progress.percentage.toFixed(1)}%)`;
    }

    // Add new bot message with the next step
    this.messages.push({
      text: responseMessage,
      sender: 'bot',
      avatar: '🤖',
      isVoice: true,
      sessionId: this.currentSessionId,
      stepNumber: this.currentStepNumber,
      feedback: null
    });

    this.cdr.detectChanges();
    this.scrollToBottom();

    // Speak the response
    try {
      this.isVoicePlaying = true;
      await this.voiceApiService.speakText(responseMessage);
      this.isVoicePlaying = false;
      this.chatService.notifyVoiceComplete();
    } catch (error) {
      console.error('[ChatWidget] Error with text-to-speech:', error);
      this.isVoicePlaying = false;
    } finally {
      // Mark feedback as complete after voice finishes
      this.isFeedbackInProgress = false;
    }
  }

  private async handleWorkOrderComplete(response: any): Promise<void> {
    // Work order completed
    sessionStorage.setItem('work_order_complete', 'true');
    
    this.messages.push({
      text: response.message || 'Work order completed successfully! 🎉',
      sender: 'bot',
      avatar: '🤖',
      isVoice: true,
      sessionId: this.currentSessionId,
      stepNumber: this.currentStepNumber,
      feedback: null
    });

    this.cdr.detectChanges();
    this.scrollToBottom();

    try {
      this.isVoicePlaying = true;
      await this.voiceApiService.speakText(response.message || 'Work order completed successfully!');
      this.isVoicePlaying = false;
      this.chatService.notifyVoiceComplete();
    } catch (error) {
      console.error('[ChatWidget] Error with text-to-speech:', error);
      this.isVoicePlaying = false;
    } finally {
      // Mark feedback as complete after voice finishes
      this.isFeedbackInProgress = false;
    }
  }
}
