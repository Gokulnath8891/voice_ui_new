import { Component, OnInit, OnDestroy, ChangeDetectorRef, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AvatarModule } from 'primeng/avatar';
import { TooltipModule } from 'primeng/tooltip';
import { WorkOrderService } from '../services/work-order.service';
import { FeedbackService } from '../services/feedback.service';
import { VoiceApiService } from '../chat-widget/voice-api.service';
import { WakeupVoiceService } from '../chat-widget/wakeup-voice.service';
import { AzureSpeechService } from '../services/azure-speech.service';
import { Subscription } from 'rxjs';

interface Message {
  text: string;
  sender: 'user' | 'bot';
  avatar: string;
  isVoice?: boolean;
  stepNumber?: number;
  sessionId?: string;
  feedback?: 'positive' | 'negative' | null;
}

@Component({
  selector: 'app-work-order-modal',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    DialogModule,
    ButtonModule,
    InputTextareaModule,
    AvatarModule,
    TooltipModule
  ],
  templateUrl: './work-order-modal.component.html',
  styleUrls: ['./work-order-modal.component.scss']
})
export class WorkOrderModalComponent implements OnInit, OnDestroy {
  @ViewChild('messagesContainer') private messagesContainer?: ElementRef;

  private _visible = false;
  
  get visible(): boolean {
    return this._visible;
  }
  
  set visible(value: boolean) {
    const wasVisible = this._visible;
    this._visible = value;
    
    // If modal is being closed (was visible, now not visible)
    if (wasVisible && !value) {
      this.handleClose();
    }
  }
  
  workOrderNumber = '';
  workOrderId = 0; // Numeric ID for work order
  userInput = '';
  messages: Message[] = [];
  
  isRecording = false;
  isProcessing = false;
  isVoicePlaying = false;
  isFeedbackInProgress = false;
  isResumedWorkOrder = false; // Track if this is a resumed work order
  
  private recognition: any = null;
  private currentSessionId = '';
  private currentStepNumber = 0;
  private currentStepId = 0; // Store the step ID for feedback API
  private chatWidgetRef: any = null; // Reference to chat widget for voice control
  private onCloseCallback?: () => void; // Callback to execute when modal closes
  private cachedApiResponse?: string; // Store API response to avoid duplicate API calls
  private azureSpeechResultSubscription: Subscription | null = null;
  private azureSpeechErrorSubscription: Subscription | null = null;
  private azureSpeechEndSubscription: Subscription | null = null;

  constructor(
    private readonly workOrderService: WorkOrderService,
    private readonly feedbackService: FeedbackService,
    private readonly voiceApiService: VoiceApiService,
    private readonly wakeupVoiceService: WakeupVoiceService,
    private readonly cdr: ChangeDetectorRef,
    private readonly azureSpeechService: AzureSpeechService
  ) {}

  ngOnInit() {
    // Initialize flags
    this.isProcessing = false;
    this.visible = false;
    this.initializeAzureSpeech();
  }

  ngOnDestroy() {
    console.log('[WorkOrderModal] Component destroyed. Cleaning up resources...');
    
    // Clean up Azure Speech subscriptions
    if (this.azureSpeechResultSubscription) {
      this.azureSpeechResultSubscription.unsubscribe();
    }
    if (this.azureSpeechErrorSubscription) {
      this.azureSpeechErrorSubscription.unsubscribe();
    }
    if (this.azureSpeechEndSubscription) {
      this.azureSpeechEndSubscription.unsubscribe();
    }
    
    // Stop Azure Speech recognition
    if (this.azureSpeechService.isActive()) {
      this.azureSpeechService.stopContinuousRecognition();
    }
    
    // Stop old recognition if any
    if (this.recognition) {
      this.recognition.stop();
    }
  }

  /**
   * Called when dialog becomes visible
   */
  onDialogShow(): void {
    console.log('[WorkOrderModal] 🎉 Dialog is now VISIBLE');
  }

  /**
   * Called when dialog is hidden
   */
  onDialogHide(): void {
    console.log('[WorkOrderModal] 🚫 Dialog is now HIDDEN');
  }

  /**
   * Open modal with work order number
   */
  async open(
    workOrderNumber: string, 
    chatWidget?: any, 
    action: 'start' | 'resume' | 'restart' = 'start',
    onClose?: () => void,
    apiResponse?: string
  ): Promise<void> {
    console.log('🔴🔴🔴 [WorkOrderModal] OPENING MODAL FOR WO:', workOrderNumber);
    if (apiResponse) {
      console.log('[WorkOrderModal] 📝 API Response received:', apiResponse);
    }
    
    // Prevent duplicate opens if already visible for the SAME work order
    if (this.visible && this.isProcessing && this.workOrderNumber === workOrderNumber) {
      console.warn('[WorkOrderModal] Already processing this WO');
      return;
    }
    
    // ALWAYS reset processing flag for new requests (different work order)
    this.isProcessing = false;
    
    // Set modal state
    this.workOrderNumber = workOrderNumber;
    this.chatWidgetRef = chatWidget;
    this.onCloseCallback = onClose;
    this.messages = [];
    this.currentStepNumber = 0;
    this.isProcessing = true;
    
    // If we have API response, store it (will be displayed by processApiResponse)
    if (apiResponse) {
      console.log('[WorkOrderModal] 📨 Storing API response to avoid duplicate API call');
      this.cachedApiResponse = apiResponse;
    }
    
    // CRITICAL: Set visible to true
    this.visible = true;
    console.log('🟢🟢🟢 [WorkOrderModal] visible=TRUE, isProcessing=TRUE');
    
    // Force change detection
    this.cdr.detectChanges();
    console.log('🟡🟡🟡 [WorkOrderModal] detectChanges() called');
    
    // Stop chat widget voice if present
    if (this.chatWidgetRef?.pauseVoiceRecognition) {
      this.chatWidgetRef.pauseVoiceRecognition();
    }
    
    // Process the work order action
    try {
      switch (action) {
        case 'resume':
          await this.resumeWorkOrder();
          break;
        case 'restart':
          await this.restartWorkOrder();
          break;
        case 'start':
        default:
          await this.startWorkOrder();
          break;
      }
    } catch (error) {
      console.error('[WorkOrderModal] ❌ Error executing action:', error);
      this.addMessage('Error processing request: ' + (error as any).message, 'bot');
    }
    
    // Start wake word listener
    setTimeout(() => {
      this.startModalWakeWordListener();
    }, 500);
  }

  /**
   * Handle modal close - called automatically when visible changes to false
   */
  private handleClose(): void {
    // Stop any ongoing speech immediately
    if ('speechSynthesis' in globalThis) {
      speechSynthesis.cancel();
    }
    
    // Stop speech recognition immediately
    if (this.recognition) {
      this.recognition.stop();
    }
    
    // Stop wake word listener immediately
    this.wakeupVoiceService.stopListening();
    
    // Reset UI state immediately
    this.isRecording = false;
    this.isProcessing = false;
    this.isVoicePlaying = false;
    this.isFeedbackInProgress = false;
    
    // Call onClose callback if provided (e.g., to reload work orders)
    if (this.onCloseCallback) {
      this.onCloseCallback();
      this.onCloseCallback = undefined; // Clear the callback
    }
    
    // Cleanup asynchronously to not block the UI
    setTimeout(() => {
      this.messages = [];
      this.currentSessionId = '';
      this.currentStepNumber = 0;
      this.currentStepId = 0;
      this.isResumedWorkOrder = false;
      this.cachedApiResponse = undefined;
      
      sessionStorage.removeItem('current_session_id');
      sessionStorage.removeItem('current_work_order');
      sessionStorage.removeItem('completed_step');
      
      // Resume chat widget voice recognition and wake word listener
      if (this.chatWidgetRef?.resumeVoiceRecognition) {
        this.chatWidgetRef.resumeVoiceRecognition();
      }
      
      // Clear chat widget reference
      this.chatWidgetRef = null;
    }, 0);
  }
  
  /**
   * Close modal - public method that can be called programmatically
   */
  close(): void {
    this.visible = false; // This will trigger handleClose via the setter
  }

  /**
   * Start work order
   */
  private async startWorkOrder(): Promise<void> {
    try {
      this.isProcessing = true;
      this.cdr.detectChanges(); // Force UI update
      
      // Check if we already have API response from chat widget (avoid duplicate API call)
      if (this.cachedApiResponse) {
        console.log('[WorkOrderModal] ♻️ Using cached API response to avoid duplicate API call');
        await this.processApiResponse(this.cachedApiResponse, 'start');
        this.isProcessing = false;
        this.cdr.detectChanges();
        return;
      }
      
      const userId = 1; // TODO: Get from AuthService
      const response = await this.workOrderService.startWork(this.workOrderNumber, userId);
      
      console.log('[WorkOrderModal] 🔍 Start work response received:', response);
      
      // Debug: Log the response properties
      console.log('[WorkOrderModal] 🐛 Debug response properties:');
      console.log('  - response.type:', (response as any).type);
      console.log('  - response.success:', (response as any).success);
      console.log('  - response.is_work_order:', (response as any).is_work_order);
      console.log('  - typeof success:', typeof (response as any).success);
      console.log('  - typeof is_work_order:', typeof (response as any).is_work_order);
      
      // Handle error response (original format)
      if (response.type === 'error') {
        this.addMessage('Error starting work order: ' + response.message, 'bot');
        return;
      }
      
      // Handle original work order start response format
      if (response.type === 'work_order_start') {
        // Store session info
        if (response.session_id) {
          this.currentSessionId = response.session_id;
          sessionStorage.setItem('current_session_id', response.session_id);
        }
        
        // Format message
        let messageText = `Starting work order ${this.workOrderNumber}.`;
        
        if (response.tts_text) {
          messageText += `\n\n${response.tts_text}`;
        }
        
        if (response.current_step?.estimated_time) {
          messageText += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
        }
        
        this.currentStepNumber++;
        
        this.messages.push({
          text: messageText,
          sender: 'bot',
          avatar: '🤖',
          isVoice: true,
          sessionId: this.currentSessionId,
          stepNumber: this.currentStepNumber,
          feedback: null
        });
        
        this.cdr.detectChanges(); // Force UI update to show message
        this.scrollToBottom();
        
        // Speak response
        await this.speakText(messageText);
      }
      // Handle new agentic RAG response format
      else if ((response as any).success === true && 
               ((response as any).is_work_order === true || 
                (response as any).route === "wo_current" ||
                (response as any).result)) {
        console.log('[WorkOrderModal] ✅ Detected agentic RAG work order response format');
        console.log('[WorkOrderModal] 🔍 Match criteria:');
        console.log('  - success === true:', (response as any).success === true);
        console.log('  - is_work_order === true:', (response as any).is_work_order === true);
        console.log('  - route === "wo_current":', (response as any).route === "wo_current");
        console.log('  - has result field:', !!(response as any).result);
        
        const agenticResponse = response as any;
        
        // Format message using the result field
        let messageText = `Starting work order ${this.workOrderNumber}.`;
        
        if (agenticResponse.result) {
          messageText += `\n\n${agenticResponse.result}`;
        }
        
        console.log('[WorkOrderModal] 📝 Formatted message:', messageText);
        
        this.currentStepNumber++;
        
        this.messages.push({
          text: messageText,
          sender: 'bot',
          avatar: '🤖',
          isVoice: true,
          sessionId: this.currentSessionId,
          stepNumber: this.currentStepNumber,
          feedback: null
        });
        
        this.cdr.detectChanges(); // Force UI update to show message
        this.scrollToBottom();
        
        // Speak response
        await this.speakText(messageText);
      }
      // Handle unexpected response format
      else {
        console.warn('[WorkOrderModal] ❌ Unexpected response format received');
        console.warn('[WorkOrderModal] 📊 Full response object:', JSON.stringify(response, null, 2));
        console.warn('[WorkOrderModal] 🔍 Condition checks:');
        console.warn('  - Original format check (response.type === "work_order_start"):', (response as any).type === 'work_order_start');
        console.warn('  - New format check part 1 (response.success === true):', (response as any).success === true);
        console.warn('  - New format check part 2 (response.is_work_order === true):', (response as any).is_work_order === true);
        console.warn('  - Combined new format check:', (response as any).success === true && (response as any).is_work_order === true);
        
        this.addMessage('Work order started but received unexpected response format.', 'bot');
      }
    } catch (error) {
      console.error('Error starting work order:', error);
      this.addMessage('Failed to start work order. Please try again.', 'bot');
    } finally {
      this.isProcessing = false;
      this.cdr.detectChanges(); // Force UI update to enable inputs
    }
  }

  /**
   * Process cached API response to avoid duplicate API calls
   * This is called when the response was already fetched by the chat widget
   */
  private async processApiResponse(apiResponse: string, action: 'start' | 'resume' | 'restart'): Promise<void> {
    try {
      console.log('[WorkOrderModal] 🔄 Processing cached API response for action:', action);
      
      // Format message based on action
      let messageText = '';
      
      if (action === 'start') {
        messageText = `Starting work order ${this.workOrderNumber}.\n\n${apiResponse}`;
      } else if (action === 'resume') {
        messageText = `Resuming work order ${this.workOrderNumber}.\n\n${apiResponse}`;
      } else if (action === 'restart') {
        messageText = `Restarting work order ${this.workOrderNumber} from the beginning.\n\n${apiResponse}`;
      }
      
      this.currentStepNumber++;
      
      // Add formatted message to display
      this.messages.push({
        text: messageText,
        sender: 'bot',
        avatar: '🤖',
        isVoice: true,
        sessionId: this.currentSessionId,
        stepNumber: this.currentStepNumber,
        feedback: null
      });
      
      this.cdr.detectChanges(); // Force UI update to show message
      this.scrollToBottom();
      
      // Speak response
      await this.speakText(messageText);
    } catch (error) {
      console.error('[WorkOrderModal] ❌ Error processing API response:', error);
      this.addMessage('Error processing work order response.', 'bot');
    }
  }

  /**
   * Resume work order from first incomplete step
   */
  private async resumeWorkOrder(): Promise<void> {
    try {
      this.isProcessing = true;
      this.cdr.detectChanges(); // Force UI update
      
      const response = await this.workOrderService.resumeWorkOrder(this.workOrderNumber);
      
      // Handle error response (original format)
      if (response.type === 'error') {
        this.addMessage('Error resuming work order: ' + response.message, 'bot');
        return;
      }
      
      // Handle original work order start response format
      if (response.type === 'work_order_start') {
        // Mark this as a resumed work order
        this.isResumedWorkOrder = true;
        
        // Store session info
        if (response.session_id) {
          this.currentSessionId = response.session_id;
          sessionStorage.setItem('current_session_id', response.session_id);
        }
        
        // Store work order ID and current step info
        if (response.work_order?.id) {
          this.workOrderId = response.work_order.id;
        }
        
        if (response.current_step?.id) {
          this.currentStepId = response.current_step.id;
        }
        
        // Format message - show message once, then current step description
        let messageText = response.message || `Resuming work order ${this.workOrderNumber}.`;
        
        // Add current step description instead of repeating the message
        if (response.current_step?.description) {
          messageText += `\n\n${response.current_step.description}`;
        }
        
        if (response.current_step?.estimated_time) {
          messageText += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
        }
        
        // Set current step number from response
        this.currentStepNumber = response.current_step?.step_number || 1;
        
        this.messages.push({
          text: messageText,
          sender: 'bot',
          avatar: '🤖',
          isVoice: true,
          sessionId: this.currentSessionId,
          stepNumber: this.currentStepNumber,
          feedback: null
        });
        
        this.cdr.detectChanges(); // Force UI update to show message
        this.scrollToBottom();
        
        // Speak response
        await this.speakText(messageText);
      }
      // Handle new agentic RAG response format
      else if ((response as any).success === true && 
               ((response as any).is_work_order === true || 
                (response as any).route === "wo_current" ||
                (response as any).result)) {
        console.log('[WorkOrderModal] ✅ Detected agentic RAG work order response format for resume');
        
        const agenticResponse = response as any;
        
        // Mark this as a resumed work order
        this.isResumedWorkOrder = true;
        
        // Format message using the result field
        let messageText = `Resuming work order ${this.workOrderNumber}.`;
        
        if (agenticResponse.result) {
          messageText += `\n\n${agenticResponse.result}`;
        }
        
        this.currentStepNumber++;
        
        this.messages.push({
          text: messageText,
          sender: 'bot',
          avatar: '🤖',
          isVoice: true,
          sessionId: this.currentSessionId,
          stepNumber: this.currentStepNumber,
          feedback: null
        });
        
        this.cdr.detectChanges(); // Force UI update to show message
        this.scrollToBottom();
        
        // Speak response
        await this.speakText(messageText);
      }
      // Handle unexpected response format
      else {
        console.warn('[WorkOrderModal] Unexpected resume response format:', response);
        this.addMessage('Work order resumed but received unexpected response format.', 'bot');
      }
    } catch (error) {
      console.error('Error resuming work order:', error);
      this.addMessage('Failed to resume work order. Please try again.', 'bot');
    } finally {
      this.isProcessing = false;
      this.cdr.detectChanges(); // Force UI update to enable inputs
    }
  }

  /**
   * Restart work order from the beginning (reset all progress)
   */
  private async restartWorkOrder(): Promise<void> {
    try {
      this.isProcessing = true;
      this.cdr.detectChanges(); // Force UI update
      
      const response = await this.workOrderService.restartWorkOrder(this.workOrderNumber);
      
      // Handle error response (original format)
      if (response.type === 'error') {
        this.addMessage('Error restarting work order: ' + response.message, 'bot');
        return;
      }
      
      // Handle original work order start response format
      if (response.type === 'work_order_start') {
        // Store session info
        if (response.session_id) {
          this.currentSessionId = response.session_id;
          sessionStorage.setItem('current_session_id', response.session_id);
        }
        
        // Format message
        let messageText = `Restarting work order ${this.workOrderNumber} from the beginning.`;
        
        if (response.tts_text) {
          messageText += `\n\n${response.tts_text}`;
        }
        
        if (response.current_step?.estimated_time) {
          messageText += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
        }
        
        this.currentStepNumber = 1; // Always start from step 1
        
        this.messages.push({
          text: messageText,
          sender: 'bot',
          avatar: '🤖',
          isVoice: true,
          sessionId: this.currentSessionId,
          stepNumber: this.currentStepNumber,
          feedback: null
        });
        
        this.cdr.detectChanges(); // Force UI update to show message
        this.scrollToBottom();
        
        // Speak response
        await this.speakText(messageText);
      }
      // Handle new agentic RAG response format
      else if ((response as any).success === true && 
               ((response as any).is_work_order === true || 
                (response as any).route === "wo_current" ||
                (response as any).result)) {
        console.log('[WorkOrderModal] ✅ Detected agentic RAG work order response format for restart');
        
        const agenticResponse = response as any;
        
        // Format message using the result field
        let messageText = `Restarting work order ${this.workOrderNumber} from the beginning.`;
        
        if (agenticResponse.result) {
          messageText += `\n\n${agenticResponse.result}`;
        }
        
        this.currentStepNumber = 1; // Always start from step 1
        
        this.messages.push({
          text: messageText,
          sender: 'bot',
          avatar: '🤖',
          isVoice: true,
          sessionId: this.currentSessionId,
          stepNumber: this.currentStepNumber,
          feedback: null
        });
        
        this.cdr.detectChanges(); // Force UI update to show message
        this.scrollToBottom();
        
        // Speak response
        await this.speakText(messageText);
      }
      // Handle unexpected response format
      else {
        console.warn('[WorkOrderModal] Unexpected restart response format:', response);
        this.addMessage('Work order restarted but received unexpected response format.', 'bot');
      }
    } catch (error) {
      console.error('Error restarting work order:', error);
      this.addMessage('Failed to restart work order. Please try again.', 'bot');
    } finally {
      this.isProcessing = false;
      this.cdr.detectChanges(); // Force UI update to enable inputs
    }
  }

  /**
   * Initialize Azure Speech Service
   */
  private initializeAzureSpeech(): void {
    console.log('[WorkOrderModal] 🎤 Initializing Azure Speech Service');
    console.trace('[WorkOrderModal] 📍 initializeAzureSpeech call stack');
    
    // Unsubscribe from any existing subscriptions to prevent duplicates
    if (this.azureSpeechResultSubscription) {
      console.warn('[WorkOrderModal] ⚠️ Found existing Azure Speech result subscription - unsubscribing');
      this.azureSpeechResultSubscription.unsubscribe();
      this.azureSpeechResultSubscription = null;
    }
    
    if (this.azureSpeechErrorSubscription) {
      console.warn('[WorkOrderModal] ⚠️ Found existing Azure Speech error subscription - unsubscribing');
      this.azureSpeechErrorSubscription.unsubscribe();
      this.azureSpeechErrorSubscription = null;
    }
    
    if (this.azureSpeechEndSubscription) {
      console.warn('[WorkOrderModal] ⚠️ Found existing Azure Speech end subscription - unsubscribing');
      this.azureSpeechEndSubscription.unsubscribe();
      this.azureSpeechEndSubscription = null;
    }
    
    // Subscribe to recognition results
    this.azureSpeechResultSubscription = this.azureSpeechService.onResult$.subscribe(
      (result) => {
        console.log(`[WorkOrderModal] ${result.isFinal ? '✅ Final' : '🎤 Interim'} result:`, result.transcript);
        
        // Only process final results
        if (result.isFinal && result.transcript.trim()) {
          const finalTranscript = result.transcript.trim();
          
          console.log('[WorkOrderModal] ✅ Processing Azure Speech final result:', finalTranscript);
          
          // Stop recognition to process this result
          this.isRecording = false;
          this.azureSpeechService.stopContinuousRecognition();
          
          // Set the user input and auto-send
          this.userInput = finalTranscript;
          this.cdr.detectChanges();
          
          // Auto-send the message
          this.sendMessage();
          
          // Restart wake word listener after processing
          setTimeout(() => this.startModalWakeWordListener(), 500);
        }
      }
    );

    // Subscribe to recognition errors
    this.azureSpeechErrorSubscription = this.azureSpeechService.onError$.subscribe(
      (error) => {
        console.error('[WorkOrderModal] ❌ Azure Speech error:', error);
        this.isRecording = false;
        this.cdr.detectChanges();
        
        // Restart wake word listener after error
        setTimeout(() => this.startModalWakeWordListener(), 500);
      }
    );

    // Subscribe to recognition end events
    this.azureSpeechEndSubscription = this.azureSpeechService.onEnd$.subscribe(
      () => {
        console.log('[WorkOrderModal] 🛑 Azure Speech recognition ended');
        this.isRecording = false;
        this.cdr.detectChanges();
        
        // Restart wake word listener after voice input ends
        setTimeout(() => this.startModalWakeWordListener(), 500);
      }
    );
  }

  /**
   * Toggle voice input
   */
  toggleVoiceInput(): void {
    if (this.isRecording) {
      this.azureSpeechService.stopContinuousRecognition();
      this.isRecording = false;
    } else {
      const started = this.azureSpeechService.startContinuousRecognition();
      this.isRecording = started;
      if (!started) {
        console.error('[WorkOrderModal] ❌ Failed to start Azure Speech recognition');
      }
    }
    this.cdr.detectChanges();
  }

  /**
   * Send message
   */
  async sendMessage(): Promise<void> {
    const messageText = this.userInput.trim();
    
    // Check for empty input
    if (!messageText) {
      console.log('[WorkOrderModal] ⚠️ Skipping sendMessage - empty input');
      return;
    }
    
    // Check if already processing
    if (this.isProcessing) {
      console.warn('[WorkOrderModal] 🚫 Already processing a message. Ignoring:', messageText);
      this.userInput = ''; // Clear input
      return;
    }
    
    this.userInput = '';
    
    console.log('[WorkOrderModal] ✅ Processing message:', messageText);

    // Add user message
    this.addMessage(messageText, 'user', false);

    try {
      // Check if it's a "proceed" command
      const nextStepPattern = /(?:proceed|continue|next|move\s+to\s+next|completed?)\s+(?:step|to\s+step)?/i;
      
      if (nextStepPattern.test(messageText) && this.currentSessionId) {
        await this.proceedToNextStep(messageText);
      } else {
        // Send as regular query to chat API
        await this.sendQueryToAPI(messageText);
      }
    } catch (error) {
      console.error('[WorkOrderModal] Error in sendMessage:', error);
    }
  }

  /**
   * Send general query to API
   */
  private async sendQueryToAPI(query: string): Promise<void> {
    try {
      this.isProcessing = true;
      this.cdr.detectChanges();

      // Get response from chat API - the API request manager handles deduplication
      const apiResponse = await this.voiceApiService.sendTextToAPI(query, false);
      const botResponse = apiResponse.text;

      // DON'T increment stepNumber here - this is not a tracked workflow step
      // Only work order start/proceed responses should have step numbers for feedback

      // Add bot response WITHOUT step number since this is just a query, not a workflow step
      this.messages.push({
        text: botResponse,
        sender: 'bot',
        avatar: '🤖',
        isVoice: true,
        sessionId: this.currentSessionId,
        stepNumber: undefined, // No step number for general queries
        feedback: null
      });

      this.cdr.detectChanges();
      this.scrollToBottom();

      // Speak the response
      await this.speakText(botResponse);

      this.isProcessing = false;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('[WorkOrderModal] Query API error:', error);
      this.addMessage('Failed to get response. Please try again.', 'bot');
      this.isProcessing = false;
      this.cdr.detectChanges();
      
      // Restart wake word listener even on error
      setTimeout(() => this.startModalWakeWordListener(), 500);
    }
  }

  /**
   * Proceed to next step using feedback API
   */
  private async proceedToNextStep(userInput: string): Promise<void> {
    // Prevent duplicate proceed calls
    if (this.isProcessing || this.isFeedbackInProgress) {
      console.warn('[WorkOrderModal] ⚠️ Already processing proceed request');
      return;
    }
    
    try {
      this.isProcessing = true;
      this.isFeedbackInProgress = true;
      
      const userId = 1; // TODO: Get from AuthService
      
      // Use different endpoint based on whether work order was resumed
      const feedbackObservable = this.isResumedWorkOrder && this.currentStepId
        ? this.feedbackService.submitWorkOrderFeedback(
            this.workOrderId,
            this.currentStepId,
            `positive - ${userInput}`,
            0.5 // TODO: Track actual time spent
          )
        : this.feedbackService.submitFeedback(
            this.currentSessionId,
            this.currentStepNumber,
            'positive',
            userInput,
            userId
          );
      
      // The API request manager handles deduplication automatically
      feedbackObservable.subscribe({
        next: async (response) => {
          console.log('[WorkOrderModal] Next step response:', response);
          
          // Update step ID if provided (for resumed work orders)
          // Use next_step for resumed work orders, current_step for chat-started
          const stepToUpdate = this.isResumedWorkOrder && response.next_step 
            ? response.next_step 
            : response.current_step;
            
          if (stepToUpdate && 'id' in stepToUpdate && stepToUpdate.id) {
            this.currentStepId = stepToUpdate.id as number;
          }
          
          // Handle both "complete" and "work_order_complete" types
          if (response.type === 'complete' || response.type === 'work_order_complete') {
            sessionStorage.setItem('work_order_complete', 'true');
            
            // Format completion message
            let completionMessage = response.message || 'Work order completed successfully! 🎉';
            
            // Add summary information if available (using any to handle dynamic API response)
            const responseData = response as any;
            if (responseData.summary) {
              completionMessage += '\n\n📊 Work Order Summary:';
              
              if (responseData.summary.summary_text) {
                completionMessage += `\n${responseData.summary.summary_text}`;
              }
              
              if (responseData.summary.major_issues_resolved) {
                completionMessage += `\n\n🔧 Major Issues Resolved:\n${responseData.summary.major_issues_resolved}`;
              }
              
              if (responseData.summary.recommendations_for_customer) {
                completionMessage += `\n\n💡 Recommendations:\n${responseData.summary.recommendations_for_customer}`;
              }
            } else {
              // Fallback to individual fields if summary object not available
              if (response.total_steps) {
                completionMessage += `\n\n✅ Total Steps Completed: ${response.total_steps}`;
              }
              if (response.total_time) {
                const hours = typeof response.total_time === 'string' 
                  ? Number.parseFloat(response.total_time).toFixed(2)
                  : response.total_time.toFixed(2);
                completionMessage += `\n⏱️ Total Time: ${hours} hours`;
              }
            }
            
            this.addMessage(completionMessage, 'bot', true);
            
            // Create voice output with summary
            let speechText = response.message || 'Work order completed successfully!';
            
            if (responseData.summary?.summary_text) {
              speechText += ` ${responseData.summary.summary_text}`;
              
              if (responseData.summary.major_issues_resolved) {
                speechText += ` Major issues resolved: ${responseData.summary.major_issues_resolved}`;
              }
              
              if (responseData.summary.recommendations_for_customer) {
                speechText += ` Recommendations for customer: ${responseData.summary.recommendations_for_customer}`;
              }
            } else if (response.tts_text) {
              speechText = response.tts_text;
            }
            
            await this.speakText(speechText);
            
            this.isFeedbackInProgress = false;
            this.isProcessing = false;
            return;
          }

          if (response.type === 'next_step') {
            // Store completed step
            if (response.progress?.completed) {
              sessionStorage.setItem('completed_step', response.progress.completed.toString());
            } else if (response.completed_steps) {
              // For work order feedback endpoint
              sessionStorage.setItem('completed_step', response.completed_steps.toString());
            }

            this.currentStepNumber++;

            // Format message differently based on endpoint used
            let messageText = response.message || 'Proceeding to next step.';
            
            // For resumed work orders, use next_step.description
            if (this.isResumedWorkOrder && response.next_step?.description) {
              messageText += `\n\n${response.next_step.description}`;
              
              if (response.next_step.estimated_time) {
                messageText += `\n\nEstimated time: ${response.next_step.estimated_time} hours`;
              }
            } else {
              // For chat-started work orders, use existing logic
              if (response.tts_text) {
                messageText += `\n\n${response.tts_text}`;
              }
              
              if (response.current_step?.estimated_time) {
                messageText += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
              }
            }

            if (response.progress) {
              messageText += `\n\nProgress: ${response.progress.completed}/${response.progress.total} steps (${response.progress.percentage.toFixed(1)}%)`;
            } else if (response.completed_steps && response.total_steps) {
              // For work order feedback endpoint
              const percentage = (response.completed_steps / response.total_steps) * 100;
              messageText += `\n\nProgress: ${response.completed_steps}/${response.total_steps} steps (${percentage.toFixed(1)}%)`;
            }

            this.messages.push({
              text: messageText,
              sender: 'bot',
              avatar: '🤖',
              isVoice: true,
              sessionId: this.currentSessionId,
              stepNumber: this.currentStepNumber,
              feedback: null
            });

            this.scrollToBottom();
            
            // For voice output, use next_step.description for resumed work orders
            const voiceText = this.isResumedWorkOrder && response.next_step?.description
              ? `${response.message}. ${response.next_step.description}`
              : messageText;
            
            await this.speakText(voiceText);
          }
          
          this.isFeedbackInProgress = false;
          this.isProcessing = false;
        },
        error: (error) => {
          console.error('[WorkOrderModal] Failed to proceed:', error);
          this.addMessage('Failed to proceed. Please try again.', 'bot');
          this.isFeedbackInProgress = false;
          this.isProcessing = false;
        }
      });
    } catch (error) {
      console.error('[WorkOrderModal] Error:', error);
      this.isFeedbackInProgress = false;
      this.isProcessing = false;
    }
  }

  /**
   * Submit feedback for a message
   */
  submitFeedback(message: Message, isPositive: boolean): void {
    // Only allow feedback on messages that have proper session and step tracking
    if (!message.sessionId || message.stepNumber === undefined) {
      console.warn('[WorkOrderModal] ⚠️ Cannot submit feedback - message missing sessionId or stepNumber:', message);
      return;
    }
    
    // Check if feedback was already submitted
    if (message.feedback) {
      console.warn('[WorkOrderModal] ⚠️ Feedback already submitted for this message:', message.feedback);
      return;
    }

    const feedback = isPositive ? 'positive' : 'negative';
    this.isFeedbackInProgress = true;

    console.log('[WorkOrderModal] 📝 Submitting feedback:', { 
      sessionId: message.sessionId, 
      stepNumber: message.stepNumber, 
      feedback 
    });

    // The API request manager handles deduplication automatically
    this.feedbackService.submitFeedback(
      message.sessionId,
      message.stepNumber,
      feedback,
      '',
      1 // TODO: Get from AuthService
    ).subscribe({
      next: (response) => {
        message.feedback = feedback;
        this.cdr.detectChanges();

        // Don't await here - handle async operations inside the handlers
        if (response.type === 'next_step' && response.message) {
          // Call without await to avoid blocking
          this.handleNextStepResponse(response).catch(error => {
            console.error('[WorkOrderModal] Error handling next step:', error);
          });
        } else if (response.type === 'complete' || response.type === 'work_order_complete') {
          // Call without await to avoid blocking
          this.handleWorkOrderComplete(response).catch(error => {
            console.error('[WorkOrderModal] Error handling completion:', error);
          });
        } else {
          // No next step, just mark as complete
          this.isFeedbackInProgress = false;
        }
      },
      error: (error) => {
        console.error('[WorkOrderModal] Feedback error:', error);
        this.isFeedbackInProgress = false;
      }
    });
  }

  /**
   * Handle next step response
   */
  private async handleNextStepResponse(response: any): Promise<void> {
    if (response.progress?.completed) {
      sessionStorage.setItem('completed_step', response.progress.completed.toString());
    }

    this.currentStepNumber++;

    let messageText = response.message;
    if (response.tts_text) {
      messageText += `\n\n${response.tts_text}`;
    }
    if (response.current_step?.estimated_time) {
      messageText += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
    }
    if (response.progress) {
      messageText += `\n\nProgress: ${response.progress.completed}/${response.progress.total} steps (${response.progress.percentage.toFixed(1)}%)`;
    }

    this.messages.push({
      text: messageText,
      sender: 'bot',
      avatar: '🤖',
      isVoice: true,
      sessionId: this.currentSessionId,
      stepNumber: this.currentStepNumber,
      feedback: null
    });

    this.scrollToBottom();
    await this.speakText(messageText);
    
    // Mark feedback as complete after voice finishes
    this.isFeedbackInProgress = false;
  }

  /**
   * Handle work order complete
   */
  private async handleWorkOrderComplete(response: any): Promise<void> {
    sessionStorage.setItem('work_order_complete', 'true');
    
    // Format completion message with details
    let completionMessage = response.message || 'Work order completed successfully! 🎉';
    
    // Add summary information if available
    if (response.summary) {
      completionMessage += '\n\n📊 Work Order Summary:';
      
      if (response.summary.summary_text) {
        completionMessage += `\n${response.summary.summary_text}`;
      }
      
      if (response.summary.major_issues_resolved) {
        completionMessage += `\n\n🔧 Major Issues Resolved:\n${response.summary.major_issues_resolved}`;
      }
      
      if (response.summary.recommendations_for_customer) {
        completionMessage += `\n\n💡 Recommendations:\n${response.summary.recommendations_for_customer}`;
      }
    } else {
      // Fallback to individual fields if summary object not available
      if (response.total_steps) {
        completionMessage += `\n\n✅ Total Steps Completed: ${response.total_steps}`;
      }
      if (response.total_time) {
        const hours = typeof response.total_time === 'string' 
          ? Number.parseFloat(response.total_time).toFixed(2)
          : response.total_time.toFixed(2);
        completionMessage += `\n⏱️ Total Time: ${hours} hours`;
      }
    }
    
    this.addMessage(completionMessage, 'bot', true);
    
    // Create voice output with summary
    let speechText = response.message || 'Work order completed successfully!';
    
    if (response.summary?.summary_text) {
      speechText += ` ${response.summary.summary_text}`;
      
      if (response.summary.major_issues_resolved) {
        speechText += ` Major issues resolved: ${response.summary.major_issues_resolved}`;
      }
      
      if (response.summary.recommendations_for_customer) {
        speechText += ` Recommendations for customer: ${response.summary.recommendations_for_customer}`;
      }
    } else if (response.tts_text) {
      speechText = response.tts_text;
    }
    
    await this.speakText(speechText);
    
    // Mark feedback as complete after voice finishes
    this.isFeedbackInProgress = false;
  }

  /**
   * Add message to chat
   */
  private addMessage(text: string, sender: 'user' | 'bot', isVoice = false): void {
    this.messages.push({
      text,
      sender,
      avatar: sender === 'user' ? '🧑' : '🤖',
      isVoice
    });
    this.cdr.detectChanges();
    this.scrollToBottom();
  }

  /**
   * Speak text using TTS
   */
  private async speakText(text: string): Promise<void> {
    try {
      this.isVoicePlaying = true;
      this.cdr.detectChanges(); // Force UI update
      await this.voiceApiService.speakText(text);
      this.isVoicePlaying = false;
      this.cdr.detectChanges(); // Force UI update to enable inputs
      
      // Restart wake word listener after TTS completes
      setTimeout(() => this.startModalWakeWordListener(), 500);
    } catch (error) {
      console.error('[WorkOrderModal] TTS error:', error);
      this.isVoicePlaying = false;
      this.cdr.detectChanges(); // Force UI update even on error
      
      // Restart wake word listener even on error
      setTimeout(() => this.startModalWakeWordListener(), 500);
    }
  }

  /**
   * Scroll to bottom of messages
   */
  private scrollToBottom(): void {
    setTimeout(() => {
      if (this.messagesContainer) {
        const element = this.messagesContainer.nativeElement;
        element.scrollTop = element.scrollHeight;
      }
    }, 100);
  }

  /**
   * Check if speech recognition is supported
   */
  get isSpeechSupported(): boolean {
    return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  }

  /**
   * Get current time
   */
  getCurrentTime(): string {
    return new Date().toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  }

  /**
   * Start wake word listener for modal
   */
  private startModalWakeWordListener(): void {
    console.log('[WorkOrderModal] 🎤 Preparing to start wake word listener for modal...');
    
    // First, ensure wake word service is completely stopped
    try {
      console.log('[WorkOrderModal] 🛑 Force-stopping any existing listeners...');
      this.wakeupVoiceService.stopListening();
      
      // Wait for full cleanup with extended timeout
      setTimeout(() => {
        console.log('[WorkOrderModal] ⏱️ Cleanup complete, starting fresh listener...');
        
        // Try to start the listener
        try {
          this.wakeupVoiceService.startListening(
            () => {
              // Wake word "hey buddy" detected - start modal voice input
              console.log('[WorkOrderModal] 🎯 Wake word detected! Starting voice input...');
              this.wakeupVoiceService.stopListening();
              this.toggleVoiceInput();
            }
          );
          console.log('[WorkOrderModal] ✓ Modal wake word listener started successfully');
        } catch (error) {
          console.error('[WorkOrderModal] ✗ Error starting listener:', error);
        }
      }, 250); // Increased cleanup time
    } catch (error) {
      console.error('[WorkOrderModal] ✗ Error in listener management:', error);
    }
  }
}
