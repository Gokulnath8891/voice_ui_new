# # from django.apps import AppConfig


# # class AgenticRagConfig(AppConfig):
# #     default_auto_field = 'django.db.models.BigAutoField'
# #     name = 'agentic_rag'


# # #--------
# from django.apps import AppConfig
# from django.conf import settings
# import sys

# # Import your synchronous build function
# from .agent import build_agent 

# # Global variable to hold your initialized agent
# AGENTIC_RAG_AGENT = None 

# class AgenticRagConfig(AppConfig):
#     default_auto_field = 'django.db.models.BigAutoField'
#     name = 'agentic_rag'

#     def ready(self):
#         # Only initialize the agent when running the server
#         if 'runserver' in sys.argv:
#             print("Initializing custom Agentic RAG Agent...")
#             global AGENTIC_RAG_AGENT
            
#             # NOTE: If your build_agent is still async, you'll need to run it in a thread/async loop here.
#             # Assuming you made it synchronous (Step 1):
#             AGENTIC_RAG_AGENT = build_agent()
#             print("Custom Agentic RAG Agent initialized successfully.")


import os
from django.apps import AppConfig

from .agent import build_agent

AGENTIC_RAG_AGENT = None

class AgenticRagConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'agentic_rag'

    def ready(self):
        # Ensure this runs only once in the main server process
        if os.environ.get("RUN_MAIN") != "true":
            return

        global AGENTIC_RAG_AGENT

        if AGENTIC_RAG_AGENT is None:
            print("Initializing custom Agentic RAG Agent...")
            AGENTIC_RAG_AGENT = build_agent()
            print("Custom Agentic RAG Agent initialized successfully.")
