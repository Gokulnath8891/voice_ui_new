# Agentic RAG Module

Django app providing intelligent query processing with automatic routing between SQL database queries and semantic vector search.

## Quick Start

### 1. Install Dependencies

```bash
pip install langchain-openai langgraph sentence-transformers
```

### 2. Run Server

```bash
python manage.py runserver
```

### 3. Test Endpoint

```bash
curl -X POST http://localhost:8000/api/agentic-rag/query/ \
  -H "Content-Type: application/json" \
  -d '{"query": "How do I replace brake pads?"}'
```

## API Endpoints

- **POST /api/agentic-rag/query/** - Process queries
- **GET /api/agentic-rag/health/** - Health check

## Documentation

See **AGENTIC_RAG_API.md** for complete API documentation and Angular integration examples.

## Module Structure

```
agentic_rag/
├── service.py    # Core business logic (LangGraph, RAG workflow)
├── views.py      # REST API endpoints
├── urls.py       # URL routing
├── apps.py       # Django app config
└── models.py     # No models (uses external services)
```

## Configuration

Edit `service.py` to change:
- Azure OpenAI settings
- Database connection
- Vector search parameters (MMR_FETCH_K, MMR_RETURN_K, MMR_LAMBDA)
- Embedding model
