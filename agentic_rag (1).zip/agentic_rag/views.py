"""
Agentic RAG API Views
Provides REST endpoint for Angular application to access intelligent RAG functionality
"""

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from drf_spectacular.utils import extend_schema, OpenApiParameter, OpenApiExample
from drf_spectacular.types import OpenApiTypes
import logging

from .service import process_agentic_query

logger = logging.getLogger(__name__)


@extend_schema(
    tags=["Agentic RAG"],
    summary="Process query with Agentic RAG",
    description="""
    Intelligent query processing with automatic routing:
    - Work order queries → SQL Agent (database queries)
    - Technical queries → Vector Agent (semantic search with agentic workflow)
    
    **Agentic Workflow:**
    1. **Router** - Analyzes query to determine best agent
    2. **Planner** - Breaks complex questions into sub-questions
    3. **Executor** - Retrieves relevant information for each sub-question
    4. **Judge** - Evaluates if retrieved information is sufficient
    5. **Synthesizer** - Combines results into coherent answer
    
    **Supports conversation memory** via thread_id parameter.
    """,
    request={
        'application/json': {
            'type': 'object',
            'properties': {
                'query': {
                    'type': 'string',
                    'description': 'User question or query',
                    'example': 'What are the steps to diagnose a faulty oxygen sensor?'
                },
                'conversation_history': {
                    'type': 'string',
                    'description': 'Previous conversation context (optional)',
                    'example': '',
                    'default': ''
                },
                'thread_id': {
                    'type': 'string',
                    'description': 'Thread ID for maintaining conversation state (optional)',
                    'example': '1',
                    'default': '1'
                }
            },
            'required': ['query']
        }
    },
    responses={
        200: {
            'description': 'Successful query processing',
            'content': {
                'application/json': {
                    'example': {
                        "success": True,
                        "result": "To diagnose a faulty oxygen sensor:\n\n1. Check for error codes using an OBD-II scanner...",
                        "context": "[id:42] Oxygen sensor diagnostics guide...",
                        "route": "vector_agent",
                        "query": "What are the steps to diagnose a faulty oxygen sensor?",
                        "per_sub": [
                            {
                                "subquery": "How to check oxygen sensor?",
                                "rewritten": "oxygen sensor diagnostic steps",
                                "retrieved": [
                                    {
                                        "id": 42,
                                        "content": "Oxygen sensor diagnostics...",
                                        "score": 0.87
                                    }
                                ]
                            }
                        ],
                        "judge": {
                            "verdict": "OK",
                            "note": "Retrieved context contains comprehensive answer"
                        }
                    }
                }
            }
        },
        400: {
            'description': 'Bad request - missing query parameter',
            'content': {
                'application/json': {
                    'example': {
                        "error": "Missing required field: query"
                    }
                }
            }
        },
        500: {
            'description': 'Internal server error during query processing',
            'content': {
                'application/json': {
                    'example': {
                        "success": False,
                        "error": "Error processing query: Database connection failed",
                        "result": "⚠️ Error processing query: Database connection failed",
                        "query": "What are the steps to diagnose a faulty oxygen sensor?"
                    }
                }
            }
        }
    },
    examples=[
        OpenApiExample(
            'Technical Query Example',
            value={
                'query': 'What are the steps to diagnose a faulty oxygen sensor?',
                'thread_id': '1'
            },
            request_only=True
        ),
        OpenApiExample(
            'Work Order Query Example',
            value={
                'query': 'Show me work order WO-12345',
                'thread_id': 'user_1_session'
            },
            request_only=True
        ),
        OpenApiExample(
            'Complex Query Example',
            value={
                'query': 'What causes engine misfires and how do I diagnose them?',
                'conversation_history': 'User: Tell me about engine diagnostics\nAssistant: Engine diagnostics involves...',
                'thread_id': 'conversation_123'
            },
            request_only=True
        ),
    ]
)
@api_view(['POST'])
def query_agentic_rag(request):
    """
    Process user query through Agentic RAG pipeline
    
    Endpoint: POST /api/agentic-rag/query/
    
    Request Body:
        {
            "query": "User question",
            "conversation_history": "Optional previous context",
            "thread_id": "Optional thread ID for conversation memory"
        }
    
    Response:
        {
            "success": true,
            "result": "Final answer text",
            "context": "Retrieved context used for answer",
            "route": "db_agent or vector_agent",
            "query": "Original query",
            "per_sub": [...],  // Agentic retrieval details
            "judge": {...}     // Quality assessment
        }
    """


    #v1

    try:
        query = request.data.get('query')

        user = request.user if request.user.is_authenticated else None
        user_id = user.id if user else None
        username = user.username if user else 'Anonymous'

        print(query)
        if not query:
            return Response({"error": "Missing required field: query"}, status=status.HTTP_400_BAD_REQUEST)
        
        
        result = process_agentic_query(
            query=query,
            user_id=user_id,
            username=username,
        )
        
        if result['success']:
            return Response(result, status=status.HTTP_200_OK)
        else:
            return Response(result, status=status.HTTP_400_BAD_REQUEST)
            
    except Exception as e:
        logger.exception(f"Unexpected error in query_agentic_rag: {e}")
        return Response(
            {
                "success": False,
                "result": f"⚠️ Unexpected server error: {e}"
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@extend_schema(
    tags=["Agentic RAG"],
    summary="Health check for Agentic RAG service",
    description="Check if the Agentic RAG service is running and can connect to required services (database, OpenAI)",
    responses={
        200: {
            'description': 'Service is healthy',
            'content': {
                'application/json': {
                    'example': {
                        "status": "healthy",
                        "message": "Agentic RAG service is operational",
                        "services": {
                            "database": "connected",
                            "openai": "available",
                            "embeddings": "loaded"
                        }
                    }
                }
            }
        }
    }
)
@api_view(['GET'])
def health_check(request):
    """
    Health check endpoint
    
    Endpoint: GET /api/agentic-rag/health/
    
    Response:
        {
            "status": "healthy",
            "message": "Agentic RAG service is operational",
            "services": {...}
        }
    """
    try:
        # Test database connection
        from .service import get_pg_connection
        conn = get_pg_connection()
        conn.close()
        db_status = "connected"
    except Exception as e:
        db_status = f"error: {str(e)}"
    
    # Check if models are loaded
    try:
        from .service import model, llm
        embeddings_status = "loaded" if model else "not loaded"
        openai_status = "available" if llm else "not available"
    except Exception as e:
        embeddings_status = f"error: {str(e)}"
        openai_status = f"error: {str(e)}"
    
    health_data = {
        "status": "healthy" if db_status == "connected" else "degraded",
        "message": "Agentic RAG service is operational",
        "services": {
            "database": db_status,
            "openai": openai_status,
            "embeddings": embeddings_status
        }
    }
    
    return Response(health_data, status=status.HTTP_200_OK)




    #v0

    # try:
    #     # Extract parameters from request
    #     query = request.data.get('query')
    #     conversation_history = request.data.get('conversation_history', '')
    #     thread_id = request.data.get('thread_id', '1')
    #     print(f'thread_id is: {thread_id}')
    #     print(f'conversation_history is: {conversation_history}')
    #     user = request.user if request.user.is_authenticated else None
    #     user_id = user.id if user else None
    #     username = user.username if user else 'Anonymous'
    #     print(f'user is {user}')
    #     print(f'user_id is {user_id}')
    #     print(f'username is {username}')
        
    #     # Validate required fields
    #     if not query:
    #         return Response(
    #             {"error": "Missing required field: query"},
    #             status=status.HTTP_400_BAD_REQUEST
    #         )
        
    #     logger.info(f"Processing agentic RAG query: {query[:100]}... (thread_id: {thread_id})")
        
    #     # Process query through agentic RAG service
    #     result = process_agentic_query(
    #         query=query,
    #         conversation_history=conversation_history,
    #         thread_id=thread_id
    #     )
        
    #     # Log result status
    #     if result.get('success'):
    #         logger.info(f"Query processed successfully via {result.get('route', 'unknown')} route")
    #     else:
    #         logger.error(f"Query processing failed: {result.get('error', 'Unknown error')}")
        
    #     # Return response
    #     return Response(result, status=status.HTTP_200_OK)
        
    # except Exception as e:
    #     logger.exception(f"Unexpected error in query_agentic_rag: {e}")
    #     return Response(
    #         {
    #             "success": False,
    #             "error": str(e),
    #             "result": f"⚠️ Unexpected server error: {e}"
    #         },
    #         status=status.HTTP_500_INTERNAL_SERVER_ERROR
    #     )