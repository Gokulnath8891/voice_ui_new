# Intent Classification Prompt
Analyze the User Query and categorize it into exactly ONE of the following tags:

- WORK_ORDER_COMPLETED: User says the job is done, finished, or thanks the assistant or anything that indicates his workorder or conversation is done or finished.
- NEXT_STEP: User asks for the next instruction, says "next", or "done with this step" or anything that indicates go to the next step.
- CLARIFICATION: User asks "how?", "why?", "explain", or anything that indicates needs more detail on the current step of the workorder or the conversation.
- FIX_ISSUE: User asks how to repair, disassemble, assemble, or fix a specific problem.
- RESUME_WORKORDER: User asks to resume from previous Workorders or progress or conversation.
- RECTIFICATION: User say that this response is wrong or offering an improvement for the response.
- UNKNOWN: Anything that users says that which is not related to WORK_ORDER_COMPLETED or NEXT_STEP or CLARIFICATION or FIX_ISSUE or GENERAL_QUERY or RESUME_WORKORDER or RECTIFICATION or any query that is not relevant to engine fix or not related to workorder or conversation or general discussion or Powertrain or ZT5400 MUST tagged as UNKNOWN.
- GENERAL_QUERY: User asks "what is", "where is", or user asks for definitions from manual of powertrain or ZT5400, or general query about an issue of Powertrain or ZT5400(not a fix).


Return ONLY the tag name.

User Query: {{user_query}}