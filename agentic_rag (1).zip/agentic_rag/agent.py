import os
from agno.agent import Agent
from agno.knowledge.chunking.agentic import AgenticChunking
from agno.knowledge.reader.pdf_reader import PDFReader
from agno.knowledge import Knowledge
from agno.tools.knowledge import KnowledgeTools
from agno.tools.tavily import TavilyTools
from agno.vectordb.chroma import ChromaDb
from agno.vectordb.pgvector import PgVector
from agno.vectordb.search import SearchType
from agno.knowledge.reranker.cohere import CohereReranker
from agno.models.azure import AzureOpenAI
from agno.knowledge.embedder.sentence_transformer import SentenceTransformerEmbedder
from .config import config
import psycopg

def build_agent():
    llm = AzureOpenAI(
        id=config.AZURE_DEPLOYMENT,
        name="AzureOpenAI",
        provider="Azure",
        azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
        api_key=config.AZURE_OPENAI_API_KEY,
        temperature=0.2
    )

    '''use better embed models to improve retriever'''
    embedder = SentenceTransformerEmbedder(id="BAAI/bge-large-en-v1.5", dimensions=1024)

    db_url = f"postgresql+psycopg://{config.DB_USERNAME}:{config.DB_PASSWORD}@{config.DB_HOST}:{config.DB_PORT}/{config.DB_NAME}"

    vector_db = PgVector(
        table_name="vector_manual", 
        db_url=db_url,
        search_type=SearchType.hybrid,
        embedder=embedder,
        # reranker=CohereReranker(api_key=config.COHERE_API_KEY)
    )

    knowledge = Knowledge(vector_db=vector_db)
    
    
    if vector_db.table_exists:
        print(f"Vector store already built with documents.")
    else:
        print("Vector store is empty. Starting PDF ingestion...")
        
        # Load all PDFs in the specified path
        for file in os.listdir(config.PDF_PATH):
            if file.lower().endswith(".pdf"):
                pdf_path = os.path.join(config.PDF_PATH, file)
                print(f"Loading {file}...")
                
                knowledge.add_content(
                    path=pdf_path,
                    reader=PDFReader(
                        name="PDF Semantic Reader",
                        chunking_strategy=AgenticChunking()
                    )
                )

    tools = [
        KnowledgeTools(knowledge=knowledge), 
        # TavilyTools(api_key=config.TAVILY_API_KEY) 
    ]

    agent = Agent(
        name="Agentic RAG",
        model=llm,
        tools=tools,
        knowledge=knowledge,
        search_knowledge=False,
        build_context=True,
        enable_user_memories=False,
        enable_agentic_memory=False,
        markdown=True,
        telemetry=False
    )

    return agent