"""
Agentic RAG Models
This module does not require database models as it uses external services.
"""

# No models required for this app
# The module uses:
# - PostgreSQL (via psycopg2 direct connection)
# - Azure OpenAI (via API)
# - SentenceTransformer (in-memory model)

from django.db import models
from django.contrib.postgres.fields import ArrayField
from pgvector.django import VectorField
from django.utils import timezone
import uuid
from django.contrib.auth.models import User, Group



class Customer(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Vehicle(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='vehicles')
    make = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    year = models.IntegerField()
    vin = models.CharField(max_length=17, unique=True)
    license_plate = models.CharField(max_length=20)
    mileage = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.year} {self.make} {self.model} - {self.license_plate}"


class WorkOrder(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('ASSIGNED', 'Assigned'),
        ('IN_PROGRESS', 'In Progress'),
        ('COMPLETED', 'Completed'),
        ('CANCELLED', 'Cancelled'),
    ]
    
    PRIORITY_CHOICES = [
        ('LOW', 'Low'),
        ('MEDIUM', 'Medium'),
        ('HIGH', 'High'),
        ('URGENT', 'Urgent'),
    ]
    
    order_number = models.CharField(max_length=20, unique=True)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='work_orders', null=True, blank=True)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name='work_orders', null=True, blank=True)
    
    service_manager = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='managed_orders',
        limit_choices_to={'groups__name': 'Service Manager'}, null=True, blank=True
    )
    technician = models.ForeignKey(
        User, on_delete=models.SET_NULL, related_name='assigned_orders',
        limit_choices_to={'groups__name': 'Technician'}, null=True, blank=True
    )
    title = models.TextField()
    description = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='MEDIUM')
    embedding = VectorField(dimensions=1024, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    def save(self, *args, **kwargs):
        if not self.order_number:
            self.order_number = f"WO-{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.order_number} - {self.title}"


class WorkOrderStep(models.Model):
    work_order = models.ForeignKey(WorkOrder, on_delete=models.CASCADE, related_name='steps')
    user_id = models.IntegerField(null=True, blank=True)
    username = models.CharField(max_length=255, null=True, blank=True)
    steps_list = models.JSONField(default=list, verbose_name="Assigned Steps Guide")
    current_step_index = models.IntegerField(default=1) # 1-based index
    is_completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Steps for {self.work_order.order_number} ({self.username})"


class WorkOrderFeedback(models.Model):
    work_order = models.ForeignKey(WorkOrder, on_delete=models.CASCADE, related_name='feedbacks')
    user_id = models.IntegerField(null=True, blank=True)
    username = models.CharField(max_length=255, null=True, blank=True)
    feedback_data = models.JSONField(default=dict)
    clarification_data = models.JSONField(default=dict)
    rectification_data = models.JSONField(default=dict)
    timestamp = models.DateTimeField(auto_now_add=True)


class WorkOrderSummary(models.Model):
    work_order = models.ForeignKey(WorkOrder, on_delete=models.CASCADE, related_name='summaries')
    user_id = models.IntegerField(null=True, blank=True)
    username = models.CharField(max_length=255, null=True, blank=True)
    summary = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)


class Conversation(models.Model):
    title = models.TextField()
    description = models.TextField()
    embedding = VectorField(dimensions=1024, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Conv - {self.title[:30]}"


class ConversationSteps(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='steps')
    user_id = models.IntegerField(null=True, blank=True)
    username = models.CharField(max_length=255, null=True, blank=True)
    original_query = models.TextField()
    steps_list = models.JSONField(default=list, verbose_name="Generated Steps Guide")
    current_step_index = models.IntegerField(default=1)
    is_completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)


class ConversationFeedback(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='feedbacks')
    user_id = models.IntegerField(null=True, blank=True)
    username = models.CharField(max_length=255, null=True, blank=True)
    feedback_data = models.JSONField(default=dict)
    clarification_data = models.JSONField(default=dict)
    rectification_data = models.JSONField(default=dict)
    timestamp = models.DateTimeField(auto_now_add=True)


class UserSession(models.Model):
    ACTIVE_QUERY_TYPES = (
        ("WORKORDER", "Work Order"),
        ("GENERAL", "General"),
    )
    user_id = models.IntegerField(unique=True)
    active_query_type = models.CharField(
        max_length=20,
        choices=ACTIVE_QUERY_TYPES,
        null=True,
        blank=True
    )
    active_wo_number = models.CharField(max_length=20, null=True, blank=True)
    last_updated = models.DateTimeField(auto_now=True)