import urllib.parse

class config:
    AZURE_OPENAI_API_KEY = "FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m"
    AZURE_OPENAI_ENDPOINT = "https://voice-assitant-openai.openai.azure.com/"
    AZURE_DEPLOYMENT = "gpt-4.1-mini" 
    CHROMA_DB_PATH = "./chroma_db"
    PDF_PATH = "../docs"  
    TAVILY_API_KEY = "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"
    # DB_USERNAME = "postgres"
    # DB_PASSWORD = "voice_password"
    # DB_HOST = "voiceassistantpsql.postgres.database.azure.com"
    # DB_PORT = 5432
    # DB_NAME = "voice_assistant_db"

    DB_USERNAME = "LVadmin"
    DB_PASSWORD = urllib.parse.quote_plus("LVwelcome@2025")
    DB_HOST = "voiceassistantpsql.postgres.database.azure.com"
    DB_PORT = 5432
    DB_NAME = "voice_assistant_db"

    COHERE_API_KEY = "iu2xVB9a40XDKa6xe8G0rJwLr7bslzyZMyIAVB3p"
