# Azure Text-to-Speech Customization Using SSML

## Overview

We can adjust the pitch, add pauses, improve pronunciation, change speaking rate, and attribute multiple voices to a single document using SSML or Speech Synthesis Markup Language.

## Using SSML for Voice Control

Use SSML's `<prosody>` tag to adjust rate (e.g., `rate="0.9"` for slower speech), pitch, and volume for varied tone.

Apply `<emphasis level="strong">` on key words to mimic natural stress patterns.

## Adding Pauses

Insert `<break time="1s"/>` for custom pauses up to 20 seconds, overriding automatic ones—e.g., after phrases for breathing effect.

Use `<mstts:silence type="Sentenceboundary" value="500ms"/>` for precise silence between sentences or at punctuation like commas.

Structure text with `<p>` for paragraphs and `<s>` for sentences to guide natural flow.

## SSML Example

```xml
<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">
    <voice name="en-US-AvaNeural">
        Welcome.<break time="750ms"/> This is more human-like speech.
        <prosody rate="medium" pitch="low">It pauses naturally.</prosody>
    </voice>
</speak>
```

## Azure Portal Customization Limitations

**Does Azure not support direct settings changes in the Azure portal for customizing speech?**

No, Azure TTS does not offer direct settings changes in the Azure portal for customizing speech tone or pauses on LLM-generated text.

Customization happens programmatically by preprocessing the LLM output text with SSML tags before sending it to the TTS API.

Use the Speech SDK's `SpeakSsmlAsync` method instead of plain text for SSML input.

## Automatic Conversion of LLM Output to SSML

**okay, can we convert LLM output to SSML automatically in Azure?**

No, Azure does not provide a built-in tool to automatically convert plain LLM output to SSML.

Implement custom preprocessing in your application code to wrap text in SSML and insert tags for pauses and tone.

Use libraries like regex or AI services for that.

## Alternatives to SSML

**Are there any other ways other than SSML?**

Yes, Opt for HD Neural voices (e.g., en-US-AriaNeural HD) which provide superior prosody, intonation, and emotional depth compared to standard Neural voices, resulting in less robotic delivery. (also Use Turbo Neural voices for faster synthesis while retaining naturalness, ideal for real-time LLM responses), Or we can train a Custom Neural Voice using our own audio samples (minimum 300 sentences) through Azure Speech Studio.

We can try going through Azure AI Foundry Voice Gallery for more human-like voice.

Another way which we can do is by using Google's Text-to-Speech AI services which will convert text into natural-sounding human-like speech. We can call their API, but it may increase the latency by a bit.
