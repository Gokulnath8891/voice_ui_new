import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';
import { ApiRequestManagerService } from './api-request-manager.service';

export interface WorkOrderResponse {
  id: number;
  order_number: string;
  customer_name: string;
  vehicle_info: string;
  service_manager_name: string;
  technician_name: string;
  title: string;
  status: string;
  priority: string;
  created_at: string;
  assigned_at: string;
}

export interface WorkOrder {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  assignee: string;
  vehicle: string;
  estimatedHours: number;
  dueDate: string;
  steps: { number: number; completed: boolean }[];
}

// Start Work API Interfaces
export interface StartWorkRequest {
  query: string;
  user_id: number;
  type: 'text' | 'voice';
}

export interface WorkflowStep {
  id?: number; // Step ID from database
  step_number: number;
  description: string;
  estimated_time?: string;
}

export interface WorkOrderDetail {
  id: number;
  order_number: string;
  title: string;
  description: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'ON_HOLD';
  customer_name: string;
  customer_email?: string;
  location: string;
  estimated_time: number;
  completed_steps: number;
  total_steps: number;
}

export interface WorkOrderStartResponse {
  type: 'work_order_start' | 'error';
  session_id?: string;
  message: string;
  tts_text?: string;
  work_order?: WorkOrderDetail;
  current_step?: WorkflowStep;
}

export interface NextStepRequest {
  session_id: string;
  query: string;
  feedback: string;
  user_id: number;
}

export interface NextStepResponse {
  type: 'next_step' | 'work_order_complete' | 'error';
  session_id?: string;
  message: string;
  tts_text?: string;
  current_step?: WorkflowStep;
  completed_step?: number;
  is_complete?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class WorkOrderService {
  private readonly apiUrl = environment.apiUrl;

  constructor(
    private readonly http: HttpClient,
    private readonly authService: AuthService,
    private readonly apiRequestManager: ApiRequestManagerService
  ) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'accept': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  async getAllWorkOrders(): Promise<WorkOrder[]> {
    try {
      const headers = this.getAuthHeaders();
      const response = await firstValueFrom(
        this.http.get<WorkOrderResponse[]>(`${this.apiUrl}/workorders/`, { headers })
      );

      // Transform API response to component format
      return response.map(order => this.transformWorkOrder(order));
    } catch (error) {
      console.error('Error fetching work orders:', error);
      throw error;
    }
  }

  private transformWorkOrder(apiOrder: WorkOrderResponse): WorkOrder {
    // Cast to any to access dynamic API properties
    const order = apiOrder as any;
    
    // Use actual steps from API if available, otherwise generate based on status
    let steps: { number: number; completed: boolean }[] = [];
    
    if (order.steps && Array.isArray(order.steps) && order.steps.length > 0) {
      // Use actual steps from API with their completion status
      steps = order.steps.map((step: any) => ({
        number: step.step_number,
        completed: step.is_completed || false,
        id: step.id,
        title: step.title,
        description: step.description
      }));
    } else if (order.total_steps) {
      // Fallback: Use total_steps and completed_steps to generate steps
      const totalSteps = order.total_steps || 0;
      const completedSteps = order.completed_steps || 0;
      
      for (let i = 1; i <= totalSteps; i++) {
        steps.push({
          number: i,
          completed: i <= completedSteps
        });
      }
    } else {
      // Last resort: Generate steps based on status
      steps = this.generateSteps(apiOrder.status);
    }
    
    // Use actual estimated hours from API if available
    const estimatedHours = order.estimated_hours 
      ? Number.parseFloat(order.estimated_hours) 
      : this.calculateEstimatedHours(apiOrder.priority);
    
    // Calculate due date (7 days from created_at for now)
    const dueDate = this.calculateDueDate(apiOrder.created_at);

    return {
      id: apiOrder.order_number,
      title: apiOrder.title,
      description: order.description || this.generateDescription(apiOrder.title, apiOrder.customer_name),
      status: this.normalizeStatus(apiOrder.status),
      priority: this.normalizePriority(apiOrder.priority),
      assignee: order.customer_name || apiOrder.technician_name || apiOrder.service_manager_name,
      vehicle: apiOrder.vehicle_info,
      estimatedHours,
      dueDate,
      steps
    };
  }

  private normalizeStatus(status: string): string {
    const statusMap: { [key: string]: string } = {
      'PENDING': 'Pending',
      'ASSIGNED': 'Assigned',
      'IN_PROGRESS': 'In Progress',
      'COMPLETED': 'Completed',
      'ON_HOLD': 'On Hold'
    };
    return statusMap[status] || status;
  }

  private normalizePriority(priority: string): string {
    const priorityMap: { [key: string]: string } = {
      'HIGH': 'High',
      'MEDIUM': 'Medium',
      'LOW': 'Low'
    };
    return priorityMap[priority] || priority;
  }

  private generateSteps(status: string): { number: number; completed: boolean }[] {
    const totalSteps = Math.floor(Math.random() * 3) + 3; // 3-6 steps
    const steps: { number: number; completed: boolean }[] = [];
    
    let completedSteps = 0;
    if (status === 'ASSIGNED') {
      completedSteps = 1;
    } else if (status === 'IN_PROGRESS') {
      completedSteps = Math.floor(totalSteps / 2);
    } else if (status === 'COMPLETED') {
      completedSteps = totalSteps;
    }

    for (let i = 1; i <= totalSteps; i++) {
      steps.push({
        number: i,
        completed: i <= completedSteps
      });
    }

    return steps;
  }

  private calculateEstimatedHours(priority: string): number {
    const hoursMap: { [key: string]: number } = {
      'HIGH': 3,
      'MEDIUM': 2.5,
      'LOW': 2
    };
    return hoursMap[priority] || 2;
  }

  private calculateDueDate(createdAt: string): string {
    const created = new Date(createdAt);
    const due = new Date(created);
    due.setDate(due.getDate() + 7); // 7 days from creation
    
    const month = String(due.getMonth() + 1).padStart(2, '0');
    const day = String(due.getDate()).padStart(2, '0');
    const year = due.getFullYear();
    
    return `${month}/${day}/${year}`;
  }

  private generateDescription(title: string, customerName: string): string {
    const descriptions: { [key: string]: string } = {
      'Oil Change': `Standard oil change service with filter replacement for ${customerName}. Inspect all fluid levels and tire pressure.`,
      'Brake': `Brake system inspection and service for ${customerName}. Check brake pads, rotors, and brake fluid condition.`,
      'Tire': `Tire service for ${customerName}. Rotation, balancing, and pressure check.`,
      'Inspection': `Comprehensive vehicle inspection for ${customerName}. Full diagnostic check of all systems.`,
      'Battery': `Battery testing and service for ${customerName}. Check charging system and connections.`,
      'Engine': `Engine diagnostic and repair for ${customerName}. Identify and resolve performance issues.`
    };

    for (const key in descriptions) {
      if (title.toLowerCase().includes(key.toLowerCase())) {
        return descriptions[key];
      }
    }

    return `Service work order for ${customerName}. ${title}`;
  }

  /**
   * Start work on a work order
   * Calls POST /api/agentic-rag/query/ to begin workflow and get first step
   * Now uses centralized API request manager for automatic deduplication
   */
  async startWork(workOrderNumber: string | number, userId: number): Promise<WorkOrderStartResponse> {
    try {
      console.log('[WorkOrderService] 🚀 startWork called:', { workOrderNumber, userId });

      // Convert numeric ID to order number format if needed
      const orderNumber = typeof workOrderNumber === 'number' ? `WO-${workOrderNumber}` : workOrderNumber;

      const payload: StartWorkRequest = {
        query: `help me fix ${orderNumber}`,
        user_id: userId,
        type: 'text'
      };

      // Use centralized API request manager - it handles deduplication automatically
      const response = await this.apiRequestManager.postPromise<WorkOrderStartResponse>(
        'agentic-rag/query/',
        payload
      );

      console.log('[WorkOrderService] ✅ startWork response received');

      // Store session ID for future feedback submissions
      if (response.session_id) {
        sessionStorage.setItem('current_session_id', response.session_id);
        sessionStorage.setItem('current_work_order', orderNumber);
      }

      return response;
    } catch (error) {
      console.error('[WorkOrderService] ❌ Error starting work:', error);
      throw error;
    }
  }

  /**
   * Proceed to next step in work order workflow
   * Calls POST /api/agentic-rag/query/ with session context to continue workflow
   * Now uses centralized API request manager for automatic deduplication
   */
  async nextStep(sessionId: string, userInput: string, userId: number): Promise<NextStepResponse> {
    try {
      console.log('[WorkOrderService] 🚀 nextStep called:', { sessionId, userInput });

      const payload: NextStepRequest = {
        session_id: sessionId,
        query: userInput,
        feedback: userInput,
        user_id: userId
      };

      // Use centralized API request manager - it handles deduplication automatically
      const response = await this.apiRequestManager.postPromise<NextStepResponse>(
        'agentic-rag/query/',
        payload
      );

      console.log('[WorkOrderService] ✅ nextStep response received');

      return response;
    } catch (error) {
      console.error('[WorkOrderService] ❌ Error proceeding to next step:', error);
      throw error;
    }
  }

  /**
   * Resume work order from the first incomplete step
   * Calls POST /api/workorders/{id}/resume/
   */
  async resumeWorkOrder(workOrderId: number | string): Promise<WorkOrderStartResponse> {
    try {
      const headers = this.getAuthHeaders();
      
      // Extract order number (e.g., "WO-20241008" -> "20241008" or 1 -> "1")
      const orderNumber = typeof workOrderId === 'string' 
        ? workOrderId.replace(/[^\d]/g, '') 
        : workOrderId.toString();
      
      const response = await firstValueFrom(
        this.http.post<any>(`${this.apiUrl}/workorders/WO-${orderNumber}/resume/`, {}, { headers })
      );

      // Transform response to match WorkOrderStartResponse format
      const transformedResponse: WorkOrderStartResponse = {
        type: 'work_order_start',
        session_id: response.session_id || `session_${Date.now()}`,
        message: response.message || `Resuming work order ${workOrderId}`,
        tts_text: response.tts_text || response.message,
        work_order: response.work_order ? {
          id: response.work_order.id,
          order_number: response.work_order.order_number,
          title: response.work_order.title,
          description: response.work_order.description,
          priority: response.work_order.priority,
          status: response.work_order.status,
          customer_name: response.work_order.customer_name || '',
          location: response.work_order.location || '',
          estimated_time: response.work_order.estimated_hours || 0,
          completed_steps: response.completed_steps || 0,
          total_steps: response.total_steps || 0
        } : undefined,
        current_step: response.current_step ? {
          id: response.current_step.id,
          step_number: response.current_step.step_number,
          description: response.current_step.description,
          estimated_time: response.current_step.estimated_time?.toString()
        } : undefined
      };

      // Store session ID
      if (transformedResponse.session_id) {
        sessionStorage.setItem('current_session_id', transformedResponse.session_id);
        sessionStorage.setItem('current_work_order', workOrderId.toString());
      }

      return transformedResponse;
    } catch (error) {
      console.error('Error resuming work order:', error);
      throw error;
    }
  }

  /**
   * Restart work order from the beginning (reset all progress)
   * Calls POST /api/workorders/{id}/restart/
   */
  async restartWorkOrder(workOrderId: number | string): Promise<WorkOrderStartResponse> {
    try {
      const headers = this.getAuthHeaders();
      
      // Extract order number (e.g., "WO-20241008" -> "20241008" or 1 -> "1")
      const orderNumber = typeof workOrderId === 'string' 
        ? workOrderId.replace(/[^\d]/g, '') 
        : workOrderId.toString();
      
      const response = await firstValueFrom(
        this.http.post<any>(`${this.apiUrl}/workorders/WO-${orderNumber}/restart/`, {}, { headers })
      );

      // Transform response to match WorkOrderStartResponse format
      const transformedResponse: WorkOrderStartResponse = {
        type: 'work_order_start',
        session_id: response.session_id || `session_${Date.now()}`,
        message: response.message || `Restarting work order ${workOrderId}`,
        tts_text: response.tts_text || response.message,
        work_order: response.work_order ? {
          id: response.work_order.id,
          order_number: response.work_order.order_number,
          title: response.work_order.title,
          description: response.work_order.description,
          priority: response.work_order.priority,
          status: response.work_order.status,
          customer_name: response.work_order.customer_name || '',
          location: response.work_order.location || '',
          estimated_time: response.work_order.estimated_hours || 0,
          completed_steps: response.completed_steps || 0,
          total_steps: response.total_steps || 0
        } : undefined,
        current_step: response.current_step ? {
          id: response.current_step.id,
          step_number: response.current_step.step_number,
          description: response.current_step.description,
          estimated_time: response.current_step.estimated_time?.toString()
        } : undefined
      };

      // Store session ID
      if (transformedResponse.session_id) {
        sessionStorage.setItem('current_session_id', transformedResponse.session_id);
        sessionStorage.setItem('current_work_order', workOrderId.toString());
      }

      return transformedResponse;
    } catch (error) {
      console.error('Error restarting work order:', error);
      throw error;
    }
  }
}
