# Agentic RAG API - Angular Integration Guide

## Overview

The **Agentic RAG API** provides intelligent query processing with automatic routing between SQL database queries and semantic vector search. It uses a multi-agent workflow to decompose complex questions, retrieve relevant information, and synthesize comprehensive answers.

**Key Features:**
- 🤖 **Automatic Routing** - Detects work order queries vs. technical questions
- 🧠 **Intelligent Planning** - Breaks complex questions into sub-questions
- 🔍 **Advanced Retrieval** - Uses MMR (Maximal Marginal Relevance) for diverse results
- ✅ **Quality Assessment** - Judges if retrieved information is sufficient
- 💬 **Conversation Memory** - Maintains context across multiple queries
- 📊 **Detailed Insights** - Returns retrieval details and quality metrics

---

## API Endpoint

### POST /api/agentic-rag/query/

**Base URL:** `http://localhost:8000/api/agentic-rag/query/`

---

## Request Format

### HTTP Headers
```http
Content-Type: application/json
```

### Request Body (JSON)

```json
{
  "query": "What are the steps to diagnose a faulty oxygen sensor?",
  "conversation_history": "",
  "thread_id": "1"
}
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | ✅ Yes | - | User's question or query |
| `conversation_history` | string | ❌ No | `""` | Previous conversation context |
| `thread_id` | string | ❌ No | `"1"` | Thread ID for maintaining conversation state |

### TypeScript Interface

```typescript
interface AgenticRagRequest {
  query: string;                    // User question
  conversation_history?: string;    // Optional previous context
  thread_id?: string;               // Optional thread ID (default: "1")
}
```

---

## Response Format

### Success Response (200 OK)

```json
{
  "success": true,
  "result": "To diagnose a faulty oxygen sensor:\n\n1. Check for error codes using an OBD-II scanner. Look for P0130-P0167 codes.\n2. Inspect the sensor wiring for damage or corrosion.\n3. Test the sensor voltage output (should be 0.1-0.9V).\n4. Check the sensor heater circuit resistance.\n\nSources: [id:42], [id:87]",
  "context": "[id:42] Oxygen sensor diagnostics guide: Use an OBD-II scanner to check for codes...\n\n[id:87] Sensor testing procedures: Measure voltage output between 0.1-0.9V...",
  "route": "vector_agent",
  "query": "What are the steps to diagnose a faulty oxygen sensor?",
  "per_sub": [
    {
      "subquery": "How to check oxygen sensor?",
      "rewritten": "oxygen sensor diagnostic steps",
      "retrieved": [
        {
          "id": 42,
          "content": "Oxygen sensor diagnostics guide: Use an OBD-II scanner...",
          "score": 0.87
        },
        {
          "id": 87,
          "content": "Sensor testing procedures: Measure voltage output...",
          "score": 0.82
        }
      ]
    }
  ],
  "judge": {
    "verdict": "OK",
    "note": "Retrieved context contains comprehensive diagnostic steps"
  }
}
```

### TypeScript Interfaces

```typescript
interface AgenticRagResponse {
  success: boolean;
  result: string;           // Final synthesized answer
  context: string;          // Retrieved context used for answer
  route: 'db_agent' | 'vector_agent' | 'unknown';
  query: string;            // Original query echoed back
  per_sub?: SubQueryResult[];  // Per-subquery retrieval details
  judge?: JudgeVerdict;        // Quality assessment
  error?: string;              // Error message (if success is false)
}

interface SubQueryResult {
  subquery: string;         // Original sub-question
  rewritten: string;        // LLM-rewritten query for retrieval
  retrieved: RetrievedDoc[];  // Documents retrieved for this subquery
}

interface RetrievedDoc {
  id: number;               // Document ID
  content: string;          // Document text content
  score: number;            // MMR relevance score
}

interface JudgeVerdict {
  verdict: 'OK' | 'NEEDS_MORE';
  note?: string;            // Additional notes
  reason?: string;          // Reason if NEEDS_MORE
}
```

---

## Workflow Explanation

### 1. Router Node
Analyzes the query to determine which agent to use:

**Work Order Queries → SQL Agent**
- Contains keywords: "work order", "WO-", "show me work order"
- Examples:
  - "Show me work order WO-12345"
  - "List all pending work orders"

**Technical Queries → Vector Agent (Agentic Workflow)**
- All other queries go through advanced RAG pipeline
- Examples:
  - "How do I replace brake pads?"
  - "What causes engine misfires?"

### 2. Agentic Workflow (Vector Agent Path)

```
┌─────────────────────────────────────────────────────────────────┐
│                      AGENTIC RAG WORKFLOW                        │
└─────────────────────────────────────────────────────────────────┘

1. PLANNER
   ├─ Analyzes query complexity
   ├─ Decomposes into 1-3 sub-questions if complex
   └─ Simple queries: [original query]
      Complex queries: [sub-q1, sub-q2, sub-q3]

2. EXECUTOR
   For each sub-question:
   ├─ Rewrite with LLM (optimize for retrieval)
   ├─ Embed using SentenceTransformer (all-MiniLM-L6-v2)
   └─ MMR Retrieve from pgvector
      ├─ Fetch top 50 candidates
      ├─ Apply MMR algorithm (balance relevance & diversity)
      └─ Return top 3 documents

3. JUDGE
   ├─ Evaluates if retrieved docs answer the questions
   ├─ Returns verdict: "OK" or "NEEDS_MORE"
   └─ Provides reasoning

4. SYNTHESIZER
   ├─ Combines retrieved context
   ├─ Generates final answer using LLM
   └─ Includes source citations [id:X]
```

---

## Angular Service Example

### Service Implementation

```typescript
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgenticRagService {
  private apiUrl = 'http://localhost:8000/api/agentic-rag';

  constructor(private http: HttpClient) {}

  /**
   * Query the Agentic RAG system
   */
  query(
    query: string, 
    conversationHistory: string = '', 
    threadId: string = '1'
  ): Observable<AgenticRagResponse> {
    const payload: AgenticRagRequest = {
      query,
      conversation_history: conversationHistory,
      thread_id: threadId
    };

    return this.http.post<AgenticRagResponse>(
      `${this.apiUrl}/query/`,
      payload
    );
  }

  /**
   * Check service health
   */
  healthCheck(): Observable<any> {
    return this.http.get(`${this.apiUrl}/health/`);
  }
}

// TypeScript Interfaces
interface AgenticRagRequest {
  query: string;
  conversation_history?: string;
  thread_id?: string;
}

interface AgenticRagResponse {
  success: boolean;
  result: string;
  context: string;
  route: 'db_agent' | 'vector_agent' | 'unknown';
  query: string;
  per_sub?: SubQueryResult[];
  judge?: JudgeVerdict;
  error?: string;
}

interface SubQueryResult {
  subquery: string;
  rewritten: string;
  retrieved: RetrievedDoc[];
}

interface RetrievedDoc {
  id: number;
  content: string;
  score: number;
}

interface JudgeVerdict {
  verdict: 'OK' | 'NEEDS_MORE';
  note?: string;
  reason?: string;
}
```

### Component Usage

```typescript
import { Component, OnInit } from '@angular/core';
import { AgenticRagService } from './services/agentic-rag.service';

@Component({
  selector: 'app-technical-assistant',
  templateUrl: './technical-assistant.component.html'
})
export class TechnicalAssistantComponent implements OnInit {
  query: string = '';
  result: string = '';
  loading: boolean = false;
  conversationHistory: string = '';
  threadId: string = 'user_session_' + Date.now();
  
  // Advanced details
  retrievalDetails: SubQueryResult[] = [];
  judgeVerdict: JudgeVerdict | null = null;
  usedRoute: string = '';

  constructor(private agenticRagService: AgenticRagService) {}

  ngOnInit() {
    this.checkHealth();
  }

  checkHealth() {
    this.agenticRagService.healthCheck()
      .subscribe({
        next: (health) => {
          console.log('Agentic RAG service health:', health);
        },
        error: (err) => {
          console.error('Service unavailable:', err);
        }
      });
  }

  onSubmitQuery() {
    if (!this.query.trim()) {
      return;
    }

    this.loading = true;
    
    this.agenticRagService.query(
      this.query, 
      this.conversationHistory, 
      this.threadId
    ).subscribe({
      next: (response) => {
        console.log('Query response:', response);
        
        if (response.success) {
          this.result = response.result;
          this.usedRoute = response.route;
          
          // Store retrieval details
          this.retrievalDetails = response.per_sub || [];
          this.judgeVerdict = response.judge || null;
          
          // Update conversation history
          this.updateConversationHistory(this.query, response.result);
          
          // Clear query input
          this.query = '';
        } else {
          this.result = `Error: ${response.error}`;
        }
        
        this.loading = false;
      },
      error: (error) => {
        console.error('Query failed:', error);
        this.result = 'Failed to process query. Please try again.';
        this.loading = false;
      }
    });
  }

  updateConversationHistory(userQuery: string, assistantResponse: string) {
    this.conversationHistory += `\nUser: ${userQuery}\nAssistant: ${assistantResponse}`;
  }

  clearConversation() {
    this.conversationHistory = '';
    this.result = '';
    this.retrievalDetails = [];
    this.judgeVerdict = null;
    // Generate new thread ID for new conversation
    this.threadId = 'user_session_' + Date.now();
  }
}
```

### Template Example

```html
<div class="agentic-rag-container">
  <h2>🤖 Technical Assistant (Agentic RAG)</h2>
  
  <!-- Query Input -->
  <div class="query-section">
    <textarea 
      [(ngModel)]="query" 
      placeholder="Ask a technical question..."
      rows="3"
      [disabled]="loading">
    </textarea>
    
    <div class="button-group">
      <button 
        (click)="onSubmitQuery()" 
        [disabled]="loading || !query.trim()">
        {{ loading ? 'Processing...' : 'Ask Question' }}
      </button>
      
      <button 
        (click)="clearConversation()" 
        [disabled]="loading">
        Clear Conversation
      </button>
    </div>
  </div>

  <!-- Loading Indicator -->
  <div *ngIf="loading" class="loading">
    <div class="spinner"></div>
    <p>Analyzing query and retrieving information...</p>
  </div>

  <!-- Result Display -->
  <div *ngIf="result && !loading" class="result-section">
    <div class="result-header">
      <h3>Answer</h3>
      <span class="route-badge" [class]="usedRoute">
        {{ usedRoute === 'db_agent' ? '🗄️ SQL' : '🔍 Vector Search' }}
      </span>
    </div>
    
    <div class="result-content" [innerHTML]="result | markdown"></div>
    
    <!-- Quality Assessment -->
    <div *ngIf="judgeVerdict" class="judge-section">
      <h4>Quality Assessment</h4>
      <div class="verdict" [class.success]="judgeVerdict.verdict === 'OK'">
        <strong>Verdict:</strong> {{ judgeVerdict.verdict }}
      </div>
      <p *ngIf="judgeVerdict.note">{{ judgeVerdict.note }}</p>
      <p *ngIf="judgeVerdict.reason" class="reason">{{ judgeVerdict.reason }}</p>
    </div>
    
    <!-- Retrieval Details (Expandable) -->
    <details *ngIf="retrievalDetails.length > 0" class="retrieval-details">
      <summary>🔎 View Retrieval Details ({{ retrievalDetails.length }} sub-queries)</summary>
      
      <div *ngFor="let subResult of retrievalDetails; let i = index" class="sub-result">
        <h5>Sub-query {{ i + 1 }}</h5>
        <p><strong>Original:</strong> {{ subResult.subquery }}</p>
        <p><strong>Rewritten:</strong> {{ subResult.rewritten }}</p>
        
        <div class="retrieved-docs">
          <h6>Retrieved Documents ({{ subResult.retrieved.length }})</h6>
          <div *ngFor="let doc of subResult.retrieved" class="doc-card">
            <div class="doc-header">
              <span class="doc-id">ID: {{ doc.id }}</span>
              <span class="doc-score">Score: {{ doc.score.toFixed(3) }}</span>
            </div>
            <p class="doc-content">{{ doc.content.substring(0, 200) }}...</p>
          </div>
        </div>
      </div>
    </details>
  </div>
</div>
```

---

## Use Cases

### 1. Technical Documentation Queries
```typescript
// Ask about diagnostic procedures
this.agenticRagService.query(
  "How do I diagnose a P0420 error code?"
).subscribe(response => {
  console.log(response.result);
  // Returns: Step-by-step diagnostic procedure with source citations
});
```

### 2. Work Order Queries
```typescript
// Query database for work orders
this.agenticRagService.query(
  "Show me all pending work orders for Building A"
).subscribe(response => {
  console.log(response.route); // "db_agent"
  console.log(response.result); // SQL query results formatted as text
});
```

### 3. Complex Multi-Part Questions
```typescript
// Agentic workflow automatically decomposes
this.agenticRagService.query(
  "What causes engine misfires and how do I diagnose them?"
).subscribe(response => {
  console.log(response.per_sub);
  // Shows breakdown:
  // - Subquery 1: "What causes engine misfires?"
  // - Subquery 2: "How to diagnose engine misfires?"
  
  console.log(response.result);
  // Synthesized answer combining both sub-queries
});
```

### 4. Conversational Context
```typescript
// First query
this.agenticRagService.query(
  "Tell me about brake maintenance",
  "",
  "conversation_1"
).subscribe(response1 => {
  // Second query with context
  this.agenticRagService.query(
    "How often should I do that?",
    `User: Tell me about brake maintenance\nAssistant: ${response1.result}`,
    "conversation_1"
  ).subscribe(response2 => {
    // System remembers "that" refers to brake maintenance
    console.log(response2.result);
  });
});
```

---

## Error Handling

### Error Response Types

#### 400 Bad Request
```json
{
  "error": "Missing required field: query"
}
```

#### 500 Internal Server Error
```json
{
  "success": false,
  "error": "Error processing query: Database connection failed",
  "result": "⚠️ Error processing query: Database connection failed",
  "query": "What are the steps to diagnose a faulty oxygen sensor?"
}
```

### Angular Error Handling

```typescript
this.agenticRagService.query(query).subscribe({
  next: (response) => {
    if (!response.success) {
      // Server returned error in response
      this.showError(`Query failed: ${response.error}`);
      return;
    }
    
    // Success - process result
    this.displayResult(response.result);
  },
  error: (httpError) => {
    // HTTP error (network, 4xx, 5xx)
    console.error('HTTP Error:', httpError);
    
    if (httpError.status === 400) {
      this.showError('Invalid query. Please check your input.');
    } else if (httpError.status === 500) {
      this.showError('Server error. Please try again later.');
    } else {
      this.showError('Network error. Please check your connection.');
    }
  }
});
```

---

## Health Check Endpoint

### GET /api/agentic-rag/health/

Check if the service is operational and all dependencies are available.

**Response:**
```json
{
  "status": "healthy",
  "message": "Agentic RAG service is operational",
  "services": {
    "database": "connected",
    "openai": "available",
    "embeddings": "loaded"
  }
}
```

**Angular Usage:**
```typescript
ngOnInit() {
  this.agenticRagService.healthCheck().subscribe({
    next: (health) => {
      if (health.status !== 'healthy') {
        console.warn('Service degraded:', health);
        this.showWarning('Some features may not be available');
      }
    },
    error: (err) => {
      console.error('Service unavailable:', err);
      this.showError('Technical assistant is currently unavailable');
    }
  });
}
```

---

## Testing with cURL

### Basic Query
```bash
curl -X POST http://localhost:8000/api/agentic-rag/query/ \
  -H "Content-Type: application/json" \
  -d '{
    "query": "How do I replace brake pads?"
  }'
```

### Query with Conversation History
```bash
curl -X POST http://localhost:8000/api/agentic-rag/query/ \
  -H "Content-Type: application/json" \
  -d '{
    "query": "How often should I do that?",
    "conversation_history": "User: Tell me about brake maintenance\nAssistant: Brake pads should be inspected...",
    "thread_id": "session_123"
  }'
```

### Health Check
```bash
curl http://localhost:8000/api/agentic-rag/health/
```

---

## Swagger/OpenAPI Documentation

The API is fully documented in Swagger UI:

**URL:** http://localhost:8000/api/docs/

1. Navigate to **Agentic RAG** section
2. Click **POST /api/agentic-rag/query/**
3. Click "Try it out"
4. Enter request body
5. Click "Execute"

---

## Performance Considerations

### Response Times
- **Simple queries:** 2-4 seconds
- **Complex queries (agentic):** 5-10 seconds
- **SQL queries:** 1-3 seconds

### Best Practices

1. **Use Thread IDs** - Maintain conversation context with consistent `thread_id`
2. **Debounce Queries** - Avoid rapid-fire requests (use 500ms debounce)
3. **Show Loading State** - Always display loading indicator during processing
4. **Handle Errors Gracefully** - Implement retry logic for network errors
5. **Cache Results** - Consider caching common queries client-side

```typescript
// Example: Debounced query input
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

queryInput$ = new Subject<string>();

ngOnInit() {
  this.queryInput$.pipe(
    debounceTime(500),
    distinctUntilChanged()
  ).subscribe(query => {
    if (query.trim()) {
      this.submitQuery(query);
    }
  });
}

onQueryChange(value: string) {
  this.queryInput$.next(value);
}
```

---

## Comparison with Other Endpoints

| Feature | Agentic RAG | Chat Query (/api/chat/query/) |
|---------|-------------|-------------------------------|
| **Purpose** | Technical documentation | Work order workflows |
| **Intelligence** | Multi-agent decomposition | Single-agent response |
| **Routing** | Automatic (SQL/Vector) | Manual query parsing |
| **Retrieval** | MMR (diverse results) | Simple vector search |
| **Quality Check** | Judge verdict included | No assessment |
| **Use Case** | General Q&A, complex questions | Work order step-by-step |

**When to use Agentic RAG:**
- ✅ General technical questions
- ✅ Complex multi-part queries
- ✅ Exploratory research
- ✅ Need quality assessment

**When to use Chat Query:**
- ✅ Work order workflows
- ✅ Step-by-step guidance
- ✅ Feedback collection
- ✅ Session management

---

## Summary for Angular Developer

**What you get:**

1. **Single Endpoint** - One API call handles all query types
2. **Automatic Routing** - System decides SQL vs. Vector search
3. **Intelligent Processing** - Complex questions automatically decomposed
4. **Quality Metrics** - Judge verdict tells you if answer is reliable
5. **Detailed Insights** - See exactly what was retrieved and how
6. **Conversation Memory** - Maintain context with thread_id

**Minimal Implementation:**

```typescript
// 1. Create service
this.agenticRagService.query("How do I replace brake pads?")
  .subscribe(response => {
    this.result = response.result;  // Display answer
  });

// 2. That's it! The system handles:
//    - Query analysis
//    - Retrieval strategy
//    - Context aggregation
//    - Answer synthesis
```

---

## Related Documentation

- `API_DOCUMENTATION_FOR_ANGULAR.md` - Complete API reference for all endpoints
- `START_WORK_BUTTON_API_INTEGRATION.md` - Work order workflow integration
- `SWAGGER_QUICK_START.md` - Interactive API testing guide
- Original Streamlit implementation: `streamlit_vc_0811_thread_v1_agentic.py`
