import sounddevice as sd
import queue, json, struct
from vosk import Model, KaldiRecognizer

MODEL_PATH = "vosk-model-small-en-us-0.15"

print("✅ Loading model...")
model = Model(MODEL_PATH)
recognizer = KaldiRecognizer(model, 16000)

audio_q = queue.Queue()

def audio_callback(indata, frames, time, status):
    audio_q.put(bytes(indata))

print("🎧 Start speaking… Say: 'hey buddy'")

with sd.RawInputStream(
    channels=1,
    callback=audio_callback,
    samplerate=16000,
    blocksize=8000,
    dtype='int16'
):
    while True:
        data = audio_q.get()
        if recognizer.AcceptWaveform(data):
            text = json.loads(recognizer.Result())["text"]
            if text.strip():
                print("🗣 Heard:", text)
                if "hey buddy" in text.lower():
                    print("✅ Wake word detected: HEY BUDDY")