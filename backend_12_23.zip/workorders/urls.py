from django.urls import path, register_converter
from . import views
from .converters import OrderNumberConverter

# Register custom converter
register_converter(OrderNumberConverter, 'order_num')

app_name = 'workorders'

urlpatterns = [
    # Customer URLs
    path('customers/', views.CustomerListCreateView.as_view(), name='customer-list'),
    path('customers/<int:pk>/', views.CustomerDetailView.as_view(), name='customer-detail'),
    
    # Vehicle URLs
    path('vehicles/', views.VehicleListCreateView.as_view(), name='vehicle-list'),
    path('vehicles/<int:pk>/', views.VehicleDetailView.as_view(), name='vehicle-detail'),
    
    # Work Order URLs
    path('workorders/', views.WorkOrderListCreateView.as_view(), name='workorder-list'),
    
    # Work Order Actions by Order Number (e.g., WO-001, 20241009) - MUST come before <int:pk> routes
    path('workorders/<order_num:order_number>/start/', views.start_work_order_by_number, name='workorder-start-by-number'),
    path('workorders/<order_num:order_number>/resume/', views.resume_work_order_by_number, name='workorder-resume-by-number'),
    path('workorders/<order_num:order_number>/restart/', views.restart_work_order_by_number, name='workorder-restart-by-number'),
    
    # Work Order URLs by ID (integer primary key)
    path('workorders/<int:pk>/', views.WorkOrderDetailView.as_view(), name='workorder-detail'),
    path('workorders/<int:pk>/assign/', views.assign_technician, name='workorder-assign'),
    path('workorders/<int:pk>/start/', views.start_work_order, name='workorder-start'),
    path('workorders/<int:pk>/resume/', views.resume_work_order, name='workorder-resume'),
    path('workorders/<int:pk>/restart/', views.restart_work_order, name='workorder-restart'),
    path('workorders/<int:pk>/complete/', views.complete_work_order, name='workorder-complete'),
    
    # Work Order Steps URLs
    path('workorders/<int:work_order_id>/steps/', views.WorkOrderStepListCreateView.as_view(), name='workorder-steps'),
    path('workorders/<int:work_order_id>/steps/<int:pk>/', views.WorkOrderStepDetailView.as_view(), name='workorder-step-detail'),
    
    # Work Order Feedback URLs
    path('workorders/<int:work_order_id>/feedback/', views.WorkOrderFeedbackListCreateView.as_view(), name='workorder-feedback'),
    
    # Work Order Summary URLs
    path('workorders/<int:work_order_id>/summary/', views.WorkOrderSummaryView.as_view(), name='workorder-summary'),
    
    # Voice Command Handler
    path('voice-command/', views.voice_command_handler, name='voice-command'),

    # LLM Question Generation
    path('generate-question/', views.generate_question_from_workorder, name='generate-question'),

    # RAG-based Step Generation
    path('generate-steps-rag/', views.generate_steps_with_rag, name='generate-steps-rag'),
]