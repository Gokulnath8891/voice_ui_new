from rest_framework import generics, status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.contrib.auth.models import User
import os
import re
from openai import AzureOpenAI
import json

from .models import (
    Customer, Vehicle, WorkOrder, WorkOrderStep, 
    WorkOrderFeedback, WorkOrderSummary
)
from .serializers import (
    CustomerSerializer, VehicleSerializer, WorkOrderSerializer, 
    WorkOrderListSerializer, WorkOrderStepSerializer, 
    WorkOrderFeedbackSerializer, WorkOrderSummarySerializer
)
from .permissions import (
    IsServiceManager, IsTechnician, IsServiceManagerOrReadOnlyTechnician,
    CanViewOwnWorkOrders, CanSubmitFeedback
)


class CustomerListCreateView(generics.ListCreateAPIView):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    permission_classes = [IsServiceManager]


class CustomerDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    permission_classes = [IsServiceManager]


class VehicleListCreateView(generics.ListCreateAPIView):
    serializer_class = VehicleSerializer
    permission_classes = [IsServiceManager]
    
    def get_queryset(self):
        customer_id = self.request.query_params.get('customer_id')
        if customer_id:
            return Vehicle.objects.filter(customer_id=customer_id)
        return Vehicle.objects.all()


class VehicleDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Vehicle.objects.all()
    serializer_class = VehicleSerializer
    permission_classes = [IsServiceManager]


class WorkOrderListCreateView(generics.ListCreateAPIView):
    permission_classes = [IsServiceManagerOrReadOnlyTechnician]
    
    def get_serializer_class(self):
        if self.request.method == 'GET':
            return WorkOrderListSerializer
        return WorkOrderSerializer
    
    def get_queryset(self):
        user = self.request.user
        
        # Base queryset with prefetch for steps to avoid N+1 queries
        base_queryset = WorkOrder.objects.select_related(
            'customer', 'vehicle', 'service_manager', 'technician'
        ).prefetch_related('steps').order_by('-created_at')
        
        # Service managers see all work orders
        if user.groups.filter(name='Service Manager').exists():
            return base_queryset
        
        # Technicians see only their assigned work orders
        elif user.groups.filter(name='Technician').exists():
            return base_queryset.filter(technician=user)
        
        return WorkOrder.objects.none()


class WorkOrderDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = WorkOrderSerializer
    permission_classes = [permissions.IsAuthenticated, CanViewOwnWorkOrders]
    
    def get_queryset(self):
        return WorkOrder.objects.select_related(
            'customer', 'vehicle', 'service_manager', 'technician'
        ).prefetch_related('steps', 'feedback', 'summary')


@api_view(['PATCH'])
@permission_classes([IsServiceManager])
def assign_technician(request, pk):
    work_order = get_object_or_404(WorkOrder, pk=pk)
    technician_id = request.data.get('technician_id')
    
    if not technician_id:
        return Response({'error': 'technician_id is required'}, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        technician = User.objects.get(id=technician_id, groups__name='Technician')
    except User.DoesNotExist:
        return Response({'error': 'Invalid technician ID'}, status=status.HTTP_400_BAD_REQUEST)
    
    work_order.technician = technician
    work_order.status = 'ASSIGNED'
    work_order.assigned_at = timezone.now()
    work_order.save()
    
    serializer = WorkOrderSerializer(work_order)
    return Response(serializer.data)


class WorkOrderStepListCreateView(generics.ListCreateAPIView):
    serializer_class = WorkOrderStepSerializer
    permission_classes = [IsServiceManager]
    
    def get_queryset(self):
        work_order_id = self.kwargs['work_order_id']
        return WorkOrderStep.objects.filter(work_order_id=work_order_id)
    
    def perform_create(self, serializer):
        work_order_id = self.kwargs['work_order_id']
        work_order = get_object_or_404(WorkOrder, id=work_order_id)
        serializer.save(work_order=work_order)


class WorkOrderStepDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = WorkOrderStepSerializer
    permission_classes = [IsServiceManager]
    
    def get_queryset(self):
        work_order_id = self.kwargs['work_order_id']
        return WorkOrderStep.objects.filter(work_order_id=work_order_id)


class WorkOrderFeedbackListCreateView(generics.ListCreateAPIView):
    serializer_class = WorkOrderFeedbackSerializer
    
    def get_permissions(self):
        if self.request.method == 'POST':
            return [CanSubmitFeedback()]
        return [permissions.IsAuthenticated(), CanViewOwnWorkOrders()]
    
    def get_queryset(self):
        work_order_id = self.kwargs['work_order_id']
        return WorkOrderFeedback.objects.filter(work_order_id=work_order_id)
    
    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['work_order_id'] = self.kwargs['work_order_id']
        return context
    
    def create(self, request, *args, **kwargs):
        """Create feedback and return next step information"""
        # Create the feedback
        response = super().create(request, *args, **kwargs)
        
        # Get work order and step details
        work_order_id = self.kwargs['work_order_id']
        work_order = WorkOrder.objects.get(pk=work_order_id)
        step_id = request.data.get('step_id')
        
        # Mark step as completed
        if step_id:
            step = WorkOrderStep.objects.filter(id=step_id, work_order=work_order).first()
            if step and not step.is_completed:
                step.is_completed = True
                step.completed_at = timezone.now()
                step.save()
                
                # Check for next step
                next_step = work_order.steps.filter(
                    step_number=step.step_number + 1
                ).first()
                
                # Check if all steps are complete
                total_steps = work_order.steps.count()
                completed_steps = work_order.steps.filter(is_completed=True).count()
                
                if completed_steps >= total_steps:
                    # All steps complete
                    work_order.status = 'COMPLETED'
                    work_order.completed_at = timezone.now()
                    work_order.save()
                    
                    # Generate work order summary
                    generate_work_order_summary(work_order)
                    
                    # Get the summary
                    try:
                        summary = WorkOrderSummary.objects.get(work_order=work_order)
                        summary_data = WorkOrderSummarySerializer(summary).data
                    except WorkOrderSummary.DoesNotExist:
                        summary_data = None
                    
                    # Calculate time metrics
                    feedback_items = WorkOrderFeedback.objects.filter(work_order=work_order)
                    total_time = sum(float(item.time_spent) for item in feedback_items if item.time_spent)
                    estimated_time = sum(float(step.estimated_time) for step in work_order.steps.all() if step.estimated_time)
                    time_variance = total_time - estimated_time
                    
                    response.data['type'] = 'work_order_complete'
                    response.data['message'] = f'Congratulations! All {total_steps} steps completed for work order {work_order.order_number}'
                    response.data['work_order_status'] = 'COMPLETED'
                    response.data['total_steps'] = total_steps
                    response.data['completed_steps'] = completed_steps
                    response.data['total_time'] = round(total_time, 2)
                    response.data['estimated_time'] = round(estimated_time, 2)
                    response.data['time_variance'] = round(time_variance, 2)
                    response.data['summary'] = summary_data
                elif next_step:
                    # Return next step info
                    response.data['type'] = 'next_step'
                    response.data['message'] = f'Step {step.step_number} completed. Moving to step {next_step.step_number}'
                    response.data['next_step'] = {
                        'id': next_step.id,
                        'step_number': next_step.step_number,
                        'title': next_step.title,
                        'description': next_step.description,
                        'estimated_time': str(next_step.estimated_time)
                    }
                    response.data['completed_steps'] = completed_steps
                    response.data['total_steps'] = total_steps
                else:
                    # Last step but something went wrong
                    response.data['type'] = 'step_complete'
                    response.data['message'] = f'Step {step.step_number} completed'
                    response.data['completed_steps'] = completed_steps
                    response.data['total_steps'] = total_steps
        
        return response


@api_view(['POST'])
@permission_classes([IsTechnician])
def start_work_order(request, pk):
    """Start a work order from the beginning (Step 1)"""
    # Get work order without technician restriction
    work_order = get_object_or_404(WorkOrder, pk=pk)
    
    # Check if work order has a technician assigned
    if not work_order.technician:
        return Response({
            'error': 'Work order must be assigned to a technician first'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    if work_order.status != 'ASSIGNED':
        return Response({'error': 'Work order must be assigned to start'}, status=status.HTTP_400_BAD_REQUEST)
    
    work_order.status = 'IN_PROGRESS'
    work_order.started_at = timezone.now()
    work_order.save()
    
    # Get the first step
    first_step = work_order.steps.filter(step_number=1).first()
    
    response_data = {
        'work_order': WorkOrderSerializer(work_order).data,
        'current_step': WorkOrderStepSerializer(first_step).data if first_step else None,
        'message': f'Started work order {work_order.order_number}',
        'total_steps': work_order.steps.count(),
        'completed_steps': work_order.steps.filter(is_completed=True).count()
    }
    
    return Response(response_data)


@api_view(['POST'])
@permission_classes([IsTechnician])
def resume_work_order(request, pk):
    """Resume a work order from the first incomplete step"""
    # Get work order without technician restriction
    work_order = get_object_or_404(WorkOrder, pk=pk)
    
    # Check if work order has a technician assigned
    if not work_order.technician:
        return Response({
            'error': 'Work order must be assigned to a technician first'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Allow resuming from any status except COMPLETED
    if work_order.status == 'COMPLETED':
        return Response({
            'error': 'Cannot resume a completed work order. Use restart instead.'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Update status to IN_PROGRESS if it was PENDING or ASSIGNED
    if work_order.status in ['PENDING', 'ASSIGNED']:
        work_order.status = 'IN_PROGRESS'
        work_order.started_at = timezone.now()
        work_order.save()
    
    # Find first incomplete step
    current_step = work_order.steps.filter(is_completed=False).order_by('step_number').first()
    
    if not current_step:
        return Response({
            'error': 'All steps are already completed',
            'work_order': WorkOrderSerializer(work_order).data
        }, status=status.HTTP_400_BAD_REQUEST)
    
    total_steps = work_order.steps.count()
    completed_steps = work_order.steps.filter(is_completed=True).count()
    progress_percentage = (completed_steps / total_steps * 100) if total_steps > 0 else 0
    
    response_data = {
        'work_order': WorkOrderSerializer(work_order).data,
        'current_step': WorkOrderStepSerializer(current_step).data,
        'message': f'Resuming work order {work_order.order_number} from step {current_step.step_number}',
        'total_steps': total_steps,
        'completed_steps': completed_steps,
        'progress_percentage': round(progress_percentage, 1),
        'remaining_steps': total_steps - completed_steps
    }
    
    return Response(response_data)


@api_view(['POST'])
@permission_classes([IsTechnician])
def restart_work_order(request, pk):
    """Restart a work order from scratch (reset all progress)"""
    # Get work order without technician restriction
    work_order = get_object_or_404(WorkOrder, pk=pk)
    
    # Check if work order has a technician assigned
    if not work_order.technician:
        return Response({
            'error': 'Work order must be assigned to a technician first'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Only allow restarting IN_PROGRESS or COMPLETED work orders
    if work_order.status not in ['IN_PROGRESS', 'COMPLETED']:
        return Response({
            'error': f'Cannot restart work order with status {work_order.status}'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Reset all steps to incomplete
    work_order.steps.all().update(is_completed=False, completed_at=None)
    
    # Clear all feedback
    WorkOrderFeedback.objects.filter(work_order=work_order).delete()
    
    # Reset work order status
    work_order.status = 'IN_PROGRESS'
    work_order.started_at = timezone.now()
    work_order.completed_at = None
    work_order.actual_hours = None
    work_order.save()
    
    # Delete summary if exists
    WorkOrderSummary.objects.filter(work_order=work_order).delete()
    
    # Get first step
    first_step = work_order.steps.filter(step_number=1).first()
    
    response_data = {
        'work_order': WorkOrderSerializer(work_order).data,
        'current_step': WorkOrderStepSerializer(first_step).data if first_step else None,
        'message': f'Work order {work_order.order_number} has been restarted from the beginning',
        'total_steps': work_order.steps.count(),
        'completed_steps': 0,
        'progress_percentage': 0
    }
    
    return Response(response_data)


@api_view(['POST'])
@permission_classes([IsTechnician])
def start_work_order_by_number(request, order_number):
    """Start a work order by order number from the beginning (Step 1)"""
    work_order = get_object_or_404(WorkOrder, order_number=order_number)
    
    # Check if work order has a technician assigned
    if not work_order.technician:
        return Response({
            'error': 'Work order must be assigned to a technician first'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    if work_order.status != 'ASSIGNED':
        return Response({'error': 'Work order must be assigned to start'}, status=status.HTTP_400_BAD_REQUEST)
    
    work_order.status = 'IN_PROGRESS'
    work_order.started_at = timezone.now()
    work_order.save()
    
    # Get the first step
    first_step = work_order.steps.filter(step_number=1).first()
    
    response_data = {
        'work_order': WorkOrderSerializer(work_order).data,
        'current_step': WorkOrderStepSerializer(first_step).data if first_step else None,
        'message': f'Started work order {work_order.order_number}',
        'total_steps': work_order.steps.count(),
        'completed_steps': work_order.steps.filter(is_completed=True).count()
    }
    
    return Response(response_data)


@api_view(['POST'])
@permission_classes([IsTechnician])
def resume_work_order_by_number(request, order_number):
    """Resume a work order by order number from the first incomplete step"""
    work_order = get_object_or_404(WorkOrder, order_number=order_number)
    
    # Check if work order has a technician assigned
    if not work_order.technician:
        return Response({
            'error': 'Work order must be assigned to a technician first'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Allow resuming from any status except COMPLETED
    if work_order.status == 'COMPLETED':
        return Response({
            'error': 'Cannot resume a completed work order. Use restart instead.'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Update status to IN_PROGRESS if it was PENDING or ASSIGNED
    if work_order.status in ['PENDING', 'ASSIGNED']:
        work_order.status = 'IN_PROGRESS'
        work_order.started_at = timezone.now()
        work_order.save()
    
    # Find first incomplete step
    current_step = work_order.steps.filter(is_completed=False).order_by('step_number').first()
    
    if not current_step:
        return Response({
            'error': 'All steps are already completed',
            'work_order': WorkOrderSerializer(work_order).data
        }, status=status.HTTP_400_BAD_REQUEST)
    
    total_steps = work_order.steps.count()
    completed_steps = work_order.steps.filter(is_completed=True).count()
    progress_percentage = (completed_steps / total_steps * 100) if total_steps > 0 else 0
    
    response_data = {
        'work_order': WorkOrderSerializer(work_order).data,
        'current_step': WorkOrderStepSerializer(current_step).data,
        'message': f'Resuming work order {work_order.order_number} from step {current_step.step_number}',
        'total_steps': total_steps,
        'completed_steps': completed_steps,
        'progress_percentage': round(progress_percentage, 1),
        'remaining_steps': total_steps - completed_steps
    }
    
    return Response(response_data)


@api_view(['POST'])
@permission_classes([IsTechnician])
def restart_work_order_by_number(request, order_number):
    """Restart a work order by order number from scratch (reset all progress)"""
    work_order = get_object_or_404(WorkOrder, order_number=order_number)
    
    # Check if work order has a technician assigned
    if not work_order.technician:
        return Response({
            'error': 'Work order must be assigned to a technician first'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Only allow restarting IN_PROGRESS or COMPLETED work orders
    if work_order.status not in ['IN_PROGRESS', 'COMPLETED']:
        return Response({
            'error': f'Cannot restart work order with status {work_order.status}'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Reset all steps to incomplete
    work_order.steps.all().update(is_completed=False, completed_at=None)
    
    # Clear all feedback
    WorkOrderFeedback.objects.filter(work_order=work_order).delete()
    
    # Reset work order status
    work_order.status = 'IN_PROGRESS'
    work_order.started_at = timezone.now()
    work_order.completed_at = None
    work_order.actual_hours = None
    work_order.save()
    
    # Delete summary if exists
    WorkOrderSummary.objects.filter(work_order=work_order).delete()
    
    # Get first step
    first_step = work_order.steps.filter(step_number=1).first()
    
    response_data = {
        'work_order': WorkOrderSerializer(work_order).data,
        'current_step': WorkOrderStepSerializer(first_step).data if first_step else None,
        'message': f'Work order {work_order.order_number} has been restarted from the beginning',
        'total_steps': work_order.steps.count(),
        'completed_steps': 0,
        'progress_percentage': 0
    }
    
    return Response(response_data)


@api_view(['POST'])
@permission_classes([IsTechnician])
def complete_work_order(request, pk):
    work_order = get_object_or_404(WorkOrder, pk=pk, technician=request.user)
    
    if work_order.status != 'IN_PROGRESS':
        return Response({'error': 'Work order must be in progress to complete'}, status=status.HTTP_400_BAD_REQUEST)
    
    work_order.status = 'COMPLETED'
    work_order.completed_at = timezone.now()
    work_order.save()
    
    # Generate summary
    generate_work_order_summary(work_order)
    
    serializer = WorkOrderSerializer(work_order)
    return Response(serializer.data)


def generate_work_order_summary(work_order):
    feedback_items = WorkOrderFeedback.objects.filter(work_order=work_order)
    total_time = sum(item.time_spent for item in feedback_items)
    total_steps = work_order.steps.filter(is_completed=True).count()
    
    # Generate summary text
    summary_text = f"Work order {work_order.order_number} completed for {work_order.vehicle}. "
    summary_text += f"Total time spent: {total_time} hours across {total_steps} completed steps. "
    
    if feedback_items:
        issues = [item.issues_encountered for item in feedback_items if item.issues_encountered]
        if issues:
            summary_text += f"Issues resolved: {'; '.join(issues)}. "
    
    # Create or update summary
    summary, created = WorkOrderSummary.objects.get_or_create(
        work_order=work_order,
        defaults={
            'summary_text': summary_text,
            'total_time_spent': total_time,
            'total_steps_completed': total_steps,
        }
    )
    
    if not created:
        summary.summary_text = summary_text
        summary.total_time_spent = total_time
        summary.total_steps_completed = total_steps
        summary.save()


class WorkOrderSummaryView(generics.RetrieveAPIView):
    serializer_class = WorkOrderSummarySerializer
    permission_classes = [permissions.IsAuthenticated, CanViewOwnWorkOrders]
    
    def get_object(self):
        work_order_id = self.kwargs['work_order_id']
        work_order = get_object_or_404(WorkOrder, id=work_order_id)
        
        # Check permissions
        self.check_object_permissions(self.request, work_order)
        
        return get_object_or_404(WorkOrderSummary, work_order=work_order)


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def voice_command_handler(request):
    """
    Handle voice commands like 'Hey buddy, get WO-12345678'
    
    Expected payload:
    {
        "command": "Hey buddy, get WO-12345678"
    }
    
    Response:
    {
        "success": true,
        "work_order": { ... },
        "generated_steps": [ ... ],
        "message": "Successfully fetched work order and generated steps"
    }
    """
    command = request.data.get('command', '').strip().lower()
    
    if not command:
        return Response(
            {'error': 'Command is required'}, 
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Extract work order ID from command
    work_order_id = extract_work_order_id(command)
    
    if not work_order_id:
        return Response(
            {'error': 'No valid work order ID found in command. Format: "Hey buddy, get WO-XXXXXXXX"'}, 
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Find the work order
    try:
        work_order = WorkOrder.objects.get(order_number=work_order_id)
    except WorkOrder.DoesNotExist:
        return Response(
            {'error': f'Work order {work_order_id} not found'}, 
            status=status.HTTP_404_NOT_FOUND
        )
    
    # Check if user has permission to view this work order
    user = request.user
    if not can_user_view_work_order(user, work_order):
        return Response(
            {'error': 'You do not have permission to view this work order'}, 
            status=status.HTTP_403_FORBIDDEN
        )
    
    # Generate steps using LLM if not already present
    existing_steps = work_order.steps.all()
    
    if not existing_steps:
        # Generate steps using LLM
        generated_steps = generate_work_order_steps(work_order)
        
        if generated_steps:
            # Save generated steps to database
            for i, step_data in enumerate(generated_steps, 1):
                WorkOrderStep.objects.create(
                    work_order=work_order,
                    step_number=i,
                    title=step_data['title'],
                    description=step_data['description'],
                    estimated_time=step_data.get('estimated_time', 0.5)
                )
            
            # Refresh steps from database
            existing_steps = work_order.steps.all()
    
    # Serialize work order data
    work_order_data = WorkOrderSerializer(work_order).data
    steps_data = WorkOrderStepSerializer(existing_steps, many=True).data
    
    return Response({
        'success': True,
        'work_order': work_order_data,
        'steps': steps_data,
        'message': f'Successfully fetched work order {work_order_id} and generated {len(existing_steps)} steps'
    })


def extract_work_order_id(command):
    """Extract work order ID from voice command"""
    # Patterns to match work order IDs
    patterns = [
        r'wo[- ]([a-f0-9]{8})',  # WO-12345678 or wo 12345678
        r'work order[- ]([a-f0-9]{8})',  # work order 12345678
        r'([a-f0-9]{8})',  # Just the 8-character hex
        r'w\.o\.?[- ]([a-f0-9]{8})',  # W.O. 12345678
    ]
    
    for pattern in patterns:
        match = re.search(pattern, command, re.IGNORECASE)
        if match:
            wo_id = match.group(1).upper()
            return f"WO-{wo_id}"
    
    return None


def can_user_view_work_order(user, work_order):
    """Check if user has permission to view the work order"""
    # Service managers can view all work orders
    if user.groups.filter(name='Service Manager').exists():
        return True
    
    # Technicians can only view their assigned work orders
    if user.groups.filter(name='Technician').exists():
        return work_order.technician == user
    
    return False


def generate_work_order_steps(work_order):
    """Generate work order steps using Azure OpenAI"""
    try:
        # Initialize Azure OpenAI client
        client = AzureOpenAI(
            api_key=os.getenv('AZURE_OPENAI_KEY'),
            api_version=os.getenv('AZURE_OPENAI_API_VERSION'),
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT')
        )
        
        # Create prompt for LLM
        prompt = f"""
You are an expert automotive technician assistant. Based on the work order details below, generate a detailed step-by-step plan for completing the repair work.

Work Order Details:
- Title: {work_order.title}
- Description: {work_order.description}
- Vehicle: {work_order.vehicle.year} {work_order.vehicle.make} {work_order.vehicle.model}
- Priority: {work_order.priority}
- Estimated Hours: {work_order.estimated_hours}

Please generate 5-8 detailed steps that a technician should follow to complete this work order. Each step should include:
1. A clear, concise title
2. Detailed description of what needs to be done
3. Estimated time in hours (as a decimal, e.g., 0.5 for 30 minutes)

Format your response as a JSON array with this structure:
[
    {{
        "title": "Step title",
        "description": "Detailed description of the step",
        "estimated_time": 0.5
    }}
]

Make sure the steps are logical, follow automotive repair best practices, and are appropriate for the specific vehicle and issue described.
"""
        
        # Call Azure OpenAI
        response = client.chat.completions.create(
            model=os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME'),
            messages=[
                {
                    "role": "system", 
                    "content": "You are an expert automotive technician assistant. Provide detailed, practical repair steps in JSON format."
                },
                {
                    "role": "user", 
                    "content": prompt
                }
            ],
            temperature=0.7,
            max_tokens=1500
        )
        
        # Parse the response
        response_text = response.choices[0].message.content.strip()
        
        # Extract JSON from response (in case there's extra text)
        json_start = response_text.find('[')
        json_end = response_text.rfind(']') + 1
        
        if json_start != -1 and json_end != -1:
            json_text = response_text[json_start:json_end]
            steps = json.loads(json_text)
            return steps
        else:
            print(f"Could not extract JSON from LLM response: {response_text}")
            return []
            
    except Exception as e:
        print(f"Error generating work order steps: {e}")
        return []


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def generate_question_from_workorder(request):
    """
    Generate searchable question from work order using LLM

    POST /api/workorder/generate-question/
    Request: {"work_order_number": "WO-20241001"}
    Response: {
        "success": true,
        "work_order_number": "WO-20241001",
        "title": "...",
        "description": "...",
        "generated_question": "..."
    }
    """
    work_order_number = request.data.get('work_order_number')

    if not work_order_number:
        return Response(
            {'error': 'work_order_number required'},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        work_order = WorkOrder.objects.get(order_number=work_order_number)
    except WorkOrder.DoesNotExist:
        return Response(
            {'error': 'Work order not found'},
            status=status.HTTP_404_NOT_FOUND
        )

    # Check permissions
    if not can_user_view_work_order(request.user, work_order):
        return Response(
            {'error': 'Permission denied'},
            status=status.HTTP_403_FORBIDDEN
        )

    # Initialize LLM service
    try:
        from voice_work_order_system import LLMService
        llm_service = LLMService()

        # Generate question
        question = llm_service.generate_question_from_work_order(
            work_order.title,
            work_order.description
        )

        return Response({
            'success': True,
            'work_order_number': work_order.order_number,
            'title': work_order.title,
            'description': work_order.description,
            'generated_question': question
        })
    except ImportError as e:
        return Response(
            {'error': f'LLM service not available: {str(e)}'},
            status=status.HTTP_503_SERVICE_UNAVAILABLE
        )
    except Exception as e:
        return Response(
            {'error': f'Error generating question: {str(e)}'},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def generate_steps_with_rag(request):
    """
    Generate work order steps using RAG system with vector search

    POST /api/workorder/generate-steps-rag/
    Request: {
        "work_order_number": "WO-20241001",
        "question": "What are the steps for oil change?",
        "min_chunks": 3  # Minimum relevant chunks required (optional, default 3)
    }

    Response (success): {
        "success": true,
        "work_order_number": "WO-20241001",
        "chunks_found": 5,
        "steps_created": 6,
        "steps": [...]
    }

    Response (insufficient chunks): {
        "success": false,
        "work_order_number": "WO-20241001",
        "chunks_found": 1,
        "message": "I can't able to answer the question",
        "reason": "Insufficient relevant documentation found"
    }
    """
    work_order_number = request.data.get('work_order_number')
    question = request.data.get('question')
    min_chunks = request.data.get('min_chunks', 3)

    if not work_order_number or not question:
        return Response({
            'error': 'work_order_number and question are required'
        }, status=status.HTTP_400_BAD_REQUEST)

    try:
        work_order = WorkOrder.objects.get(order_number=work_order_number)
    except WorkOrder.DoesNotExist:
        return Response(
            {'error': 'Work order not found'},
            status=status.HTTP_404_NOT_FOUND
        )

    # Check permissions
    if not can_user_view_work_order(request.user, work_order):
        return Response(
            {'error': 'Permission denied'},
            status=status.HTTP_403_FORBIDDEN
        )

    # Check if steps already exist
    if work_order.steps.exists():
        return Response({
            'error': 'Steps already exist for this work order',
            'work_order_number': work_order.order_number,
            'existing_steps': work_order.steps.count()
        }, status=status.HTTP_400_BAD_REQUEST)

    # Initialize services
    try:
        from voice_work_order_system import VectorService, LLMService
        vector_service = VectorService()
        llm_service = LLMService()
    except ImportError as e:
        return Response(
            {'error': f'Required services not available: {str(e)}'},
            status=status.HTTP_503_SERVICE_UNAVAILABLE
        )

    try:
        # Search for relevant procedures using RAG
        relevant_chunks = vector_service.search_relevant_procedures(
            question,
            n_results=8
        )

        # Check if we have enough relevant chunks
        if len(relevant_chunks) < min_chunks:
            return Response({
                'success': False,
                'work_order_number': work_order.order_number,
                'chunks_found': len(relevant_chunks),
                'message': "I can't able to answer the question",
                'reason': f'Insufficient relevant documentation found (minimum {min_chunks} chunks required, found {len(relevant_chunks)})'
            }, status=status.HTTP_200_OK)  # 200 OK but success=false

        # Generate steps using LLM with RAG context
        generated_steps = llm_service.generate_detailed_steps(
            work_order.title,
            work_order.description,
            relevant_chunks
        )

        if not generated_steps:
            return Response({
                'success': False,
                'work_order_number': work_order.order_number,
                'chunks_found': len(relevant_chunks),
                'message': "I can't able to answer the question",
                'reason': 'Failed to generate steps from available documentation'
            }, status=status.HTTP_200_OK)

        # Save generated steps to database
        created_steps = []
        for i, step_data in enumerate(generated_steps, 1):
            step = WorkOrderStep.objects.create(
                work_order=work_order,
                step_number=i,
                title=step_data.get('title', f'Step {i}'),
                description=step_data.get('description', ''),
                estimated_time=step_data.get('estimated_time', 0.5)
            )
            created_steps.append({
                'step_number': step.step_number,
                'title': step.title,
                'description': step.description,
                'estimated_time': float(step.estimated_time)
            })

        # Update work order status if needed
        if work_order.status == 'ASSIGNED':
            work_order.status = 'IN_PROGRESS'
            work_order.started_at = timezone.now()
            work_order.save()

        return Response({
            'success': True,
            'work_order_number': work_order.order_number,
            'chunks_found': len(relevant_chunks),
            'steps_created': len(created_steps),
            'steps': created_steps,
            'message': f'Successfully generated {len(created_steps)} steps from {len(relevant_chunks)} relevant procedures'
        })

    except Exception as e:
        return Response(
            {'error': f'Error generating steps: {str(e)}'},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
