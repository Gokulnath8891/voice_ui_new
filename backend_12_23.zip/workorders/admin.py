from django.contrib import admin
from .models import (
    TechnicianProfile, ServiceManagerProfile, Customer, Vehicle,
    WorkOrder, WorkOrderStep, WorkOrderFeedback, WorkOrderSummary
)


@admin.register(TechnicianProfile)
class TechnicianProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'employee_id', 'phone', 'specialization', 'created_at']
    search_fields = ['user__username', 'employee_id', 'specialization']


@admin.register(ServiceManagerProfile)
class ServiceManagerProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'employee_id', 'phone', 'department', 'created_at']
    search_fields = ['user__username', 'employee_id', 'department']


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'email', 'phone', 'created_at']
    search_fields = ['first_name', 'last_name', 'email']


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ['make', 'model', 'year', 'license_plate', 'customer', 'created_at']
    search_fields = ['make', 'model', 'vin', 'license_plate']
    list_filter = ['make', 'year']


@admin.register(WorkOrder)
class WorkOrderAdmin(admin.ModelAdmin):
    list_display = ['order_number', 'title', 'customer', 'technician', 'status', 'priority', 'created_at']
    search_fields = ['order_number', 'title', 'customer__first_name', 'customer__last_name']
    list_filter = ['status', 'priority', 'created_at']


@admin.register(WorkOrderStep)
class WorkOrderStepAdmin(admin.ModelAdmin):
    list_display = ['work_order', 'step_number', 'title', 'is_completed', 'created_at']
    list_filter = ['is_completed', 'created_at']


@admin.register(WorkOrderFeedback)
class WorkOrderFeedbackAdmin(admin.ModelAdmin):
    list_display = ['work_order', 'technician', 'step', 'time_spent', 'created_at']
    search_fields = ['work_order__order_number', 'technician__username']


@admin.register(WorkOrderSummary)
class WorkOrderSummaryAdmin(admin.ModelAdmin):
    list_display = ['work_order', 'total_time_spent', 'total_steps_completed', 'created_at']
    search_fields = ['work_order__order_number']
