import psycopg2

# Path to your SQL file
#sql_file_path = r"C:\Users\guruprasadh.s.lv\Downloads\01-init.sql"
sql_file_path=r"E:/voice_Assistant_code/psql_server/init-scripts/01-init.sql"
# Database connection details (to the default postgres DB)
conn_params = {
    "dbname": "postgres", # connect to default database to create new DB
    "user": "LVadmin",
    "password": "LVwelcome@2025",
    "host": "voiceassistantpsql.postgres.database.azure.com",
    "port": "5432",
}

def run_init_sql():
    try:
        # Read the SQL file
        with open(sql_file_path, "r") as file:
            sql_script = file.read()

        # Connect to PostgreSQL
        conn = psycopg2.connect(**conn_params)
        conn.autocommit = True # Required for CREATE DATABASE and similar commands
        cursor = conn.cursor()

        # Split script into statements (ignoring psql meta commands like \c)
        statements = [
            stmt.strip() for stmt in sql_script.split(";") if stmt.strip() and not stmt.strip().startswith("\\")
        ]

        for stmt in statements:
            try:
                cursor.execute(stmt)
                print(f"Executed: {stmt[:60]}...")
            except Exception as e:
                print(f"Error executing statement: {stmt[:60]}...\n{e}")

        print("✅ Database initialization completed successfully.")

    except Exception as e:
        print("❌ Database initialization failed:", e)

    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    run_init_sql()
