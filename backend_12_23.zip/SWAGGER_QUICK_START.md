# API Documentation - Quick Start Guide

## 🚀 Accessing Swagger/OpenAPI Documentation

### 1. Install Required Package

First, install the `drf-spectacular` package:

```bash
pip install drf-spectacular
```

Or if using the virtual environment:

```bash
C:/lv/backend_new/.venv/Scripts/python.exe -m pip install drf-spectacular
```

### 2. Start the Django Server

```bash
cd C:\lv\backend_new
C:/lv/backend_new/.venv/Scripts/python.exe manage.py runserver
```

### 3. Access the Documentation

Once the server is running, you can access the API documentation at:

#### **Swagger UI (Interactive)** - RECOMMENDED
```
http://localhost:8000/api/docs/
```

**Features:**
- Interactive API testing interface
- Try out endpoints directly from the browser
- View request/response schemas
- See example payloads
- Test authentication

#### **ReDoc (Read-Only)**
```
http://localhost:8000/api/redoc/
```

**Features:**
- Clean, modern documentation layout
- Better for reading and understanding API structure
- Great for generating PDF documentation
- Mobile-friendly

#### **OpenAPI Schema (JSON)**
```
http://localhost:8000/api/schema/
```

**Features:**
- Raw OpenAPI 3.0 schema in JSON format
- Can be imported into tools like Postman, Insomnia
- Used for code generation tools

---

## 📋 Complete API Endpoint List

### Authentication
- **POST** `/api/login/` - User authentication

### Work Orders (Technician)
- **GET** `/api/technician/workorders/?user_id={id}` - Get technician's work orders

### Work Orders (Manager)
- **GET** `/api/manager/workorders/?user_id={id}&status={status}` - Get manager's work orders

### Chat & Workflow
- **POST** `/api/chat/query/` - Process chat queries and start workflows
- **POST** `/api/chat/feedback/` - Submit step feedback

### Voice Assistant
- **GET** `/api/voice/commands/` - Get available voice commands
- **GET** `/api/voice/init/?user_id={id}` - Initialize voice proxy

### Feedback & History
- **GET** `/api/workorder/{id}/feedback/` - Get feedback history
- **POST** `/api/workorder/reset/` - Reset completed work order

---

## 🧪 Testing Endpoints with Swagger UI

### Example 1: Login

1. Go to `http://localhost:8000/api/docs/`
2. Find the **POST /api/login/** endpoint
3. Click "Try it out"
4. Enter request body:
   ```json
   {
     "username": "john_smith",
     "password": "demo123"
   }
   ```
5. Click "Execute"
6. View the response

### Example 2: Get Work Orders

1. After login, note the `user.id` from the response
2. Find **GET /api/technician/workorders/**
3. Click "Try it out"
4. Enter the `user_id` parameter
5. Click "Execute"
6. View the list of work orders

### Example 3: Start Work Order Workflow

1. Copy a `order_number` from the work orders list (e.g., "WO-2024-001")
2. Find **POST /api/chat/query/**
3. Click "Try it out"
4. Enter request body:
   ```json
   {
     "query": "work order WO-2024-001",
     "user_id": 1,
     "type": "text"
   }
   ```
5. Click "Execute"
6. Note the `session_id` in the response

### Example 4: Submit Step Feedback

1. Use the `session_id` from previous step
2. Find **POST /api/chat/feedback/**
3. Click "Try it out"
4. Enter request body:
   ```json
   {
     "session_id": "wo_101_1_abc123",
     "feedback": "Step completed successfully",
     "user_id": 1
   }
   ```
5. Click "Execute"
6. View the next step or completion message

---

## 🔧 Using with Angular

### Import OpenAPI Schema

1. Download the schema:
   ```bash
   curl http://localhost:8000/api/schema/ > api-schema.json
   ```

2. Generate TypeScript interfaces using tools like:
   - **openapi-generator-cli**
   - **ng-openapi-gen**
   - **swagger-codegen**

### Example with ng-openapi-gen:

```bash
npm install -g ng-openapi-gen
ng-openapi-gen --input api-schema.json --output src/app/api
```

This will generate:
- TypeScript interfaces for all models
- Angular services for each endpoint
- Type-safe API calls

---

## 📦 Importing to Postman

1. Open Postman
2. Click "Import"
3. Select "Link"
4. Enter: `http://localhost:8000/api/schema/`
5. Click "Import"

All endpoints will be added to your Postman workspace with:
- Request examples
- Response schemas
- Documentation

---

## 📊 API Statistics

- **Total Endpoints:** 9 main endpoints
- **Authentication:** Username/password (JWT available)
- **Format:** JSON
- **Base URL:** `http://localhost:8000/api`

---

## 🎯 Next Steps for Angular Team

1. ✅ Access Swagger UI at `http://localhost:8000/api/docs/`
2. ✅ Test all endpoints to understand request/response formats
3. ✅ Download OpenAPI schema for code generation
4. ✅ Generate TypeScript interfaces and services
5. ✅ Implement Angular HTTP services
6. ✅ Build UI components using the generated services
7. ✅ Configure CORS in Django for Angular dev server

---

## 🔒 Security Notes

**For Production:**
- Enable JWT authentication
- Remove `CORS_ALLOW_ALL_ORIGINS = True`
- Add proper authentication to Swagger UI
- Use HTTPS
- Implement rate limiting
- Add API key authentication

**Current Setup (Development):**
- CSRF protection disabled on API endpoints
- CORS configured for localhost
- No authentication required for documentation

---

## 📞 Support

For questions about the API:
1. Check the comprehensive documentation at `http://localhost:8000/api/docs/`
2. Review the detailed markdown document: `API_DOCUMENTATION_FOR_ANGULAR.md`
3. Contact the backend development team

---

## 🐛 Troubleshooting

### Issue: Cannot access Swagger UI

**Solution:**
```bash
# Make sure drf-spectacular is installed
pip install drf-spectacular

# Check it's in INSTALLED_APPS in settings.py
# Restart Django server
python manage.py runserver
```

### Issue: CORS errors from Angular

**Solution:**
Add Angular dev server URL to `settings.py`:
```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:4200",  # Angular default port
]
```

### Issue: 404 on endpoints

**Solution:**
- Ensure Django server is running
- Check URL pattern matches exactly
- Verify base URL is `http://localhost:8000/api/`

---

**Last Updated:** November 19, 2025  
**API Version:** 1.0.0
