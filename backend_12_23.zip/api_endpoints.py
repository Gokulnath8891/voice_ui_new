#!/usr/bin/env python
"""
Django API Endpoints for Dash Application
Provides REST API endpoints for the voice assistant Dash interface
"""

import os
import sys
import django
from pathlib import Path
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate
from django.contrib.auth.models import User, Group
from django.db.models import Q, Count
from django.utils import timezone
import json
from datetime import datetime
from decimal import Decimal

# Add the project directory to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
django.setup()

from workorders.models import WorkOrder, WorkOrderStep, WorkOrderFeedback, WorkOrderSummary
from voice_work_order_system import VoiceWorkOrderWorkflow


class DashAPIEndpoints:
    """API endpoints for the Dash application"""
    
    def __init__(self):
        self.voice_workflow = VoiceWorkOrderWorkflow()
    
    @csrf_exempt
    def login(self, request):
        """Authenticate user and return user details with role"""
        if request.method != 'POST':
            return JsonResponse({'error': 'Method not allowed'}, status=405)
        
        try:
            data = json.loads(request.body)
            username = data.get('username')
            password = data.get('password')
            
            if not username or not password:
                return JsonResponse({'error': 'Username and password required'}, status=400)
            
            user = authenticate(username=username, password=password)
            if not user:
                return JsonResponse({'error': 'Invalid credentials'}, status=401)
            
            # Determine user role
            role = 'unknown'
            if user.groups.filter(name='Service Manager').exists():
                role = 'service_manager'
            elif user.groups.filter(name='Technician').exists():
                role = 'technician'
            
            return JsonResponse({
                'success': True,
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'role': role
                }
            })
        
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    def get_technician_work_orders(self, request):
        """Get top 10 work orders assigned to logged-in technician"""
        user_id = request.GET.get('user_id')
        if not user_id:
            return JsonResponse({'error': 'User ID required'}, status=400)
        
        try:
            user = User.objects.get(id=user_id)
            work_orders = WorkOrder.objects.filter(
                technician=user
            ).select_related(
                'customer', 'vehicle', 'service_manager'
            ).prefetch_related(
                'steps', 'feedback'
            ).order_by('-created_at')[:10]
            
            orders_data = []
            for wo in work_orders:
                total_steps = wo.steps.count()
                completed_steps = wo.steps.filter(is_completed=True).count()
                progress = (completed_steps / total_steps * 100) if total_steps > 0 else 0
                
                orders_data.append({
                    'id': wo.id,
                    'order_number': wo.order_number,
                    'title': wo.title,
                    'description': wo.description,
                    'status': wo.status,
                    'priority': wo.priority,
                    'customer_name': f"{wo.customer.first_name} {wo.customer.last_name}",
                    'vehicle': f"{wo.vehicle.year} {wo.vehicle.make} {wo.vehicle.model}",
                    'created_at': wo.created_at.isoformat(),
                    'estimated_hours': float(wo.estimated_hours) if wo.estimated_hours else 0,
                    'actual_hours': float(wo.actual_hours) if wo.actual_hours else 0,
                    'progress': round(progress, 1),
                    'total_steps': total_steps,
                    'completed_steps': completed_steps
                })
            
            return JsonResponse({'work_orders': orders_data})
        
        except User.DoesNotExist:
            return JsonResponse({'error': 'User not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    def get_manager_work_orders(self, request):
        """Get work orders for service manager view"""
        user_id = request.GET.get('user_id')
        status_filter = request.GET.get('status', 'all')
        
        if not user_id:
            return JsonResponse({'error': 'User ID required'}, status=400)
        
        try:
            user = User.objects.get(id=user_id)
            
            # Base query for work orders managed by this service manager
            base_query = WorkOrder.objects.filter(
                service_manager=user
            ).select_related(
                'customer', 'vehicle', 'technician'
            ).prefetch_related(
                'steps', 'feedback'
            )
            
            # Apply status filter
            if status_filter == 'pending':
                work_orders = base_query.filter(status='PENDING')
            elif status_filter == 'assigned':
                work_orders = base_query.filter(status='ASSIGNED')
            elif status_filter == 'in_progress':
                work_orders = base_query.filter(status='IN_PROGRESS')
            elif status_filter == 'completed':
                work_orders = base_query.filter(status='COMPLETED')
            else:
                work_orders = base_query.all()
            
            work_orders = work_orders.order_by('-created_at')[:50]
            
            orders_data = []
            for wo in work_orders:
                total_steps = wo.steps.count()
                completed_steps = wo.steps.filter(is_completed=True).count()
                progress = (completed_steps / total_steps * 100) if total_steps > 0 else 0
                
                # Get real-time step details
                steps_data = []
                for step in wo.steps.all().order_by('step_number'):
                    steps_data.append({
                        'step_number': step.step_number,
                        'title': step.title,
                        'is_completed': step.is_completed,
                        'completed_at': step.completed_at.isoformat() if step.completed_at else None
                    })
                
                orders_data.append({
                    'id': wo.id,
                    'order_number': wo.order_number,
                    'title': wo.title,
                    'description': wo.description,
                    'status': wo.status,
                    'priority': wo.priority,
                    'customer_name': f"{wo.customer.first_name} {wo.customer.last_name}",
                    'vehicle': f"{wo.vehicle.year} {wo.vehicle.make} {wo.vehicle.model}",
                    'technician_name': f"{wo.technician.first_name} {wo.technician.last_name}" if wo.technician else "Unassigned",
                    'created_at': wo.created_at.isoformat(),
                    'estimated_hours': float(wo.estimated_hours) if wo.estimated_hours else 0,
                    'actual_hours': float(wo.actual_hours) if wo.actual_hours else 0,
                    'progress': round(progress, 1),
                    'total_steps': total_steps,
                    'completed_steps': completed_steps,
                    'steps': steps_data
                })
            
            return JsonResponse({'work_orders': orders_data})
        
        except User.DoesNotExist:
            return JsonResponse({'error': 'User not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    @csrf_exempt
    def process_chat_query(self, request):
        """Process chat queries from the chatbot"""
        if request.method != 'POST':
            return JsonResponse({'error': 'Method not allowed'}, status=405)
        
        try:
            data = json.loads(request.body)
            query = data.get('query', '').strip()
            user_id = data.get('user_id')
            query_type = data.get('type', 'text')  # 'text' or 'voice'
            
            if not query:
                return JsonResponse({'error': 'Query is required'}, status=400)
            
            if not user_id:
                return JsonResponse({'error': 'User ID is required'}, status=400)
            
            user = User.objects.get(id=user_id)
            
            # Check if query contains work order pattern
            if 'WO-' in query.upper():
                return self._process_work_order_query(query, user)
            else:
                return self._process_general_query(query, user)
        
        except User.DoesNotExist:
            return JsonResponse({'error': 'User not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    def _process_work_order_query(self, query, user):
        """Process query containing work order ID"""
        try:
            # Extract work order ID
            order_id = self.voice_workflow.extract_work_order_id(query)
            if not order_id:
                return JsonResponse({
                    'type': 'error',
                    'message': 'Could not find a valid work order ID in your query'
                })
            
            # Load work order
            work_order = self.voice_workflow.load_work_order(order_id)
            if not work_order:
                return JsonResponse({
                    'type': 'error',
                    'message': f'Work order {order_id} not found'
                })
            
            # Generate and store tasks if not already exist
            if not work_order.steps.exists():
                success = self.voice_workflow.generate_and_store_tasks(work_order)
                if not success:
                    return JsonResponse({
                        'type': 'error',
                        'message': f'Failed to generate tasks for work order {order_id}'
                    })

            # Check if this is a "start over" command and reset progress
            if "start over" in query.lower():
                print(f"🔄 Start over detected for work order {order_id} - resetting progress")
                # Reset all work order steps to incomplete
                work_order.steps.all().update(is_completed=False, completed_at=None)

                # Clear existing feedback
                try:
                    from voice_work_order_system import WorkOrderFeedback
                    WorkOrderFeedback.objects.filter(work_order=work_order).delete()
                    print(f"   • Cleared feedback for work order {order_id}")
                except Exception as e:
                    print(f"   • Warning: Could not clear feedback: {e}")

                # Delete existing workflow session
                session_id = f"wo_{work_order.id}_{user.id}"
                try:
                    from chat_workflow_handler import workflow_handler
                    workflow_handler._delete_session(session_id)
                    print(f"   • Cleared workflow session: {session_id}")
                except Exception as e:
                    print(f"   • Warning: Could not clear session: {e}")

            # Determine which step to start from
            if "resume" in query.lower():
                # Resume from first incomplete step
                print(f"▶️ Resume detected for work order {order_id} - finding first incomplete step")
                current_step = work_order.steps.filter(is_completed=False).order_by('step_number').first()
                if not current_step:
                    # All steps completed
                    return JsonResponse({
                        'type': 'error',
                        'message': f'All steps in work order {order_id} are already completed'
                    })
                print(f"   • Resuming from Step {current_step.step_number}: {current_step.title}")
            else:
                # Start from first step (regular start or start over)
                current_step = work_order.steps.filter(step_number=1).first()
                if not current_step:
                    return JsonResponse({
                        'type': 'error',
                        'message': 'No steps found for this work order'
                    })
            
            # Create a workflow session for work order tracking
            from chat_workflow_handler import workflow_handler

            # Create workflow session
            work_order_data = {
                'id': work_order.id,
                'order_number': work_order.order_number,
                'title': work_order.title,
                'vehicle': str(work_order.vehicle),
                'total_steps': work_order.steps.count()
            }

            current_step_data = {
                'step_number': current_step.step_number,
                'title': current_step.title,
                'description': current_step.description,
                'estimated_time': float(current_step.estimated_time)
            }
            
            # Start workflow session using the workflow handler
            session_id = workflow_handler.start_work_order_session(
                user.id,
                work_order_data,
                current_step_data
            )
            
            # Create appropriate message based on command type
            if "start over" in query.lower():
                message = f"🔄 Work order {work_order.order_number} has been reset. Starting fresh from Step 1: {current_step.title}"
                tts_text = f"Work order {work_order.order_number} reset. Starting fresh. Step 1 of {work_order.steps.count()}: {current_step.title}. {current_step.description}"
            elif "resume" in query.lower():
                # Calculate how many steps are completed for progress info
                completed_steps = work_order.steps.filter(is_completed=True).count()
                message = f"▶️ Resuming work order {work_order.order_number}. Continuing from Step {current_step.step_number}: {current_step.title}"
                tts_text = f"Welcome back! You have completed {completed_steps} out of {work_order.steps.count()} steps. Resuming from Step {current_step.step_number}: {current_step.title}. {current_step.description}. Please provide your feedback when you complete this step."
            else:
                message = f"Starting work order {work_order.order_number}. Step {current_step.step_number}: {current_step.title}"
                tts_text = f"Step {current_step.step_number} of {work_order.steps.count()}: {current_step.title}. {current_step.description}"

            return JsonResponse({
                'type': 'work_order_start',
                'session_id': session_id,
                'work_order': work_order_data,
                'current_step': current_step_data,
                'message': message,
                'instruction': current_step.description,
                'tts_text': tts_text
            })
        
        except Exception as e:
            return JsonResponse({
                'type': 'error',
                'message': f'Error processing work order: {str(e)}'
            })
    
    def _process_general_query(self, query, user):
        """Process general maintenance query without work order"""
        try:
            llm_service = self.voice_workflow.task_breakdown_service.llm_service
            vector_service = self.voice_workflow.task_breakdown_service.vector_service

            question = llm_service.generate_question_from_work_order(query, "General maintenance query")
            relevant_procedures = vector_service.search_relevant_procedures(question)

            if not relevant_procedures:
                return JsonResponse({
                    'type': 'simple_response',
                    'message': 'I could not find relevant information for your query. Please try rephrasing or provide more details.'
                })

            context = "\n\n".join([
                f"Document: {proc.get('title', 'N/A')}\nContent: {proc.get('content', proc.get('text', 'N/A'))}"
                for proc in relevant_procedures
            ])

            summary_prompt = f"""Based on the following maintenance documentation, provide a clear and concise answer to the user's query.

User Query: {query}

Relevant Documentation:
{context}

Please provide a helpful summary that directly answers the user's question. Be specific and actionable."""

            summary = llm_service.client.chat.completions.create(
                model=llm_service.model_name,
                messages=[
                    {"role": "system", "content": "You are a helpful automotive maintenance assistant. Provide clear, concise, and actionable answers based on the provided documentation."},
                    {"role": "user", "content": summary_prompt}
                ],
                temperature=0.3,
                max_tokens=500
            )

            response_text = summary.choices[0].message.content.strip()

            return JsonResponse({
                'type': 'simple_response',
                'message': response_text
            })

        except Exception as e:
            return JsonResponse({
                'type': 'error',
                'message': f'Error processing query: {str(e)}'
            })
    
    @csrf_exempt
    def submit_step_feedback(self, request):
        """Submit feedback for a completed step"""
        if request.method != 'POST':
            return JsonResponse({'error': 'Method not allowed'}, status=405)
        
        try:
            data = json.loads(request.body)
            work_order_id = data.get('work_order_id')
            step_number = data.get('step_number')
            feedback_text = data.get('feedback', 'Step completed via chat interface')
            user_id = data.get('user_id')
            time_spent = data.get('time_spent')  # in hours
            
            if not all([work_order_id, step_number, user_id]):
                return JsonResponse({'error': 'Missing required fields'}, status=400)
            
            user = User.objects.get(id=user_id)
            work_order = WorkOrder.objects.get(id=work_order_id)
            
            # Collect feedback
            success = self.voice_workflow.collect_step_feedback(
                work_order, step_number, user, feedback_text, time_spent
            )
            
            if not success:
                return JsonResponse({'error': 'Failed to record feedback'}, status=500)
            
            # Check if there's a next step
            next_step_num = step_number + 1
            next_step = work_order.steps.filter(step_number=next_step_num).first()
            
            # Check if all steps are complete
            total_steps = work_order.steps.count()
            completed_steps = work_order.steps.filter(is_completed=True).count()
            
            if completed_steps >= total_steps:
                # Update work order status to COMPLETED
                work_order.status = 'COMPLETED'
                work_order.completed_at = timezone.now()
                work_order.save()

                # Generate summary using the workorders app function
                from workorders.views import generate_work_order_summary
                from workorders.serializers import WorkOrderSummarySerializer
                generate_work_order_summary(work_order)

                # Get the generated summary
                try:
                    summary = WorkOrderSummary.objects.get(work_order=work_order)
                    summary_data = WorkOrderSummarySerializer(summary).data
                except WorkOrderSummary.DoesNotExist:
                    summary_data = None

                # Calculate total time spent
                all_feedback = WorkOrderFeedback.objects.filter(work_order=work_order)
                total_time = sum(float(feedback.time_spent) for feedback in all_feedback if feedback.time_spent)
                estimated_time = sum(float(step.estimated_time) for step in work_order.steps.all() if step.estimated_time)
                time_variance = total_time - estimated_time

                # Create detailed completion message
                completion_message = f'Congratulations! All {total_steps} steps completed for work order {work_order.order_number}'

                # Create comprehensive TTS message with time summary
                if total_time > 0:
                    tts_message = f'Outstanding work! You have successfully completed work order {work_order.order_number}. '
                    tts_message += f'Total time: {total_time:.1f} hours. '
                    if time_variance > 0:
                        tts_message += f'You completed this {time_variance:.1f} hours over the estimated time. '
                    elif time_variance < -0.5:
                        tts_message += f'Excellent efficiency! You finished {abs(time_variance):.1f} hours under the estimated time. '
                    tts_message += f'Thank you for your professional work and detailed feedback on all {total_steps} steps.'
                else:
                    tts_message = f'Excellent work! You have successfully completed all {total_steps} steps for work order {work_order.order_number}. Thank you for your detailed feedback and professional execution.'

                return JsonResponse({
                    'type': 'work_order_complete',
                    'message': completion_message,
                    'tts_text': tts_message,
                    'total_time': round(total_time, 2),
                    'estimated_time': round(estimated_time, 2),
                    'time_variance': round(time_variance, 2),
                    'total_steps': total_steps,
                    'completed_steps': completed_steps,
                    'work_order_number': work_order.order_number,
                    'work_order_status': 'COMPLETED',
                    'summary': summary_data
                })
            elif next_step:
                return JsonResponse({
                    'type': 'next_step',
                    'current_step': {
                        'step_number': next_step.step_number,
                        'title': next_step.title,
                        'description': next_step.description,
                        'estimated_time': float(next_step.estimated_time)
                    },
                    'message': f'Step {step_number} completed! Ready for step {next_step_num}',
                    'instruction': next_step.description,
                    'tts_text': f'Step {next_step.step_number} of {total_steps}: {next_step.title}. {next_step.description}',
                    'progress': {
                        'completed': completed_steps,
                        'total': total_steps,
                        'percentage': round(completed_steps / total_steps * 100, 1)
                    }
                })
            else:
                return JsonResponse({
                    'type': 'error',
                    'message': 'Step completed but no next step found'
                })
        
        except (User.DoesNotExist, WorkOrder.DoesNotExist):
            return JsonResponse({'error': 'User or Work Order not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    @csrf_exempt
    def process_session_feedback(self, request):
        """Process feedback for a chat session"""
        print(f"🔧 DEBUG: Feedback endpoint called with method: {request.method}")
        print(f"🔧 DEBUG: Request body: {request.body}")
        
        if request.method != 'POST':
            return JsonResponse({'error': 'Method not allowed'}, status=405)
        
        try:
            data = json.loads(request.body)
            session_id = data.get('session_id')
            feedback = data.get('feedback', '').strip()
            user_id = data.get('user_id')
            
            # Debug logging
            print(f"DEBUG: Received data: {data}")
            print(f"DEBUG: session_id={session_id}, feedback='{feedback}', user_id={user_id}")
            
            if not all([session_id, feedback, user_id]):
                return JsonResponse({'error': f'Missing required fields. Got session_id={session_id}, feedback={feedback}, user_id={user_id}'}, status=400)
            
            # For now, use the workflow handler from the local import
            # This is a temporary solution until full session management is implemented
            from chat_workflow_handler import workflow_handler
            
            result = workflow_handler.process_feedback(session_id, feedback, user_id)
            
            return JsonResponse(result)
            
        except Exception as e:
            return JsonResponse({
                'type': 'error',
                'message': f'Error processing feedback: {str(e)}'
            })
    
    def get_voice_commands(self, request):
        """Get voice-friendly work order commands for a user"""
        if request.method != 'GET':
            return JsonResponse({'error': 'Only GET requests allowed'}, status=405)
        
        try:
            user_id = request.GET.get('user_id')
            if not user_id:
                return JsonResponse({'error': 'user_id parameter required'}, status=400)
            
            user_id = int(user_id)
            
            # Initialize voice proxy for the user
            mapping = self.voice_workflow.initialize_voice_proxy_for_user(user_id)
            
            # Get voice commands help
            commands = self.voice_workflow.get_user_voice_commands_help(user_id)
            
            return JsonResponse({
                'user_id': user_id,
                'voice_mapping_count': len(mapping),
                'commands': commands,
                'success': True
            })
            
        except Exception as e:
            return JsonResponse({
                'error': f'Error getting voice commands: {str(e)}',
                'success': False
            }, status=500)
    
    def init_voice_proxy(self, request):
        """Initialize voice proxy mapping for a user"""
        if request.method != 'POST':
            return JsonResponse({'error': 'Only POST requests allowed'}, status=405)
        
        try:
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            
            if not user_id:
                return JsonResponse({'error': 'user_id required'}, status=400)
            
            # Initialize voice proxy mapping
            mapping = self.voice_workflow.initialize_voice_proxy_for_user(user_id)
            
            return JsonResponse({
                'user_id': user_id,
                'mapping_count': len(mapping),
                'message': f'Voice proxy initialized with {len(mapping)} work orders',
                'success': True
            })
            
        except Exception as e:
            return JsonResponse({
                'error': f'Error initializing voice proxy: {str(e)}',
                'success': False
            }, status=500)

    def get_work_order_feedback_history(self, request, work_order_id):
        """Get feedback history for a work order"""
        if request.method != 'GET':
            return JsonResponse({'error': 'Method not allowed'}, status=405)

        try:
            # Get work order
            work_order = WorkOrder.objects.get(id=work_order_id)

            # Get all feedback for this work order, ordered by step number
            from voice_work_order_system import WorkOrderFeedback
            feedbacks = WorkOrderFeedback.objects.filter(
                work_order=work_order
            ).order_by('step_number', 'created_at')

            # Format feedback history
            feedback_history = []
            for feedback in feedbacks:
                feedback_history.append({
                    'step_number': feedback.step_number,
                    'feedback': feedback.feedback_text,
                    'time_spent': float(feedback.time_spent) if feedback.time_spent else 0,
                    'submitted_at': feedback.created_at.isoformat(),
                    'user_id': feedback.user.id if feedback.user else None
                })

            return JsonResponse({
                'success': True,
                'work_order_id': work_order_id,
                'work_order_number': work_order.order_number,
                'feedback_history': feedback_history
            })

        except WorkOrder.DoesNotExist:
            return JsonResponse({'error': 'Work order not found'}, status=404)
        except Exception as e:
            print(f"❌ Error getting feedback history: {e}")
            return JsonResponse({'error': str(e)}, status=500)

    @csrf_exempt
    def reset_work_order(self, request):
        """Reset a completed work order back to ASSIGNED status"""
        if request.method != 'POST':
            return JsonResponse({'error': 'Method not allowed'}, status=405)

        try:
            data = json.loads(request.body)
            work_order_number = data.get('work_order_number')
            user_id = data.get('user_id')

            if not all([work_order_number, user_id]):
                return JsonResponse({'error': 'Missing required fields'}, status=400)

            # Get work order
            work_order = WorkOrder.objects.get(order_number=work_order_number)

            # Security check - only allow resetting COMPLETED work orders
            if work_order.status != 'COMPLETED':
                return JsonResponse({'error': 'Only completed work orders can be reset'}, status=400)

            print(f"🔄 Resetting work order {work_order_number} for user {user_id}")

            # Reset work order status to ASSIGNED
            work_order.status = 'ASSIGNED'
            work_order.save()

            # Reset all steps to not completed
            work_order.steps.all().update(is_completed=False, completed_at=None)

            # Delete all feedback for this work order
            WorkOrderFeedback.objects.filter(work_order=work_order).delete()

            # Delete any workflow sessions for this work order
            try:
                from chat_workflow_handler import workflow_handler
                session_id = f"wo_{work_order.id}_{user_id}"
                workflow_handler._delete_session(session_id)
                print(f"✅ Deleted workflow session: {session_id}")
            except Exception as e:
                print(f"⚠️ Could not delete workflow session: {e}")

            # Delete work order summary if it exists
            try:
                WorkOrderSummary.objects.filter(work_order=work_order).delete()
                print(f"✅ Deleted work order summary")
            except Exception as e:
                print(f"⚠️ Could not delete work order summary: {e}")

            print(f"✅ Successfully reset work order {work_order_number}")

            return JsonResponse({
                'success': True,
                'message': f'Work order {work_order_number} has been reset to ASSIGNED status',
                'work_order_number': work_order_number,
                'new_status': 'ASSIGNED'
            })

        except WorkOrder.DoesNotExist:
            return JsonResponse({'error': 'Work order not found'}, status=404)
        except Exception as e:
            print(f"❌ Error resetting work order: {e}")
            return JsonResponse({'error': str(e)}, status=500)


# Initialize the endpoints
api_endpoints = DashAPIEndpoints()

# URL patterns for Django
def setup_api_urls():
    """Setup API URL patterns"""
    from django.urls import path
    
    urlpatterns = [
        path('api/login/', api_endpoints.login, name='api_login'),
        path('api/technician/workorders/', api_endpoints.get_technician_work_orders, name='technician_workorders'),
        path('api/manager/workorders/', api_endpoints.get_manager_work_orders, name='manager_workorders'),
        path('api/chat/query/', api_endpoints.process_chat_query, name='chat_query'),
        path('api/chat/feedback/', api_endpoints.process_session_feedback, name='session_feedback'),
        path('api/voice/commands/', api_endpoints.get_voice_commands, name='voice_commands'),
        path('api/voice/init/', api_endpoints.init_voice_proxy, name='voice_init'),
        path('api/workorder/<int:work_order_id>/feedback/', api_endpoints.get_work_order_feedback_history, name='workorder_feedback_history'),
        path('api/workorder/reset/', api_endpoints.reset_work_order, name='reset_workorder'),
    ]
    
    return urlpatterns

if __name__ == "__main__":
    print("API Endpoints module loaded successfully")
    print("Available endpoints:")
    print("- POST /api/login/ - User authentication")
    print("- GET /api/technician/workorders/ - Get technician work orders")
    print("- GET /api/manager/workorders/ - Get manager work orders")
    print("- POST /api/chat/query/ - Process chat queries")
    print("- POST /api/chat/feedback/ - Submit step feedback")