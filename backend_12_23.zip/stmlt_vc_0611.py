import streamlit as st
import azure.cognitiveservices.speech as speechsdk
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
import tempfile
import os
import psycopg2
import numpy as np
from typing import TypedDict, Optional
from sentence_transformers import SentenceTransformer
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_openai import AzureChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command
import streamlit as st
import azure.cognitiveservices.speech as speechsdk
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from pydub import AudioSegment
import base64
import tempfile
import pyttsx3
from streamlit_TTS import auto_play, text_to_speech, text_to_audio
from gtts.lang import tts_langs
import io
from gtts import gTTS

# ---------- TTS ----------
def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def greet_user(name="User"):
    speak(f"Hi, {name}. How may I help you today?")
    log_event(f"Greeted user {name}")


# ---------- Logging ----------
def log_event(message):
    with open("assistant_log.txt", "a", encoding="utf-8") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"[{timestamp}] {message}\n")


# -----------------------------
# Azure Configuration
# -----------------------------
AZURE_SPEECH_KEY = "BsDXPQTKwsh9ABh5jDIigsKc25GxXrQnX8FzEuKKxoI15upppkULJQQJ99BFACYeBjFXJ3w3AAAYACOG11aU"
AZURE_SPEECH_REGION = "eastus"


# ===============================
# 🔹 Define State using TypedDict
# ===============================
class QueryState(TypedDict):
    query: str
    result: Optional[str]
    context: Optional[str]

# ===============================
# 🔹 Azure OpenAI Configuration
# ===============================

# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


DB_URI='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'

EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
#engine = create_engine(DB_URI)
model = SentenceTransformer(EMBED_MODEL)


# --- Azure OpenAI setup ---
llm = AzureChatOpenAI(
 azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview',
    temperature=0
)


# ===============================
# 🔹 SentenceTransformer Embedding
# ===============================
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ===============================
# 🔹 PostgreSQL Connection
# ===============================
def get_pg_connection():
    return psycopg2.connect(
        host="voiceassistantpsql.postgres.database.azure.com",
        dbname="voice_assistant_db",
        user="postgres",
        password="voice_password",
        port="5432"
    )

# ===============================
# 🔹 Router Node
# ===============================
def router_node(state: QueryState):
    """Decide whether to use SQL or vector search."""
    #q = state["query"].lower()
    q=state.get("query","").lower()
    #if q.strip().contains("work order") or " from " in q:
    if "work order" in q:
        next_node="db_agent"
    else:
        next_node="vector_agent"
    return {"next":next_node}

# ===============================
# 🔹 SQL Agent Node
# ===============================
def db_agent(state: QueryState):
    """Executes SQL queries directly in PostgreSQL."""
    query = state["query"]
    context = state.get("context", "")
    prompt = f"""
    You are an automotive assistant.
    If question involves work order details, use SQL to retrieve them.
    Otherwise, answer naturally.
    Previous context: {context}
    Question: {query}
    """
    
    db = SQLDatabase.from_uri(
        "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
    )

    
    sql_agent = create_sql_agent(
        llm=llm,
        db=db,
        verbose=True,
        top_k=5,  # optional
        agent_type="openai-tools",  # use the new LCEL-compatible type
    )

    # Run user query through the SQL agent
    try:
        result = sql_agent.invoke({"input": prompt})
        result_text = result.get("output", "No output from SQL Agent.")
    except Exception as e:
        result_text = f"Error executing SQL Agent: {e}"

    return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {result_text}",
        "result": result_text
    }
    
# ===============================
# 🔹 Vector Agent Node
# ===============================
def vector_agent(state: QueryState):
    """Performs semantic search using pgvector and SentenceTransformer."""
    query = state["query"]
    context = state.get("context", "")
    try:
        # Step 1: Encode the query into vector
        query_vector = embed_model.encode(query)
        query_vector = np.array(query_vector, dtype=np.float32).tolist()

        # Step 2: Retrieve similar content
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT content, 1 - (embedding <=> %s::vector) AS similarity
            FROM powertrain_pdf_docs
            ORDER BY embedding <=> %s::vector
            LIMIT 3;
        """, (query_vector, query_vector))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            return {"result": "⚠️ No similar content found in vector DB."}

        context = "\n".join([r[0] for r in rows])

        # Step 3: LLM call with retrieved context
        prompt = f"""
        You are a helpful voice assistant for an automotive technician.
        Use the following context to answer the user's question.
        If you don’t know the answer, politely say No.
        Be brief and clear.
        If there are multiple steps, just give one step and ask the user if they want to proceed for next step.

        \n\n Context:\n{context}
        \n\n query: {query}
        """
        response = llm.invoke(prompt)
        first_answer=response.content.strip()
        return {
        "query": query,
        "context": context + f"\nUser: {query}\nAssistant: {first_answer}",
        "result": first_answer}

    except Exception as e:
        return {"result": f"⚠️ Vector Agent Error: {e}"}

# ===============================
# 🔹 LangGraph Workflow
# ===============================
graph = StateGraph(QueryState)
graph.add_node("router", router_node)
graph.add_node("db_agent", db_agent)
graph.add_node("vector_agent", vector_agent)

graph.add_conditional_edges(
    "router",
    lambda state:state["next"],
    {
        "db_agent": "db_agent",
        "vector_agent": "vector_agent"
    }
)

graph.add_edge("db_agent", END)
graph.add_edge("vector_agent", END)
graph.set_entry_point("router")

# Memory checkpoint
checkpointer = MemorySaver()
#app = graph.compile(checkpointer=checkpointer)
app = graph.compile()

#workflow = graph.compile()

# -----------------------------
# Azure STT
# -----------------------------
def azure_stt_from_file(audio_path):
    speech_config = speechsdk.SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
    audio_input = speechsdk.AudioConfig(filename=audio_path)
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_input)
    result = recognizer.recognize_once()
    if result.reason == speechsdk.ResultReason.RecognizedSpeech:
        return result.text
    return ""

# -----------------------------
# Azure TTS (returns bytes)
# -----------------------------
def azure_tts_to_bytes(text):
    speech_config = speechsdk.SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
    speech_config.speech_synthesis_voice_name = "en-US-JennyNeural"
    out_path = tempfile.mktemp(suffix=".wav")
    audio_output = speechsdk.AudioConfig(filename=out_path)
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_output)
    synthesizer.speak_text_async(text).get()
    with open(out_path, "rb") as f:
        audio_bytes = f.read()
    return audio_bytes

# -----------------------------
# Streamlit UI
# -----------------------------
st.title("🎤 Work Order Assistant")

if "history" not in st.session_state:
    st.session_state.history = []
    st.session_state.context = ""

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! How can I help you today?"}
    ]

# Display chat messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])
        if "audio" in msg:
            st.audio(msg["audio"], format="audio/wav")



    
for msg in st.session_state.history:
    with st.chat_message(msg["role"]):
         st.markdown(msg["content"])
# -----------------------------
# Input: Mic or Text
# -----------------------------
col1, col2 = st.columns([1,1])

with col1:
    audio_bytes = st.audio_input("🎙️ Speak your query")

with col2:
    user_text = st.text_input("Or type your message here...")

# -----------------------------
# Function to process input
# -----------------------------
def process_input(query_text):
    if not query_text.strip():
        return
    #st.session_state.messages.append({"role": "user", "content": query_text})
    st.session_state.history.append({"role": "user", "content": query_text})
    output_state = app.invoke({"query": query_text,"context": st.session_state.context})
    
    answer = output_state.get("result", "No response from LangGraph")
    
    result = output_state.get("result", "⚠️ No result key found.")
    st.session_state.context = output_state.get("context", st.session_state.context)
    st.session_state.history.append({"role": "assistant", "content": result})

    audio_out = azure_tts_to_bytes(answer)
    """
    st.session_state.messages.append({
            "role": "assistant",
            "content": answer,
            "audio": audio_out})
    """
    tts=gTTS(text=answer, lang='en')
    mp3_bytes=io.BytesIO()
    tts.write_to_fp(mp3_bytes)
    mp3_bytes.seek(0)
    #st.success("speech generated")
    #st.audio(mp3_bytes, format="audio/mp3")
    b64 = base64.b64encode(mp3_bytes.read()).decode()

        # Autoplay HTML audio (hidden)
    audio_html = f"""
    <audio autoplay="true" style="display:none;">
        <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
    </audio>
    """

    st.markdown(audio_html, unsafe_allow_html=True)
    st.success("✅ Speaking...")

if audio_bytes is not None:
    # Read raw bytes from UploadedFile
    audio_content = audio_bytes.read()  # ✅ Now this is bytes

    # Write to temporary WAV file
    temp_audio = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    temp_audio.write(audio_content)
    temp_audio.flush()

    # Send to Azure STT
    stt_text = azure_stt_from_file(temp_audio.name)
    process_input(stt_text)
# -----------------------------
# Process Text Input
# -----------------------------
st.session_state.chat_log = []
if user_text:
    process_input(user_text)

with st.expander("🧠 Conversation History"):
        for role, msg in st.session_state.chat_log:
            st.markdown(f"**{role}**: {msg}")

with st.subheader("💬 Live Conversation"):
     for role, msg in st.session_state.chat_log:
        if role == "🧑":
            st.markdown(f"<div style='color:blue'><b>{role}</b>: {msg}</div>", unsafe_allow_html=True)
        else:
            st.markdown(f"<div style='color:green'><b>{role}</b>: {msg}</div>", unsafe_allow_html=True)

with st.expander("📜 Assistant Log"):
     if os.path.exists("assistant_log.txt"):
        with open("assistant_log.txt", "r", encoding="utf-8") as f:
             st.text(f.read())
     else:
        st.info("No logs yet.")

