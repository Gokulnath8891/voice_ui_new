import streamlit as st
import os
from dotenv import load_dotenv

from langchain_openai import AzureChatOpenAI
from langchain_postgres import PGVector
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain.sql_database import SQLDatabase
from langchain.agents import create_sql_agent
from langgraph.graph import StateGraph, END
from langchain_core.prompts import ChatPromptTemplate

load_dotenv()

# -----------------------
# CONFIG
# -----------------------
#DB_URL = os.getenv("DATABASE_URL")
#AZURE_DEPLOYMENT_NAME = os.getenv("AZURE_DEPLOYMENT_NAME")
#AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
#AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")

DB_URL='postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db'
AZURE_DEPLOYMENT_NAME='gpt-4.1-mini'
AZURE_OPENAI_ENDPOINT="https://voice-assitant-openai.openai.azure.com/"
AZURE_OPENAI_API_KEY ='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m'
AZURE_OPENAI_API_VERSION= '2024-12-01-preview'


#azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
#api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
#deployment_name="gpt-4.1-mini",
#api_version='2024-12-01-preview'

# -----------------------
# LLM (Azure OpenAI)
# -----------------------
llm = AzureChatOpenAI(
    azure_deployment=AZURE_DEPLOYMENT_NAME,
    openai_api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
)

# -----------------------
# SentenceTransformer Embeddings
# -----------------------
embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

# -----------------------
# Vector Store (existing pgvector table)
# -----------------------
vector_store = PGVector(
    connection_string=DB_URL,
    embedding_function=embeddings,
    collection_name="powertrain_pdf_docs"  # use your existing table name
)

retriever = vector_store.as_retriever(
    search_type="similarity",
    search_kwargs={"k": 3}
)

# -----------------------
# SQL Agent Setup
# -----------------------
sql_db = SQLDatabase.from_uri(DB_URL)
sql_agent = create_sql_agent(llm, sql_db)

# -----------------------
# LangGraph Nodes
# -----------------------
def retrieval_node(state):
    """Retrieve context from pgvector."""
    query = state["question"]
    docs = retriever.get_relevant_documents(query)
    state["context"] = "\n".join([d.page_content for d in docs])
    return state

def sql_query_node(state):
    """Run SQL agent for structured DB query."""
    query = state["question"]
    sql_response = sql_agent.invoke({"input": query})
    state["sql_answer"] = sql_response["output"]
    return state

def llm_node(state):
    """Combine vector + SQL context and generate answer."""
    prompt = ChatPromptTemplate.from_template("""
    You are a helpful assistant.
    Context from documents:
    {context}

    SQL Insights:
    {sql_answer}

    User Question:
    {question}

    Give a concise, factual answer.
    """)
    response = llm(prompt.format_messages(
        context=state.get("context", ""),
        sql_answer=state.get("sql_answer", ""),
        question=state["question"]
    ))
    state["answer"] = response.content
    return state

# -----------------------
# LangGraph Wiring
# -----------------------
graph = StateGraph(dict)

graph.add_node("retrieval", retrieval_node)
graph.add_node("sql_query", sql_query_node)
graph.add_node("llm", llm_node)

graph.add_edge("retrieval", "sql_query")
graph.add_edge("sql_query", "llm")
graph.add_edge("llm", END)

graph.set_entry_point("retrieval")

app = graph.compile()

# -----------------------
# Streamlit UI
# -----------------------
st.title("🤖 LangGraph RAG + SQL Agent + SentenceTransformer + Azure OpenAI")

user_input = st.text_input("Ask your question:")
if st.button("Submit") and user_input:
    with st.spinner("Thinking..."):
        result = app.invoke({"question": user_input})
        st.markdown("### 🔍 Retrieved Context")
        st.write(result.get("context", "None"))

        st.markdown("### 🧮 SQL Agent Output")
        st.write(result.get("sql_answer", "None"))

        st.markdown("### 💬 Final Answer")
        st.success(result["answer"])