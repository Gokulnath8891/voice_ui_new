from django.urls import path, include
from . import views

app_name = 'voice_assistant'

urlpatterns = [
    # Session management
    path('session/create/', views.CreateVoiceSessionView.as_view(), name='create_session'),
    
    # Voice Assistant API endpoints (v1)
    path('v1/speech/recognize/', views.SpeechRecognitionView.as_view(), name='speech_recognize'),
    path('v1/search/query/', views.SemanticSearchView.as_view(), name='semantic_search'),
    path('v1/speech/synthesize/', views.TextToSpeechView.as_view(), name='text_to_speech'),
    
    # Statistics and monitoring
    path('stats/', views.VoiceAssistantStatsView.as_view(), name='stats'),
    path('health/', views.health_check, name='health_check'),
]