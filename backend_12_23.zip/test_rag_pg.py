from sentence_transformers import SentenceTransformer
from PyPDF2 import PdfReader
from sqlalchemy import create_engine, text
import os

# =================== CONFIG =================== #
#DB_URI = "postgresql+psycopg2://voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
DB_URI = "postgresql+psycopg2://postgres:voice_password@voiceassistantpsql.postgres.database.azure.com:5432/voice_assistant_db"
PDF_DIR = r"E:/voice_Assistant_code/docs/powertrain_zt5400/"  # folder containing one or more PDF files
EMBED_MODEL = "all-MiniLM-L6-v2"
TABLE_NAME = "powertrain_pdf_docs"
# ============================================== #

# ---------- STEP 1: Ensure pgvector table ----------
def setup_database(engine):
    create_table_sql = f"""
    CREATE EXTENSION IF NOT EXISTS vector;
    CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
        id SERIAL PRIMARY KEY,
        doc_name TEXT,
        content TEXT,
        embedding vector(384)
    );
    """
    with engine.begin() as conn:
        conn.execute(text(create_table_sql))
    print("✅ Database table ready.")


# ---------- STEP 2: Read and split PDF ----------
def read_pdf(file_path):
    reader = PdfReader(file_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text


def split_text(text, chunk_size=1000, overlap=100):
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return chunks


# ---------- STEP 3: Insert into PostgreSQL ----------
def store_embeddings(engine, model, pdf_path):
    doc_name = os.path.basename(pdf_path)
    text_data = read_pdf(pdf_path)
    chunks = split_text(text_data)
    embeddings = model.encode(chunks)

    with engine.begin() as conn:
        for content, emb in zip(chunks, embeddings):
            conn.execute(
                text(f"INSERT INTO {TABLE_NAME} (doc_name, content, embedding) VALUES (:d, :c, :e)"),
                {"d": doc_name, "c": content, "e": emb.tolist()}
            )
    print(f"✅ Stored {len(chunks)} chunks from {doc_name}.")


# ---------- STEP 4: Semantic Retrieval ----------
def retrieve(engine, model, query, top_k=3):
    query_emb = model.encode([query])[0].tolist()
    query_emb_str="[" +",".join([str(x) for x in query_emb])+"]"
    with engine.connect() as conn:
        results = conn.execute(
            text(f"""
                SELECT doc_name, content,
                       1 - (embedding <=> '{query_emb_str}'::vector) AS similarity
                FROM {TABLE_NAME}
                ORDER BY embedding <=> '{query_emb_str}'::vector
                LIMIT :k
            """),
            {"k": top_k}
        ).fetchall()
    print("\n🔍 Top Matches:")
    for r in results:
        print(f"\n📄 {r.doc_name} | Similarity: {r.similarity:.3f}\n{r.content[:300]}...")
    return results



# ---------- STEP 5 (Optional): RAG with LLM ----------
def ask_llm(context, question):
    try:
        from langchain_openai import AzureChatOpenAI
        llm = AzureChatOpenAI(
            azure_endpoint="https://voice-assitant-openai.openai.azure.com/",
            api_key='FZCLpZV8bEetpSuhgMkt1Dt1xliAuFYubu04XuPemwgrJ35PnNsBJQQJ99BFACYeBjFXJ3w3AAABACOGNC1m',
            deployment_name="gpt-4.1-mini",
            api_version='2024-12-01-preview'
        )
        prompt = f"""
        Use the following context to answer the question:

        Context:
        {context}

        Question:
        {question}
        """
        response = llm.invoke(prompt).content
        print("\n🤖 LLM Answer:\n", response)
        return response
    except Exception as e:
        print("⚠️ LLM step skipped:", e)


# ---------- MAIN PIPELINE ----------
if __name__ == "__main__":
    engine = create_engine(DB_URI)
    #setup_database(engine)

    model = SentenceTransformer(EMBED_MODEL)
    """
    # Step A: Load all PDFs from folder
    for file in os.listdir(PDF_DIR):
        print(file)
        if file.lower().endswith(".pdf"):
            pdf_path = os.path.join(PDF_DIR, file)
            store_embeddings(engine, model, pdf_path)
    """
    # Step B: Run a sample query
    user_query = input("\nEnter your query: ")
    results = retrieve(engine, model, user_query, top_k=1)

    # Step C: Optional RAG response
    context = "\n".join([r.content for r in results])
    ask_llm(context, user_query)
