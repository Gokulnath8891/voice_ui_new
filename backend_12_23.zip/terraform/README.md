# Terraform Azure Infrastructure

This Terraform configuration creates Azure infrastructure for the Voice Assistant application with remote state storage in Azure Storage.

## Prerequisites

1. **Azure CLI**: Install and login to Azure
   ```bash
   az login
   ```

2. **Terraform**: Install Terraform >= 1.0

## Setup Instructions

### Step 1: Create State Storage (First Time Only)

Before using the main configuration, you need to create the Azure Storage for Terraform state:

```bash
# Initialize and apply the state storage setup
terraform init
terraform apply -target=azurerm_resource_group.terraform_state -target=azurerm_storage_account.terraform_state -target=azurerm_storage_container.terraform_state

# Get the storage account details
terraform output terraform_state_storage_account_name
terraform output terraform_state_access_key
```

### Step 2: Configure Backend

Update `backend.hcl` with the output values from Step 1:

```hcl
resource_group_name  = "terraform-state-rg"
storage_account_name = "<output_from_step_1>"
container_name       = "tfstate"
key                  = "voice-assistant/terraform.tfstate"
```

### Step 3: Configure Variables

Copy and customize the variables file:

```bash
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your values
```

### Step 4: Initialize with Remote Backend

```bash
# Remove local state and reinitialize with remote backend
rm -rf .terraform terraform.tfstate*
terraform init -backend-config="backend.hcl"
```

### Step 5: Deploy Infrastructure

```bash
# Plan the deployment
terraform plan

# Apply the configuration
terraform apply
```

## Resources Created

- **Resource Group**: Main resource group for all resources
- **Storage Account**: For application data, documents, and voice recordings
- **App Service Plan & App Service**: For hosting the voice assistant backend
- **PostgreSQL Flexible Server**: Database for application data
- **Key Vault**: For storing secrets and connection strings
- **Storage Containers**: Separate containers for documents and voice recordings

## Outputs

After deployment, you can get important information:

```bash
# Get all outputs
terraform output

# Get specific sensitive outputs
terraform output -raw postgresql_connection_string
terraform output -raw storage_connection_string
```

## Environment Variables for Application

Set these environment variables in your application:

```bash
STORAGE_ACCOUNT_NAME=$(terraform output -raw storage_account_name)
STORAGE_CONNECTION_STRING=$(terraform output -raw storage_connection_string)
POSTGRESQL_CONNECTION_STRING=$(terraform output -raw postgresql_connection_string)
```

## Clean Up

To destroy all resources:

```bash
terraform destroy
```

## Troubleshooting

1. **Storage account name conflicts**: The configuration uses random suffixes to avoid naming conflicts
2. **Authentication issues**: Ensure you're logged in with `az login`
3. **Permissions**: Your Azure account needs Contributor access to create resources

## File Structure

- `providers.tf`: Provider and Terraform configuration
- `variables.tf`: Input variables
- `main.tf`: Main infrastructure resources
- `outputs.tf`: Output values
- `backend.tf`: Backend configuration documentation
- `backend.hcl`: Backend configuration file
- `setup-state-storage.tf`: Initial state storage setup
- `terraform.tfvars.example`: Example variables file