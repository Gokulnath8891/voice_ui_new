#!/usr/bin/env python
"""
PDF Processing Test Script

Quick test script to validate PDF processing functionality.
"""

import os
import sys
from pathlib import Path

# Add Django project to path
project_root = Path(__file__).parent
sys.path.append(str(project_root))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'workorder_system.settings')
import django
django.setup()

from pdf_to_vectordb import PDFProcessor, PDFToVectorDB


def create_test_pdf_content():
    """Create a sample text that simulates PDF content for testing"""
    return """
    Machine Learning and Artificial Intelligence Guide
    
    Chapter 1: Introduction to Machine Learning
    
    Machine learning is a subset of artificial intelligence (AI) that focuses on the use of data and algorithms to imitate the way that humans learn, gradually improving its accuracy.
    
    Machine learning is an important component of the growing field of data science. Through the use of statistical methods, algorithms are trained to make classifications or predictions, and to uncover key insights in data mining projects.
    
    Chapter 2: Types of Machine Learning
    
    There are three main types of machine learning:
    
    1. Supervised Learning: Uses labeled datasets to train algorithms that to classify data or predict outcomes accurately.
    
    2. Unsupervised Learning: Uses machine learning algorithms to analyze and cluster unlabeled datasets.
    
    3. Reinforcement Learning: Uses rewards and punishments to learn optimal actions in a particular environment.
    
    Chapter 3: Deep Learning
    
    Deep learning is a subset of machine learning, which is essentially a neural network with three or more layers. These neural networks attempt to simulate the behavior of the human brain.
    
    Applications of deep learning include:
    - Computer vision
    - Natural language processing
    - Speech recognition
    - Recommendation systems
    """


def test_pdf_processor():
    """Test PDF processor functionality"""
    print("Testing PDF Processor...")
    
    # Create processor
    processor = PDFProcessor(chunk_size=500, chunk_overlap=100)
    
    # Test text chunking
    sample_text = create_test_pdf_content()
    metadata = {
        "title": "ML Guide",
        "author": "Test Author",
        "pages": 3,
        "word_count": len(sample_text.split())
    }
    
    chunks = processor.chunk_text(sample_text, metadata)
    
    print(f"Text chunking successful!")
    print(f"   Original text length: {len(sample_text)} characters")
    print(f"   Number of chunks: {len(chunks)}")
    print(f"   Average chunk size: {sum(len(c['content']) for c in chunks) // len(chunks)} characters")
    
    # Display first chunk
    if chunks:
        print(f"\nFirst chunk preview:")
        print(f"   Content: {chunks[0]['content'][:200]}...")
        print(f"   Metadata keys: {list(chunks[0]['metadata'].keys())}")
    
    return chunks


def test_vector_integration():
    """Test vector database integration"""
    print("\nTesting Vector Database Integration...")
    
    try:
        # Initialize processor
        processor = PDFToVectorDB(collection_name="test_collection")
        processor.initialize_vector_service()
        
        print("Vector service initialization successful!")
        
        # Get collection stats
        stats = processor.vector_service.get_collection_stats()
        print(f"   Collection: {stats.get('name', 'unknown')}")
        print(f"   Total documents: {stats.get('total_documents', 0)}")
        print(f"   Embedding model: {stats.get('embedding_model', 'unknown')}")
        
        return True
        
    except Exception as e:
        print(f"Vector database test failed: {e}")
        return False


def test_search_functionality():
    """Test search functionality with sample data"""
    print("\nTesting Search Functionality...")
    
    try:
        # Create test documents
        test_documents = [
            {
                'content': 'Machine learning is a method of data analysis that automates analytical model building.',
                'metadata': {'topic': 'machine_learning', 'source': 'test1'},
                'source': 'test_doc_1.txt',
                'source_type': 'text',
                'chunk_index': 0,
                'language': 'en'
            },
            {
                'content': 'Deep learning uses neural networks with multiple layers to model complex patterns in data.',
                'metadata': {'topic': 'deep_learning', 'source': 'test2'},
                'source': 'test_doc_2.txt',
                'source_type': 'text',
                'chunk_index': 0,
                'language': 'en'
            }
        ]
        
        # Initialize processor
        processor = PDFToVectorDB(collection_name="search_test_collection")
        processor.initialize_vector_service()
        
        # Add test documents
        added_count = processor.vector_service.add_documents(test_documents)
        print(f"Added {added_count} test documents")
        
        # Test search
        search_result = processor.vector_service.search_similar(
            "What is machine learning?",
            max_results=3,
            similarity_threshold=0.3
        )
        
        if search_result['status'] == 'success':
            print(f"Search test successful!")
            print(f"   Found {len(search_result['relevant_chunks'])} relevant chunks")
            print(f"   Processing time: {search_result['processing_time_ms']}ms")
            
            # Show top result
            if search_result['relevant_chunks']:
                top_result = search_result['relevant_chunks'][0]
                print(f"   Top result similarity: {top_result['similarity_score']:.3f}")
                print(f"   Content preview: {top_result['content'][:150]}...")
            
            return True
        else:
            print(f"Search failed: {search_result.get('error', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"Search functionality test failed: {e}")
        return False


def main():
    """Run all tests"""
    print("PDF Processing System Test Suite")
    print("="*50)
    
    test_results = []
    
    # Test 1: PDF Processor
    try:
        chunks = test_pdf_processor()
        test_results.append(("PDF Processor", True))
    except Exception as e:
        print(f"PDF Processor test failed: {e}")
        test_results.append(("PDF Processor", False))
    
    # Test 2: Vector Integration
    vector_ok = test_vector_integration()
    test_results.append(("Vector Integration", vector_ok))
    
    # Test 3: Search Functionality (only if vector integration works)
    if vector_ok:
        search_ok = test_search_functionality()
        test_results.append(("Search Functionality", search_ok))
    else:
        test_results.append(("Search Functionality", False))
        print("Skipping search test due to vector integration failure")
    
    # Summary
    print("\n" + "="*50)
    print("TEST RESULTS SUMMARY")
    print("="*50)
    
    for test_name, passed in test_results:
        status = "PASSED" if passed else "FAILED"
        print(f"{test_name:<25} {status}")
    
    passed_count = sum(1 for _, passed in test_results if passed)
    total_count = len(test_results)
    
    print(f"\nOverall: {passed_count}/{total_count} tests passed")
    
    if passed_count == total_count:
        print("All tests passed! System is ready for PDF processing.")
        return 0
    else:
        print("Some tests failed. Please check the error messages above.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)