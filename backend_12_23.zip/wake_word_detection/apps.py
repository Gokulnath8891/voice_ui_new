from django.apps import AppConfig


class WakeWordDetectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wake_word_detection'
    verbose_name = 'Wake Word Detection'

    def ready(self):
        """Initialize wake word detection when Django starts"""
        import wake_word_detection.signals