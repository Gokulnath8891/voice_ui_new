import azure.cognitiveservices.speech as speechsdk

speech_key = "1QD2Whn5LX4JPSORsLv7OP2zus76eJ86cLstg7zOLCHc3sVrqFYAJQQJ99BEACHYHv6XJ3w3AAAYACOGypYi"
region = "eastus2"
keyword_model_file = "2cd0bba2-bdfb-478c-8df7-383bbce3e3ff.table"
custom_model_endpoint = "8b77c65f-0e35-4993-a611-51d21413c7b0"

def start_keyword_detection():
    print('hi')
    audio_config = speechsdk.AudioConfig(use_default_microphone=True)
    keyword_model = speechsdk.KeywordRecognitionModel(keyword_model_file)
    recognizer = speechsdk.KeywordRecognizer(audio_config=audio_config)
    print("Listening for wake word 'Hey Buddy'...")
    result = recognizer.recognize_once_async(keyword_model).get()
    print(result.reason)
    if result.reason == speechsdk.ResultReason.RecognizedKeyword:
        print("Wake word detected!")
        start_custom_speech_recognition()
    else:
        print('not working')

def start_custom_speech_recognition():
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=region)
    speech_config.endpoint_id = custom_model_endpoint
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)
    print("Listening for your command...")
    result = recognizer.recognize_once_async().get()
    print(f"You said: {result.text}")

#start_keyword_detection()

from gtts import gTTS 
tts=gTTS("hello world")
tts.save("test.mp3")
print("OK!")

