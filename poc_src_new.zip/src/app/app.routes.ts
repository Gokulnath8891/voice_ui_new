import { Routes } from '@angular/router';
import { IgtChartComponent } from './igt-chart/igt-chart.component';

export const routes: Routes = [
  {
    path: '',
    component: IgtChartComponent,
    title: 'IGT Chart - Ignition, Timing, and Air-Fuel Ratio'
  },
  {
    path: 'igt-chart',
    component: IgtChartComponent,
    title: 'IGT Chart - Ignition, Timing, and Air-Fuel Ratio'
  },
  {
    path: '**',
    redirectTo: '/',
  },
];
