import { Injectable } from '@angular/core';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';

export interface ReportData {
  testInfo: {
    testName: string;
    testDate: string;
    testDuration: string;
    testBy: string;
    vehicleModel: string;
    batteryCapacity: string;
    softwareVersion: string;
  };
  testParameters: Array<{
    parameter: string;
    value: string;
    unit: string;
    status: string;
  }>;
  testResults: Array<{
    time: string;
    velocity: number;
    soc: number;
    current: number;
    torque: number;
    throttle: number;
  }>;
  chartImageData?: string;
}

@Injectable({
  providedIn: 'root'
})
export class PdfReportService {

  constructor() { }

  async generateReport(data: ReportData): Promise<void> {
    const doc = new jsPDF('p', 'mm', 'a4');
    let yPosition = 20;

    // Header
    this.addHeader(doc, yPosition);
    yPosition += 30;

    // Test Information Section
    yPosition = this.addTestInfo(doc, data.testInfo, yPosition);
    yPosition += 15;

    // Test Parameters Section
    yPosition = this.addTestParameters(doc, data.testParameters, yPosition);
    yPosition += 15;

    // Chart Section (if chart data is provided)
    if (data.chartImageData) {
      yPosition = await this.addChart(doc, data.chartImageData, yPosition);
      yPosition += 10;
    }

    // Add new page if needed for results table
    if (yPosition > 200) {
      doc.addPage();
      yPosition = 20;
    }

    // Test Results Table
    this.addTestResults(doc, data.testResults, yPosition);

    // Footer
    this.addFooter(doc);

    // Save the PDF
    const timestamp = new Date().toISOString().split('T')[0];
    doc.save(`EV_Performance_Report_${timestamp}.pdf`);
  }

  private addHeader(doc: jsPDF, yPosition: number): void {
    // Company/Test Lab Header
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Electric Vehicle Performance Test Report', 105, yPosition, { align: 'center' });
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('Advanced EV Testing Laboratory', 105, yPosition + 8, { align: 'center' });
    
    // Add a line separator
    doc.setLineWidth(0.5);
    doc.line(20, yPosition + 15, 190, yPosition + 15);
  }

  private addTestInfo(doc: jsPDF, testInfo: any, yPosition: number): number {
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Test Information', 20, yPosition);
    yPosition += 10;

    // Create test info table
    const testInfoData = [
      ['Test Name', testInfo.testName || 'EV Performance Analysis'],
      ['Test Date', testInfo.testDate || new Date().toLocaleDateString()],
      ['Duration', testInfo.testDuration || 'N/A'],
      ['Tested By', testInfo.testBy || 'Test Engineer'],
      ['Vehicle Model', testInfo.vehicleModel || 'Generic EV'],
      ['Battery Capacity', testInfo.batteryCapacity || 'N/A'],
      ['Software Version', testInfo.softwareVersion || 'v1.0.0']
    ];

    autoTable(doc, {
      startY: yPosition,
      head: [['Parameter', 'Value']],
      body: testInfoData,
      theme: 'striped',
      headStyles: { fillColor: [41, 128, 185], textColor: 255 },
      columnStyles: {
        0: { cellWidth: 60, fontStyle: 'bold' },
        1: { cellWidth: 100 }
      },
      margin: { left: 20, right: 20 }
    });

    return (doc as any).lastAutoTable.finalY + 10;
  }

  private addTestParameters(doc: jsPDF, parameters: any[], yPosition: number): number {
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Test Parameters', 20, yPosition);
    yPosition += 10;

    // Default parameters if none provided
    const defaultParams = [
      { parameter: 'Test Condition', value: '0-100 km/h', unit: 'km/h', status: 'PASS' },
      { parameter: 'Speed Range', value: '0-120', unit: 'km/h', status: 'PASS' },
      { parameter: 'Load Condition', value: 'Heavy 80%', unit: '%', status: 'PASS' },
      { parameter: 'Temperature', value: '25', unit: '°C', status: 'PASS' },
      { parameter: 'Battery SoC', value: '80-20', unit: '%', status: 'PASS' }
    ];

    const paramData = (parameters.length > 0 ? parameters : defaultParams).map(param => [
      param.parameter,
      param.value,
      param.unit,
      param.status
    ]);

    autoTable(doc, {
      startY: yPosition,
      head: [['Parameter', 'Value', 'Unit', 'Status']],
      body: paramData,
      theme: 'striped',
      headStyles: { fillColor: [52, 152, 219], textColor: 255 },
      columnStyles: {
        0: { cellWidth: 50 },
        1: { cellWidth: 40 },
        2: { cellWidth: 30 },
        3: { 
          cellWidth: 40,
          fontStyle: 'bold'
        }
      },
      didParseCell: (data: any) => {
        if (data.column.index === 3 && data.cell.text[0] === 'PASS') {
          data.cell.styles.textColor = [0, 128, 0]; // Green for PASS
        } else if (data.column.index === 3 && data.cell.text[0] === 'FAIL') {
          data.cell.styles.textColor = [255, 0, 0]; // Red for FAIL
        }
      },
      margin: { left: 20, right: 20 }
    });

    return (doc as any).lastAutoTable.finalY + 10;
  }

  private async addChart(doc: jsPDF, chartImageData: string, yPosition: number): Promise<number> {
    try {
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('Performance Chart', 20, yPosition);
      yPosition += 10;

      // Add chart image
      const imgWidth = 170;
      const imgHeight = 100;
      
      doc.addImage(chartImageData, 'PNG', 20, yPosition, imgWidth, imgHeight);
      
      return yPosition + imgHeight + 10;
    } catch (error) {
      console.error('Error adding chart to PDF:', error);
      return yPosition;
    }
  }

  private addTestResults(doc: jsPDF, results: any[], yPosition: number): void {
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Test Results Data', 20, yPosition);
    yPosition += 10;

    // Prepare results data
    const resultsData = results.slice(0, 20).map((result, index) => [
      result.time || `${index * 5}s`,
      result.velocity?.toFixed(1) || '0.0',
      result.soc?.toFixed(1) || '0.0',
      result.current?.toFixed(2) || '0.00',
      result.torque?.toFixed(1) || '0.0',
      result.throttle?.toFixed(1) || '0.0'
    ]);

    autoTable(doc, {
      startY: yPosition,
      head: [['Time', 'Velocity (km/h)', 'SoC (%)', 'Current (A)', 'Torque (Nm)', 'Throttle (%)']],
      body: resultsData,
      theme: 'striped',
      headStyles: { fillColor: [155, 89, 182], textColor: 255 },
      styles: { fontSize: 8 },
      columnStyles: {
        0: { cellWidth: 25 },
        1: { cellWidth: 30 },
        2: { cellWidth: 25 },
        3: { cellWidth: 30 },
        4: { cellWidth: 30 },
        5: { cellWidth: 30 }
      },
      margin: { left: 20, right: 20 }
    });

    if (results.length > 20) {
      const finalY = (doc as any).lastAutoTable.finalY;
      doc.setFontSize(10);
      doc.setFont('helvetica', 'italic');
      doc.text(`Note: Showing first 20 of ${results.length} data points`, 20, finalY + 10);
    }
  }

  private addFooter(doc: jsPDF): void {
    const pageCount = doc.getNumberOfPages();
    
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      
      // Footer line
      doc.setLineWidth(0.3);
      doc.line(20, 280, 190, 280);
      
      // Footer text
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text('Generated by EV Performance Testing System', 20, 285);
      doc.text(`Generated on: ${new Date().toLocaleString()}`, 20, 290);
      doc.text(`Page ${i} of ${pageCount}`, 190, 290, { align: 'right' });
      
      // Confidential notice
      doc.setFont('helvetica', 'bold');
      doc.text('CONFIDENTIAL', 105, 290, { align: 'center' });
    }
  }

  async captureChartAsImage(chartElement: HTMLElement): Promise<string> {
    try {
      const canvas = await html2canvas(chartElement, {
        backgroundColor: '#ffffff',
        scale: 2,
        logging: false,
        useCORS: true
      });
      return canvas.toDataURL('image/png');
    } catch (error) {
      console.error('Error capturing chart:', error);
      return '';
    }
  }

  // Method to generate CSV data for detailed analysis
  generateCSVData(results: any[]): string {
    const headers = ['Time', 'Velocity (km/h)', 'SoC (%)', 'Current (A)', 'Torque (Nm)', 'Throttle (%)'];
    const csvContent = [
      headers.join(','),
      ...results.map((result, index) => [
        result.time || `${index * 5}s`,
        result.velocity?.toFixed(1) || '0.0',
        result.soc?.toFixed(1) || '0.0',
        result.current?.toFixed(2) || '0.00',
        result.torque?.toFixed(1) || '0.0',
        result.throttle?.toFixed(1) || '0.0'
      ].join(','))
    ].join('\n');

    return csvContent;
  }

  downloadCSV(csvContent: string, filename?: string): void {
    const timestamp = new Date().toISOString().split('T')[0];
    const csvFilename = filename || `EV_Performance_Data_${timestamp}.csv`;
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', csvFilename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }
}