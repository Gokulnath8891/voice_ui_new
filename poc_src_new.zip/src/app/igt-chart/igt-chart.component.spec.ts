import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IgtChartComponent } from './igt-chart.component';

describe('IgtChartComponent', () => {
  let component: IgtChartComponent;
  let fixture: ComponentFixture<IgtChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [IgtChartComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(IgtChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have default test conditions', () => {
    expect(component.testConditions.length).toBeGreaterThan(0);
  });

  it('should generate chart after view init', () => {
    spyOn(component, 'generateChart');
    component.ngAfterViewInit();
    expect(component.generateChart).toHaveBeenCalled();
  });
});
