import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import * as ExcelJS from 'exceljs';
import { TelemetryRow } from '../models/telemetry-row';

@Injectable({
  providedIn: 'root'
})
export class TelemetryExcelService {
  constructor(private http: HttpClient) {}

  /**
   * Load and parse telemetry data from Excel file
   */
  loadTelemetryDataPromise(filePath: string): Observable<TelemetryRow[]> {
    return new Observable(observer => {
      this.http.get(filePath, { responseType: 'arraybuffer' }).subscribe({
        next: async (buffer) => {
          try {
            const data = await this.parseExcelAsync(buffer);
            observer.next(data);
            observer.complete();
          } catch (error) {
            observer.error(error);
          }
        },
        error: (err) => observer.error(err)
      });
    });
  }

  private async parseExcelAsync(buffer: ArrayBuffer): Promise<TelemetryRow[]> {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);

    const worksheet = workbook.worksheets[0];
    if (!worksheet) {
      throw new Error('No worksheet found in Excel file');
    }

    const rows: TelemetryRow[] = [];
    const headers: string[] = [];

    // Read header row
    const headerRow = worksheet.getRow(1);
    headerRow.eachCell((cell, colNumber) => {
      headers[colNumber - 1] = String(cell.value).trim().toLowerCase();
    });

    // Process data rows
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header

      const rowData: any = {};
      row.eachCell((cell, colNumber) => {
        const header = headers[colNumber - 1];
        if (header) {
          rowData[header] = cell.value;
        }
      });

      const telemetryRow = this.normalizeRow(rowData);
      if (telemetryRow.vehicle_id) {
        rows.push(telemetryRow);
      }
    });

    return rows;
  }

  private normalizeRow(rawRow: any): TelemetryRow {
    return {
      vehicle_id: String(rawRow['vehicle_id'] || rawRow['vehicle id'] || ''),
      timestamp: this.parseTimestamp(rawRow['timestamp'] || rawRow['time']),
      engine_rpm: this.parseNumber(rawRow['engine_rpm'] || rawRow['engine rpm'] || rawRow['rpm']),
      vehicle_speed_kph: this.parseNumber(rawRow['vehicle_speed_kph'] || rawRow['vehicle speed'] || rawRow['speed']),
      wheel_speed_fl_kph: this.parseNumber(rawRow['wheel_speed_fl_kph'] || rawRow['wheel_fl'] || rawRow['fl_speed']),
      wheel_speed_fr_kph: this.parseNumber(rawRow['wheel_speed_fr_kph'] || rawRow['wheel_fr'] || rawRow['fr_speed']),
      wheel_speed_rl_kph: this.parseNumber(rawRow['wheel_speed_rl_kph'] || rawRow['wheel_rl'] || rawRow['rl_speed']),
      wheel_speed_rr_kph: this.parseNumber(rawRow['wheel_speed_rr_kph'] || rawRow['wheel_rr'] || rawRow['rr_speed']),
      brake_temp_c: this.parseNumber(rawRow['brake_temp_c'] || rawRow['brake_temp'] || rawRow['brake temperature']),
      brake_pedal_pos_percent: this.parseNumber(rawRow['brake_pedal_pos_percent'] || rawRow['brake_pedal'] || rawRow['pedal_position']),
      abs_fault_indicator: this.parseNumber(rawRow['abs_fault_indicator'] || rawRow['abs_fault'] || rawRow['abs']),
      failure_type: rawRow['failure_type'] || rawRow['failure'] || null,
      failure_date: this.parseTimestamp(rawRow['failure_date'] || rawRow['failure_time'])
    };
  }

  private parseTimestamp(value: any): Date {
    if (!value) return new Date();
    if (value instanceof Date) return value;
    if (typeof value === 'string') return new Date(value);
    // Excel serial date
    if (typeof value === 'number') {
      const date = new Date((value - 25569) * 86400 * 1000);
      return date;
    }
    return new Date();
  }

  private parseNumber(value: any): number | undefined {
    if (value === null || value === undefined || value === '') return undefined;
    const num = Number(value);
    return isNaN(num) ? undefined : num;
  }
}
