import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChartsPocComponent } from './charts-poc.component';

const routes: Routes = [
  {
    path: '',
    component: ChartsPocComponent,
    title: 'Performance Analysis - Charts POC'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChartsPocRoutingModule {}
