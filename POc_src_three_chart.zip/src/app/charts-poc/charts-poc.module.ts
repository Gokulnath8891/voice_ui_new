import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PlotlyModule } from 'angular-plotly.js';

// PrimeNG Modules
import { DropdownModule } from 'primeng/dropdown';
import { InputNumberModule } from 'primeng/inputnumber';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { ChartsPocRoutingModule } from './charts-poc-routing.module';
import { ChartsPocComponent } from './charts-poc.component';
import { TelemetryExcelService } from './services/telemetry-excel.service';

@NgModule({
  declarations: [
    ChartsPocComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule,
    PlotlyModule,
    ChartsPocRoutingModule,
    // PrimeNG
    DropdownModule,
    InputNumberModule,
    CheckboxModule,
    InputTextModule,
    MessageModule,
    ProgressSpinnerModule
  ],
  providers: [
    TelemetryExcelService
  ]
})
export class ChartsPocModule {}
