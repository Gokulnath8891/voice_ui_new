import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { debounceTime, Subject, takeUntil } from 'rxjs';
import { PlotlyModule } from 'angular-plotly.js';

// PrimeNG Modules
import { DropdownModule } from 'primeng/dropdown';
import { InputNumberModule } from 'primeng/inputnumber';
import { CheckboxModule } from 'primeng/checkbox';
import { MessageModule } from 'primeng/message';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { TelemetryExcelService } from './services/telemetry-excel.service';
import { TelemetryRow } from './models/telemetry-row';

interface DropdownOption {
  label: string;
  value: string;
}

@Component({
  selector: 'app-charts-poc',
  standalone: false,
  templateUrl: './charts-poc.component.html',
  styleUrls: ['./charts-poc.component.css']
})
export class ChartsPocComponent implements OnInit, OnDestroy {
  filterForm!: FormGroup;
  allData: TelemetryRow[] = [];
  filteredData: TelemetryRow[] = [];
  loading = true;
  error = '';

  vehicleOptions: DropdownOption[] = [];

  metricOptions: DropdownOption[] = [
    { label: 'Engine RPM', value: 'engine_rpm' },
    { label: 'Vehicle Speed (km/h)', value: 'vehicle_speed_kph' },
    { label: 'Wheel Speed FL (km/h)', value: 'wheel_speed_fl_kph' },
    { label: 'Wheel Speed FR (km/h)', value: 'wheel_speed_fr_kph' },
    { label: 'Wheel Speed RL (km/h)', value: 'wheel_speed_rl_kph' },
    { label: 'Wheel Speed RR (km/h)', value: 'wheel_speed_rr_kph' },
    { label: 'Brake Temperature (°C)', value: 'brake_temp_c' },
    { label: 'Brake Pedal Position (%)', value: 'brake_pedal_pos_percent' }
  ];

  contourModeOptions: DropdownOption[] = [
    { label: 'Time Series (Time vs Metric)', value: 'timeseries' },
    { label: 'Metric Correlation (Metric vs Metric)', value: 'correlation' }
  ];

  // Chart data
  barChartData: any = [];
  barChartLayout: any = {};
  barChartConfig: any = { responsive: true, displayModeBar: true };
  
  contourChartData: any = [];
  contourChartLayout: any = {};
  contourChartConfig: any = { responsive: true, displayModeBar: true };

  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private excelService: TelemetryExcelService
  ) {
    // Initialize with empty layout to prevent undefined errors
    this.barChartLayout = {
      title: 'Loading...',
      xaxis: { title: 'Time (Seconds)' },
      yaxis: { title: 'Metric Values' },
      height: 400
    };
    this.contourChartLayout = {
      title: 'Loading...',
      xaxis: { title: 'X-Axis' },
      yaxis: { title: 'Y-Axis' },
      height: 400
    };
  }

  ngOnInit(): void {
    this.initializeForm();
    this.loadData();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  initializeForm(): void {
    this.filterForm = this.fb.group({
      vehicleId: [''],
      resolution: [10],
      minSpeed: [null],
      maxSpeed: [null],
      minRpm: [null],
      maxRpm: [null],
      barMetric1: ['engine_rpm'],
      barMetric2: ['vehicle_speed_kph'],
      barMetric3: ['brake_temp_c'],
      contourMode: ['timeseries'],
      contourMetricX: ['engine_rpm'],
      contourMetricY: ['vehicle_speed_kph']
    });

    this.filterForm.valueChanges
      .pipe(debounceTime(150), takeUntil(this.destroy$))
      .subscribe(() => {
        this.applyFilters();
      });
  }

  loadData(): void {
    this.loading = true;
    this.error = '';

    this.excelService.loadTelemetryDataPromise('assets/telemetry_10ms_interval.xlsx').subscribe({
      next: (data) => {
        this.allData = data;
        this.filteredData = data;
        this.extractVehicleOptions();
        this.loading = false;
        this.updateCharts();
      },
      error: (err) => {
        this.error = `Failed to load data: ${err.message}`;
        this.loading = false;
      }
    });
  }

  extractVehicleOptions(): void {
    const uniqueVehicles = [...new Set(this.allData.map(row => row.vehicle_id))];
    this.vehicleOptions = uniqueVehicles.map(id => ({
      label: `Vehicle ${id}`,
      value: id
    }));

    if (this.vehicleOptions.length > 0) {
      this.filterForm.patchValue({ vehicleId: this.vehicleOptions[0].value }, { emitEvent: false });
    }
  }

  applyFilters(): void {
    const formValues = this.filterForm.value;
    let filtered = [...this.allData];

    // Vehicle filter
    if (formValues.vehicleId) {
      filtered = filtered.filter(row => row.vehicle_id === formValues.vehicleId);
    }

    // Speed range
    if (formValues.minSpeed !== null && formValues.minSpeed !== undefined) {
      filtered = filtered.filter(row => (row.vehicle_speed_kph || 0) >= formValues.minSpeed);
    }
    if (formValues.maxSpeed !== null && formValues.maxSpeed !== undefined) {
      filtered = filtered.filter(row => (row.vehicle_speed_kph || 0) <= formValues.maxSpeed);
    }

    // RPM range
    if (formValues.minRpm !== null && formValues.minRpm !== undefined) {
      filtered = filtered.filter(row => (row.engine_rpm || 0) >= formValues.minRpm);
    }
    if (formValues.maxRpm !== null && formValues.maxRpm !== undefined) {
      filtered = filtered.filter(row => (row.engine_rpm || 0) <= formValues.maxRpm);
    }

    // Downsample
    const resolution = formValues.resolution || 1;
    if (resolution > 1) {
      filtered = filtered.filter((_, index) => index % resolution === 0);
    }

    this.filteredData = filtered;
    this.updateCharts();
  }

  updateCharts(): void {
    // Update both charts synchronously
    this.updateBarChart();
    this.updateContourChart();
  }

  updateBarChart(): void {
    if (!this.filteredData || this.filteredData.length === 0) {
      this.barChartData = [];
      this.barChartLayout = {
        title: 'No data available',
        xaxis: { title: 'Time (Seconds)' },
        yaxis: { title: 'Metric Values' },
        height: 400
      };
      return;
    }

    try {
      const formValues = this.filterForm?.value;
      if (!formValues) {
        console.error('Form values not available');
        return;
      }

      const metric1 = formValues.barMetric1;
      const metric2 = formValues.barMetric2;
      const metric3 = formValues.barMetric3;

      if (!metric1 || !metric2 || !metric3) {
        console.error('Bar chart metrics not selected');
        return;
      }

      // Calculate seconds from first timestamp
      const firstTimestamp = this.filteredData[0]?.timestamp?.getTime();
      if (!firstTimestamp) {
        console.error('Invalid timestamp data');
        return;
      }

      const xLabels = this.filteredData.map(row => {
        const diffMs = row.timestamp.getTime() - firstTimestamp;
        return Math.floor(diffMs / 1000); // Absolute seconds
      });

      // Aggregate data into time bins (every N seconds)
      const binSize = 5; // 5 second bins
      const bins: { [key: number]: { values1: number[], values2: number[], values3: number[] } } = {};

      this.filteredData.forEach((row, idx) => {
        const seconds = xLabels[idx];
        const binKey = Math.floor(seconds / binSize) * binSize;

        if (!bins[binKey]) {
          bins[binKey] = { values1: [], values2: [], values3: [] };
        }

        // Safely access properties with fallback
        const val1 = row.hasOwnProperty(metric1) ? (row as any)[metric1] : null;
        const val2 = row.hasOwnProperty(metric2) ? (row as any)[metric2] : null;
        const val3 = row.hasOwnProperty(metric3) ? (row as any)[metric3] : null;

        // Validate and push values
        if (val1 !== undefined && val1 !== null && !isNaN(Number(val1)) && isFinite(Number(val1))) {
          bins[binKey].values1.push(Number(val1));
        }
        if (val2 !== undefined && val2 !== null && !isNaN(Number(val2)) && isFinite(Number(val2))) {
          bins[binKey].values2.push(Number(val2));
        }
        if (val3 !== undefined && val3 !== null && !isNaN(Number(val3)) && isFinite(Number(val3))) {
          bins[binKey].values3.push(Number(val3));
        }
      });

      // Calculate min/max/avg for each bin
      const binKeys = Object.keys(bins).map(Number).sort((a, b) => a - b);
      
      if (binKeys.length === 0) {
        this.barChartData = [];
        this.barChartLayout = {
          title: 'No valid data in selected range',
          xaxis: { title: 'Time (Seconds)' },
          yaxis: { title: 'Metric Values' }
        };
        return;
      }

      const xBinLabels = binKeys.map(k => `${k}s`);

      const getStats = (values: number[]) => {
        if (!values || values.length === 0) return { min: 0, max: 0, avg: 0 };
        
        // Filter out any remaining invalid values
        const validValues = values.filter(v => v !== null && v !== undefined && !isNaN(v) && isFinite(v));
        
        if (validValues.length === 0) return { min: 0, max: 0, avg: 0 };
        
        const min = Math.min(...validValues);
        const max = Math.max(...validValues);
        const avg = validValues.reduce((sum, v) => sum + v, 0) / validValues.length;
        
        // Ensure results are valid
        return { 
          min: isFinite(min) ? min : 0, 
          max: isFinite(max) ? max : 0, 
          avg: isFinite(avg) ? avg : 0 
        };
      };

      const stats1 = binKeys.map(k => getStats(bins[k].values1));
      const stats2 = binKeys.map(k => getStats(bins[k].values2));
      const stats3 = binKeys.map(k => getStats(bins[k].values3));

      const metric1Label = this.metricOptions.find(m => m.value === metric1)?.label || metric1;
      const metric2Label = this.metricOptions.find(m => m.value === metric2)?.label || metric2;
      const metric3Label = this.metricOptions.find(m => m.value === metric3)?.label || metric3;

      // Validate stats arrays before creating chart data
      const validateStatsArray = (stats: any[]) => {
        return stats.every(s => 
          s && 
          typeof s.min === 'number' && isFinite(s.min) &&
          typeof s.max === 'number' && isFinite(s.max) &&
          typeof s.avg === 'number' && isFinite(s.avg)
        );
      };

      if (!validateStatsArray(stats1) || !validateStatsArray(stats2) || !validateStatsArray(stats3)) {
        console.error('Invalid statistics calculated for bar chart');
        this.barChartData = [];
        this.barChartLayout = {
          title: 'Error: Invalid data for selected metrics',
          xaxis: { title: 'Time (Seconds)' },
          yaxis: { title: 'Metric Values' },
          height: 400
        };
        return;
      }

      this.barChartData = [
        // Metric 1 - Min/Max/Avg
        {
          x: xBinLabels,
          y: stats1.map(s => s.min),
          type: 'bar',
          name: `${metric1Label} (Min)`,
          marker: { color: 'rgba(31, 119, 180, 0.6)' }
        },
        {
          x: xBinLabels,
          y: stats1.map(s => s.avg),
          type: 'bar',
          name: `${metric1Label} (Avg)`,
          marker: { color: 'rgba(31, 119, 180, 0.8)' }
        },
        {
          x: xBinLabels,
          y: stats1.map(s => s.max),
          type: 'bar',
          name: `${metric1Label} (Max)`,
          marker: { color: 'rgba(31, 119, 180, 1.0)' }
        },
      // Metric 2
      {
        x: xBinLabels,
        y: stats2.map(s => s.min),
        type: 'bar',
        name: `${metric2Label} (Min)`,
        marker: { color: 'rgba(255, 127, 14, 0.6)' }
      },
      {
        x: xBinLabels,
        y: stats2.map(s => s.avg),
        type: 'bar',
        name: `${metric2Label} (Avg)`,
        marker: { color: 'rgba(255, 127, 14, 0.8)' }
      },
      {
        x: xBinLabels,
        y: stats2.map(s => s.max),
        type: 'bar',
        name: `${metric2Label} (Max)`,
        marker: { color: 'rgba(255, 127, 14, 1.0)' }
      },
      // Metric 3
      {
        x: xBinLabels,
        y: stats3.map(s => s.min),
        type: 'bar',
        name: `${metric3Label} (Min)`,
        marker: { color: 'rgba(44, 160, 44, 0.6)' }
      },
      {
        x: xBinLabels,
        y: stats3.map(s => s.avg),
        type: 'bar',
        name: `${metric3Label} (Avg)`,
        marker: { color: 'rgba(44, 160, 44, 0.8)' }
      },
      {
        x: xBinLabels,
        y: stats3.map(s => s.max),
        type: 'bar',
        name: `${metric3Label} (Max)`,
        marker: { color: 'rgba(44, 160, 44, 1.0)' }
      }
    ];

    this.barChartLayout = {
      title: {
        text: 'Performance Analysis - Min/Max/Avg (5s bins)',
        font: { size: 14, family: 'Arial' },
        x: 0.02
      },
      xaxis: {
        title: 'Time (Seconds)',
        font: { size: 11 }
      },
      yaxis: {
        title: 'Metric Values',
        font: { size: 11 }
      },
      barmode: 'group',
      showlegend: true,
      legend: {
        x: 0.5,
        y: 1.15,
        xanchor: 'center',
        yanchor: 'top',
        orientation: 'h',
        font: { size: 9 }
      },
      margin: { l: 70, r: 50, t: 120, b: 60 },
      plot_bgcolor: '#FFFFFF',
      paper_bgcolor: '#FFFFFF'
    };
    
    // Force Angular change detection by creating new array reference
    this.barChartData = [...this.barChartData];
    
    } catch (error) {
      console.error('Error updating bar chart:', error);
      this.barChartData = [];
      this.barChartLayout = {
        title: 'Error loading chart',
        xaxis: { title: 'Time (Seconds)' },
        yaxis: { title: 'Metric Values' },
        height: 400
      };
    }
  }

  updateContourChart(): void {
    if (!this.filteredData || this.filteredData.length === 0) {
      this.contourChartData = [];
      this.contourChartLayout = {
        title: 'No data available',
        xaxis: { title: 'X-Axis' },
        yaxis: { title: 'Y-Axis' },
        height: 400
      };
      return;
    }

    try {
      const formValues = this.filterForm?.value;
      if (!formValues) {
        console.error('Form values not available');
        return;
      }

      const mode = formValues.contourMode;

      if (mode === 'timeseries') {
        this.createTimeSeriesContour();
      } else {
        this.createCorrelationContour();
      }
    } catch (error) {
      console.error('Error updating contour chart:', error);
      this.contourChartData = [];
      this.contourChartLayout = {
        title: 'Error loading chart',
        xaxis: { title: 'X-Axis' },
        yaxis: { title: 'Y-Axis' },
        height: 400
      };
    }
  }

  createTimeSeriesContour(): void {
    if (!this.filteredData || this.filteredData.length === 0) {
      console.error('No filtered data for timeseries contour');
      return;
    }

    const formValues = this.filterForm?.value;
    if (!formValues) {
      console.error('Form values not available');
      return;
    }

    const metricY = formValues.contourMetricY;
    if (!metricY) {
      console.error('Contour Y metric not selected');
      return;
    }

    // Calculate seconds
    const firstTimestamp = this.filteredData[0]?.timestamp?.getTime();
    if (!firstTimestamp) {
      console.error('Invalid timestamp data');
      return;
    }

    const xData = this.filteredData.map(row => {
      const diffMs = row.timestamp.getTime() - firstTimestamp;
      return Math.floor(diffMs / 1000);
    });

    const yData = this.filteredData.map(row => {
      const val = (row as any)[metricY];
      return (val !== undefined && val !== null && !isNaN(val)) ? val : null;
    });

    // Filter out any invalid data
    const validData = xData.map((x, i) => ({ x, y: yData[i] })).filter(d => 
      !isNaN(d.x) && d.y !== null && !isNaN(d.y)
    );
    
    if (validData.length === 0) {
      this.contourChartData = [];
      this.contourChartLayout = {
        title: 'No valid data for contour',
        xaxis: { title: 'Time (Seconds)' },
        yaxis: { title: 'Metric' }
      };
      return;
    }

    // Create bins for contour
    const binSize = 2; // 2 second bins
    const maxSeconds = Math.max(...validData.map(d => d.x));
    const numBins = Math.max(1, Math.ceil(maxSeconds / binSize));

    const zMatrix: number[][] = [];
    const xBins: number[] = [];
    const yBins: number[] = [];

    // Create Y bins
    const allYValues = validData.map(d => d.y);
    const minY = Math.min(...allYValues);
    const maxY = Math.max(...allYValues);
    const range = maxY - minY;
    const yBinSize = range > 0 ? range / 20 : 1; // 20 bins for Y

    for (let i = 0; i <= 20; i++) {
      yBins.push(minY + i * yBinSize);
    }

    // Create X bins and Z matrix
    for (let i = 0; i <= numBins; i++) {
      xBins.push(i * binSize);
      zMatrix.push(new Array(yBins.length).fill(0));
    }

    // Fill Z matrix with data density
    validData.forEach(d => {
      const xBinIdx = Math.floor(d.x / binSize);
      const yBinIdx = yBinSize > 0 ? Math.floor((d.y - minY) / yBinSize) : 0;

      if (xBinIdx >= 0 && xBinIdx < zMatrix.length && yBinIdx >= 0 && yBinIdx < yBins.length) {
        zMatrix[xBinIdx][yBinIdx]++;
      }
    });

    const metricLabel = this.metricOptions.find(m => m.value === formValues.contourMetricY)?.label || '';

    this.contourChartData = [{
      x: xBins,
      y: yBins,
      z: zMatrix,
      type: 'contour',
      colorscale: [
        [0, 'rgb(255, 237, 160)'],
        [0.25, 'rgb(254, 217, 118)'],
        [0.5, 'rgb(254, 178, 76)'],
        [0.75, 'rgb(253, 141, 60)'],
        [1, 'rgb(227, 26, 28)']
      ],
      colorbar: {
        title: 'Density',
        titleside: 'right',
        titlefont: { size: 10 }
      }
    }];

    this.contourChartLayout = {
      title: {
        text: `Performance Contour: ${metricLabel} over Time`,
        font: { size: 14, family: 'Arial' },
        x: 0.02
      },
      xaxis: {
        title: 'Time (Seconds)',
        font: { size: 11 }
      },
      yaxis: {
        title: metricLabel,
        font: { size: 11 }
      },
      margin: { l: 70, r: 100, t: 100, b: 60 },
      plot_bgcolor: '#FFFFFF',
      paper_bgcolor: '#FFFFFF'
    };
  }

  createCorrelationContour(): void {
    if (!this.filteredData || this.filteredData.length === 0) {
      console.error('No filtered data for correlation contour');
      return;
    }

    const formValues = this.filterForm?.value;
    if (!formValues) {
      console.error('Form values not available');
      return;
    }

    const metricX = formValues.contourMetricX;
    const metricY = formValues.contourMetricY;

    if (!metricX || !metricY) {
      console.error('Contour metrics not selected');
      return;
    }

    const xData = this.filteredData.map(row => {
      const val = (row as any)[metricX];
      return (val !== undefined && val !== null && !isNaN(val)) ? val : null;
    });
    
    const yData = this.filteredData.map(row => {
      const val = (row as any)[metricY];
      return (val !== undefined && val !== null && !isNaN(val)) ? val : null;
    });

    // Filter valid data - exclude null values
    const validData = xData.map((x, i) => ({ x, y: yData[i] }))
      .filter(d => d.x !== null && d.y !== null && !isNaN(d.x) && !isNaN(d.y) && d.x !== 0 && d.y !== 0);

    if (validData.length === 0) {
      this.contourChartData = [];
      this.contourChartLayout = {
        title: 'No valid data for correlation',
        xaxis: { title: 'X Metric' },
        yaxis: { title: 'Y Metric' },
        height: 400
      };
      return;
    }

    // Create 2D histogram
    const allXValues = validData.map(d => d.x);
    const allYValues = validData.map(d => d.y);
    const minX = Math.min(...allXValues);
    const maxX = Math.max(...allXValues);
    const minY = Math.min(...allYValues);
    const maxY = Math.max(...allYValues);

    const rangeX = maxX - minX;
    const rangeY = maxY - minY;
    
    if (rangeX === 0 || rangeY === 0) {
      this.contourChartData = [];
      this.contourChartLayout = {
        title: 'Insufficient data variation',
        xaxis: { title: 'X Metric' },
        yaxis: { title: 'Y Metric' }
      };
      return;
    }

    const numBins = 20;
    const xBinSize = rangeX / numBins;
    const yBinSize = rangeY / numBins;

    const xBins: number[] = [];
    const yBins: number[] = [];
    const zMatrix: number[][] = [];

    for (let i = 0; i <= numBins; i++) {
      xBins.push(minX + i * xBinSize);
      yBins.push(minY + i * yBinSize);
      zMatrix.push(new Array(numBins + 1).fill(0));
    }

    // Fill matrix
    validData.forEach(d => {
      const xBinIdx = Math.floor((d.x - minX) / xBinSize);
      const yBinIdx = Math.floor((d.y - minY) / yBinSize);

      if (xBinIdx >= 0 && xBinIdx < zMatrix.length && yBinIdx >= 0 && yBinIdx < yBins.length) {
        zMatrix[xBinIdx][yBinIdx]++;
      }
    });

    const metricXLabel = this.metricOptions.find(m => m.value === metricX)?.label || '';
    const metricYLabel = this.metricOptions.find(m => m.value === metricY)?.label || '';

    this.contourChartData = [{
      x: xBins,
      y: yBins,
      z: zMatrix,
      type: 'contour',
      colorscale: [
        [0, 'rgb(255, 237, 160)'],
        [0.25, 'rgb(254, 217, 118)'],
        [0.5, 'rgb(254, 178, 76)'],
        [0.75, 'rgb(253, 141, 60)'],
        [1, 'rgb(227, 26, 28)']
      ],
      colorbar: {
        title: 'Density',
        titleside: 'right',
        titlefont: { size: 10 }
      }
    }];

    this.contourChartLayout = {
      title: {
        text: `Correlation Analysis: ${metricXLabel} vs ${metricYLabel}`,
        font: { size: 14, family: 'Arial' },
        x: 0.02
      },
      xaxis: {
        title: metricXLabel,
        font: { size: 11 }
      },
      yaxis: {
        title: metricYLabel,
        font: { size: 11 }
      },
      margin: { l: 70, r: 100, t: 100, b: 60 },
      plot_bgcolor: '#FFFFFF',
      paper_bgcolor: '#FFFFFF'
    };
  }
}
