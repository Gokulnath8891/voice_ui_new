import { Routes } from '@angular/router';
import { IgtChartComponent } from './igt-chart/igt-chart.component';

export const routes: Routes = [
  {
    path: '',
    component: IgtChartComponent,
    title: 'IGT Chart - Ignition, Timing, and Air-Fuel Ratio'
  },
  {
    path: 'igt-chart',
    component: IgtChartComponent,
    title: 'IGT Chart - Ignition, Timing, and Air-Fuel Ratio'
  },
  {
    path: 'charts-poc',
    loadChildren: () => import('./charts-poc/charts-poc.module').then(m => m.ChartsPocModule),
    title: 'Charts POC - Telemetry Analysis'
  },
  {
    path: 'telemetry-dashboard',
    loadChildren: () => import('./telemetry-dashboard/telemetry-dashboard.module').then(m => m.TelemetryDashboardModule),
    title: 'Telemetry Dashboard - Multi-Axis Analysis'
  },
  {
    path: '**',
    redirectTo: '/',
  },
];
