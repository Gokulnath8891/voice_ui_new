import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as Plotly from 'plotly.js-dist-min';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DividerModule } from 'primeng/divider';
import { FormsModule } from '@angular/forms';
import { MessageModule } from 'primeng/message';
import { TooltipModule } from 'primeng/tooltip';
import { ChipModule } from 'primeng/chip';
import { PdfReportService, ReportData } from './pdf-report.service';

interface TestCondition {
  testId: string;
  speed: number;
  load: number;
}

interface DropdownOption {
  label: string;
  value: any;
}

@Component({
  selector: 'app-igt-chart',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    DropdownModule,
    MultiSelectModule,
    ButtonModule,
    CardModule,
    DividerModule,
    MessageModule,
    TooltipModule,
    ChipModule
  ],
  templateUrl: './igt-chart.component.html',
  styleUrls: ['./igt-chart.component.scss']
})
export class IgtChartComponent implements OnInit, AfterViewInit {
  @ViewChild('plotlyChart', { static: false }) plotlyChart!: ElementRef;

  testConditions: DropdownOption[] = [
    { label: 'EV_Performance_Test_001', value: { testId: 'EV_Performance_Test_001', power: 'Standard', mode: 'Acceleration' } },
    { label: 'EV_Performance_Test_002', value: { testId: 'EV_Performance_Test_002', power: 'Eco', mode: 'Efficiency' } },
    { label: 'EV_Performance_Test_003', value: { testId: 'EV_Performance_Test_003', power: 'Sport', mode: 'Performance' } },
  ];

  speedOptions: DropdownOption[] = [
    { label: '0-50 km/h', value: 50 },
    { label: '0-80 km/h', value: 80 },
    { label: '0-100 km/h', value: 100 },
    { label: '0-120 km/h', value: 120 },
    { label: '0-150 km/h', value: 150 },
  ];

  loadOptions: DropdownOption[] = [
    { label: 'Light Load (20%)', value: 20 },
    { label: 'Medium Load (50%)', value: 50 },
    { label: 'Heavy Load (80%)', value: 80 },
    { label: 'Max Load (100%)', value: 100 },
    { label: 'Overload (110%)', value: 110 },
  ];

  deltaParam1Options: DropdownOption[] = [
    { label: 'Velocity', value: 'Velocity' },
    { label: 'Current', value: 'Current' },
    { label: 'Torque', value: 'Torque' },
    { label: 'Power', value: 'Power' },
  ];

  deltaParam2Options: DropdownOption[] = [
    { label: 'SoC', value: 'SoC' },
    { label: 'Temperature', value: 'Temperature' },
    { label: 'Throttle', value: 'Throttle' },
    { label: 'Voltage', value: 'Voltage' },
  ];

  selectedTestCondition: any = this.testConditions[0].value;
  selectedSpeed: number = 100;
  selectedLoad: number = 50;
  deltaIgtParam1: string = 'Velocity';
  deltaIgtParam2: string = 'SoC';

  // Data series options for multi-select
  dataSeriesOptions: DropdownOption[] = [
    { label: 'Velocity [km/h]', value: 'IgnOut_Advance' },
    { label: 'SoC [%]', value: 'IgnBas_Advance_CNG' },
    { label: 'Current [A]', value: 'IMFR50' },
    { label: 'Torque [Nm]', value: 'TORQUE' },
    { label: 'Temperature [degC]', value: 'LAMBDA_METER' },
    { label: 'Throttle [%]', value: 'THROTTLE' }
  ];

  // Pre-selected all series by default
  selectedDataSeries: string[] = [
    'IgnOut_Advance',
    'IgnBas_Advance_CNG',
    'IMFR50',
    'TORQUE',
    'LAMBDA_METER',
    'THROTTLE'
  ];

  constructor(private readonly pdfReportService: PdfReportService) {}

  ngOnInit(): void {
    this.selectedSpeed = this.selectedTestCondition.power === 'Standard' ? 100 : 
                        this.selectedTestCondition.power === 'Eco' ? 80 : 120;
    this.selectedLoad = this.selectedTestCondition.mode === 'Acceleration' ? 50 : 
                        this.selectedTestCondition.mode === 'Efficiency' ? 20 : 80;
  }

  ngAfterViewInit(): void {
    this.generateChart();
  }

  onTestConditionChange(): void {
    this.selectedSpeed = this.selectedTestCondition.power === 'Standard' ? 100 : 
                        this.selectedTestCondition.power === 'Eco' ? 80 : 120;
    this.selectedLoad = this.selectedTestCondition.mode === 'Acceleration' ? 50 : 
                        this.selectedTestCondition.mode === 'Efficiency' ? 20 : 80;
    this.generateChart();
  }

  onSpeedChange(): void {
    // Update test condition based on speed selection
    this.generateChart();
  }

  onLoadChange(): void {
    // Update test condition based on load selection
    this.generateChart();
  }

  onDeltaParam1Change(): void {
    this.generateChart();
  }

  onDeltaParam2Change(): void {
    this.generateChart();
  }

  onDataSeriesChange(): void {
    this.generateChart();
  }

  generateChart(): void {
    if (!this.plotlyChart) return;

    // Real data points from the spreadsheet
    const timePoints = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
    
    const velocity = [0, 2.5, 6.2, 10.8, 16.5, 23.1, 30.5, 38.2, 46.4, 54.1, 61.5, 68.2, 74.4, 79.8, 84.5, 88.6, 92.1, 95, 97.4, 99.2, 100];
    
    const soc = [85, 84.99, 84.98, 84.97, 84.95, 84.93, 84.9, 84.87, 84.83, 84.79, 84.75, 84.71, 84.67, 84.63, 84.6, 84.57, 84.55, 84.53, 84.51, 84.49, 84.48];
    
    const voltage = [400.2, 398.5, 396.1, 393.4, 390.2, 387.5, 384.1, 381.2, 378.4, 376.1, 374.2, 372.8, 374.5, 376.8, 379.2, 381.5, 383.4, 385.1, 386.8, 388.2, 389.5];
    
    const current = [0.4, 22.1, 48.5, 85.2, 130.8, 175.4, 210.6, 245.2, 268.5, 285.1, 290, 288.5, 250.2, 210.8, 175.5, 140.2, 110.8, 85.4, 65.2, 45.1, 35];
    
    const temperature = [25, 25.01, 25.02, 25.04, 25.07, 25.11, 25.16, 25.22, 25.29, 25.37, 25.46, 25.56, 25.67, 25.79, 25.92, 26.06, 26.21, 26.37, 26.54, 26.72, 26.91];
    
    const torque = [0, 45, 90, 160, 240, 310, 350, 350, 350, 350, 350, 340, 310, 280, 240, 190, 150, 110, 80, 50, 40];
    
    const throttle = [0, 15, 35, 55, 75, 90, 100, 100, 100, 100, 100, 100, 90, 80, 70, 60, 50, 40, 30, 20, 15];

    // Create triangle markers for knock events (downward triangles)
    const knockTimePoints = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20];
    const knockYPosition = knockTimePoints.map(x => {
      const idx = timePoints.indexOf(x);
      return idx >= 0 ? soc[idx] : 84;
    });

    // Helper function to get trend arrow (color will be set per line)
    const getTrendArrow = (current: number, previous: number) => {
      const diff = current - previous;
      const threshold = Math.abs(current) * 0.01; // 1% threshold for considering it flat
      
      if (diff > threshold) return '↗'; // Up arrow
      if (diff < -threshold) return '↘'; // Down arrow
      return '→'; // Flat arrow
    };

    // Create arrow annotations showing trends - REMOVED, using marker symbols instead
    const annotations: Partial<Plotly.Annotations>[] = [];

    // Add text annotations for key values at endpoints
    annotations.push(
      {
        x: timePoints.at(-1) || 0,
        y: velocity.at(-1) || 0,
        text: `${(velocity.at(-1) || 0).toFixed(1)}`,
        showarrow: true,
        arrowhead: 2,
        arrowsize: 1,
        arrowwidth: 1,
        arrowcolor: '#000000',
        ax: 30,
        ay: 0,
        font: { size: 9, color: '#000000' },
        bgcolor: 'rgba(255, 255, 255, 0.8)',
        bordercolor: '#000000',
        borderwidth: 1,
        borderpad: 2,
        yref: 'y'
      }
    );

    // Helper function to get trend arrow symbol
    const getArrowSymbol = (current: number, previous: number) => {
      const diff = current - previous;
      const threshold = Math.abs(current) * 0.01; // 1% threshold for considering it flat
      
      if (diff > threshold) return 'triangle-up'; // Up arrow
      if (diff < -threshold) return 'triangle-down'; // Down arrow
      return 'diamond'; // Flat/stable
    };

    // Calculate arrow symbols for each data series
    const velocitySymbols = velocity.map((val, idx) => {
      if (idx === 0) return 'circle'; // First point is a circle
      return getArrowSymbol(val, velocity[idx - 1]);
    });

    const socSymbols = soc.map((val, idx) => {
      if (idx === 0) return 'circle';
      return getArrowSymbol(val, soc[idx - 1]);
    });

    const torqueSymbols = torque.map((val, idx) => {
      if (idx === 0) return 'circle';
      return getArrowSymbol(val, torque[idx - 1]);
    });

    const currentSymbols = current.map((val, idx) => {
      if (idx === 0) return 'circle';
      return getArrowSymbol(val, current[idx - 1]);
    });

    const temperatureSymbols = temperature.map((val, idx) => {
      if (idx === 0) return 'circle';
      return getArrowSymbol(val, temperature[idx - 1]);
    });

    const throttleSymbols = throttle.map((val, idx) => {
      if (idx === 0) return 'circle';
      return getArrowSymbol(val, throttle[idx - 1]);
    });

    const data: Plotly.Data[] = [
      // Velocity (km/h) - Left Y-axis 1
      {
        x: timePoints,
        y: velocity,
        type: 'scatter',
        mode: 'lines+markers',
        name: `Velocity [km/h]: ${velocity[velocity.length - 1]}`,
        line: { color: '#000000', width: 3 },
        marker: { 
          size: 10, 
          symbol: velocitySymbols as any, 
          color: '#000000',
          line: { width: 1, color: '#000000' }
        },
        yaxis: 'y',
        visible: this.selectedDataSeries.includes('IgnOut_Advance') ? true : 'legendonly'
      },
      // SoC [%] - Left Y-axis 2
      {
        x: timePoints,
        y: soc,
        type: 'scatter',
        mode: 'lines+markers',
        name: `SoC [%]: ${soc[soc.length - 1]}`,
        line: { color: '#8B3A0A', width: 3 },
        marker: { 
          size: 10, 
          symbol: socSymbols as any, 
          color: '#8B3A0A',
          line: { width: 1, color: '#8B3A0A' }
        },
        yaxis: 'y2',
        visible: this.selectedDataSeries.includes('IgnBas_Advance_CNG') ? true : 'legendonly'
      },
      
      // Current [A] - Right Y-axis 1
      {
        x: timePoints,
        y: current,
        type: 'scatter',
        mode: 'lines+markers',
        name: `Current [A]: ${current[current.length - 1]}`,
        line: { color: '#4472C4', width: 3 },
        marker: { 
          size: 10, 
          symbol: currentSymbols as any, 
          color: '#4472C4',
          line: { width: 1, color: '#4472C4' }
        },
        yaxis: 'y3',
        visible: this.selectedDataSeries.includes('IMFR50') ? true : 'legendonly'
      },
      // Torque [Nm] - Right Y-axis 2
      {
        x: timePoints,
        y: torque,
        type: 'scatter',
        mode: 'lines+markers',
        name: `Torque [Nm]: ${torque[torque.length - 1]}`,
        line: { color: '#70AD47', width: 3 },
        marker: { 
          size: 10, 
          symbol: torqueSymbols as any, 
          color: '#70AD47',
          line: { width: 1, color: '#70AD47' }
        },
        yaxis: 'y4',
        visible: this.selectedDataSeries.includes('TORQUE') ? true : 'legendonly'
      },
      // Temperature [degC] - Right Y-axis 3
      {
        x: timePoints,
        y: temperature,
        type: 'scatter',
        mode: 'lines+markers',
        name: `Temp [degC]: ${temperature.at(-1)}`,
        line: { color: '#9966CC', width: 3 },
        marker: { 
          size: 10, 
          symbol: temperatureSymbols as any, 
          color: '#9966CC',
          line: { width: 1, color: '#9966CC' }
        },
        yaxis: 'y5',
        visible: this.selectedDataSeries.includes('LAMBDA_METER') ? true : 'legendonly'
      },
      // Throttle [%] - Right Y-axis 4
      {
        x: timePoints,
        y: throttle,
        type: 'scatter',
        mode: 'lines+markers',
        name: `Throttle [%]: ${throttle.at(-1)}`,
        line: { color: '#FF6600', width: 3 },
        marker: { 
          size: 10, 
          symbol: throttleSymbols as any, 
          color: '#FF6600',
          line: { width: 1, color: '#FF6600' }
        },
        yaxis: 'y6',
        visible: this.selectedDataSeries.includes('THROTTLE') ? true : 'legendonly'
      }
    ];

    const layout: Partial<Plotly.Layout> = {
      title: {
        text: `Electric Vehicle Performance Data`,
        font: { size: 16, family: 'Arial, sans-serif', weight: 700 as any },
        x: 0.5,
        xanchor: 'center',
        y: 0.98,
        yanchor: 'top'
      },
      xaxis: {
        title: {
          text: 'Time [s]',
          font: { size: 11 }
        },
        gridcolor: '#E5E5E5',
        zeroline: true,
        zerolinecolor: '#999',
        zerolinewidth: 1,
        range: [0, 22],
        showgrid: true,
        domain: [0.1, 0.9]
      },
      // Left Y-axis 1: Velocity (black) - outer left
      yaxis: {
        title: {
          text: 'Velocity [km/h]',
          font: { color: '#000000', size: 10 }
        },
        tickfont: { color: '#000000', size: 9 },
        side: 'left',
        position: 0,
        range: [0, 110],
        showgrid: false,
        showticklabels: this.selectedDataSeries.includes('IgnOut_Advance'),
        ticks: this.selectedDataSeries.includes('IgnOut_Advance') ? 'outside' : '',
        ticklen: this.selectedDataSeries.includes('IgnOut_Advance') ? 5 : 0,
        visible: this.selectedDataSeries.includes('IgnOut_Advance')
      },
      // Left Y-axis 2: SoC (brown) - inner left
      yaxis2: {
        title: {
          text: 'SoC [%]',
          font: { color: '#8B3A0A', size: 10 }
        },
        tickfont: { color: '#8B3A0A', size: 9 },
        overlaying: 'y',
        side: 'left',
        position: 0.1,
        range: [84, 85.5],
        showgrid: false,
        showticklabels: this.selectedDataSeries.includes('IgnBas_Advance_CNG'),
        ticks: this.selectedDataSeries.includes('IgnBas_Advance_CNG') ? 'outside' : '',
        ticklen: this.selectedDataSeries.includes('IgnBas_Advance_CNG') ? 5 : 0,
        visible: this.selectedDataSeries.includes('IgnBas_Advance_CNG')
      },
      // Right Y-axis 1: Current (blue) - inner right
      yaxis3: {
        title: {
          text: 'Current [A]',
          font: { color: '#4472C4', size: 10 }
        },
        tickfont: { color: '#4472C4', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 0.9,
        range: [0, 320],
        showgrid: false,
        showticklabels: this.selectedDataSeries.includes('IMFR50'),
        ticks: this.selectedDataSeries.includes('IMFR50') ? 'outside' : '',
        ticklen: this.selectedDataSeries.includes('IMFR50') ? 5 : 0,
        visible: this.selectedDataSeries.includes('IMFR50')
      },
      // Right Y-axis 2: Torque (green) - middle right
      yaxis4: {
        title: {
          text: 'Torque [Nm]',
          font: { color: '#70AD47', size: 10 }
        },
        tickfont: { color: '#70AD47', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 0.95,
        range: [0, 380],
        showgrid: false,
        showticklabels: this.selectedDataSeries.includes('TORQUE'),
        ticks: this.selectedDataSeries.includes('TORQUE') ? 'outside' : '',
        ticklen: this.selectedDataSeries.includes('TORQUE') ? 5 : 0,
        visible: this.selectedDataSeries.includes('TORQUE')
      },
      // Right Y-axis 3: Temperature (purple) - outer right
      yaxis5: {
        title: {
          text: 'Temp [degC]',
          font: { color: '#9966CC', size: 10 }
        },
        tickfont: { color: '#9966CC', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 1,
        range: [24, 28],
        showgrid: false,
        showticklabels: this.selectedDataSeries.includes('LAMBDA_METER'),
        ticks: this.selectedDataSeries.includes('LAMBDA_METER') ? 'outside' : '',
        ticklen: this.selectedDataSeries.includes('LAMBDA_METER') ? 5 : 0,
        visible: this.selectedDataSeries.includes('LAMBDA_METER')
      },
      // Right Y-axis 4: Throttle (orange) - far right
      yaxis6: {
        title: {
          text: 'Throttle [%]',
          font: { color: '#FF6600', size: 10 }
        },
        tickfont: { color: '#FF6600', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 0.04,
        range: [0, 110],
        showgrid: false,
        showticklabels: this.selectedDataSeries.includes('THROTTLE'),
        ticks: this.selectedDataSeries.includes('THROTTLE') ? 'outside' : '',
        ticklen: this.selectedDataSeries.includes('THROTTLE') ? 5 : 0,
        visible: this.selectedDataSeries.includes('THROTTLE')
      },
      legend: {
        x: 0.5,
        y: 1.15,
        xanchor: 'center',
        yanchor: 'top',
        orientation: 'h',
        bgcolor: 'rgba(255, 255, 255, 0.95)',
        bordercolor: '#333333',
        borderwidth: 1,
        font: { size: 8, family: 'Arial' },
        itemsizing: 'constant',
        tracegroupgap: 6,
        itemwidth: 35,
        traceorder: 'normal'
      },
      hovermode: 'closest',
      showlegend: true,
      autosize: true,
      margin: { l: 60, r: 100, t: 120, b: 50 },
      plot_bgcolor: '#FFFFFF',
      paper_bgcolor: '#FFFFFF',
      // Add vertical lines for all data points and reference lines
      shapes: [
        // Velocity Y-axis line (black) - only show if selected
        ...(this.selectedDataSeries.includes('IgnOut_Advance') ? [{
          type: 'line' as const,
          x0: -.0,
          y0: 0,
          x1: -.0,
          y1: 1,
          xref: 'paper' as const,
          yref: 'paper' as const,
          line: {
            color: 'black',
            width: 2,
            dash: 'solid' as const
          }
        }] : []),
        // SoC Y-axis line (red/brown) - only show if selected
        ...(this.selectedDataSeries.includes('IgnBas_Advance_CNG') ? [{
          type: 'line' as const,
          x0: .1,
          y0: 0,
          x1: .1,
          y1: 1,
          xref: 'paper' as const,
          yref: 'paper' as const,
          line: {
            color: '#8B3A0A',
            width: 2,
            dash: 'solid' as const
          }
        }] : []),
        // Current Y-axis line (blue) - only show if selected
        ...(this.selectedDataSeries.includes('IMFR50') ? [{
          type: 'line' as const,
          x0: 0.9,
          y0: 0,
          x1: .9,
          y1: 1,
          xref: 'paper' as const,
          yref: 'paper' as const,
          line: {
            color: '#4472C4',
            width: 2,
            dash: 'solid' as const
          }
        }] : []),
        // Torque Y-axis line (green) - only show if selected
        ...(this.selectedDataSeries.includes('TORQUE') ? [{
          type: 'line' as const,
          x0: .95,
          y0: 0,
          x1: .95,
          y1: 1,
          xref: 'paper' as const,
          yref: 'paper' as const,
          line: {
            color: '#70AD47',
            width: 2,
            dash: 'solid' as const
          }
        }] : []),
        // Temperature Y-axis line (purple) - only show if selected
        ...(this.selectedDataSeries.includes('LAMBDA_METER') ? [{
          type: 'line' as const,
          x0: .99,
          y0: 0,
          x1: .99,
          y1: 1,
          xref: 'paper' as const,
          yref: 'paper' as const,
          line: {
            color: '#9966CC',
            width: 2,
            dash: 'solid' as const
          }
        }] : []),
        // Throttle Y-axis line (orange) - only show if selected
        ...(this.selectedDataSeries.includes('THROTTLE') ? [{
          type: 'line' as const,
          x0: .04,
          y0: 0,
          x1: .04,
          y1: 1,
          xref: 'paper' as const,
          yref: 'paper' as const,
          line: {
            color: '#FF6600',
            width: 2,
            dash: 'solid' as const
          }
        }] : []),
        // Add vertical grid lines at all data points
        ...timePoints.map(x => ({
          type: 'line' as const,
          x0: x,
          x1: x,
          y0: 0,
          y1: 1,
          yref: 'paper' as const,
          line: {
            color: '#E0E0E0',
            width: 0.5,
            dash: 'dot' as const
          }
        }))
      ],
      annotations: annotations
    };

    const config: Partial<Plotly.Config> = {
      responsive: true,
      displayModeBar: true,
      displaylogo: false,
      modeBarButtonsToRemove: ['lasso2d', 'select2d'],
      toImageButtonOptions: {
        format: 'png',
        filename: `IGT_Report_${this.selectedTestCondition.speed}RPM_${this.selectedTestCondition.load}Load`,
        height: 800,
        width: 1200,
        scale: 2
      }
    };

    Plotly.newPlot(this.plotlyChart.nativeElement, data, layout, config);
  }

  downloadReport(format: string = 'pdf'): void {
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const filename = `EV_Performance_Report_${this.selectedTestCondition.testId}_${timestamp}`;

    switch (format) {
      case 'pdf':
        this.generatePDFReport();
        break;
      
      case 'png':
        if (this.plotlyChart) {
          Plotly.downloadImage(this.plotlyChart.nativeElement, {
            format: 'png',
            filename: filename,
            height: 800,
            width: 1200,
            scale: 2
          });
        }
        break;
      
      case 'csv':
        this.downloadDetailedCSV();
        break;
      
      case 'excel':
        alert(`Downloading EV Data (Excel)...\nFilename: ${filename}.xlsx\nThis feature will export all chart data to Excel format.`);
        break;
      
      default:
        alert('Unsupported format selected.');
    }
  }

  private downloadCSV(filename: string): void {
    // Generate CSV data from the new chart data
    const timePoints = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
    const velocity = [0, 2.5, 6.2, 10.8, 16.5, 23.1, 30.5, 38.2, 46.4, 54.1, 61.5, 68.2, 74.4, 79.8, 84.5, 88.6, 92.1, 95, 97.4, 99.2, 100];
    const soc = [85, 84.99, 84.98, 84.97, 84.95, 84.93, 84.9, 84.87, 84.83, 84.79, 84.75, 84.71, 84.67, 84.63, 84.6, 84.57, 84.55, 84.53, 84.51, 84.49, 84.48];
    const current = [0.4, 22.1, 48.5, 85.2, 130.8, 175.4, 210.6, 245.2, 268.5, 285.1, 290, 288.5, 250.2, 210.8, 175.5, 140.2, 110.8, 85.4, 65.2, 45.1, 35];
    const torque = [0, 45, 90, 160, 240, 310, 350, 350, 350, 350, 350, 340, 310, 280, 240, 190, 150, 110, 80, 50, 40];
    const temperature = [25, 25.01, 25.02, 25.04, 25.07, 25.11, 25.16, 25.22, 25.29, 25.37, 25.46, 25.56, 25.67, 25.79, 25.92, 26.06, 26.21, 26.37, 26.54, 26.72, 26.91];
    const throttle = [0, 15, 35, 55, 75, 90, 100, 100, 100, 100, 100, 100, 90, 80, 70, 60, 50, 40, 30, 20, 15];

    // Create CSV content
    let csvContent = 'Time[s],Velocity[km/h],SoC[%],Current[A],Torque[Nm],Temp[degC],Throttle[%]\n';
    
    for (let i = 0; i < timePoints.length; i++) {
      csvContent += `${timePoints[i]},${velocity[i]},${soc[i]},${current[i]},${torque[i]},${temperature[i].toFixed(2)},${throttle[i]}\n`;
    }

    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  // PDF Report Generation Methods
  async generatePDFReport(): Promise<void> {
    try {
      // Capture chart as image
      const chartImageData = await this.pdfReportService.captureChartAsImage(
        this.plotlyChart.nativeElement
      );

      // Prepare test results data
      const testResults = this.prepareTestResultsData();

      // Prepare report data
      const reportData: ReportData = {
        testInfo: {
          testName: this.selectedTestCondition.testId || 'EV Performance Test',
          testDate: new Date().toLocaleDateString(),
          testDuration: '20 seconds',
          testBy: 'Test Engineer',
          vehicleModel: 'Generic Electric Vehicle',
          batteryCapacity: '75 kWh',
          softwareVersion: 'v2.1.0'
        },
        testParameters: [
          { parameter: 'Test Condition', value: this.selectedTestCondition.testId, unit: '-', status: 'PASS' },
          { parameter: 'Speed Range', value: `0-${this.selectedSpeed}`, unit: 'km/h', status: 'PASS' },
          { parameter: 'Load Condition', value: `${this.selectedLoad}%`, unit: '%', status: 'PASS' },
          { parameter: 'Power Mode', value: this.selectedTestCondition.power, unit: '-', status: 'PASS' },
          { parameter: 'Test Mode', value: this.selectedTestCondition.mode, unit: '-', status: 'PASS' },
          { parameter: 'Delta Param 1', value: this.deltaIgtParam1, unit: '-', status: 'PASS' },
          { parameter: 'Delta Param 2', value: this.deltaIgtParam2, unit: '-', status: 'PASS' }
        ],
        testResults: testResults,
        chartImageData: chartImageData
      };

      // Generate and download PDF
      await this.pdfReportService.generateReport(reportData);
      
    } catch (error) {
      console.error('Error generating PDF report:', error);
      alert('Error generating PDF report. Please try again.');
    }
  }

  private prepareTestResultsData(): any[] {
    // Generate test data matching the current chart
    const timePoints = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
    const velocity = [0, 2.5, 6.2, 10.8, 16.5, 23.1, 30.5, 38.2, 46.4, 54.1, 61.5, 68.2, 74.4, 79.8, 84.5, 88.6, 92.1, 95, 97.4, 99.2, 100];
    const soc = [85, 84.99, 84.98, 84.97, 84.95, 84.93, 84.9, 84.87, 84.83, 84.79, 84.75, 84.71, 84.67, 84.63, 84.6, 84.57, 84.55, 84.53, 84.51, 84.49, 84.48];
    const current = [0.4, 22.1, 48.5, 85.2, 130.8, 175.4, 210.6, 245.2, 268.5, 285.1, 290, 288.5, 250.2, 210.8, 175.5, 140.2, 110.8, 85.4, 65.2, 45.1, 35];
    const torque = [0, 45, 90, 160, 240, 310, 350, 350, 350, 350, 350, 340, 310, 280, 240, 190, 150, 110, 80, 50, 40];
    const throttle = [0, 15, 35, 55, 75, 90, 100, 100, 100, 100, 100, 100, 90, 80, 70, 60, 50, 40, 30, 20, 15];

    return timePoints.map((time, index) => ({
      time: `${time}s`,
      velocity: velocity[index],
      soc: soc[index],
      current: current[index],
      torque: torque[index],
      throttle: throttle[index]
    }));
  }

  // Method to download detailed CSV data for analysis
  downloadDetailedCSV(): void {
    const testResults = this.prepareTestResultsData();
    const csvContent = this.pdfReportService.generateCSVData(testResults);
    this.pdfReportService.downloadCSV(csvContent);
  }
}
