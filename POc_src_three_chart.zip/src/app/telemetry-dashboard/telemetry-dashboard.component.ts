import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray } from '@angular/forms';
import { Subject, debounceTime, takeUntil } from 'rxjs';
import { TelemetryExcelService } from './services/telemetry-excel.service';
import { TelemetryRow } from './models/telemetry-row';

@Component({
  selector: 'app-telemetry-dashboard',
  templateUrl: './telemetry-dashboard.component.html',
  styleUrls: ['./telemetry-dashboard.component.css']
})
export class TelemetryDashboardComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  
  filterForm!: FormGroup;
  allData: TelemetryRow[] = [];
  filteredData: TelemetryRow[] = [];
  vehicleOptions: string[] = [];
  gearOptions: number[] = [];
  loading = true;
  error: string | null = null;

  // Metric options for line chart
  metricOptions = [
    { label: 'Engine RPM', value: 'engine_rpm' },
    { label: 'Vehicle Speed (kph)', value: 'vehicle_speed_kph' },
    { label: 'Engine Torque', value: 'engine_torque' },
    { label: 'Throttle Position (%)', value: 'throttle_position' },
    { label: 'Brake Temperature (°C)', value: 'brake_temp_c' },
    { label: 'Coolant Temperature (°C)', value: 'coolant_temp' },
    { label: 'Oil Pressure (PSI)', value: 'oil_pressure' },
    { label: 'Fuel Consumption', value: 'fuel_consumption' },
    { label: 'Acceleration (m/s²)', value: 'acceleration' }
  ];

  // Chart 1: Line chart data
  lineChartData: any = {};
  lineChartLayout: any = {};
  lineChartConfig: any = { responsive: true, displayModeBar: true, useResizeHandler: true };

  // Chart 2: Heatmap data
  heatmapData: any = {};
  heatmapLayout: any = {};
  heatmapConfig: any = { responsive: true, displayModeBar: true, useResizeHandler: true };

  constructor(
    private fb: FormBuilder,
    private telemetryService: TelemetryExcelService
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.loadData();
    this.setupFilterListeners();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initializeForm(): void {
    this.filterForm = this.fb.group({
      vehicleId: [''],
      startTime: [''],
      endTime: [''],
      resolution: [1],
      minSpeed: [0],
      maxSpeed: [200],
      minRpm: [0],
      maxRpm: [5000],
      gearPosition: [''],
      eventOverlays: this.fb.group({
        absFaults: [false],
        brakingEvents: [false],
        failureEvents: [false]
      }),
      lineChartMetrics: this.fb.group({
        metric1: ['engine_rpm'],
        metric2: ['vehicle_speed_kph'],
        metric3: ['engine_torque']
      })
    });
  }

  private setupFilterListeners(): void {
    this.filterForm.valueChanges
      .pipe(
        debounceTime(150),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.applyFilters();
      });
  }

  private loadData(): void {
    this.loading = true;
    this.error = null;

    this.telemetryService.loadTelemetryDataPromise('assets/telemetry_10ms_interval.xlsx')
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          this.allData = data;
          this.extractVehicleOptions();
          
          // Set default vehicle if available
          if (this.vehicleOptions.length > 0) {
            this.filterForm.patchValue({ vehicleId: this.vehicleOptions[0] }, { emitEvent: false });
          }
          
          this.applyFilters();
          this.loading = false;
        },
        error: (err) => {
          console.error('Error loading telemetry data:', err);
          this.error = 'Failed to load telemetry data. Please check the Excel file.';
          this.loading = false;
        }
      });
  }

  private extractVehicleOptions(): void {
    const uniqueVehicles = new Set<string>();
    const uniqueGears = new Set<number>();
    
    this.allData.forEach(row => {
      if (row.vehicle_id) {
        uniqueVehicles.add(row.vehicle_id);
      }
      if (row.gear_position !== undefined && row.gear_position !== null) {
        uniqueGears.add(row.gear_position);
      }
    });
    
    this.vehicleOptions = Array.from(uniqueVehicles).sort();
    this.gearOptions = Array.from(uniqueGears).sort((a, b) => a - b);
  }

  private applyFilters(): void {
    const formValue = this.filterForm.value;
    let filtered = [...this.allData];

    // Filter by vehicle
    if (formValue.vehicleId) {
      filtered = filtered.filter(row => row.vehicle_id === formValue.vehicleId);
    }

    // Filter by time range
    if (formValue.startTime) {
      const startDate = new Date(formValue.startTime);
      filtered = filtered.filter(row => row.timestamp >= startDate);
    }
    if (formValue.endTime) {
      const endDate = new Date(formValue.endTime);
      filtered = filtered.filter(row => row.timestamp <= endDate);
    }

    // Filter by speed range
    if (formValue.minSpeed !== null && formValue.minSpeed !== undefined) {
      filtered = filtered.filter(row => 
        !row.vehicle_speed_kph || row.vehicle_speed_kph >= formValue.minSpeed
      );
    }
    if (formValue.maxSpeed !== null && formValue.maxSpeed !== undefined) {
      filtered = filtered.filter(row => 
        !row.vehicle_speed_kph || row.vehicle_speed_kph <= formValue.maxSpeed
      );
    }

    // Filter by RPM range
    if (formValue.minRpm !== null && formValue.minRpm !== undefined) {
      filtered = filtered.filter(row => 
        !row.engine_rpm || row.engine_rpm >= formValue.minRpm
      );
    }
    if (formValue.maxRpm !== null && formValue.maxRpm !== undefined) {
      filtered = filtered.filter(row => 
        !row.engine_rpm || row.engine_rpm <= formValue.maxRpm
      );
    }

    // Filter by gear position
    if (formValue.gearPosition !== '' && formValue.gearPosition !== null) {
      filtered = filtered.filter(row => row.gear_position === formValue.gearPosition);
    }

    // Apply downsampling
    const resolution = formValue.resolution || 1;
    if (resolution > 1) {
      filtered = filtered.filter((_, index) => index % resolution === 0);
    }

    this.filteredData = filtered;
    this.updateCharts(formValue.eventOverlays, formValue.lineChartMetrics);
  }

  private updateCharts(eventOverlays: any, lineChartMetrics: any = null): void {
    this.updateLineChart(eventOverlays, lineChartMetrics);
    this.updateHeatmap();
  }

  private updateLineChart(eventOverlays: any, lineChartMetrics: any = null): void {
    if (this.filteredData.length === 0) {
      this.lineChartData = {};
      return;
    }

    // Get metric selections or use defaults
    const metric1 = lineChartMetrics?.metric1 || 'engine_rpm';
    const metric2 = lineChartMetrics?.metric2 || 'vehicle_speed_kph';
    const metric3 = lineChartMetrics?.metric3 || 'engine_torque';

    const timestamps = this.filteredData.map(row => row.timestamp);
    
    // Helper function to get metric data and label
    const getMetricData = (metricKey: string) => {
      const data = this.filteredData.map(row => (row as any)[metricKey] || 0);
      const metricInfo = this.metricOptions.find(m => m.value === metricKey);
      return {
        data,
        label: metricInfo?.label || metricKey
      };
    };

    const metric1Data = getMetricData(metric1);
    const metric2Data = getMetricData(metric2);
    const metric3Data = getMetricData(metric3);

    const traces: any[] = [
      {
        x: timestamps,
        y: metric1Data.data,
        type: 'scattergl',
        mode: 'lines',
        name: metric1Data.label,
        line: { color: 'rgb(31, 119, 180)', width: 2 },
        yaxis: 'y1'
      },
      {
        x: timestamps,
        y: metric2Data.data,
        type: 'scattergl',
        mode: 'lines',
        name: metric2Data.label,
        line: { color: 'rgb(255, 127, 14)', width: 2 },
        yaxis: 'y2'
      },
      {
        x: timestamps,
        y: metric3Data.data,
        type: 'scattergl',
        mode: 'lines',
        name: metric3Data.label,
        line: { color: 'rgb(44, 160, 44)', width: 2 },
        yaxis: 'y3'
      }
    ];

    // Add event overlays
    const shapes: any[] = [];
    
    if (eventOverlays.absFaults) {
      const absEvents = this.filteredData.filter(row => row.abs_fault_indicator === 1);
      if (absEvents.length > 0) {
        traces.push({
          x: absEvents.map(row => row.timestamp),
          y: absEvents.map(row => (row as any)[metric1] || 0),
          type: 'scatter',
          mode: 'markers',
          name: 'ABS Faults',
          marker: { color: 'red', size: 10, symbol: 'x' },
          yaxis: 'y1'
        });
      }
    }

    if (eventOverlays.brakingEvents) {
      const brakeEvents = this.filteredData.filter(row => 
        row.brake_pedal_pos_percent && row.brake_pedal_pos_percent > 10
      );
      if (brakeEvents.length > 0) {
        traces.push({
          x: brakeEvents.map(row => row.timestamp),
          y: brakeEvents.map(row => (row as any)[metric2] || 0),
          type: 'scatter',
          mode: 'markers',
          name: 'Braking Events',
          marker: { color: 'orange', size: 8, symbol: 'triangle-down' },
          yaxis: 'y2'
        });
      }
    }

    if (eventOverlays.failureEvents) {
      const failureEvents: Date[] = [];
      this.filteredData.forEach(row => {
        if (row.failure_date && !isNaN(row.failure_date.getTime())) {
          failureEvents.push(row.failure_date);
        } else if (row.failure_type && row.failure_type.trim() !== '') {
          failureEvents.push(row.timestamp);
        }
      });

      failureEvents.forEach(failureTime => {
        shapes.push({
          type: 'line',
          x0: failureTime,
          x1: failureTime,
          y0: 0,
          y1: 1,
          yref: 'paper',
          line: {
            color: 'rgba(255, 0, 0, 0.5)',
            width: 2,
            dash: 'dash'
          }
        });
      });
    }

    this.lineChartData = traces;

    // Calculate min/max for each metric to set appropriate ranges
    const metric1Values = metric1Data.data.filter(v => v !== null && v !== undefined);
    const metric2Values = metric2Data.data.filter(v => v !== null && v !== undefined);
    const metric3Values = metric3Data.data.filter(v => v !== null && v !== undefined);

    const getRange = (values: number[]) => {
      if (values.length === 0) return [0, 100];
      const min = Math.min(...values);
      const max = Math.max(...values);
      const padding = (max - min) * 0.1; // 10% padding
      return [min - padding, max + padding];
    };

    const range1 = getRange(metric1Values);
    const range2 = getRange(metric2Values);
    const range3 = getRange(metric3Values);

    this.lineChartLayout = {
      title: {
        text: 'Multi-Metric Time Series Analysis',
        font: { size: 14, family: 'Arial' },
        x: 0.02,
        xanchor: 'left',
        y: 0.98,
        yanchor: 'top'
      },
      xaxis: { 
        title: {
          text: 'Time',
          font: { size: 11 }
        },
        type: 'date',
        domain: [0, 0.90],
        gridcolor: '#E5E5E5',
        zeroline: true,
        showgrid: true
      },
      yaxis: {
        title: {
          text: `${metric1Data.label} [${range1[0].toFixed(1)} - ${range1[1].toFixed(1)}]`,
          font: { color: 'rgb(31, 119, 180)', size: 10 }
        },
        titlefont: { color: 'rgb(31, 119, 180)' },
        tickfont: { color: 'rgb(31, 119, 180)', size: 9 },
        side: 'left',
        position: 0,
        range: range1,
        showgrid: true,
        gridcolor: '#E5E5E5',
        ticks: 'outside',
        ticklen: 5
      },
      yaxis2: {
        title: {
          text: `${metric2Data.label} [${range2[0].toFixed(1)} - ${range2[1].toFixed(1)}]`,
          font: { color: 'rgb(255, 127, 14)', size: 10 }
        },
        titlefont: { color: 'rgb(255, 127, 14)' },
        tickfont: { color: 'rgb(255, 127, 14)', size: 9 },
        overlaying: 'y',
        side: 'right',
        position: 0.95,
        range: range2,
        showgrid: false,
        ticks: 'outside',
        ticklen: 5
      },
      yaxis3: {
        title: {
          text: `${metric3Data.label} [${range3[0].toFixed(1)} - ${range3[1].toFixed(1)}]`,
          font: { color: 'rgb(44, 160, 44)', size: 10 }
        },
        titlefont: { color: 'rgb(44, 160, 44)' },
        tickfont: { color: 'rgb(44, 160, 44)', size: 9 },
        overlaying: 'y',
        side: 'right',
        anchor: 'free',
        position: 1.0,
        range: range3,
        showgrid: false,
        ticks: 'outside',
        ticklen: 5
      },
      showlegend: true,
      legend: { 
        x: 0.5, 
        y: 1.15, 
        xanchor: 'center',
        yanchor: 'top',
        orientation: 'h',
        bgcolor: 'rgba(255, 255, 255, 0.95)',
        bordercolor: '#333333',
        borderwidth: 1,
        font: { size: 9, family: 'Arial' }
      },
      shapes: [
        // Add vertical reference lines for y-axes
        {
          type: 'line',
          x0: 0,
          y0: 0,
          x1: 0,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: 'rgb(31, 119, 180)',
            width: 2,
            dash: 'solid'
          }
        },
        {
          type: 'line',
          x0: 0.95,
          y0: 0,
          x1: 0.95,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: 'rgb(255, 127, 14)',
            width: 2,
            dash: 'solid'
          }
        },
        {
          type: 'line',
          x0: 1.0,
          y0: 0,
          x1: 1.0,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: 'rgb(44, 160, 44)',
            width: 2,
            dash: 'solid'
          }
        },
        ...shapes
      ],
      margin: { l: 70, r: 120, t: 120, b: 60 },
      hovermode: 'closest',
      plot_bgcolor: '#FFFFFF',
      paper_bgcolor: '#FFFFFF'
    };
  }

  private updateHeatmap(): void {
    if (this.filteredData.length === 0) {
      this.heatmapData = {};
      return;
    }

    // Define metrics for heatmap
    const metrics = [
      { key: 'wheel_speed_fl_kph', label: 'Wheel FL (kph)' },
      { key: 'wheel_speed_fr_kph', label: 'Wheel FR (kph)' },
      { key: 'wheel_speed_rl_kph', label: 'Wheel RL (kph)' },
      { key: 'wheel_speed_rr_kph', label: 'Wheel RR (kph)' },
      { key: 'brake_temp_c', label: 'Brake Temp (°C)' }
    ];

    // Bin size: 200ms
    const binSizeMs = 200;
    const startTime = this.filteredData[0].timestamp.getTime();
    const endTime = this.filteredData[this.filteredData.length - 1].timestamp.getTime();
    const numBins = Math.ceil((endTime - startTime) / binSizeMs);

    // Initialize bins
    const bins: Map<number, Map<string, number[]>> = new Map();

    // Populate bins
    this.filteredData.forEach(row => {
      const binIndex = Math.floor((row.timestamp.getTime() - startTime) / binSizeMs);
      
      if (!bins.has(binIndex)) {
        bins.set(binIndex, new Map());
      }
      
      const binData = bins.get(binIndex)!;
      
      metrics.forEach(metric => {
        const value = (row as any)[metric.key];
        if (value !== undefined && value !== null && !isNaN(value)) {
          if (!binData.has(metric.key)) {
            binData.set(metric.key, []);
          }
          binData.get(metric.key)!.push(value);
        }
      });
    });

    // Calculate averages and build matrix
    const binTimestamps: string[] = [];
    const zMatrix: (number | null)[][] = metrics.map(() => []);

    for (let i = 0; i < numBins; i++) {
      const binTime = new Date(startTime + i * binSizeMs);
      binTimestamps.push(binTime.toISOString());
      
      const binData = bins.get(i);
      
      metrics.forEach((metric, metricIndex) => {
        if (binData && binData.has(metric.key)) {
          const values = binData.get(metric.key)!;
          const avg = values.reduce((sum, val) => sum + val, 0) / values.length;
          zMatrix[metricIndex].push(avg);
        } else {
          zMatrix[metricIndex].push(null);
        }
      });
    }

    this.heatmapData = [{
      x: binTimestamps,
      y: metrics.map(m => m.label),
      z: zMatrix,
      type: 'heatmap',
      colorscale: 'Viridis',
      hoverongaps: false
    }];

    this.heatmapLayout = {
      title: 'Metrics Heatmap (200ms bins)',
      xaxis: { 
        title: 'Time',
        type: 'date'
      },
      yaxis: { 
        title: 'Metrics'
      },
      margin: { l: 150, r: 60, t: 80, b: 60 }
    };
  }
}
