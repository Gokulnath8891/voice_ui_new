import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { debounceTime, Subject, takeUntil } from 'rxjs';
import * as Plotly from 'plotly.js-dist-min';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DividerModule } from 'primeng/divider';
import { InputNumberModule } from 'primeng/inputnumber';
import { MessageModule } from 'primeng/message';
import { TooltipModule } from 'primeng/tooltip';
import { ChipModule } from 'primeng/chip';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { CheckboxModule } from 'primeng/checkbox';
import { TelemetryExcelService } from './services/telemetry-excel.service';
import { TelemetryRow } from './models/telemetry-row';

interface DropdownOption {
  label: string;
  value: any;
}

interface MetricConfig {
  name: string;
  color: string;
  yAxisKey: string;
  position: number;
  side: 'left' | 'right';
}

@Component({
  selector: 'app-telemetry-multi-axis-chart',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    DropdownModule,
    ButtonModule,
    CardModule,
    DividerModule,
    InputNumberModule,
    MessageModule,
    TooltipModule,
    ChipModule,
    ProgressSpinnerModule,
    CheckboxModule
  ],
  templateUrl: './telemetry-multi-axis-chart.component.html',
  styleUrls: ['./telemetry-multi-axis-chart.component.scss']
})
export class TelemetryMultiAxisChartComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('plotlyChart', { static: false }) plotlyChart!: ElementRef;

  filterForm!: FormGroup;
  allData: TelemetryRow[] = [];
  filteredData: TelemetryRow[] = [];
  isLoading = true;
  errorMessage = '';

  vehicleOptions: DropdownOption[] = [];

  metricOptions: DropdownOption[] = [
    { label: 'Engine RPM', value: 'engine_rpm' },
    { label: 'Vehicle Speed (km/h)', value: 'vehicle_speed_kph' },
    { label: 'Wheel Speed FL (km/h)', value: 'wheel_speed_fl_kph' },
    { label: 'Wheel Speed FR (km/h)', value: 'wheel_speed_fr_kph' },
    { label: 'Wheel Speed RL (km/h)', value: 'wheel_speed_rl_kph' },
    { label: 'Wheel Speed RR (km/h)', value: 'wheel_speed_rr_kph' },
    { label: 'Brake Temperature (°C)', value: 'brake_temp_c' },
    { label: 'Brake Pedal Position (%)', value: 'brake_pedal_pos_percent' },
    { label: 'ABS Fault Indicator', value: 'abs_fault_indicator' }
  ];

  // Metric configurations for multi-axis display
  metricConfigs: { [key: string]: MetricConfig } = {
    engine_rpm: { name: 'Engine RPM', color: '#000000', yAxisKey: 'y', position: 0, side: 'left' },
    vehicle_speed_kph: { name: 'Speed (km/h)', color: '#ED7D31', yAxisKey: 'y2', position: 0.08, side: 'left' },
    wheel_speed_fl_kph: { name: 'Wheel FL (km/h)', color: '#4472C4', yAxisKey: 'y3', position: 0.92, side: 'right' },
    wheel_speed_fr_kph: { name: 'Wheel FR (km/h)', color: '#70AD47', yAxisKey: 'y4', position: 0.94, side: 'right' },
    wheel_speed_rl_kph: { name: 'Wheel RL (km/h)', color: '#9966CC', yAxisKey: 'y5', position: 0.96, side: 'right' },
    wheel_speed_rr_kph: { name: 'Wheel RR (km/h)', color: '#C00000', yAxisKey: 'y6', position: 0.98, side: 'right' },
    brake_temp_c: { name: 'Brake Temp (°C)', color: '#00B0F0', yAxisKey: 'y7', position: 1, side: 'right' },
    brake_pedal_pos_percent: { name: 'Brake Pedal (%)', color: '#FFC000', yAxisKey: 'y8', position: 0.04, side: 'left' },
    abs_fault_indicator: { name: 'ABS Fault', color: '#7030A0', yAxisKey: 'y9', position: 0.88, side: 'right' }
  };

  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private excelService: TelemetryExcelService
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.loadTelemetryData();
  }

  ngAfterViewInit(): void {
    // Chart will be generated after data loads
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  initializeForm(): void {
    this.filterForm = this.fb.group({
      selectedVehicle: [''],
      startTime: [''],
      endTime: [''],
      downsampleFactor: [10],
      minSpeed: [null],
      maxSpeed: [null],
      minRpm: [null],
      maxRpm: [null],
      metric1: ['engine_rpm'],
      metric2: ['vehicle_speed_kph'],
      metric3: ['wheel_speed_fl_kph'],
      metric4: ['wheel_speed_fr_kph'],
      metric5: ['brake_temp_c'],
      metric6: ['brake_pedal_pos_percent']
    });

    this.filterForm.valueChanges
      .pipe(debounceTime(150), takeUntil(this.destroy$))
      .subscribe(() => {
        this.applyFilters();
      });
  }

  loadTelemetryData(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.excelService.loadTelemetryDataPromise('assets/telemetry_10ms_interval.xlsx').subscribe({
      next: (data) => {
        this.allData = data;
        this.filteredData = data;
        this.extractVehicleOptions();
        this.isLoading = false;
        
        // Wait for view to update before generating chart
        setTimeout(() => this.generateChart(), 100);
      },
      error: (error) => {
        this.errorMessage = `Failed to load telemetry data: ${error.message}`;
        this.isLoading = false;
        console.error('Error loading telemetry data:', error);
      }
    });
  }

  extractVehicleOptions(): void {
    const uniqueVehicles = [...new Set(this.allData.map(row => row.vehicle_id))];
    this.vehicleOptions = uniqueVehicles.map(id => ({
      label: `Vehicle ${id}`,
      value: id
    }));

    if (this.vehicleOptions.length > 0) {
      this.filterForm.patchValue({ selectedVehicle: this.vehicleOptions[0].value }, { emitEvent: false });
    }
  }

  applyFilters(): void {
    const formValues = this.filterForm.value;
    let filtered = [...this.allData];

    // Vehicle filter
    if (formValues.selectedVehicle) {
      filtered = filtered.filter(row => row.vehicle_id === formValues.selectedVehicle);
    }

    // Time range filter
    if (formValues.startTime) {
      const startDate = new Date(formValues.startTime);
      filtered = filtered.filter(row => row.timestamp >= startDate);
    }
    if (formValues.endTime) {
      const endDate = new Date(formValues.endTime);
      filtered = filtered.filter(row => row.timestamp <= endDate);
    }

    // Speed range filter
    if (formValues.minSpeed !== null && formValues.minSpeed !== undefined) {
      filtered = filtered.filter(row => (row.vehicle_speed_kph || 0) >= formValues.minSpeed);
    }
    if (formValues.maxSpeed !== null && formValues.maxSpeed !== undefined) {
      filtered = filtered.filter(row => (row.vehicle_speed_kph || 0) <= formValues.maxSpeed);
    }

    // RPM range filter
    if (formValues.minRpm !== null && formValues.minRpm !== undefined) {
      filtered = filtered.filter(row => (row.engine_rpm || 0) >= formValues.minRpm);
    }
    if (formValues.maxRpm !== null && formValues.maxRpm !== undefined) {
      filtered = filtered.filter(row => (row.engine_rpm || 0) <= formValues.maxRpm);
    }

    // Downsample
    const factor = formValues.downsampleFactor || 1;
    if (factor > 1) {
      filtered = filtered.filter((_, index) => index % factor === 0);
    }

    this.filteredData = filtered;
    this.generateChart();
  }

  generateChart(): void {
    if (!this.plotlyChart || this.filteredData.length === 0) return;

    const formValues = this.filterForm.value;
    const selectedMetrics = [
      formValues.metric1,
      formValues.metric2,
      formValues.metric3,
      formValues.metric4,
      formValues.metric5,
      formValues.metric6
    ].filter(m => m); // Remove null/undefined

    // Prepare time data (x-axis)
    const timeData = this.filteredData.map(row => row.timestamp);

    // Create traces for each selected metric
    const traces: Plotly.Data[] = selectedMetrics.map((metricKey, index) => {
      const config = this.metricConfigs[metricKey];
      const yData = this.filteredData.map(row => this.getMetricValue(row, metricKey));
      const avgValue = yData.reduce((sum, val) => sum + val, 0) / yData.length;

      return {
        x: timeData,
        y: yData,
        type: 'scatter',
        mode: 'lines+markers',
        name: `${config.name}: ${avgValue.toFixed(2)}`,
        line: { color: config.color, width: 2 },
        marker: { size: 5, symbol: 'circle', color: config.color },
        yaxis: config.yAxisKey
      };
    });

    // Build layout with multi-axis configuration
    const layout: Partial<Plotly.Layout> = {
      title: {
        text: `Telemetry Multi-Axis Analysis - Vehicle ${formValues.selectedVehicle || 'All'}`,
        font: { size: 14, family: 'Arial' },
        x: 0.02,
        xanchor: 'left',
        y: 0.98,
        yanchor: 'top'
      },
      xaxis: {
        title: {
          text: 'Time',
          font: { size: 11 }
        },
        gridcolor: '#E5E5E5',
        zeroline: true,
        zerolinecolor: '#999',
        zerolinewidth: 1,
        showgrid: true,
        domain: [0.12, 0.88] // Leave space for 6 y-axes (2 left, 4 right)
      },
      legend: {
        x: 0.5,
        y: 1.15,
        xanchor: 'center',
        yanchor: 'top',
        orientation: 'h',
        bgcolor: 'rgba(255, 255, 255, 0.95)',
        bordercolor: '#333333',
        borderwidth: 1,
        font: { size: 9, family: 'Arial' },
        itemsizing: 'constant',
        tracegroupgap: 6,
        itemwidth: 40,
        traceorder: 'normal'
      },
      hovermode: 'closest',
      showlegend: true,
      autosize: true,
      margin: { l: 80, r: 120, t: 120, b: 60 },
      plot_bgcolor: '#FFFFFF',
      paper_bgcolor: '#FFFFFF',
      shapes: []
    };

    // Add y-axes dynamically for each selected metric
    selectedMetrics.forEach((metricKey, index) => {
      const config = this.metricConfigs[metricKey];
      const yData = this.filteredData.map(row => this.getMetricValue(row, metricKey));
      const minVal = Math.min(...yData);
      const maxVal = Math.max(...yData);
      const range = [minVal * 0.9, maxVal * 1.1]; // Add 10% padding

      const yAxisConfig: Partial<Plotly.LayoutAxis> = {
        title: {
          text: config.name,
          font: { color: config.color, size: 10 }
        },
        tickfont: { color: config.color, size: 9 },
        side: config.side,
        position: config.position,
        range: range,
        showgrid: index === 0, // Only show grid for first axis
        showticklabels: true,
        ticks: 'outside',
        ticklen: 5
      };

      if (index > 0) {
        yAxisConfig.overlaying = 'y';
      }

      // Add axis to layout
      const axisKey = config.yAxisKey.replace('y', 'yaxis');
      const finalKey = axisKey === 'yaxis' ? 'yaxis' : axisKey;
      (layout as any)[finalKey] = yAxisConfig;

      // Add vertical reference line for each axis
      if (layout.shapes) {
        layout.shapes.push({
          type: 'line',
          x0: config.position,
          y0: 0,
          x1: config.position,
          y1: 1,
          xref: 'paper',
          yref: 'paper',
          line: {
            color: config.color,
            width: 2,
            dash: 'solid'
          }
        } as any);
      }
    });

    const config: Partial<Plotly.Config> = {
      responsive: true,
      displayModeBar: true,
      displaylogo: false,
      modeBarButtonsToRemove: ['lasso2d', 'select2d'],
      toImageButtonOptions: {
        format: 'png',
        filename: `Telemetry_MultiAxis_${new Date().toISOString().slice(0, 10)}`,
        height: 800,
        width: 1400,
        scale: 2
      }
    };

    Plotly.newPlot(this.plotlyChart.nativeElement, traces, layout, config);
  }

  getMetricValue(row: TelemetryRow, metricKey: string): number {
    const value = (row as any)[metricKey];
    return typeof value === 'number' ? value : 0;
  }

  downloadChart(format: string = 'png'): void {
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const filename = `Telemetry_MultiAxis_${timestamp}`;

    switch (format) {
      case 'png':
        if (this.plotlyChart) {
          Plotly.downloadImage(this.plotlyChart.nativeElement, {
            format: 'png',
            filename: filename,
            height: 800,
            width: 1400,
            scale: 2
          });
        }
        break;

      case 'csv':
        this.downloadCSV(filename);
        break;

      default:
        alert('Unsupported format selected.');
    }
  }

  private downloadCSV(filename: string): void {
    const formValues = this.filterForm.value;
    const selectedMetrics = [
      formValues.metric1,
      formValues.metric2,
      formValues.metric3,
      formValues.metric4,
      formValues.metric5,
      formValues.metric6
    ].filter(m => m);

    // Create CSV header
    let csvContent = 'Timestamp,Vehicle_ID';
    selectedMetrics.forEach(metric => {
      csvContent += `,${this.metricConfigs[metric].name}`;
    });
    csvContent += '\n';

    // Add data rows
    this.filteredData.forEach(row => {
      csvContent += `${row.timestamp.toISOString()},${row.vehicle_id}`;
      selectedMetrics.forEach(metric => {
        csvContent += `,${this.getMetricValue(row, metric)}`;
      });
      csvContent += '\n';
    });

    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  refreshChart(): void {
    this.generateChart();
  }
}
