export interface TelemetryRow {
  vehicle_id: string;
  timestamp: Date;
  engine_rpm?: number;
  vehicle_speed_kph?: number;
  wheel_speed_fl_kph?: number;
  wheel_speed_fr_kph?: number;
  wheel_speed_rl_kph?: number;
  wheel_speed_rr_kph?: number;
  brake_temp_c?: number;
  brake_pedal_pos_percent?: number;
  abs_fault_indicator?: number;
  failure_type?: string;
  failure_date?: Date | null;
  engine_torque?: number;
  throttle_position?: number;
  coolant_temp?: number;
  oil_pressure?: number;
  fuel_consumption?: number;
  gear_position?: number;
  acceleration?: number;
}
