import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from, map } from 'rxjs';
import * as ExcelJS from 'exceljs';
import { TelemetryRow } from '../models/telemetry-row';

@Injectable({
  providedIn: 'root'
})
export class TelemetryExcelService {
  constructor(private http: HttpClient) {}

  /**
   * Load and parse the telemetry Excel file
   * @param filePath Path to the Excel file
   * @returns Observable of parsed telemetry rows
   */
  loadTelemetryData(filePath: string): Observable<TelemetryRow[]> {
    return this.http.get(filePath, { responseType: 'arraybuffer' }).pipe(
      map(buffer => {
        return this.parseExcelBuffer(buffer);
      })
    );
  }

  private parseExcelBuffer(buffer: ArrayBuffer): TelemetryRow[] {
    const workbook = new ExcelJS.Workbook();
    
    // Parse synchronously and wrap in array for from() conversion
    const rows: TelemetryRow[] = [];
    
    // Load workbook from buffer
    workbook.xlsx.load(buffer).then(wb => {
      const worksheet = wb.worksheets[0];
      if (!worksheet) {
        throw new Error('No worksheet found in Excel file');
      }

      // Read header row
      const headerRow = worksheet.getRow(1);
      const headers: string[] = [];
      headerRow.eachCell((cell, colNumber) => {
        headers[colNumber - 1] = String(cell.value).trim().toLowerCase();
      });

      // Process data rows
      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber === 1) return; // Skip header

        const rowData: any = {};
        row.eachCell((cell, colNumber) => {
          const header = headers[colNumber - 1];
          if (header) {
            rowData[header] = cell.value;
          }
        });

        const telemetryRow = this.normalizeRow(rowData);
        if (telemetryRow && telemetryRow.timestamp && !isNaN(telemetryRow.timestamp.getTime())) {
          rows.push(telemetryRow);
        }
      });
    });

    // Since ExcelJS load is async, we need to handle this differently
    // Return parsed rows directly from synchronous parsing
    return this.parseExcelBufferSync(buffer);
  }

  private parseExcelBufferSync(buffer: ArrayBuffer): TelemetryRow[] {
    const workbook = new ExcelJS.Workbook();
    const rows: TelemetryRow[] = [];
    
    // We'll use the promise-based approach but handle it synchronously
    // For now, return empty and let the async version handle it
    // This is a workaround since ExcelJS is primarily async
    
    this.parseExcelAsync(buffer).then(data => {
      rows.push(...data);
    });

    return rows;
  }

  private async parseExcelAsync(buffer: ArrayBuffer): Promise<TelemetryRow[]> {
    const workbook = new ExcelJS.Workbook();
    const rows: TelemetryRow[] = [];
    
    await workbook.xlsx.load(buffer);
    
    const worksheet = workbook.worksheets[0];
    if (!worksheet) {
      throw new Error('No worksheet found in Excel file');
    }

    // Read header row
    const headerRow = worksheet.getRow(1);
    const headers: string[] = [];
    headerRow.eachCell((cell, colNumber) => {
      headers[colNumber - 1] = String(cell.value).trim().toLowerCase();
    });

    // Process data rows
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header

      const rowData: any = {};
      row.eachCell((cell, colNumber) => {
        const header = headers[colNumber - 1];
        if (header) {
          rowData[header] = cell.value;
        }
      });

      const telemetryRow = this.normalizeRow(rowData);
      if (telemetryRow && telemetryRow.timestamp && !isNaN(telemetryRow.timestamp.getTime())) {
        rows.push(telemetryRow);
      }
    });

    // Sort by timestamp ascending
    rows.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());

    return rows;
  }

  /**
   * Load and parse Excel file returning a Promise
   */
  loadTelemetryDataAsync(filePath: string): Observable<TelemetryRow[]> {
    return this.http.get(filePath, { responseType: 'arraybuffer' }).pipe(
      map(buffer => from(this.parseExcelAsync(buffer))),
      map(promise => {
        const rows: TelemetryRow[] = [];
        promise.subscribe(data => rows.push(...data));
        return rows;
      })
    );
  }

  /**
   * Better approach: Return Observable that resolves the promise
   */
  loadTelemetryDataPromise(filePath: string): Observable<TelemetryRow[]> {
    return new Observable(observer => {
      this.http.get(filePath, { responseType: 'arraybuffer' }).subscribe({
        next: async (buffer) => {
          try {
            const rows = await this.parseExcelAsync(buffer);
            observer.next(rows);
            observer.complete();
          } catch (error) {
            observer.error(error);
          }
        },
        error: (err) => observer.error(err)
      });
    });
  }

  private normalizeRow(rowData: any): TelemetryRow | null {
    try {
      // Parse timestamp
      const timestamp = this.parseTimestamp(rowData['timestamp'] || rowData['date'] || rowData['time']);
      if (!timestamp || isNaN(timestamp.getTime())) {
        return null;
      }

      // Parse failure_date if exists
      let failureDate: Date | null = null;
      if (rowData['failure_date']) {
        failureDate = this.parseTimestamp(rowData['failure_date']);
      }

      const row: TelemetryRow = {
        vehicle_id: String(rowData['vehicle_id'] || rowData['vehicleid'] || ''),
        timestamp: timestamp,
        engine_rpm: this.parseNumber(rowData['engine_rpm'] || rowData['enginerpm']),
        vehicle_speed_kph: this.parseNumber(rowData['vehicle_speed_kph'] || rowData['vehiclespeedkph'] || rowData['vehicle_speed']),
        wheel_speed_fl_kph: this.parseNumber(rowData['wheel_speed_fl_kph'] || rowData['wheelspeedflkph'] || rowData['wheel_speed_fl']),
        wheel_speed_fr_kph: this.parseNumber(rowData['wheel_speed_fr_kph'] || rowData['wheelspeedfrkph'] || rowData['wheel_speed_fr']),
        wheel_speed_rl_kph: this.parseNumber(rowData['wheel_speed_rl_kph'] || rowData['wheelspeedrlkph'] || rowData['wheel_speed_rl']),
        wheel_speed_rr_kph: this.parseNumber(rowData['wheel_speed_rr_kph'] || rowData['wheelspeedrrkph'] || rowData['wheel_speed_rr']),
        brake_temp_c: this.parseNumber(rowData['brake_temp_c'] || rowData['braketempc'] || rowData['brake_temp']),
        brake_pedal_pos_percent: this.parseNumber(rowData['brake_pedal_pos_percent'] || rowData['brakepedalpospercent'] || rowData['brake_pedal']),
        abs_fault_indicator: this.parseNumber(rowData['abs_fault_indicator'] || rowData['absfaultindicator'] || rowData['abs_fault']),
        failure_type: String(rowData['failure_type'] || rowData['failuretype'] || '').trim(),
        failure_date: failureDate,
        // Additional metrics
        engine_torque: this.parseNumber(rowData['engine_torque'] || rowData['enginetorque'] || rowData['torque']),
        throttle_position: this.parseNumber(rowData['throttle_position'] || rowData['throttleposition'] || rowData['throttle']),
        coolant_temp: this.parseNumber(rowData['coolant_temp'] || rowData['coolanttemp'] || rowData['coolant_temperature']),
        oil_pressure: this.parseNumber(rowData['oil_pressure'] || rowData['oilpressure']),
        fuel_consumption: this.parseNumber(rowData['fuel_consumption'] || rowData['fuelconsumption'] || rowData['fuel']),
        gear_position: this.parseNumber(rowData['gear_position'] || rowData['gearposition'] || rowData['gear']),
        acceleration: this.parseNumber(rowData['acceleration'] || rowData['accel'])
      };

      return row;
    } catch (error) {
      console.error('Error normalizing row:', error, rowData);
      return null;
    }
  }

  private parseTimestamp(value: any): Date | null {
    if (!value) return null;

    // If it's already a Date
    if (value instanceof Date) {
      return value;
    }

    // If it's a string
    if (typeof value === 'string') {
      // Try parsing as ISO string or common formats
      const parsed = new Date(value);
      if (!isNaN(parsed.getTime())) {
        return parsed;
      }
    }

    // If it's an Excel serial date (number)
    if (typeof value === 'number') {
      // Excel serial dates start from 1900-01-01
      // But Excel incorrectly treats 1900 as a leap year, so we need to adjust
      const excelEpoch = new Date(1899, 11, 30); // December 30, 1899
      const msPerDay = 86400000;
      return new Date(excelEpoch.getTime() + value * msPerDay);
    }

    return null;
  }

  private parseNumber(value: any): number | undefined {
    if (value === null || value === undefined || value === '') {
      return undefined;
    }

    if (typeof value === 'number') {
      return value;
    }

    if (typeof value === 'string') {
      const parsed = parseFloat(value);
      return isNaN(parsed) ? undefined : parsed;
    }

    return undefined;
  }
}
