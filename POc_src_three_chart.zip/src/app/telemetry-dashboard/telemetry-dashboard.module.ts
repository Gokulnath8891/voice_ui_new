import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PlotlyModule } from 'angular-plotly.js';

// PrimeNG Modules
import { DropdownModule } from 'primeng/dropdown';
import { InputNumberModule } from 'primeng/inputnumber';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DividerModule } from 'primeng/divider';
import { TooltipModule } from 'primeng/tooltip';
import { ChipModule } from 'primeng/chip';

import { TelemetryDashboardRoutingModule } from './telemetry-dashboard-routing.module';
import { TelemetryDashboardComponent } from './telemetry-dashboard.component';
import { TelemetryMultiAxisChartComponent } from './telemetry-multi-axis-chart.component';
import { TelemetryExcelService } from './services/telemetry-excel.service';

@NgModule({
  declarations: [
    TelemetryDashboardComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    PlotlyModule,
    TelemetryDashboardRoutingModule,
    // PrimeNG
    DropdownModule,
    InputNumberModule,
    CheckboxModule,
    InputTextModule,
    MessageModule,
    ProgressSpinnerModule,
    ButtonModule,
    CardModule,
    DividerModule,
    TooltipModule,
    ChipModule,
    // Standalone Components
    TelemetryMultiAxisChartComponent
  ],
  providers: [
    TelemetryExcelService
  ]
})
export class TelemetryDashboardModule {}
