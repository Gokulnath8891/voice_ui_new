import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TelemetryDashboardComponent } from './telemetry-dashboard.component';
import { TelemetryMultiAxisChartComponent } from './telemetry-multi-axis-chart.component';

const routes: Routes = [
  {
    path: '',
    component: TelemetryDashboardComponent,
    title: 'Telemetry Dashboard'
  },
  {
    path: 'multi-axis',
    component: TelemetryMultiAxisChartComponent,
    title: 'Multi-Axis Telemetry Chart'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TelemetryDashboardRoutingModule {}
