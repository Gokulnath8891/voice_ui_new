# Reporting Security Issues

The development team takes security seriously, and we follow all recommendations from the [Google/Angular team](https://angular.dev/best-practices/security). If you believe you have found a security issue within this library, please submit a new security vulnerability bug report to this repository.

If this is an urgent issue, or you need clarification, feel free to reach out to us using one of the communication channels outlined in the README.
