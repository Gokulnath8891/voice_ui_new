# Voicebot UI - Angular Application

## Getting Started

To get started with this application, you will need to do the following:

1. Pull down a copy of this project using your preferred method (.zip download, HTTPS/SSH clone). Place it somewhere convenient.
1. Install Node.js v20.x on your computer via your preferred package manager.
1. Configure command-line proxy settings appropriately if required by your network environment.
   1. Locations where environmental variables are often set can include the following:
      1. macOS:
         - Bash`.bashrc`,`.bash_profile`, and /or `.profile`
         - Zsh: `.zshrc` and /or `.profile`
      1. Windows
         - PowerShell: `Profile.ps1`
         - Git Bash: `.bashrc`, `.bash_profile`, and /or `.profile`
1. Open a terminal/command prompt inside of the project.
1. Run `npm install`.
1. Start your local development server with `npm run start-local`
1. Finally, visit <http://localhost:9500> to see your rendered app in the browser

## Theming your Application

This project utilizes [PrimeNG Sass Theme](https://github.com/primefaces/primeng-sass-theme) for UI components.

### A Note on Accessibility

Accessibility is of the utmost importance to us. Developing an accessible application means making it usable to everyone, including those with visual, hearing, motor, and cognitive impairments. We follow Web Content Accessibility Guidelines (WCAG) 2.1 Level AA standards.

## Continuous Integration (CI)

### Tekton

Version 18.x includes support for Tekton pipelines-as-code (PaC) for CI and CD to GCP. You can find the pipeline files in the `.tekton/` directory.

### Jenkins

Additionally, we have support for Jenkins Pipeline for deployment to PCF. Please note that while we still have this available to use, it is effectively deprecated and will not receive further updates.

## Other Libraries and Features

This starter project is designed to be an empty scaffold to help kickstart your development efforts. To that end, it deliberately only includes the minimum set of dependencies required to be effective. There are other libraries, such as Chart.js (dynamic charting), NGXS (reactive-style state management), and some others that can be added as needed.

## Upcoming Releases and Version Support

This version of the application should be considered a snapshot in time view of the larger Angular ecosystem. We strive to keep this template up to date with the latest releases from the Angular team, but keep in mind that we also have cascading dependencies and implications to consider when it comes to our release cadence.

In terms of version support, we track [the support policy and schedule that is published by the Angular team](https://angular.dev/reference/releases#support-policy-and-schedule). We do our best to keep up with the current Active releases mentioned there, but keep in mind that various external factors may cause us to stay on an earlier release beyond Active support and into Long-Term Support (LTS).

## Notes

- For more details on the Angular 18.x release, take a look at the [Angular 18.0 release blog post](https://blog.angular.dev/angular-v18-is-now-available-e79d5ac0affe).
- For more details on other breaking changes that could come up in your application, take a look at the [Angular Update Guide](https://angular.dev/update-guide?v=17.0-18.0&l=2).
