import {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
} from "./chunk-DNNANJOB.js";
import "./chunk-6P4VJP7Y.js";
import "./chunk-2XT472H2.js";
import "./chunk-NDLUEX73.js";
import "./chunk-YDY3RWJH.js";
import "./chunk-UG2HF7V3.js";
import "./chunk-5RX6UB6R.js";
import "./chunk-VO6BACRA.js";
import "./chunk-JGRU35LY.js";
import "./chunk-BUGEQH7Q.js";
import "./chunk-QK66BDO5.js";
import "./chunk-L5KPHALF.js";
import "./chunk-3OF44R55.js";
import "./chunk-5KBFVXBM.js";
import "./chunk-QXTNZ7G7.js";
import "./chunk-OR2P5YVE.js";
import "./chunk-OCWABLU3.js";
import "./chunk-5KXDAEEK.js";
import "./chunk-VMI3K6GE.js";
import "./chunk-WD6C567C.js";
import "./chunk-HM5YLMWO.js";
import "./chunk-3OV72XIM.js";
export {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
};
//# sourceMappingURL=primeng_calendar.js.map
