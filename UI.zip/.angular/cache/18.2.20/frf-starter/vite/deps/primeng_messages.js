import {
  Messages,
  MessagesModule
} from "./chunk-IIKOFS7Q.js";
import "./chunk-UVZVCKF2.js";
import "./chunk-GWRBUG2D.js";
import "./chunk-5RX6UB6R.js";
import "./chunk-VO6BACRA.js";
import "./chunk-4XPV5KIZ.js";
import "./chunk-BUGEQH7Q.js";
import "./chunk-QK66BDO5.js";
import "./chunk-L5KPHALF.js";
import "./chunk-3OF44R55.js";
import "./chunk-5KBFVXBM.js";
import "./chunk-OR2P5YVE.js";
import "./chunk-OCWABLU3.js";
import "./chunk-5KXDAEEK.js";
import "./chunk-VMI3K6GE.js";
import "./chunk-WD6C567C.js";
import "./chunk-HM5YLMWO.js";
import "./chunk-3OV72XIM.js";
export {
  Messages,
  MessagesModule
};
//# sourceMappingURL=primeng_messages.js.map
