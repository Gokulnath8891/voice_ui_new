import {
  InputText,
  InputTextModule
} from "./chunk-CD274NI2.js";
import "./chunk-L5KPHALF.js";
import "./chunk-3OF44R55.js";
import "./chunk-QXTNZ7G7.js";
import "./chunk-OR2P5YVE.js";
import "./chunk-OCWABLU3.js";
import "./chunk-5KXDAEEK.js";
import "./chunk-VMI3K6GE.js";
import "./chunk-WD6C567C.js";
import "./chunk-HM5YLMWO.js";
import "./chunk-3OV72XIM.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
