import { TestBed } from '@angular/core/testing';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthService);
    
    // Clear localStorage and sessionStorage before each test
    localStorage.clear();
    sessionStorage.clear();
  });

  afterEach(() => {
    localStorage.clear();
    sessionStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return false for isLoggedIn when no user is logged in', () => {
    expect(service.isLoggedIn).toBeFalsy();
  });

  it('should login with correct credentials', async () => {
    const result = await service.login('admin', 'password', false);
    expect(result).toBeTruthy();
    expect(service.isLoggedIn).toBeTruthy();
    expect(service.currentUserValue?.username).toBe('admin');
  });

  it('should fail login with incorrect credentials', async () => {
    const result = await service.login('wrong', 'wrong', false);
    expect(result).toBeFalsy();
    expect(service.isLoggedIn).toBeFalsy();
  });

  it('should store token in sessionStorage when rememberMe is false', async () => {
    await service.login('admin', 'password', false);
    expect(sessionStorage.getItem('authToken')).toBeTruthy();
    expect(localStorage.getItem('authToken')).toBeFalsy();
  });

  it('should store token in localStorage when rememberMe is true', async () => {
    await service.login('admin', 'password', true);
    expect(localStorage.getItem('authToken')).toBeTruthy();
    expect(sessionStorage.getItem('authToken')).toBeFalsy();
  });

  it('should logout and clear tokens', async () => {
    await service.login('admin', 'password', true);
    expect(service.isLoggedIn).toBeTruthy();
    
    service.logout();
    expect(service.isLoggedIn).toBeFalsy();
    expect(localStorage.getItem('authToken')).toBeFalsy();
    expect(sessionStorage.getItem('authToken')).toBeFalsy();
  });

  it('should get token from storage', async () => {
    await service.login('admin', 'password', true);
    expect(service.getToken()).toBe('mock-jwt-token');
  });
});
