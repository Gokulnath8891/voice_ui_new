import { HttpClient } from '@angular/common/http';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SidebarModule } from 'primeng/sidebar';
import { ButtonModule } from 'primeng/button';
import { ChipModule } from 'primeng/chip';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AvatarModule } from 'primeng/avatar';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { CardModule } from 'primeng/card';
import { TagModule } from 'primeng/tag';
import { BadgeModule } from 'primeng/badge';
import { PaginatorModule } from 'primeng/paginator';
import { WorkOrderService } from '../services/work-order.service';
import { ChatCommunicationService } from '../services/chat-communication.service';
import { AuthService } from '../services/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'work-order',
  standalone: true,
  imports: [
    FormsModule, 
    SidebarModule, 
    ButtonModule, 
    ChipModule, 
    InputTextareaModule, 
    AvatarModule, 
    CommonModule,
    InputTextModule,
    TableModule,
    CardModule,
    TagModule,
    BadgeModule,
    PaginatorModule
],
  templateUrl: './work-order.component.html',
  styleUrl: './work-order.component.scss'
})
export class WorkOrderComponent implements OnInit, OnDestroy {
  selectedTab: string = 'All';
  selectedPriority: string = 'All';
  
  statusTabs = [
    { label: 'All', value: 'All' },
    { label: 'Pending', value: 'Pending' },
    { label: 'Assigned', value: 'Assigned' },
    { label: 'In Progress', value: 'In Progress' },
    { label: 'Completed', value: 'Completed' }
  ];

  priorityTabs = [
    { label: 'All', value: 'All' },
    { label: 'High', value: 'High' },
    { label: 'Medium', value: 'Medium' },
    { label: 'Low', value: 'Low' }
  ];

  workOrders: any[] = [];
  filteredWorkOrders: any[] = [];
  paginatedWorkOrders: any[] = [];
  isLoading = false;
  errorMessage = '';
  
  // Pagination properties
  currentPage: number = 0;
  itemsPerPage: number = 8;

  // Subscription for voice completion events
  private voiceCompleteSubscription?: Subscription;

  constructor(
    private readonly http: HttpClient,
    private readonly workOrderService: WorkOrderService,
    private readonly chatService: ChatCommunicationService,
    private readonly authService: AuthService
  ) {}

  ngOnInit() {
    this.loadWorkOrders();
    this.subscribeToVoiceCompletion();
  }

  ngOnDestroy() {
    if (this.voiceCompleteSubscription) {
      this.voiceCompleteSubscription.unsubscribe();
    }
  }

  /**
   * Subscribe to voice completion events to mark steps as completed
   */
  private subscribeToVoiceCompletion() {
    this.voiceCompleteSubscription = this.chatService.voiceComplete$.subscribe(() => {
      console.log('[WorkOrder] Voice synthesis completed, checking for step completion...');
      
      // Check if there's a completed step in sessionStorage
      const completedStepStr = sessionStorage.getItem('completed_step');
      if (completedStepStr) {
        const completedStepNumber = parseInt(completedStepStr, 10);
        console.log('[WorkOrder] Marking step as completed:', completedStepNumber);
        
        // Get current work order from sessionStorage
        const currentWorkOrderStr = sessionStorage.getItem('current_work_order');
        if (currentWorkOrderStr) {
          try {
            const currentWorkOrder = JSON.parse(currentWorkOrderStr);
            
            // Find the work order in our list
            const workOrder = this.workOrders.find(wo => wo.id === currentWorkOrder.id);
            if (workOrder && workOrder.steps) {
              // Mark the step as completed
              const step = workOrder.steps.find((s: any) => s.number === completedStepNumber);
              if (step) {
                step.completed = true;
                console.log('[WorkOrder] Step marked as completed in UI:', step);
                
                // Trigger change detection by updating the filtered and paginated lists
                this.applyFilters();
              }
            }
          } catch (error) {
            console.error('[WorkOrder] Error parsing current_work_order:', error);
          }
        }
        
        // Clear the completed step from sessionStorage
        sessionStorage.removeItem('completed_step');
      }
      
      // Check if work order is complete
      const workOrderComplete = sessionStorage.getItem('work_order_complete');
      if (workOrderComplete === 'true') {
        console.log('[WorkOrder] Work order is complete!');
        // TODO: Show completion message or update UI
        sessionStorage.removeItem('work_order_complete');
      }
    });
  }

  async loadWorkOrders() {
    this.isLoading = true;
    this.errorMessage = '';
    
    try {
      this.workOrders = await this.workOrderService.getAllWorkOrders();
      this.filteredWorkOrders = [...this.workOrders];
      this.updatePaginatedWorkOrders();
    } catch (error) {
      console.error('Error loading work orders:', error);
      this.errorMessage = 'Failed to load work orders. Please try again.';
      // Fallback to mock data if API fails
      this.loadMockData();
    } finally {
      this.isLoading = false;
    }
  }

  loadMockData() {
    this.workOrders = [
      { 
        id: 'WO-20241008', 
        title: 'Suspension Repair - Front Struts',
        description: 'Replace front struts and strut mounts. Customer reports clunking noise over bumps and uneven tire wear.',
        status: 'Pending',
        priority: 'High',
        assignee: 'Amanda Harris',
        vehicle: '2021 Nissan Altima',
        estimatedHours: 2.5,
        dueDate: '10/29/2025',
        steps: [
          { number: 1, completed: false },
          { number: 2, completed: false },
          { number: 3, completed: false },
          { number: 4, completed: false },
          { number: 5, completed: false },
          { number: 6, completed: false }
        ]
      },
      { 
        id: 'WO-20241005', 
        title: 'Tesla Software Update and Diagnostics',
        description: 'Perform software update for Tesla Model 3. Run full diagnostic check on battery and electric motor systems. Customer reported range anxiety.',
        status: 'Assigned',
        priority: 'Low',
        assignee: 'William Taylor',
        vehicle: '2022 Tesla Model 3',
        estimatedHours: 2.5,
        dueDate: '10/29/2025',
        steps: [
          { number: 1, completed: true },
          { number: 2, completed: false },
          { number: 3, completed: false },
          { number: 4, completed: false },
          { number: 5, completed: false },
          { number: 6, completed: false }
        ]
      },
      { 
        id: 'WO-20241002', 
        title: 'Brake Pad Replacement - Front',
        description: 'Replace front brake pads and resurface rotors. Customer reported squeaking noise when braking.',
        status: 'Assigned',
        priority: 'Medium',
        assignee: 'Emily Thompson',
        vehicle: '2019 Honda Accord',
        estimatedHours: 2.5,
        dueDate: '10/29/2025',
        steps: [
          { number: 1, completed: true },
          { number: 2, completed: true },
          { number: 3, completed: true },
          { number: 4, completed: false }
        ]
      },
      { 
        id: 'WO-20240998', 
        title: 'Engine Oil Change Service',
        description: 'Standard oil change service with filter replacement. Inspect all fluid levels and tire pressure.',
        status: 'In Progress',
        priority: 'Low',
        assignee: 'Michael Chen',
        vehicle: '2020 Toyota Camry',
        estimatedHours: 1,
        dueDate: '10/28/2025',
        steps: [
          { number: 1, completed: true },
          { number: 2, completed: true },
          { number: 3, completed: false }
        ]
      },
      { 
        id: 'WO-20240995', 
        title: 'Transmission Fluid Exchange',
        description: 'Complete transmission fluid exchange. Customer reports shifting issues and transmission slipping.',
        status: 'In Progress',
        priority: 'High',
        assignee: 'Sarah Rodriguez',
        vehicle: '2018 Ford F-150',
        estimatedHours: 3,
        dueDate: '10/30/2025',
        steps: [
          { number: 1, completed: true },
          { number: 2, completed: true },
          { number: 3, completed: true },
          { number: 4, completed: true },
          { number: 5, completed: false }
        ]
      },
      { 
        id: 'WO-20240990', 
        title: 'Air Conditioning System Repair',
        description: 'Diagnose and repair A/C system. Customer reports weak cooling and strange odor from vents.',
        status: 'Completed',
        priority: 'Medium',
        assignee: 'James Wilson',
        vehicle: '2021 Chevrolet Malibu',
        estimatedHours: 4,
        dueDate: '10/27/2025',
        steps: [
          { number: 1, completed: true },
          { number: 2, completed: true },
          { number: 3, completed: true },
          { number: 4, completed: true }
        ]
      }
    ];

    this.filteredWorkOrders = [...this.workOrders];
    this.updatePaginatedWorkOrders();
  }

  filterByStatus(status: string) {
    this.selectedTab = status;
    this.currentPage = 0;
    this.applyFilters();
  }

  filterByPriority(priority: string) {
    this.selectedPriority = priority;
    this.currentPage = 0;
    this.applyFilters();
  }

  applyFilters() {
    let filtered = [...this.workOrders];

    // Apply status filter
    if (this.selectedTab !== 'All') {
      filtered = filtered.filter(order => order.status === this.selectedTab);
    }

    // Apply priority filter
    if (this.selectedPriority !== 'All') {
      filtered = filtered.filter(order => order.priority === this.selectedPriority);
    }

    this.filteredWorkOrders = filtered;
    this.updatePaginatedWorkOrders();
  }

  getPriorityFilterSeverity(priority: string): 'danger' | 'warning' | 'success' | 'primary' | 'secondary' {
    if (this.selectedPriority === priority) {
      switch (priority.toLowerCase()) {
        case 'high':
          return 'danger';
        case 'medium':
          return 'warning';
        case 'low':
          return 'success';
        default:
          return 'primary';
      }
    }
    return 'secondary';
  }

  onPageChange(event: any) {
    this.currentPage = event.page;
    this.itemsPerPage = event.rows;
    this.updatePaginatedWorkOrders();
  }

  updatePaginatedWorkOrders() {
    const startIndex = this.currentPage * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedWorkOrders = this.filteredWorkOrders.slice(startIndex, endIndex);
  }

  getPriorityBadgeSeverity(priority: string): 'danger' | 'warning' | 'success' | 'info' {
    switch (priority.toLowerCase()) {
      case 'high':
        return 'danger';
      case 'medium':
        return 'warning';
      case 'low':
        return 'success';
      default:
        return 'info';
    }
  }

  async startWork(order: any) {
    try {
      console.log('Starting work on:', order);
      
      // Get current user ID (you may need to get this from AuthService)
      const userId = 1; // TODO: Get from AuthService or stored user data
      
      // Call the API to start work
      const response = await this.workOrderService.startWork(order.id, userId);
      
      if (response.type === 'error') {
        console.error('Error starting work:', response.message);
        alert(`Error: ${response.message}`);
        return;
      }
      
      if (response.type === 'work_order_start') {
        console.log('Work order started successfully:', response);
        
        // Format the message to display in chat
        // Extract only "Starting work order WO-XXXXXX" part (without Step information)
        let chatMessage = '';
        
        if (response.message) {
          // Find the work order number pattern (WO-XXXXXX) and trim everything after it
          const woMatch = response.message.match(/(Starting work order\s+WO-\d+)/i);
          if (woMatch) {
            chatMessage = woMatch[1] + '.';
          } else {
            chatMessage = `Starting work order ${order.id}.`;
          }
        } else {
          chatMessage = `Starting work order ${order.id}.`;
        }
        
        // Add the tts_text which contains the current step information
        if (response.tts_text) {
          chatMessage += `\n\n${response.tts_text}`;
        }
        
        // Add estimated time from current_step
        if (response.current_step?.estimated_time) {
          chatMessage += `\n\nEstimated time: ${response.current_step.estimated_time} hours`;
        }
        
        // Send message to chat widget (will auto-open and play voice)
        this.chatService.sendMessage(chatMessage, true, true);
        
        // Update the work order status in the list
        const workOrder = this.workOrders.find(wo => wo.id === order.id);
        if (workOrder && response.work_order) {
          workOrder.status = this.normalizeStatus(response.work_order.status);
          this.applyFilters();
        }
        
        console.log('Session ID stored:', response.session_id);
      }
    } catch (error) {
      console.error('Failed to start work:', error);
      alert('Failed to start work order. Please try again.');
    }
  }
  
  private normalizeStatus(status: string): string {
    const statusMap: { [key: string]: string } = {
      'PENDING': 'Pending',
      'ASSIGNED': 'Assigned',
      'IN_PROGRESS': 'In Progress',
      'COMPLETED': 'Completed',
      'ON_HOLD': 'On Hold'
    };
    return statusMap[status] || status;
  }
}

